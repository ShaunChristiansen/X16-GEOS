; Commander X16 hardware and GEOS-X16 memory layout
;
; GEOS runs with the C64 memory map. On the X16:
;   $00      RAM bank register  ($A000-$BFFF window). GEOS writes $2F to
;            the C64 CPU_DDR at boot, so GEOS's own $A000-$BFFF (screen
;            bitmap + icons) lives in RAM bank $2F.
;   $01      ROM bank register  ($C000-$FFFF window). GEOS writes C64
;            CPU_DATA values ($30/$35/$36/$37) here; cartridge RAM banks
;            48-55 ($30-$37) each hold a copy of the GEOS kernel, with
;            $D000-$DFFF replaced by a C64 I/O register shadow in the
;            banks where the C64 would see I/O ($35-$37).
;   $9F00-$9FFF  X16 I/O (VIA1, VIA2, VERA, YM2151)

.ifndef x16_inc
x16_inc = 1

; --- banks -----------------------------------------------------------
X16_BANK_GEOSRAM  = $2F         ; RAM bank with GEOS $A000-$BFFF
X16_BANK_DBUF     = 2           ; RAM bank: disk block buffer ($A000) and
                                ; each drive's last block ($A100 + drive * $100)
X16_BANK_CACHE    = 3           ; RAM banks 3..: disk cache, one track per
X16_CACHE_SLOTS   = 12          ; bank (sdio.s)
X16_BANK_KSAVE    = $2E         ; RAM bank: X16 KERNAL zp/$0200 snapshot
X16_RAWQ          = $A600       ; in bank KSAVE: raw key event queue (256 bytes)
X16_BANK_CART     = 32          ; cartridge boot bank
X16_BANK_HELPER   = 33          ; cartridge bank with screen copy code
H_SDREAD          = $C012       ; helper bank: disk block read (sdio.s)
H_SDWRITE         = $C015       ;              disk block write
H_CHDEV           = $C018       ;              ChangeDiskDevice
H_RAMOP           = $C01B       ;              DoRAMOp (RAM expansion)
H_SETNEXTFREE     = $C01E       ;              disk driver BAM routines
H_ALLOCATEBLOCK   = $C021       ;              (bam.s)
H_FINDBAMBIT      = $C024
H_FREEBLOCK       = $C027
H_CALCBLKSFREE    = $C02A
H_MOUNT           = $C02D       ;              SD CARD: an image in a drive
H_GETNAME         = $C030       ;              its name
X16_BANK_REU      = 15          ; RAM banks 15..: GEOS's RAM expansion
X16_REU_SIZE      = 1           ; its size in 64K banks (8 RAM banks each)
X16_BANK_C64BAS   = 23          ; RAM bank: the C64's BASIC ROM (BASIC.BIN),
                                ; for geoCalc's maths (x16io.s: X16_C64On)
X16_BANK_PRN      = 25          ; RAM bank: printer code and buffer (prn.s)
PRN_ENTRY         = $A000       ;   the C64 KERNAL calls (c64kernal.s)
PRN_KJOB          = $A003       ;   run with the X16 KERNAL in (X16_KRun)
PRN_BOOTWALL      = $A006       ;   the boot's wallpaper (boot.s, X16 KERNAL in)
X16_BANK_NET      = 26          ; RAM bank: the Calypso card's NET.BIN ($A000)
NET_CODE          = $B000       ;   and calypso.s (serial.s: CalGo)
X16_BANK_C64TMP   = 24          ; RAM bank: KERNAL.BIN while booting
X16_BANK_C64VIEW  = 56          ; cartridge bank: the C64's $C000-$FFFF with
                                ; $01 = $37: GEOS's $C000-$DFFF, then the C64
                                ; KERNAL ROM (KERNAL.BIN)
X16_BANK_RAMVIEW  = $30         ; kernel, RAM at $D000 (C64 $01=$30)
X16_BANK_IOVIEW   = $35         ; kernel, I/O shadow at $D000 (C64 $01=$35)
X16_NUM_MIRRORS   = 8           ; banks $30..$37

; --- VIA1 (I2C on port A) --------------------------------------------
VIA1_PRB   = $9F00
VIA1_PRA   = $9F01
VIA1_DDRB  = $9F02
VIA1_DDRA  = $9F03
VIA1_IFR   = $9F0D
VIA1_IER   = $9F0E
VIA2_IFR   = $9F1D
VIA2_IER   = $9F1E
I2C_SDA    = 1
I2C_SCL    = 2
SMC_I2C    = $42
RTC_I2C    = $6F

; --- VERA -------------------------------------------------------------
VERA_ADDR_L   = $9F20
VERA_ADDR_M   = $9F21
VERA_ADDR_H   = $9F22
VERA_DATA0    = $9F23
VERA_DATA1    = $9F24
VERA_CTRL     = $9F25
VERA_IEN      = $9F26
VERA_ISR      = $9F27
VERA_IRQLINE  = $9F28
VERA_DC_VIDEO = $9F29           ; DCSEL=0
VERA_DC_HSCALE= $9F2A
VERA_DC_VSCALE= $9F2B
VERA_DC_BORDER= $9F2C
VERA_DC_HSTART= $9F29           ; DCSEL=1
VERA_DC_HSTOP = $9F2A
VERA_DC_VSTART= $9F2B
VERA_DC_VSTOP = $9F2C
VERA_L0_CONFIG   = $9F2D
VERA_L0_MAPBASE  = $9F2E
VERA_L0_TILEBASE = $9F2F
VERA_L0_HSCROLL_L= $9F30
VERA_L0_HSCROLL_H= $9F31
VERA_L1_CONFIG   = $9F34

VERA_INC_1    = $10
VERA_INC_40   = $B0             ; increment index 11 = 40 bytes

VERA_L1_MAPBASE  = $9F35
VERA_L1_TILEBASE = $9F36

; VRAM layout: the screen is two tile layers (see helper.s)
VRAM_TILES1   = $00000          ; layer 1: 2bpp tile n = card n (16 bytes)
VRAM_MAP1     = $04000          ; layer 1 map, 64x32 entries
VRAM_MAP0     = $05000          ; layer 0 map, 64x32 entries
VRAM_TILES0   = $06000          ; layer 0: 8bpp tiles 0-999 = wallpaper
VRAM_WALLPAL  = $15A00          ;   (the wallpaper: tiles, then 256 colours)
VRAM_SOLID    = VRAM_TILES0 + 1023 * 64  ; layer 0 tile 1023: all value 1
VRAM_SPRDATA  = $16000          ; 8 sprites, up to 64x64 4bpp, $800 apart
VRAM_PALETTE  = $1FA00
VRAM_SPRATTR  = $1FC00

; --- X16 KERNAL ------------------------------------------------------
K_LISTEN      = $FFB1
K_SECOND      = $FF93
K_CIOUT       = $FFA8
K_UNLSN       = $FFAE
K_SETLFS      = $FFBA
K_SETNAM      = $FFBD
K_OPEN        = $FFC0
K_CLOSE       = $FFC3
K_CHKIN       = $FFC6
K_CHKOUT      = $FFC9
K_CLRCHN      = $FFCC
K_CHRIN       = $FFCF
K_CHROUT      = $FFD2
K_LOAD        = $FFD5
K_READST      = $FFB7
K_ACPTR       = $FFA5
K_MACPTR      = $FF44
K_CLALL       = $FFE7
K_MCIOUT      = $FEB1
K_I2C_READ    = $FEC6
K_I2C_WRITE   = $FEC9
K_CLOCK_GET   = $FF50
K_MOUSE_CONFIG= $FF68

.endif
