; GEOS-X16: calls for GEOS programs (ca65).  A program checks for "X16G" at
; X16_SIG (and the version at X16_VER) first: on a C64 those bytes are the
; C64 KERNAL's.  Then: lda #call, jsr X16_CALL.
;
; Call 9 runs an X16 KERNAL routine, so a GEOS program can use the X16's
; SD card (or anything else in the X16 KERNAL) while GEOS draws its screen:
;     X16K X16K_SETNAM          ; A, X, Y as for that routine
; (X16K_CODE, once in the program, has the 5-byte block and a helper).
; The routine starts with C = 0 (MACPTR and MCIOUT then step through
; memory).  Back: the routine's A, X, Y and C.  GEOS-X16 swaps GEOS out and the X16
; KERNAL in around each call (interrupts off), so r0-r15 ($02-$21) reach it
; as they are.  Rules: names and buffers below $A000; files 10-14 (GEOS-X16
; keeps 2-6 and 15 open); a CHKIN/CHKOUT is undone by GEOS-X16's own disk
; access, so CLRCHN before giving GEOS the control back.

X16_SIG   = $FF78               ; "X16G"
X16_VER   = $FF7C               ; 2 or more: call 9 is there; 3: 10 and 11
X16_CALL  = $FF7D

X16C_SETWALL = 0                ; r0 = a wallpaper's name (0: none); C = 1 failed
X16C_GETWALL = 1                ; its name -> (r0)
X16C_SOPEN   = 2                ; the serial port: open, X = a baud code
X16C_SCLOSE  = 3
X16C_SPUT    = 4                ; X = the byte
X16C_SGET    = 5                ; C = 0 and A = a byte, or C = 1
X16C_SCARR   = 6                ; A = $10: carrier
X16C_KERNAL  = 9                ; X/Y = a block: .word routine, .byte a, x, y
X16C_MOUNT   = 10               ; version 3: drive X (8-10) gets the disk image
                                ; r0 names (same type, D81/D64); C = 1, A = 1 no
                                ; drive or bad name, 2 not an image, 3 the other
                                ; type, 4 failed (the drive is empty now)
X16C_DRVNAME = 11               ; drive X's image file name -> (r0) ("": none)

; X16 KERNAL routines (any routine in the X16 KERNAL ROM can be called)
X16K_READST  = $FFB7
X16K_SETLFS  = $FFBA
X16K_SETNAM  = $FFBD
X16K_OPEN    = $FFC0
X16K_CLOSE   = $FFC3
X16K_CHKIN   = $FFC6
X16K_CHKOUT  = $FFC9
X16K_CLRCHN  = $FFCC
X16K_CHRIN   = $FFCF
X16K_CHROUT  = $FFD2
X16K_LOAD    = $FFD5
X16K_SAVE    = $FFD8
X16K_MACPTR  = $FF44            ; block read: A = count, X/Y = buffer
X16K_MCIOUT  = $FEB1            ; block write

.macro X16K routine
	pha
	lda #<(routine)
	sta x16kblk
	lda #>(routine)
	sta x16kblk+1
	pla
	jsr x16k_go
.endmacro

; once in the program (in RAM: the block is written): the block and the
; helper the macro calls
.macro X16K_CODE
x16kblk: .res 5
x16k_go:
	sta x16kblk+2
	stx x16kblk+3
	sty x16kblk+4
	ldx #<x16kblk
	ldy #>x16kblk
	lda #X16C_KERNAL
	jmp X16_CALL
.endmacro
