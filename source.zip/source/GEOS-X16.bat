@echo off
rem GEOS 2.0 for the Commander X16, in x16emu R49
rem
rem This folder holds geosx16.bin, GEOSDISK.D64 or .D81 (drive A) and, optionally,
rem GEOSDSK2.D64 (drive B).  x16emu.exe (with its rom.bin) is looked for in
rem this folder and the one above it; or set X16EMU to its full path.
setlocal
cd /d "%~dp0"
if not defined X16EMU if exist "%~dp0x16emu.exe" set "X16EMU=%~dp0x16emu.exe"
if not defined X16EMU if exist "%~dp0..\x16emu.exe" set "X16EMU=%~dp0..\x16emu.exe"
if not defined X16EMU (
  echo Cannot find x16emu.exe. Put this folder next to x16emu.exe, inside
  echo the x16emu folder, or set X16EMU in this file.
  pause
  exit /b 1
)
if not exist GEOSDISK.D64 if not exist GEOSDISK.D81 (
  echo GEOSDISK.D64 or GEOSDISK.D81 is missing: put a GEOS 2.0 disk image
  echo with DESK TOP in this folder under one of those names.
  pause
  exit /b 1
)
rem Ctrl+M in the emulator window releases (and recaptures) the mouse.
"%X16EMU%" -cartbin geosx16.bin -rtc -scale 2 -capture %*
