#!/bin/sh
# GEOS-X16: deskTop "options > BASIC" goes straight to X16 BASIC (no
# question), handed over without a reset; X16 BASIC must really run there
# (COLOR 1,2:CLS turns the screen red: a crash into the monitor, also blue,
# would not).
set -e
cd "$(dirname "$0")"
HERE=$(pwd)
X16EMU=${X16EMU:-/home/claude/ext/x16-emulator/x16emu}
X16ROM=${X16ROM:-/home/claude/ext/x16-rom/build/x16/rom.bin}
DISK=${DISK:-../disks/WORK.D64}
T=$HERE/build/test
export DISPLAY=${DISPLAY:-:99}
pgrep -x Xvfb >/dev/null || { Xvfb $DISPLAY -screen 0 1024x768x24 >/dev/null 2>&1 & sleep 1; }
. tools/x16ui.sh
mkdir -p $T/keep; rm -f $T/*.D64 $T/*.BIN $T/*.bin
cp geosx16.bin $T/; cp $DISK $T/GEOSDISK.D64
start
shot b1_geos
python3 tools/x16basic.py $T/b1_geos.png >/dev/null 2>&1 && fail "GEOS did not start"
goto 180 7; click; sleep 1; goto 175 47; click; sleep 4; shot b2_basic
python3 tools/x16basic.py $T/b2_basic.png || fail "options > BASIC did not get to X16 BASIC"
basic_alive b3_alive || fail "X16 BASIC is not running"
cp $T/b*.png $T/keep/
pkill -x "$(basename "$X16EMU")" || true
echo PASS
