#!/bin/sh
# The WALLPAPER program in x16emu (Linux, needs Xvfb, xdotool, ImageMagick
# "import", python3, ca65/ld65):
#   WALLPAPER is put on a copy of drive A (tools/mkwallapp.py), with
#   GEOSWALL.BMX and the GeosWallpapers folder next to it.  It chooses
#   Space (GEOSWALL.CFG must name it, and it must still be there after a
#   new boot), then no wallpaper ("NONE"), then a wallpaper whose folder is
#   missing (an error box; still none), then Aurora, then your own
#   GEOSWALL.BMX.  The deskTop's screenshots go to build/test_wall/.
#   X16EMU=path/to/x16emu X16ROM=path/to/rom.bin ./test_x16_wallpaper.sh
set -e
cd "$(dirname "$0")"
HERE=$(pwd)
X16EMU=${X16EMU:-/home/claude/ext/x16-emulator/x16emu}
X16ROM=${X16ROM:-/home/claude/ext/x16-rom/build/x16/rom.bin}
DISK=${DISK:-../disks/WORK.D64}
command -v ca65 >/dev/null 2>&1 || PATH=/home/claude/ext/cc65/bin:$PATH
T=$HERE/build/test_wall
rm -rf $T; mkdir -p $T
cp geosx16.bin $T/
cp $DISK $T/GEOSDISK.D64
cp -r GeosWallpapers $T/
[ -f GEOSWALL.BMX ] && cp GEOSWALL.BMX $T/ || python3 tools/mkwall.py --default $T/GEOSWALL.BMX >/dev/null
python3 tools/mkwallapp.py $T/GEOSDISK.D64 >/dev/null
export DISPLAY=${DISPLAY:-:99}
pgrep -x Xvfb >/dev/null || { Xvfb $DISPLAY -screen 0 1024x768x24 >/dev/null 2>&1 & sleep 1; }

. tools/x16ui.sh
cfg() { tr -d '\r' < $T/GEOSWALL.CFG; }
# WALLPAPER (the 8th file: row 2, column 4), then menu item $1 (0-7)
pick() { goto 220 97; dclick; sleep 4; shot menu_$1; goto 60 $(( 58 + $1 * 14 )); click; sleep 5; }

echo "boot: GEOSWALL.BMX, no GEOSWALL.CFG"
start
shot 1_default
echo "Space"
pick 2; shot 2_space
[ "$(cfg)" = "/GeosWallpapers/:SPACE.BMX" ] || fail "GEOSWALL.CFG: $(cfg)"
echo "a new boot keeps it"
start
shot 3_space_again
echo "no wallpaper"
pick 6; shot 4_none
[ "$(cfg)" = "NONE" ] || fail "GEOSWALL.CFG: $(cfg)"
echo "a missing folder: an error box"
mv $T/GeosWallpapers $T/away
pick 1; shot 5_error
goto 95 111; click; sleep 5; shot 6_after_error
mv $T/away $T/GeosWallpapers
[ "$(cfg)" = "NONE" ] || fail "GEOSWALL.CFG: $(cfg)"
echo "Aurora"
pick 5; shot 7_aurora
[ "$(cfg)" = "/GeosWallpapers/:AURORA.BMX" ] || fail "GEOSWALL.CFG: $(cfg)"
echo "your own GEOSWALL.BMX"
pick 0; shot 8_own
[ "$(cfg)" = "GEOSWALL.BMX" ] || fail "GEOSWALL.CFG: $(cfg)"
pkill -x "$(basename "$X16EMU")" || true
echo "PASS (screenshots in $T)"
