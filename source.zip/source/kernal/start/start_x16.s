; GEOS KERNAL by Berkeley Softworks
; reverse engineered by Maciej Witkowiak, Michael Steil
; Commander X16 start code, adapted from start64.s
;
; Runs once, from low RAM at $5000, after the cartridge boot code has set
; up the X16 (VERA, disk image in RAM banks, mirror banks, low-RAM parts of
; GEOS).  It is entered with CPU_DATA = $30 (ROM bank $30 = kernel, RAM
; view) and CPU_DDR = $2F (RAM bank $2F = GEOS $A000-$BFFF).

.include "const.inc"
.include "geossym.inc"
.include "geosmac.inc"
.include "config.inc"
.include "kernal.inc"
.include "inputdrv.inc"
.include "c64.inc"
.include "x16.inc"

.import InitGEOEnv
.import _DoFirstInitIO
.import _EnterDeskTop

.import LdApplic
.import GetBlock
.import EnterDeskTop
.import GetDirHead
.import FirstInit
.import i_FillRam

.import x16_rtc, x16_drv2, x16_dopen, x16_itype
.import X16_Poke

.global _ResetHandle

.segment "start"

_ResetHandle:
	sei
	cld
	ldx #$FF
	txs

	lda #IO_IN
	sta CPU_DATA

	; NMI/IRQ vectors are part of every mirror bank image.

	; draw background pattern
	LoadW r0, SCREEN_BASE
	ldx #$7D
@2:	ldy #$3F
@3:	lda #$55
	sta (r0),y
	dey
	lda #$AA
	sta (r0),y
	dey
	bpl @3
	lda #$40
	clc
	adc r0L
	sta r0L
	bcc @4
	inc r0H
@4:	dex
	bne @2

	; set clock in CIA1 TOD from the X16 real time clock
	lda cia1base+15
	and #$7F
	sta cia1base+15 ; prepare for setting time
	lda x16_rtc+3   ; hours 0-23
	ldx #0
	cmp #12
	bcc @5
	ldx #$80        ; PM
	sbc #12
@5:	cmp #0
	bne @6
	lda #12         ; 0 -> 12 (AM or PM)
@6:	jsr BinToBCD
	stx r0L
	ora r0L
	sta cia1base+11 ; hour BCD + PM flag
	lda x16_rtc+4
	jsr BinToBCD
	sta cia1base+10 ; minutes
	lda x16_rtc+5
	jsr BinToBCD
	sta cia1base+9  ; seconds
	lda #0
	sta cia1base+8  ; 10ths: starts the clock

	lda #RAM_64K
	sta CPU_DATA

	jsr i_FillRam
	.word $0500
	.word dirEntryBuf
	.byte 0

	; set date from the X16 real time clock: GEOS stores the year
	; modulo 100 (2000 is 0)
	lda x16_rtc+0   ; year - 1900
@7:	cmp #100
	bcc @8
	sbc #100
	bcs @7
@8:	sta year
	lda x16_rtc+1
	sta month
	lda x16_rtc+2
	sta day

	jsr FirstInit
	jsr MouseInit

	lda #currentInterleave
	sta interleave
	lda #1
	sta NUMDRV
	ldy #8          ; GEOSDISK is drive 8 (A:)
	sty curDrive
	sty curDevice
	lda x16_itype   ; a 1541 (D64) or a 1581 (D81) to applications
	sta curType
	sta _driveType,y
	bit x16_drv2    ; GEOSDSK2 there: drive 9 (B:)
	bpl @nob
	lda x16_itype+1
	sta _driveType+9
	inc NUMDRV
@nob:	lda x16_dopen   ; GEOSDSK3 there: drive 10 (C:)
	and #$20
	beq @noc
	lda x16_itype+2
	sta _driveType+10
	inc NUMDRV
@noc:
	; a RAM expansion (X16 banked RAM, reu.s), with the disk drivers "in
	; it": GEOS 2.0's deskTop wants both for drive C.  The one driver here
	; serves every drive, so SetDevice has none to fetch
	lda #X16_REU_SIZE
	sta ramExpSize
	lda sysRAMFlg
	ora #%01000000
	sta sysRAMFlg

OrigResetHandle:
	sei
	cld
	ldx #$ff
	jsr _DoFirstInitIO
	jsr InitGEOEnv
	jsr GetDirHead
	lda bootTr              ; the first time: the directory's first block,
	bne @b0                 ; 18/1 - or 40/3 when drive A is a D81 (a 1581)
	ldx #DIR_TRACK
	ldy #1
	lda curType
	and #%00001111
	cmp #DRV_1581
	bcc @a0
	ldx #DIR_1581_TRACK
	ldy #3
@a0:	stx bootTr
	sty bootSec
@b0:	MoveB bootSec, r1H
	MoveB bootTr, r1L
	AddVB 32, bootOffs
	bne @3
@1:	MoveB bootSec2, r1H
	MoveB bootTr2, r1L
	bne @3
	lda NUMDRV
	bne @2
	inc NUMDRV
@2:	lda #<_EnterDeskTop
	ldy #>_EnterDeskTop
	jsr SetEnterDeskTop
	jmp EnterDeskTop

@3:	MoveB r1H, bootSec
	MoveB r1L, bootTr
	LoadW r4, diskBlkBuf
	jsr GetBlock
	bnex @2
	MoveB diskBlkBuf+1, bootSec2
	MoveB diskBlkBuf, bootTr2
@4:	ldy bootOffs
	lda diskBlkBuf+2,y
	beq @5
	lda diskBlkBuf+$18,y
	cmp #AUTO_EXEC
	beq @6
@5:	AddVB 32, bootOffs
	bne @4
	beq @1
@6:	ldx #0
@7:	lda diskBlkBuf+2,y
	sta dirEntryBuf,x
	iny
	inx
	cpx #30
	bne @7
	LoadW r9, dirEntryBuf
	lda #<_ResetHandle
	ldy #>_ResetHandle
	jsr SetEnterDeskTop
	LoadB r0L, 0
	jsr LdApplic
bootTr:
	.byte 0                 ; (0: not set yet)
bootSec:
	.byte 1
bootTr2:
	.byte 0
bootSec2:
	.byte 0
bootOffs:
	.byte 0

; the EnterDeskTop jump table entry is kernel RAM: patch it in every
; mirror bank.  A/Y = target
SetEnterDeskTop:
	pha
	tya
	ldx #<(EnterDeskTop+2)
	ldy #>(EnterDeskTop+2)
	jsr X16_Poke
	pla
	ldx #<(EnterDeskTop+1)
	ldy #>(EnterDeskTop+1)
	jmp X16_Poke

; A = 0..99 -> BCD
BinToBCD:
	ldy #0
@1:	cmp #10
	bcc @2
	sbc #10
	iny
	bne @1
@2:	sta r0H
	tya
	asl
	asl
	asl
	asl
	ora r0H
	rts
