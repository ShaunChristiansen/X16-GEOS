; GEOS for the Commander X16: another disk image in a drive, while GEOS
; runs (GEOS-X16 call 10: SD CARD's "Put it in a drive").  The X16 KERNAL part, in RAM
; bank X16_BANK_NET above calypso.s (prn.s's Mount job calls it through
; serial.s's CalGo: X16 KERNAL in, interrupts off).  sdio.s's H_Mount does
; the rest (the last-block copy, the bits, the cache, the name).
;
; The image: the file r0 names (in the program's memory), ".D81" or ".D64",
; the same type as the drive's image now (the drive type stays).  Checked
; first on file 9 (opened, its header block's DOS version, its last block
; read to $BD00 here), so a bad one leaves the drive as it was; then the old
; image's file closes and the new one opens on its channel (2 + image),
; read and write, or read-only.
; In: c_x = the image (0-2).  Out: C = 0 and A = 0 (read and write) or $80
; (read-only), or C = 1 and A = 1 (no such drive, or a bad name), 2 (not
; there, or not a disk image), 3 (not the drive's type), 4 (it would not
; open again: the drive is empty now)

.include "x16.inc"
.include "const.inc"

.setcpu "65SC02"

.import c_x, x16_dopen, x16_itype
.global MountJob

r0      = $02
NAME    = $0200                 ; (the X16 KERNAL's: in now)
BLK     = $BD00
LFN_T   = 9

.segment "netram"

MountJob:
	ldx c_x
	stx m_img
	lda m_bits,x            ; a drive with an image
	and x16_dopen
	beq @e1
	ldy #0                  ; the name
@n:	lda (r0),y
	beq @ne
	sta NAME,y
	iny
	cpy #56
	bne @n
@e1:	lda #1
	sec
	rts
@ne:	sty m_len
	cpy #5
	bcc @e1
	ldx #0                  ; ".D81" or ".D64"
	lda NAME-1,y
	cmp #'1'
	bne :+
	lda NAME-2,y
	cmp #'8'
	bne @e2n
	inx
	bra @t
:	cmp #'4'
	bne @e2n
	lda NAME-2,y
	cmp #'6'
	beq @t
@e2n:	lda #2
	sec
	rts
@t:	stx m_t
	ldy m_img               ; the drive's type
	lda x16_itype,y
	cmp m_type,x
	beq :+
	lda #3
	sec
	rts
:	lda #'R'                ; there, and a disk image?
	jsr Suffix
	lda #LFN_T
	jsr OpenL
	jsr Status
	cmp #'0'
	bne @bad
	ldx m_t
	lda m_hdl,x
	ldy m_hdh,x
	jsr ReadB
	ldx m_t
	lda BLK+2
	cmp m_dos,x
	bne @bad
	lda m_lstl,x            ; its last block -> BLK
	ldy m_lsth,x
	jsr ReadB
	lda #LFN_T
	jsr K_CLOSE
	lda m_img               ; the old one out, the new one in
	clc
	adc #2
	sta m_ch
	jsr K_CLOSE
	lda #'M'
	jsr Suffix
	lda m_ch
	jsr OpenL
	jsr Status
	cmp #'0'
	bne :+
	lda #0                  ; read and write
	clc
	rts
:	lda m_ch
	jsr K_CLOSE
	lda #'R'
	jsr Suffix
	lda m_ch
	jsr OpenL
	jsr Status
	cmp #'0'
	bne :+
	lda #$80                ; read-only
	clc
	rts
:	lda m_ch
	jsr K_CLOSE
	ldx m_img
	lda m_bits,x
	trb x16_dopen
	lda #4
	sec
	rts
@bad:	lda #LFN_T
	jsr K_CLOSE
@e2:	lda #2
	sec
	rts

; NAME + ",S," + A
Suffix:
	ldy m_len
	pha
	lda #','
	sta NAME,y
	lda #'S'
	sta NAME+1,y
	lda #','
	sta NAME+2,y
	pla
	sta NAME+3,y
	rts

; OPEN A,8,A,NAME (with the suffix)
OpenL:
	sta m_lfn
	lda m_len
	clc
	adc #4
	ldx #<NAME
	ldy #>NAME
	jsr K_SETNAM
	lda m_lfn
	ldx #8
	ldy m_lfn
	jsr K_SETLFS
	jmp K_OPEN

; A = the first character of the drive's status (channel 15)
Status:
	ldx #15
	jsr K_CHKIN
	jsr K_ACPTR
	sta m_st
	ldy #40
@l:	phy
	jsr K_READST
	ply
	and #$40
	bne @x
	phy
	jsr K_ACPTR
	ply
	cmp #13
	beq @x
	dey
	bne @l
@x:	jsr K_CLRCHN
	lda m_st
	rts

; block A/Y (lo/hi) of the image on file m_lfn -> BLK
ReadB:
	sta m_b
	sty m_b+1
	ldx #15                 ; "P" chr$(file) <position: block * 256>
	jsr K_CHKOUT
	lda #'P'
	jsr K_CHROUT
	lda m_lfn
	jsr K_CHROUT
	lda #0
	jsr K_CHROUT
	lda m_b
	jsr K_CHROUT
	lda m_b+1
	jsr K_CHROUT
	lda #0
	jsr K_CHROUT
	jsr K_CLRCHN
	ldx m_lfn
	jsr K_CHKIN
	ldy #0
@l:	phy
	jsr K_ACPTR
	ply
	sta BLK,y
	iny
	bne @l
	jmp K_CLRCHN

; D64, D81: header block, DOS version, last block, GEOS drive type
m_hdl:	.byte <357, <1560
m_hdh:	.byte >357, >1560
m_dos:	.byte 'A', 'D'
m_lstl:	.byte <682, <3199
m_lsth:	.byte >682, >3199
m_type:	.byte DRV_1541, DRV_1581
m_bits:	.byte $80, $40, $20

m_img:	.byte 0
m_len:	.byte 0
m_t:	.byte 0
m_ch:	.byte 0
m_lfn:	.byte 0
m_st:	.byte 0
m_b:	.word 0
