; GEOS for the Commander X16: sounds.  A soft click when the mouse button
; goes down (a softer one when it comes up), a flick when a menu drops
; down, a flip when a dialog box opens and a shorter one when it closes.
; All on VERA's PSG voice 15 (VRAM $1F9FC-$1F9FF), so the YM2151 and the
; other PSG voices stay the programs' own.  GEOSSND.CFG "OFF" (boot.s):
; no sounds.
;
; From the VSYNC interrupt (prn.s: Tick), once a frame: the mouse button
; (GEOS's mouseData), and the requests that GEOS's DoMenu0, DoDlgBox and
; RstrFrmDialogue leave (snd_menu, snd_dlg, snd_close: a DEC each, x16io.s).
; A click is one short burst (a few ms, timed here); the others are steps
; of a frame each.

.include "x16.inc"

.setcpu "65SC02"

.import snd_menu, snd_dlg, snd_close
.global SndTick, snd_on

mouseData = $8505               ; $80: button up
PSG15   = $1F9FC                ; voice 15: freq lo, freq hi, LR+volume, wave+width
W_PULSE = $00
W_NOISE = $C0
LR      = $C0                   ; both speakers

.segment "prnram"

SndTick:
	bit snd_on
	bmi :+
	stz snd_menu            ; off: requests dropped
	stz snd_dlg
	stz snd_close
	rts
:	lda VERA_CTRL           ; VERA's address port 0 kept
	pha
	stz VERA_CTRL
	lda VERA_ADDR_L
	pha
	lda VERA_ADDR_M
	pha
	lda VERA_ADDR_H
	pha
	; the mouse button: a click on a change
	lda mouseData
	and #$80
	ldx s_wait              ; the first 3 seconds (GEOS starting): no clicks
	beq :+
	dec s_wait
	sta s_btn
:	cmp s_btn
	beq @req
	sta s_btn
	cmp #0
	bne @up
	lda #40                 ; down: louder
	ldx #8
	bra @click
@up:	lda #18                 ; up: softer
	ldx #5
@click:	jsr Click
@req:	; requests: the latest wins
	ldy #0
	lda snd_menu
	beq :+
	ldy #s_flick - seqs
	stz snd_menu
:	lda snd_dlg
	beq :+
	ldy #s_flip - seqs
	stz snd_dlg
:	lda snd_close
	beq :+
	ldy #s_shut - seqs
	stz snd_close
:	cpy #0
	beq @step
	sty s_pos
@step:	ldy s_pos               ; one step a frame
	beq @done
	lda seqs+2,y
	beq @end
	jsr Voice
	lda s_pos
	clc
	adc #4
	sta s_pos
	bra @done
@end:	stz s_pos
	jsr Silence
@done:	pla
	sta VERA_ADDR_H
	pla
	sta VERA_ADDR_M
	pla
	sta VERA_ADDR_L
	pla
	sta VERA_CTRL
	rts

; a click: noise at volume A for about X * 0.2 ms, then silence
Click:
	sta s_v
	stx s_n
	ldy #s_clk - seqs
	lda s_v
	sta seqs+2,y            ; (its volume)
	jsr Voice
@w:	ldy #0                  ; about 1600 cycles
@d:	nop
	dey
	bne @d
	dec s_n
	bne @w
	stz s_pos               ; (a click stops a sound that was playing)
Silence:
	jsr Addr
	stz VERA_DATA0
	stz VERA_DATA0
	stz VERA_DATA0
	stz VERA_DATA0
	rts

; voice 15 <- the step at seqs+Y: freq lo, freq hi, volume, wave+width
Voice:
	jsr Addr
	lda seqs,y
	sta VERA_DATA0
	lda seqs+1,y
	sta VERA_DATA0
	lda seqs+2,y
	ora #LR
	sta VERA_DATA0
	lda seqs+3,y
	sta VERA_DATA0
	rts

Addr:
	lda #<PSG15
	sta VERA_ADDR_L
	lda #>(PSG15 & $FFFF)
	sta VERA_ADDR_M
	lda #^PSG15 | VERA_INC_1
	sta VERA_ADDR_H
	rts

; Hz -> PSG frequency value (48828.125 / 2^17 Hz a step)
.define F(hz) (hz * 131072 / 48828)

seqs:	.byte 0, 0, 0, 0        ; (offset 0: nothing playing)
s_clk:	.word F(3000)           ; a click: noise
	.byte 40, W_NOISE
s_flick: .word F(2400)          ; a menu: a short falling chirp
	.byte 24, W_PULSE | 16
	.word F(1700)
	.byte 18, W_PULSE | 16
	.word F(1200)
	.byte 10, W_PULSE | 16
	.byte 0, 0, 0, 0
s_flip:	.word F(6000)           ; a dialog box: a rising swish
	.byte 14, W_NOISE
	.word F(9000)
	.byte 26, W_NOISE
	.word F(12000)
	.byte 20, W_NOISE
	.word F(14000)
	.byte 8, W_NOISE
	.byte 0, 0, 0, 0
s_shut:	.word F(12000)          ; closed: a falling one, shorter
	.byte 18, W_NOISE
	.word F(7000)
	.byte 10, W_NOISE
	.byte 0, 0, 0, 0

snd_on:	.byte $80               ; $80: sounds on
s_btn:	.byte $80
s_pos:	.byte 0
s_wait:	.byte 180
s_v:	.byte 0
s_n:	.byte 0
