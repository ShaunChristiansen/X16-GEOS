; GEOS for the Commander X16: SNES controllers move the mouse pointer.
; Once a frame from the VSYNC interrupt (prn.s: Tick) the controllers in
; ports 1 and 2 are read (VIA 1 port A, as the X16 KERNAL's joystick_scan
; does: PA2 latch, PA3 clock, PA7/PA6 data; PA0-1, the I2C lines to the
; mouse and keyboard, are left alone) and their buttons go into the mouse's
; movement and button (x16io.s: msumx, msumy, joybtn), which GEOS's
; UpdateMouse takes as the mouse's own:
;   D-pad   the pointer: 1 pixel a frame, 2 after 10 frames, 4 after 30
;   Y held  1 pixel a frame (for small moves)
;   A or B  the mouse button (held: dragging; twice: a double click)
; No controller: its lines read 1, nothing pressed.  The mouse still works.

.include "x16.inc"

.setcpu "65SC02"

.import msumx, msumy, joybtn, mvalid
.global JoyTick

PRA     = $9F01                 ; VIA 1 port A
DDRA    = $9F03
LATCH   = $04
CLK     = $08

.segment "prnram"

JoyTick:
	lda DDRA                ; latch and clock out, the data lines in
	and #$0F
	ora #LATCH | CLK
	sta DDRA
	lda #CLK                ; latch pulse, clock high
	sta PRA
	lda #LATCH | CLK
	sta PRA
	pha
	pla
	pha
	pla
	pha
	pla
	stz PRA
	ldy #16                 ; 16 bits: pad 1 (PA7), pad 2 (PA6)
@b:	stz PRA                 ; clock low
	pha
	pla
	lda PRA
	ldx #CLK
	stx PRA                 ; clock high
	asl a                   ; PA7 -> C
	ror j1+1                ; (in from the top: the first bit ends at bit 0)
	ror j1
	asl a                   ; PA6 -> C
	ror j2+1
	ror j2
	dey
	bne @b
	; both pads (active low): bit 0 B, 1 Y, 2 Select, 3 Start, 4 Up, 5 Down,
	; 6 Left, 7 Right, 8 A, 9 X, 10 L, 11 R; 12-15: 1 for an SNES pad
	lda j1
	and j2
	eor #$FF
	sta p0                  ; (pressed: 1)
	lda j1+1
	and j2+1
	eor #$FF
	sta p1
	and #$F0                ; (not an SNES pad's: no A X L R)
	beq :+
	stz p1
:	; the button: A or B
	lda p0
	and #$01
	sta q
	lda p1
	and #$01
	ora q
	cmp jbtn
	beq @mv
	sta jbtn
	sta joybtn              ; (bit 0: pressed; x16io.s ORs it in)
	lda #1
	sta mvalid
@mv:	lda p0                  ; the D-pad
	and #$F0
	bne :+
	stz held
	rts
:	lda held                ; how long: the speed
	cmp #255
	beq :+
	inc held
:	ldx #2                  ; (msum units: 2 a GEOS pixel)
	lda p0
	and #$02                ; Y: slow
	bne @sp
	lda held
	cmp #10
	bcc @sp
	ldx #4
	cmp #30
	bcc @sp
	ldx #8
@sp:	stx q
	lda p0
	and #$80                ; right
	beq :+
	lda q
	ldx #0
	jsr AddX
:	lda p0
	and #$40                ; left
	beq :+
	lda #0
	sec
	sbc q
	ldx #$FF
	jsr AddX
:	lda p0
	and #$10                ; up (msumy: up is positive)
	beq :+
	lda q
	ldx #0
	jsr AddY
:	lda p0
	and #$20                ; down
	beq :+
	lda #0
	sec
	sbc q
	ldx #$FF
	jsr AddY
:	lda #1
	sta mvalid
	rts

AddX:	clc
	adc msumx
	sta msumx
	txa
	adc msumx+1
	sta msumx+1
	rts
AddY:	clc
	adc msumy
	sta msumy
	txa
	adc msumy+1
	sta msumy+1
	rts

j1:	.word $FFFF
j2:	.word $FFFF
p0:	.byte 0
p1:	.byte 0
q:	.byte 0
jbtn:	.byte 0
held:	.byte 0
