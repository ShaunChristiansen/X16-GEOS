; GEOS for the Commander X16: 6502 vectors of the kernel mirror banks
; (GEOS on the C64 writes them at boot; here they are part of the image)

.import _NMIHandler
.import _IRQHandler
.import X16_Reboot

.segment "vectors"

	.word _NMIHandler
	.word X16_Reboot
	.word _IRQHandler
