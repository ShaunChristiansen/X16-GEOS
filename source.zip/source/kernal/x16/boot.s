; GEOS for the Commander X16: cartridge boot (ROM bank 32)
;
; The X16 KERNAL calls $C004 in bank 32 (with jsrfar, interrupts masked)
; when bank 32 starts with "CX16".  This code
;   - returns to BASIC at once if GEOS left the quit marker at $0400
;   - copies the low-RAM parts of GEOS into place
;   - opens the disk images GEOSDISK.D64 (drive A), GEOSDSK2.D64 (drive
;     B) and GEOSDSK3.D64 (drive C), which GEOS then reads and writes
;     block by block
;   - reads the real time clock, sets up the SMC mouse and snapshots the
;     X16 KERNAL's state
;   - sets VERA up for the screen (two tile layers) and sprites, and
;     loads the wallpaper (a BMX picture) into VRAM when there is one
;   - builds the kernel mirror banks 48-55 from the image in bank 34
;   - starts GEOS at _ResetHandle ($5000)

.setcpu "65SC02"

.include "const.inc"
.include "geossym.inc"
.include "config.inc"
.include "kernal.inc"
.include "c64.inc"
.include "x16.inc"

.import __start_LOAD__, __start_RUN__, __start_SIZE__
.import __drvx16_LOAD__, __drvx16_RUN__
.import __x16io_RUN__, __x16io_SIZE__
.import __x16bss_RUN__, __x16bss_SIZE__
.import __files1a2a_LOAD__, __files1a2a_RUN__
.import __serial1_RUN__, __serial1_SIZE__
.import __mouseptr_LOAD__, __mouseptr_RUN__
.import __dlgbox2_RUN__, __dlgbox2_SIZE__
.import __x16boot_LOAD__, __x16boot_RUN__, __x16boot_SIZE__
.import __prnram_LOAD__, __prnram_RUN__, __prnram_SIZE__
.import _ResetHandle
.import X16_IrqEntry, X16_NmiEntry, X16_KernalIrq
.import w_cur, w_new, ser_port, ser_div, snd_on, net_ok, ser_force
.import __netram_LOAD__, __netram_RUN__, __netram_SIZE__
.import x16_rtc, x16_msize, x16_wtok, x16_drv2, x16_wpok, x16_dopen, x16_last, x16_dmap
.import x16_itype, x16_c64rom
.import c64pal_gb, c64pal_r

X16_BANK_KERNIMG = 34           ; pristine kernel image

.macro KCALL addr
	pha
	lda #<(addr)
	sta kcall_vec
	lda #>(addr)
	sta kcall_vec+1
	pla
	jsr X16_KCall
	sei                     ; some KERNAL calls (CHROUT, LOAD) enable interrupts
.endmacro

.macro COPY src, dst, len
	lda #<(src)
	sta r0L
	lda #>(src)
	sta r0H
	lda #<(dst)
	sta r1L
	lda #>(dst)
	sta r1H
	lda #<(len)
	sta r2L
	lda #>(len)
	sta r2H
	jsr Copy
.endmacro

.macro FILL dst, len
	lda #<(dst)
	sta r1L
	lda #>(dst)
	sta r1H
	lda #<(len)
	sta r2L
	lda #>(len)
	sta r2H
	jsr Fill
.endmacro

.segment "cartboot"

	.byte "CX16"
CartEntry:
	ldx #7
@q:	lda $0400,x
	cmp quitmagic,x
	bne Boot
	dex
	bpl @q
	stz $0400               ; GEOS quit to BASIC: consume the marker
	rts

Boot:
	sei
	; GEOS's low RAM, then its parts
	FILL $0400, $9F00-$0400
	COPY __drvx16_LOAD__, __drvx16_RUN__, __x16io_RUN__ + __x16io_SIZE__ - __drvx16_RUN__
	FILL __x16bss_RUN__, __x16bss_SIZE__
	COPY __start_LOAD__, __start_RUN__, __start_SIZE__
	COPY __files1a2a_LOAD__, __files1a2a_RUN__, __serial1_RUN__ + __serial1_SIZE__ - __files1a2a_RUN__
	COPY __x16boot_LOAD__, __x16boot_RUN__, __x16boot_SIZE__
	lda #X16_BANK_PRN       ; the printer code (prn.s)
	sta CPU_DDR
	FILL $A000, $2000
	COPY __prnram_LOAD__, __prnram_RUN__, __prnram_SIZE__
	lda #X16_BANK_GEOSRAM
	sta CPU_DDR
	FILL $A000, $2000
	COPY __mouseptr_LOAD__, __mouseptr_RUN__, __dlgbox2_RUN__ + __dlgbox2_SIZE__ - __mouseptr_RUN__

	ldx #<msg_load
	ldy #>msg_load
	jsr Print

	; the disk images stay on the X16's disk: GEOS reads and writes their
	; blocks there (sdio.s).  Devices 8-11 start with images 0-3
	ldx #3
@dm:	txa
	sta x16_dmap,x
	dex
	bpl @dm
	lda #X16_BANK_DBUF      ; no image names yet (OdName, call 11)
	sta CPU_DDR
	stz $A400
	stz $A440
	stz $A480
	stz $A4C0
	; the command channel is for the seeks
	lda #0
	KCALL K_SETNAM
	lda #15
	ldx #8
	ldy #15
	KCALL K_SETLFS
	KCALL K_OPEN
	bcs DiskError
	jsr LoadDrv             ; (the images SD CARD put in, if any)
	lda #0                  ; drive A: GEOSDISK (.D64 or .D81), needed
	jsr OpenDrive
	bcc DiskOK
DiskError:
	KCALL K_CLALL
	ldx #<msg_nodisk
	ldy #>msg_nodisk
	jsr Print
	jsr WaitKey             ; BASIC's start-up clears the screen
	rts                     ; back to the KERNAL: BASIC

; wait for a key (SMC key code) or about 15 seconds (VSYNC flags)
WaitKey:
	lda #<900
	sta r5L
	lda #>900
	sta r5H
@1:	lda #1
	sta VERA_ISR
@2:	lda VERA_ISR
	and #1
	beq @2
	ldx #SMC_I2C
	ldy #$07                ; key code
	KCALL K_I2C_READ
	cmp #0
	beq @3
	bpl @x                  ; a key was pressed
@3:	lda r5L
	bne @4
	dec r5H
@4:	dec r5L
	lda r5L
	ora r5H
	bne @1
@x:	rts

DiskOK:
	; date and time
	KCALL K_CLOCK_GET
	ldx #7
@r:	lda r0L,x
	sta x16_rtc,x
	dex
	bpl @r

	; drives B and C: GEOSDSK2 and GEOSDSK3, when they are there
	lda #1
	jsr OpenDrive
	bcs @nob
	lda #$80
	sta x16_drv2
	lda #2                  ; (drive C only with a drive B)
	jsr OpenDrive
@nob:
	jsr LoadWall
	jsr LoadSer
	jsr LoadSnd
	jsr LoadNet
	jsr LoadRoms
	; mouse: the KERNAL's mouse_config also hides the host pointer in
	; x16emu; then the SMC delivers a key code and a mouse packet per read
	lda #$FF
	ldx #0
	ldy #0
	KCALL K_MOUSE_CONFIG
	ldx #SMC_I2C
	ldy #$22                ; mouse device ID: 3/4 = with wheel
	KCALL K_I2C_READ
	ldx #3
	cmp #3
	beq @w
	cmp #4
	bne @m3
@w:	ldx #4
@m3:	stx x16_msize
	lda #$43
	ldx #SMC_I2C
	ldy #$40
	KCALL K_I2C_WRITE

	jsr X16_SaveKernalState
	jsr VeraSetup
	jmp BuildMirrors        ; low RAM; does not come back

; ---- copy r2 bytes from (r0) to (r1)
Copy:
	ldy #0
	ldx r2H
	beq @tail
@pg:	lda (r0),y
	sta (r1),y
	iny
	bne @pg
	inc r0H
	inc r1H
	dex
	bne @pg
@tail:	ldx r2L
	beq @x
@t:	lda (r0),y
	sta (r1),y
	iny
	dex
	bne @t
@x:	rts

; ---- clear r2 bytes at (r1)
Fill:
	lda #0
	ldy #0
	ldx r2H
	beq @tail
@pg:	sta (r1),y
	iny
	bne @pg
	inc r1H
	dex
	bne @pg
@tail:	ldx r2L
	beq @x
@t:	sta (r1),y
	iny
	dex
	bne @t
@x:	rts

; ---- print the zero-terminated message at X/Y
Print:
	stx r3L
	sty r3H
	ldy #0
@1:	lda (r3),y
	beq @x
	phy
	KCALL K_CHROUT
	ply
	iny
	bne @1
@x:	rts

; ---- read the drive status line from channel 15, return its first digit
DriveStatus:
	ldx #15
	KCALL K_CHKIN
	KCALL K_ACPTR           ; (CHRIN gives CR while the status is set)
	sta r4L
	ldy #40
@1:	phy
	KCALL K_READST
	ply
	and #$40
	bne @2
	phy
	KCALL K_ACPTR
	ply
	cmp #13
	beq @2
	dey
	bne @1
@2:	KCALL K_CLRCHN
	lda r4L
	rts

; ---- open a drive's disk image (A = 0 GEOSDISK, 1 GEOSDSK2, 2 GEOSDSK3)
; on channel 2 + A: a D64 (a 1541 disk, DOS version "A" in its BAM) or else
; a D81 (a 1581 disk, "D" in its header), in modify mode (read and write)
; or else read mode.  Modify mode makes a file that is not there (CMDR-DOS
; and x16emu alike), so read mode looks first.  Its last block goes to
; $A100 + drive * $100 of RAM bank X16_BANK_DBUF: reading the last byte of
; a file makes the DOS close it, so the file is opened again after that.
; C = 1: no image
OpenDrive:
	sta od_drv
	clc
	adc #2
	sta od_ch
	stz od_d81
	stz od_cfg              ; GEOSDRV.CFG names one (SD CARD)? that first
	jsr DcName
	lda (r5)
	beq @ext
	dec od_cfg
	ldy #$FF                ; its type: ".D81" or ".D64"
:	iny
	lda (r5),y
	bne :-
	dey
	lda (r5),y
	cmp #'1'
	bne @ext
	dec od_d81
@ext:	lda #'R'                ; is it there?
	sta od_mode
	jsr OdOpen
	jsr DriveStatus
	pha
	lda od_ch
	KCALL K_CLOSE
	pla
	cmp #'0'
	bne @nxt
	lda #'M'
@try:	sta od_mode
	jsr OdOpen
	jsr DriveStatus
	cmp #'0'
	beq @open
	lda od_ch
	KCALL K_CLOSE
	lda od_mode
	cmp #'R'
	beq @nxt
	lda #'R'
	bra @try
@nxt:	bit od_cfg              ; GEOSDRV.CFG's one not good: the usual one
	bpl :+
	stz od_cfg
	stz od_d81
	jmp @ext
:	lda od_d81              ; no D64 (or not a good one): a D81?
	bne @no0
	dec od_d81
	bra @ext
@no0:	jmp @no
@open:	ldx od_d81              ; X = 0 D64, 1 D81
	beq @1
	ldx #1
@1:	stx od_t
	lda od_hdl,x            ; the BAM or header block: 18/0 or 40/0
	pha
	lda od_hdh,x
	tax
	lda #X16_BANK_DBUF      ; (no DOS version left from another image)
	sta CPU_DDR
	stz $A000+2
	pla
	ldy #>$A000
	jsr OdRead
	lda #X16_BANK_DBUF
	sta CPU_DDR
	ldx od_t
	lda $A000+2
	cmp od_dos,x
	beq @2
	lda od_ch
	KCALL K_CLOSE
	bra @nxt
@2:	lda od_drv              ; the last block
	clc
	adc #>$A100
	tay
	lda od_lstl,x
	pha
	lda od_lsth,x
	tax
	pla
	jsr OdRead
	lda od_ch
	KCALL K_CLOSE
	jsr OdOpen
	jsr DriveStatus
	cmp #'0'
	beq @ok
	jmp @fail
@ok:	ldx od_drv
	lda od_bits,x
	tsb x16_dopen
	lda od_mode
	cmp #'M'
	bne @ro
	lda od_bits,x
	tsb x16_wtok
@ro:	ldy od_t
	lda od_type,y
	sta x16_itype,x
	txa
	asl a
	tax
	lda od_lstl,y
	sta x16_last,x
	lda od_lsth,y
	sta x16_last+1,x
	jsr OdMsg
	jsr OdName
	clc
	rts
@fail:	lda od_ch
	KCALL K_CLOSE
@no:	sec
	rts

; D64, D81: header block, DOS version, last block, GEOS drive type
od_hdl:		.byte <357, <1560
od_hdh:		.byte >357, >1560
od_dos:		.byte 'A', 'D'
od_lstl:	.byte <682, <3199
od_lsth:	.byte >682, >3199
od_type:	.byte DRV_1541, DRV_1581

; OPEN od_ch,8,od_ch,"<drive od_drv's file name>,S,<od_mode>"
OdOpen:
	bit od_cfg
	bpl @u
	jsr DcName              ; GEOSDRV.CFG's name
	ldy #0
@d:	lda (r5),y
	beq @dn
	sta od_name,y
	iny
	bra @d
@dn:	sty od_nlen
	bra @e
@u:	ldx od_drv
	lda od_x12,x
	tax
	ldy #0
@c:	lda od_names,x
	sta od_name,y
	inx
	iny
	cpy #12
	bne @c
	sty od_nlen
	lda od_d81              ; (".D64" or ".D81")
	beq @e
	lda #'8'
	sta od_name+10
	lda #'1'
	sta od_name+11
@e:	ldy od_nlen             ; ",S," and the mode
	lda #','
	sta od_name,y
	sta od_name+2,y
	lda #'S'
	sta od_name+1,y
	lda od_mode
	sta od_name+3,y
	tya
	clc
	adc #4
	ldx #<od_name
	ldy #>od_name
	KCALL K_SETNAM
	lda od_ch
	ldx #8
	ldy od_ch
	KCALL K_SETLFS
	KCALL K_OPEN
	rts

; block A/X (lo/hi) of the image on od_ch -> page Y of RAM bank X16_BANK_DBUF
OdRead:
	sta od_blk
	stx od_blk+1
	sty r6H
	stz r6L
	ldx #15                 ; "P" chr$(channel) <position: block * 256>
	KCALL K_CHKOUT
	lda #'P'
	KCALL K_CHROUT
	lda od_ch
	KCALL K_CHROUT
	lda #0
	KCALL K_CHROUT
	lda od_blk
	KCALL K_CHROUT
	lda od_blk+1
	KCALL K_CHROUT
	lda #0
	KCALL K_CHROUT
	KCALL K_CLRCHN
	ldx od_ch
	KCALL K_CHKIN
	ldy #0
@l:	phy
	KCALL K_ACPTR
	ply
	ldx #X16_BANK_DBUF
	stx CPU_DDR
	sta (r6),y
	iny
	bne @l
	KCALL K_CLRCHN
	rts

; the image's name -> $A400 + drive * 64 of RAM bank X16_BANK_DBUF (GEOS-X16
; call 11: which image is in a drive; sdio.s)
OdName:
	lda #X16_BANK_DBUF
	sta CPU_DDR
	lda od_drv
	asl a
	asl a
	asl a
	asl a
	asl a
	asl a
	tax
	ldy #0
@c:	lda od_name,y
	sta $A400,x
	inx
	iny
	cpy od_nlen
	bne @c
	stz $A400,x
	rts

; r5 = drive od_drv's name from GEOSDRV.CFG (dc_names; "" for none)
DcName:
	lda od_drv
	asl a                   ; * 40 = * 32 + * 8
	asl a
	asl a
	sta r5L
	asl a
	asl a
	clc
	adc r5L
	adc #<dc_names
	sta r5L
	lda #>dc_names
	adc #0
	sta r5H
	rts

; ---- GEOSDRV.CFG (SD CARD writes it): a line per drive (A, B, C), each a
; disk image's name, or empty for the usual one -> dc_names
LoadDrv:
	ldx #3*40-1
:	stz dc_names,x
	dex
	bpl :-
	lda #dd_cfgl
	ldx #<dd_cfg
	ldy #>dd_cfg
	KCALL K_SETNAM
	lda #1
	ldx #8
	ldy #9
	KCALL K_SETLFS
	KCALL K_OPEN
	bcc :+
	rts
:	jsr DriveStatus
	cmp #'0'
	bne @cl
	ldx #1
	KCALL K_CHKIN
	stz od_drv              ; (the line: its drive)
	stz od_nlen             ;   and its length
@rd:	KCALL K_ACPTR
	cmp #10
	beq @nx
	cmp #13
	bne @ch
	inc od_drv              ; the next drive's line
	stz od_nlen
	lda od_drv
	cmp #3
	beq @eol
	bra @nx
@ch:	pha
	jsr DcName
	pla
	ldy od_nlen
	cpy #39
	bcs @nx
	sta (r5),y
	inc od_nlen
@nx:	KCALL K_READST
	cmp #0
	beq @rd
@eol:	KCALL K_CLRCHN
@cl:	lda #1
	KCALL K_CLOSE
	rts

; "DRIVE A: GEOSDISK.D64", and " (READ-ONLY)" when it is
OdMsg:
	ldx #<msg_drive
	ldy #>msg_drive
	jsr Print
	lda od_drv
	clc
	adc #'A'
	KCALL K_CHROUT
	lda #':'
	KCALL K_CHROUT
	lda #' '
	KCALL K_CHROUT
	ldy #0
@n:	lda od_name,y
	phy
	KCALL K_CHROUT
	ply
	iny
	cpy od_nlen
	bne @n
	lda od_mode
	cmp #'M'
	beq @cr
	ldx #<msg_ro
	ldy #>msg_ro
	jsr Print
@cr:	lda #13
	KCALL K_CHROUT
	rts

od_bits:	.byte $80, $40, $20
od_x12:		.byte 0, 12, 24

; ---- the wallpaper, a BMX picture (the X16's bitmap format), loaded
; into VRAM by prn.s (tiles 0-999 of layer 0, then its 256 colours): the
; file GEOSWALL.CFG names (the WALLPAPER program writes it; "NONE": no
; wallpaper), else GEOSWALL.BMX, when there is one.  Its name goes to
; prn.s's w_cur ("" for none)
LoadWall:
	stz wl_n
	lda #wl_cfgl            ; GEOSWALL.CFG: one line
	ldx #<wl_cfg
	ldy #>wl_cfg
	KCALL K_SETNAM
	lda #1
	ldx #8
	ldy #9                  ; (channels 2-4 are the disk images)
	KCALL K_SETLFS
	KCALL K_OPEN
	bcs @def
	jsr DriveStatus
	cmp #'0'
	bne @cl
	ldx #1
	KCALL K_CHKIN
@rd:	KCALL K_ACPTR
	cmp #13
	beq @eol
	ldx wl_n
	sta wl_name,x
	inc wl_n
	cpx #WL_MAX-2
	bcs @eol
	KCALL K_READST
	cmp #0
	beq @rd                 ; (EOF or an error: that was all)
@eol:	KCALL K_CLRCHN
@cl:	lda #1
	KCALL K_CLOSE
	lda wl_n
	bne @got
@def:	ldx #x16_wallnamelen    ; no GEOSWALL.CFG: GEOSWALL.BMX
	stx wl_n
@dc:	lda x16_wallname-1,x
	sta wl_name-1,x
	dex
	bne @dc
@got:	ldx wl_n
	stz wl_name,x
	cpx #4                  ; "NONE"?
	bne @load
@nc:	lda wl_name-1,x
	ora #$20                ; (either case)
	cmp wl_none-1,x
	bne @load
	dex
	bne @nc
	ldx #<msg_nowall
	ldy #>msg_nowall
	jsr Print
	bra @cur0
@load:	lda CPU_DDR             ; the name -> prn.s's w_new, then its
	pha                     ; BMX loader (BootWall: X16 KERNAL in)
	lda #X16_BANK_PRN
	sta CPU_DDR
	ldx wl_n
@wn:	lda wl_name,x
	sta w_new,x
	dex
	bpl @wn
	KCALL PRN_BOOTWALL
	pla
	sta CPU_DDR
	bcs @nowp               ; (w_cur: "")
	ldx #<msg_wall
	ldy #>msg_wall
	jsr Print
	ldx #<wl_name
	ldy #>wl_name
	jsr Print
	ldx #<msg_cr
	ldy #>msg_cr
	jsr Print
@nowp:	rts
@cur0:	ldx #0                  ; none
	stz wl_name
@cur:	lda CPU_DDR
	pha
	lda #X16_BANK_PRN
	sta CPU_DDR
@cc:	lda wl_name,x
	sta w_cur,x
	dex
	bpl @cc
	pla
	sta CPU_DDR
	rts

; ---- GEOSSER.CFG (optional, one line): which port of TexElec's serial card
; the terminal programs use, "WIFI" (the ESP32, the default) or "DB9", and
; a speed ("DB9 9600"; 300-115200).  -> serial.s's ser_port and ser_div
LoadSer:
	stz wl_n
	lda #ws_cfgl
	ldx #<ws_cfg
	ldy #>ws_cfg
	KCALL K_SETNAM
	lda #1
	ldx #8
	ldy #9
	KCALL K_SETLFS
	KCALL K_OPEN
	bcs @no
	jsr DriveStatus
	cmp #'0'
	bne @cl
	ldx #1
	KCALL K_CHKIN
@rd:	KCALL K_ACPTR
	cmp #13
	beq @eol
	ldx wl_n
	sta wl_name,x
	inc wl_n
	cpx #WL_MAX-2
	bcs @eol
	KCALL K_READST
	cmp #0
	beq @rd
@eol:	KCALL K_CLRCHN
@cl:	lda #1
	KCALL K_CLOSE
@no:	ldx wl_n
	stz wl_name,x
	lda CPU_DDR
	pha
	lda #X16_BANK_PRN
	sta CPU_DDR
	ldx #0                  ; "DB9" in it: the DB9 port; "CAL": the Calypso
	stx ser_port
	stx ser_force
@kw:	lda wl_name,x
	beq @kwx
	ora #$20
	cmp #'d'
	bne @kc
	lda wl_name+1,x
	ora #$20
	cmp #'b'
	bne @kn
	lda wl_name+2,x
	cmp #'9'
	bne @kn
	lda #1
	sta ser_port
	bra @kn
@kc:	cmp #'c'
	bne @kn
	lda wl_name+1,x
	ora #$20
	cmp #'a'
	bne @kn
	lda wl_name+2,x
	ora #$20
	cmp #'l'
	bne @kn
	lda #$80
	sta ser_force
@kn:	inx
	bra @kw
@kwx:
	ldx #$FF                ; the first digit
@d:	inx
	lda wl_name,x
	beq @x
	cmp #'0'
	bcc @d
	cmp #'9'+1
	bcs @d
	stx ws_i
	ldy #0                  ; which speed: the table's strings
@sp:	ldx ws_i
@ch:	lda ws_speeds,y
	beq @end                ; the string ended: did the number?
	cmp wl_name,x
	bne @skip
	inx
	iny
	bra @ch
@end:	lda wl_name,x
	cmp #'0'
	bcc :+
	cmp #'9'+1
	bcc @nxt                ; (more digits: not this one)
:	lda ws_speeds+1,y       ; found: its divisor
	sta ser_div
	lda ws_speeds+2,y
	sta ser_div+1
	bra @x
@skip:	lda ws_speeds,y         ; to the end of this string
	beq @nxt
	iny
	bra @skip
@nxt:	iny                     ; past the 0 and the divisor
	iny
	iny
	lda ws_speeds,y
	bne @sp
	ldx ws_i                ; none: past these digits (DB9's 9), on
@k:	inx
	lda wl_name,x
	cmp #'0'
	bcc :+
	cmp #'9'+1
	bcc @k
:	dex
	jmp @d
@x:	pla
	sta CPU_DDR
	rts
ws_speeds:
	.byte "300", 0
	.word 3072
	.byte "1200", 0
	.word 768
	.byte "2400", 0
	.word 384
	.byte "4800", 0
	.word 192
	.byte "9600", 0
	.word 96
	.byte "19200", 0
	.word 48
	.byte "38400", 0
	.word 24
	.byte "57600", 0
	.word 16
	.byte "115200", 0
	.word 8
	.byte 0

; ---- the Calypso card: calypso.s into RAM bank X16_BANK_NET at $B000, and
; the card's NET.BIN (from its firmware: a file on its DOS device, or a copy
; on the SD card) below it at $A000.  Loaded: the terminals can use it
; (serial.s: net_ok)
LoadNet:
	lda #X16_BANK_NET
	sta CPU_DDR
	FILL $A000, $2000
	COPY __netram_LOAD__, __netram_RUN__, __netram_SIZE__
	lda #nb_namel
	ldx #<nb_name
	ldy #>nb_name
	KCALL K_SETNAM
	lda #1
	ldx #8
	ldy #2                  ; headerless
	KCALL K_SETLFS
	lda #X16_BANK_NET
	sta CPU_DDR
	lda #0
	ldx #<$A000
	ldy #>$A000
	KCALL K_LOAD
	bcs @no
	lda CPU_DDR             ; it must end below calypso.s, in this bank
	cmp #X16_BANK_NET
	bne @big
	cpy #>NET_CODE
	bcs @big
	lda $A000               ; and start with a jump table
	cmp #$4C
	bne @no
	lda #X16_BANK_PRN
	sta CPU_DDR
	lda #$80
	sta net_ok
@no:	lda #X16_BANK_PRN
	sta CPU_DDR
	rts
@big:	lda #X16_BANK_NET       ; (calypso.s again)
	sta CPU_DDR
	COPY __netram_LOAD__, __netram_RUN__, __netram_SIZE__
	bra @no

; ---- GEOSSND.CFG (optional, one line): "OFF" turns the sounds off (snd.s)
LoadSnd:
	stz wl_n
	lda #wd_cfgl
	ldx #<wd_cfg
	ldy #>wd_cfg
	KCALL K_SETNAM
	lda #1
	ldx #8
	ldy #9
	KCALL K_SETLFS
	KCALL K_OPEN
	bcc :+
	rts
:
	jsr DriveStatus
	cmp #'0'
	bne @cl
	ldx #1
	KCALL K_CHKIN
	KCALL K_ACPTR
	sta wl_name
	KCALL K_ACPTR
	sta wl_name+1
	KCALL K_CLRCHN
	lda wl_name             ; "OF"(F), either case
	ora #$20
	cmp #'o'
	bne @cl
	lda wl_name+1
	ora #$20
	cmp #'f'
	bne @cl
	lda CPU_DDR
	pha
	lda #X16_BANK_PRN
	sta CPU_DDR
	stz snd_on
	pla
	sta CPU_DDR
@cl:	lda #1
	KCALL K_CLOSE
@no:	rts

; ---- the C64's BASIC and KERNAL ROMs (BASIC.BIN and KERNAL.BIN, 8K each,
; your own copies), when they are there: geoCalc does its maths with
; BASIC's floating point routines (x16io.s: X16_C64On).  BASIC.BIN goes to
; RAM bank X16_BANK_C64BAS, KERNAL.BIN for now to X16_BANK_C64TMP
; (BuildMirrors puts it into the cartridge bank X16_BANK_C64VIEW)
LoadRoms:
	lda #rom_basl
	sta rom_n
	lda #X16_BANK_C64BAS
	ldx #<rom_bas
	ldy #>rom_bas
	jsr LoadRom
	bcs @no
	ldx #7                  ; "CBMBASIC" at $A004
@1:	lda $A004,x
	cmp sig_bas,x
	bne @no
	dex
	bpl @1
	lda #rom_kerl
	sta rom_n
	lda #X16_BANK_C64TMP
	ldx #<rom_ker
	ldy #>rom_ker
	jsr LoadRom
	bcs @no
	ldx #5                  ; the CHRGET routine BASIC copies, at $E3A2
@2:	lda $A3A2,x
	cmp sig_ker,x
	bne @no
	dex
	bpl @2
	lda #$80
	sta x16_c64rom
	ldx #<msg_rom
	ldy #>msg_rom
	jmp Print
	; no ROMs: BASIC's bank is all RTS, so that a program calling BASIC's
	; maths (the calculator, geoCalc: X16_C64On) gets nothing done instead
	; of running into whatever is there; number to text ($BDDD) gives
	; "C64 ROM?"
@no:	lda #X16_BANK_C64BAS
	sta CPU_DDR
	lda r0L
	pha
	lda r0H
	pha
	stz r0L
	lda #$A0
	sta r0H
	lda #$60
	ldx #$20
	ldy #0
@f:	sta (r0),y
	iny
	bne @f
	inc r0H
	dex
	bne @f
	pla
	sta r0H
	pla
	sta r0L
	ldx #nr_end - nr_fout - 1
@g:	lda nr_fout,x
	sta $BDDD,x
	dex
	bpl @g
	ldx #nr_txe - nr_txt - 1
@h:	lda nr_txt,x
	sta $BFF0,x
	dex
	bpl @h
	rts
nr_fout:	.byte $A9, $F0, $A0, $BF, $60   ; lda #$F0 / ldy #$BF / rts
nr_end:
nr_txt:	.byte "C64 ROM?", 0
nr_txe:

; headerless load of the ROM file named at X/Y (rom_n characters) to
; $A000 of RAM bank A.  C = 1: not there.  That RAM bank is mapped.  (Not
; r0-r15 for the bank: the KERNAL uses them)
LoadRom:
	sta rom_b
	lda rom_n
	KCALL K_SETNAM
	lda #1
	ldx #8
	ldy #2                  ; headerless
	KCALL K_SETLFS
	lda rom_b
	sta CPU_DDR
	lda #0
	ldx #<$A000
	ldy #>$A000
	KCALL K_LOAD
	lda rom_b               ; (the load may have gone on into the next bank)
	sta CPU_DDR
	rts

sig_bas:	.byte "CBMBASIC"
sig_ker:	.byte $E6, $7A, $D0, $02, $E6, $7B

; ---- VERA: the screen is two tile layers (see helper.s), sprites, palette
VeraSetup:
	stz VERA_CTRL
	lda VERA_DC_VIDEO
	and #$0F
	ora #$70                ; layers 0 and 1 and sprites on
	sta VERA_DC_VIDEO
	lda #64                 ; 2x: 320x240
	sta VERA_DC_HSCALE
	sta VERA_DC_VSCALE
	lda #$01                ; border: C64 black
	sta VERA_DC_BORDER
	lda #$02                ; DCSEL = 1
	sta VERA_CTRL
	stz VERA_DC_HSTART
	lda #160
	sta VERA_DC_HSTOP
	lda #20                 ; 200 lines, centred
	sta VERA_DC_VSTART
	lda #220
	sta VERA_DC_VSTOP
	stz VERA_CTRL
	; layer 0: 64x32 map, 8bpp tiles (background colours, wallpaper)
	; layer 1: 64x32 map, 2bpp tiles (the bitmap's cards)
	lda #$13
	sta VERA_L0_CONFIG
	lda #<(VRAM_MAP0 >> 9)
	sta VERA_L0_MAPBASE
	lda #<((VRAM_TILES0 >> 11) << 2)
	sta VERA_L0_TILEBASE
	lda #$11
	sta VERA_L1_CONFIG
	lda #<(VRAM_MAP1 >> 9)
	sta VERA_L1_MAPBASE
	lda #<((VRAM_TILES1 >> 11) << 2)
	sta VERA_L1_TILEBASE
	ldx #3
@sc:	stz VERA_L0_HSCROLL_L,x ; no scrolling
	stz VERA_L0_HSCROLL_L+7,x
	dex
	bpl @sc
	; clear layer 1's tiles, sprite images, sprite attributes
	lda #^VRAM_TILES1 | VERA_INC_1
	ldx #>VRAM_TILES1
	ldy #(VRAM_MAP1 - VRAM_TILES1) >> 8
	jsr VClear
	lda #^VRAM_SPRDATA | VERA_INC_1
	ldx #>(VRAM_SPRDATA & $FFFF)
	ldy #$40
	jsr VClear
	lda #^VRAM_SPRATTR | VERA_INC_1
	ldx #>(VRAM_SPRATTR & $FFFF)
	ldy #4
	jsr VClear
	; both maps: tile 1023, palette offset 0 (layer 0: black, layer 1:
	; blank) until the helper bank has converted the screen
	lda #VERA_INC_1
	sta VERA_ADDR_H
	lda #>VRAM_MAP1
	sta VERA_ADDR_M
	stz VERA_ADDR_L
	ldy #(VRAM_TILES0 - VRAM_MAP1) >> 9
	ldx #0
@m:	lda #<1023
	sta VERA_DATA0
	lda #>1023
	sta VERA_DATA0
	inx
	bne @m
	dey
	bne @m
	; the wallpaper's colours -> the palette (GEOS's own entries are set
	; below)
	bit x16_wpok
	bpl @nowc
	lda #1
	sta VERA_CTRL
	lda #^VRAM_PALETTE | VERA_INC_1
	sta VERA_ADDR_H
	lda #>(VRAM_PALETTE & $FFFF)
	sta VERA_ADDR_M
	stz VERA_ADDR_L
	stz VERA_CTRL
	lda #^VRAM_WALLPAL | VERA_INC_1
	sta VERA_ADDR_H
	lda #>(VRAM_WALLPAL & $FFFF)
	sta VERA_ADDR_M
	stz VERA_ADDR_L
	ldy #2
	ldx #0
@wp:	lda VERA_DATA0
	sta VERA_DATA1
	inx
	bne @wp
	dey
	bne @wp
@nowc:	; layer 0's solid tile (1023): pixel value 1, so the palette offset
	; (= background colour) selects entry 16 * colour + 1
	stz VERA_CTRL
	lda #^VRAM_SOLID | VERA_INC_1
	sta VERA_ADDR_H
	lda #>(VRAM_SOLID & $FFFF)
	sta VERA_ADDR_M
	lda #<VRAM_SOLID
	sta VERA_ADDR_L
	ldx #64
	lda #1
@so:	sta VERA_DATA0
	dex
	bne @so
	; palette: 16*c+1 = C64 colour c, 16*c+3 = black (the mouse pointer's
	; outline), entry 0 = black
	ldx #0
@p:	lda #VERA_INC_1 | 1
	sta VERA_ADDR_H
	lda #$FA
	sta VERA_ADDR_M
	txa
	asl a
	asl a
	asl a
	asl a
	inc a
	asl a                   ; (16c+1)*2
	sta VERA_ADDR_L
	bcc @lo
	inc VERA_ADDR_M
@lo:	lda c64pal_gb,x
	sta VERA_DATA0
	lda c64pal_r,x
	sta VERA_DATA0
	stz VERA_DATA0          ; 16*c+2: set by the helper bank
	stz VERA_DATA0
	stz VERA_DATA0          ; 16*c+3
	stz VERA_DATA0
	inx
	cpx #16
	bne @p
	lda #VERA_INC_1 | 1
	sta VERA_ADDR_H
	lda #$FA
	sta VERA_ADDR_M
	stz VERA_ADDR_L
	stz VERA_DATA0
	stz VERA_DATA0
	rts

; A = ADDR_H, X = ADDR_M, Y = pages to clear
VClear:
	sta VERA_ADDR_H
	stx VERA_ADDR_M
	stz VERA_ADDR_L
	ldx #0
@1:	stz VERA_DATA0
	inx
	bne @1
	dey
	bne @1
	rts

quitmagic: .byte "GEOSQUIT"


CartRti:
	rti

msg_load:   .byte 13, "GEOS 2.0 FOR THE COMMANDER X16", 13, 0
msg_nodisk: .byte "NO GEOSDISK.D64 OR GEOSDISK.D81 IMAGE.", 13
            .byte "PUT A GEOS DISK IMAGE WITH ONE OF THOSE", 13
            .byte "NAMES NEXT TO THE EMULATOR (OR ON THE", 13
            .byte "SD CARD).", 13, 13
            .byte "PRESS A KEY.", 13, 0
msg_drive:  .byte "DRIVE ", 0
msg_ro:     .byte " (READ-ONLY)", 0
msg_wall:   .byte "WALLPAPER: ", 0
msg_nowall: .byte "WALLPAPER: NONE", 13, 0
msg_cr:     .byte 13, 0
msg_rom:    .byte "C64 ROMS: BASIC.BIN, KERNAL.BIN", 13, 0

;---------------------------------------------------------------------------
; boot code that must run from low RAM: builds the mirror banks
;---------------------------------------------------------------------------
.segment "x16boot"

BuildMirrors:
	lda #$C0
	sta bm_page
@p:	lda #X16_BANK_KERNIMG
	sta CPU_DATA
	lda bm_page
	sta @s+2
	ldx #0
@s:	lda $C000,x
	sta $0800,x
	inx
	bne @s
	lda #X16_BANK_RAMVIEW
	sta bm_bank
@b:	lda bm_bank
	sta CPU_DATA
	lda bm_page
	sta @d+2
	ldx #0
@c:	lda $0800,x
@d:	sta $C000,x
	inx
	bne @c
	inc bm_bank
	lda bm_bank
	cmp #X16_BANK_RAMVIEW + X16_NUM_MIRRORS
	bne @b
	inc bm_page
	bne @p
	; I/O shadow ($D000-$DFFF) in the banks where the C64 sees I/O
	lda #X16_BANK_IOVIEW
	sta bm_bank
@io:	lda bm_bank
	sta CPU_DATA
	lda #$D0
	sta @f+2
	ldy #16
@fp:	ldx #0
	lda #0
@f:	sta $D000,x
	inx
	bne @f
	inc @f+2
	dey
	bne @fp
	lda #$FF                ; CIA1 ports: no key pressed
	sta $DC00
	sta $DC01
	inc bm_bank
	lda bm_bank
	cmp #X16_BANK_RAMVIEW + X16_NUM_MIRRORS
	bne @io
	; with the C64's ROMs: the C64 view for geoCalc's maths (x16io.s:
	; X16_C64On): $C000-$DFFF as in mirror bank $37, then the C64 KERNAL
	bit x16_c64rom
	bpl @nor
	lda #$C0
	sta bm_page
@vp:	lda #X16_BANK_RAMVIEW + 7
	sta CPU_DATA
	lda bm_page
	sta @vs+2
	sta @vd+2
	ldx #0
@vs:	lda $C000,x
	sta $0800,x
	inx
	bne @vs
	lda #X16_BANK_C64VIEW
	sta CPU_DATA
@vc:	lda $0800,x
@vd:	sta $C000,x
	inx
	bne @vc
	inc bm_page
	lda bm_page
	cmp #$E0
	bne @vp
	lda #X16_BANK_C64TMP
	sta CPU_DDR
	lda #>$A000
	sta @ks+2
	lda #>$E000
	sta @kd+2
@kp:	ldx #0
@ks:	lda $A000,x
@kd:	sta $E000,x
	inx
	bne @ks
	inc @ks+2
	inc @kd+2
	bne @kp
@nor:
	; interrupts: VERA VSYNC only
	lda #$7F
	sta VIA1_IER
	sta VIA2_IER
	lda #$01
	sta VERA_IEN
	lda #$FF
	sta VERA_ISR
	lda #$4C                ; IRQ/NMI entry in RAM ($038B/$03B7), as
	sta $038B               ; X16_FixEntry (compat.s) keeps them
	sta $03B7
	lda #<X16_IrqEntry
	sta $038C
	lda #>X16_IrqEntry
	sta $038D
	lda #<X16_NmiEntry
	sta $03B8
	lda #>X16_NmiEntry
	sta $03B9
	lda #X16_BANK_GEOSRAM
	sta CPU_DDR
	jmp _ResetHandle        ; low RAM; it maps the kernel itself

bm_page: .byte 0
bm_bank: .byte 0

; snapshot of the X16 KERNAL's $02-$FF and $0200-$03FF in RAM bank $2E:
;   $A000-$A2FF  X16 KERNAL state     $A300-$A5FF  GEOS state (while swapped)
X16_SaveKernalState:  ; (runs once, at boot)
	lda CPU_DDR
	pha
	lda #X16_BANK_KSAVE
	sta CPU_DDR
	ldx #2
@1:	lda $00,x
	sta $A000,x
	inx
	bne @1
@2:	lda $0200,x
	sta $A100,x
	lda $0300,x
	sta $A200,x
	inx
	bne @2
	; while GEOS calls the KERNAL (disk write-through), an interrupt goes
	; to the KERNAL's own handler: make it only acknowledge VSYNC
	lda #<X16_KernalIrq
	sta $A200 + ($0314 - $0300)
	lda #>X16_KernalIrq
	sta $A200 + ($0315 - $0300)
	pla
	sta CPU_DDR
	rts


;---------------------------------------------------------------------------
; call the X16 KERNAL routine at (kcall_vec): A/X/Y/C in and out (boot code
; in bank 32 cannot map the KERNAL's ROM bank itself)
;---------------------------------------------------------------------------
X16_KCall:
	sta kc_a
	lda CPU_DATA
	sta kc_bnk
	stz CPU_DATA
	lda kc_a
	jsr @go
	sta kc_a
	php
	lda kc_bnk
	sta CPU_DATA
	plp
	lda kc_a
	rts
@go:	jmp (kcall_vec)
kcall_vec:	.word 0
kc_a:		.byte 0
kc_bnk:		.byte 0

od_names:	.byte "GEOSDISK.D64", "GEOSDSK2.D64", "GEOSDSK3.D64"
od_name:	.res 48                 ; a drive's image name, ",S,", the mode
od_nlen:	.byte 0
od_cfg:		.byte 0                 ; $80: GEOSDRV.CFG's name for this drive
dc_names:	.res 3 * 40             ; GEOSDRV.CFG's names (LoadDrv)
dd_cfg:		.byte "GEOSDRV.CFG"
dd_cfgl = * - dd_cfg
od_drv:		.byte 0
od_ch:		.byte 0
od_mode:	.byte 0
od_blk:		.byte 0, 0
od_d81:		.byte 0                 ; $FF: trying the .D81 name
od_t:		.byte 0                 ; 0 D64, 1 D81
rom_n:		.byte 0                 ; LoadRom: name length, RAM bank
rom_b:		.byte 0
rom_bas:	.byte "BASIC.BIN"       ; (names in low RAM: the KERNAL reads them
rom_basl = * - rom_bas          ; with its own ROM bank mapped)
rom_ker:	.byte "KERNAL.BIN"
rom_kerl = * - rom_ker
x16_wallname:	.byte "GEOSWALL.BMX"
x16_wallnamelen = * - x16_wallname
nb_name:	.byte "NET.BIN"
nb_namel = * - nb_name
wd_cfg:		.byte "GEOSSND.CFG"
wd_cfgl = * - wd_cfg
ws_cfg:		.byte "GEOSSER.CFG"
ws_cfgl = * - ws_cfg
ws_i:		.byte 0
wl_cfg:		.byte "GEOSWALL.CFG"
wl_cfgl = * - wl_cfg
wl_none:	.byte "none"
WL_MAX = 48                     ; (prn.s: WNAME)
wl_name:	.res WL_MAX
wl_n:		.byte 0

;---------------------------------------------------------------------------
.segment "cartvectors"
	.word CartRti, CartRti, CartRti
