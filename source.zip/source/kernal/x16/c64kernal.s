; GEOS for the Commander X16: the C64 KERNAL's jump table ($FF81-$FFF5)
;
; GEOS applications, desk accessories and printer drivers call the C64
; KERNAL between InitForIO and DoneWithIO: the serial bus routines (LISTEN,
; SECOND, CIOUT, ...) for printers and for disk commands, READST, and a few
; others.  On the C64 InitForIO maps the KERNAL ROM there; here the table
; is in every kernel mirror bank, in the input driver's space (which this
; port does not load drivers into).
;
; Printers (devices 4-7) go to prn.s in RAM bank X16_BANK_PRN: LISTEN,
; SECOND, CIOUT, UNLSN, and SETLFS/SETNAM/OPEN/CHKOUT/CHROUT/CLRCHN/CLOSE.
; prn.s passes them to a printer on the X16's IEC port through the X16
; KERNAL, or writes the bytes to a file (PRINTn.PRN) when no printer
; answers.  Everything else answers as a C64 with nothing else on its
; serial bus: "device not present" (ST = $80).

.include "const.inc"
.include "geossym.inc"
.include "x16.inc"

.setcpu "65SC02"

C64_ST = $90                    ; KERNAL I/O status (not used by GEOS)

.segment "c64kcode"

.global P_Tick, P_Patch

; the printer calls: A, P, X, Y and the RAM bank go on the stack, prn.s
; (PRN_ENTRY, A = the call) reads and changes them there
P_Listen:	pha
		lda #0
		bra PrnGo
P_Second:	pha
		lda #1
		bra PrnGo
P_Ciout:	pha
		lda #2
		bra PrnGo
P_Unlsn:	pha
		lda #3
		bra PrnGo
P_Setlfs:	pha
		lda #4
		bra PrnGo
P_Setnam:	pha
		lda #5
		bra PrnGo
P_Open:		pha
		lda #6
		bra PrnGo
P_Close:	pha
		lda #7
		bra PrnGo
P_Chkout:	pha
		lda #8
		bra PrnGo
P_Clrchn:	pha
		lda #9
		bra PrnGo
P_Chrout:	pha
		lda #10
		bra PrnGo
P_Ext:		pha                     ; GEOS-X16 calls for programs ($FF7D)
		lda #12
		bra PrnGo
P_Patch:	pha                     ; after every ReadFile (compat.s)
		lda #13
		bra PrnGo
P_Tick:		pha                     ; the IRQ, once a frame
		lda #11
PrnGo:		php
		sei
		phx
		phy
		ldx CPU_DDR
		phx
		ldx #X16_BANK_PRN
		stx CPU_DDR
		jsr PRN_ENTRY
		plx
		stx CPU_DDR
		ply
		plx
		plp
		pla
		rts

NoDevice:                       ; LISTEN, TALK, OPEN, CHKIN, CHKOUT, LOAD, SAVE
	lda #$80
	sta C64_ST
	lda #5                  ; DEVICE NOT PRESENT
	sec
	rts
Nothing:
	clc
	rts
ReadSt:
	lda C64_ST
	rts
Acptr:                          ; nothing to read: time out, end of data
	lda #$42
	sta C64_ST
	lda #13
	clc
	rts
Stop:                           ; STOP key not pressed: Z = 0
	lda #$FF
	clc
	rts
Getin:
	lda #0
	clc
	rts
Rdtim:
	lda #0
	tax
	tay
	rts
Screen:
	ldx #40
	ldy #25
	rts
Iobase:
	ldx #<$DC00
	ldy #>$DC00
	rts
Memtop:
	ldx #<$A000
	ldy #>$A000
	rts
Membot:
	ldx #<$0800
	ldy #>$0800
	rts

; GEOS-X16 calls for GEOS programs: "X16G" and a version at $FF78, then
; jmp at $FF7D with A = the call (prn.s: Ext)
.segment "x16ext"               ; $FF78
	.byte "X16G", 3                 ; (2: call 9, the X16 KERNAL; 3: 10, 11, disks)
	jmp P_Ext

.segment "c64ktab"              ; $FF81

	jmp Nothing             ; FF81 CINT
	jmp Nothing             ; FF84 IOINIT
	jmp Nothing             ; FF87 RAMTAS
	jmp Nothing             ; FF8A RESTOR
	jmp Nothing             ; FF8D VECTOR
	jmp Nothing             ; FF90 SETMSG
	jmp P_Second            ; FF93 SECOND
	jmp Nothing             ; FF96 TKSA
	jmp Memtop              ; FF99 MEMTOP
	jmp Membot              ; FF9C MEMBOT
	jmp Nothing             ; FF9F SCNKEY
	jmp Nothing             ; FFA2 SETTMO
	jmp Acptr               ; FFA5 ACPTR
	jmp P_Ciout             ; FFA8 CIOUT
	jmp Nothing             ; FFAB UNTLK
	jmp P_Unlsn             ; FFAE UNLSN
	jmp P_Listen            ; FFB1 LISTEN
	jmp NoDevice            ; FFB4 TALK
	jmp ReadSt              ; FFB7 READST
	jmp P_Setlfs            ; FFBA SETLFS
	jmp P_Setnam            ; FFBD SETNAM
	jmp P_Open              ; FFC0 OPEN
	jmp P_Close             ; FFC3 CLOSE
	jmp NoDevice            ; FFC6 CHKIN
	jmp P_Chkout            ; FFC9 CHKOUT
	jmp P_Clrchn            ; FFCC CLRCHN
	jmp Acptr               ; FFCF CHRIN
	jmp P_Chrout            ; FFD2 CHROUT
	jmp NoDevice            ; FFD5 LOAD
	jmp NoDevice            ; FFD8 SAVE
	jmp Nothing             ; FFDB SETTIM
	jmp Rdtim               ; FFDE RDTIM
	jmp Stop                ; FFE1 STOP
	jmp Getin               ; FFE4 GETIN
	jmp Nothing             ; FFE7 CLALL
	jmp Nothing             ; FFEA UDTIM
	jmp Screen              ; FFED SCREEN
	jmp Nothing             ; FFF0 PLOT
	jmp Iobase              ; FFF3 IOBASE
