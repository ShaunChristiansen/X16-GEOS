; GEOS-X16: what the core does about applications that use the X16's
; interrupt entry.
;
; Every interrupt on the X16 goes through RAM at $038B (IRQ, BRK) and
; $03B7 (NMI): the vector pull maps ROM bank 0, whose vectors lead there,
; and nothing can move them.  On a C64 that is free RAM, and applications
; may use it.  When an application is loaded, X16_PatchAppl (x16io.s)
; looks for the code that uses it and points it at the core instead; the
; application on the disk is not changed.
;
; geoCalc swaps its zero page ($80-$FA) with $0334-$03AE, which takes in
; $038B-$038D: with interrupts on, the next interrupt ran its data.  Its
; swap loop becomes a call to X16_ZpSwap, which does the same swap but
; keeps those three bytes in zs_save.
;
; A program may also be loaded into page 3 (Graphics Grabber 2.0 loads at
; $0340, with code at $038B).  At the end of every ReadFile (interrupts
; still off) X16_P3Grab looks at the entries: the program's bytes at
; $038B-$038D go to p3_save and the IRQ entry is put back; when the
; program itself runs into $038B, X16_IrqEntry (x16io.s) sees that it was
; not an interrupt (no vector pull: ROM bank 0 is not mapped) and goes to
; p3_exec, code built from those bytes that does what they do and goes on
; after them.  The program's bytes at $03B7-$03B9 stay (data, in that
; program): there is no NMI entry while it runs.

.include "const.inc"
.include "geossym.inc"

.setcpu "65SC02"

.import X16_IrqEntry, X16_NmiEntry
.global zs_save
.global X16_PatZS, X16_ZpSwap, X16_PatGC
.import x16_c64rom, X16_C64On, X16_C64Off, X16_C64On2, X16_C64Off2
.global X16_FixEntry, X16_P3Grab, X16_DTClear
.global p3_own, p3_save, p3_exec, p3_jret, p3_jtgt, p3_x, P3_Jsr
.import X16_P3Build, P_Patch

.segment "x16bss2"      ; low RAM ($9Exx)

zs_save:  .res 3        ; geoCalc's $038B-$038D (X16_ZpSwap)
p3_own:   .res 1        ; $80: the program has code at $038B (p3_save)
                        ; $40: the program has its bytes at $03B7-$03B9
p3_save:  .res 3        ; the program's bytes at $038B-$038D
p3_exec:  .res 13       ; what they do (built by P3_Build)
p3_jret:  .res 2        ; a jsr there: the return address it pushes
p3_jtgt:  .res 2        ;              and its target
p3_x:     .res 1        ; P3_Build: next byte of p3_exec

.segment "x16kern"

; at (r0): geoCalc's swap loop?  Then JSR X16_ZpSwap and NOPs in its place.
; Y changed.
X16_PatZS:
	ldy #zspat_end - zspat - 1
@c:	lda (r0),y
	cmp zspat,y
	bne @x
	dey
	bpl @c
	ldy #0
	lda #$20                ; jsr X16_ZpSwap
	sta (r0),y
	iny
	lda #<X16_ZpSwap
	sta (r0),y
	iny
	lda #>X16_ZpSwap
	sta (r0),y
	lda #$EA
@f:	iny
	sta (r0),y
	cpy #zspat_end - zspat - 1
	bne @f
	lda #0                  ; the three bytes start empty
	sta zs_save
	sta zs_save+1
	sta zs_save+2
@x:	rts

; ldx #$7A / ldy $80,x / lda $0334,x / sta $80,x / tya / sta $0334,x
; dex / bpl (the code after it restores A, X, Y and P from the stack)
zspat:	.byte $A2, $7A, $B4, $80, $BD, $34, $03, $95, $80, $98, $9D, $34, $03, $CA, $10, $F2
zspat_end:

; at (r0): geoCalc's switch to the C64's BASIC ROM, or back?  Then calls
; to X16_C64On / X16_C64Off (x16io.s) in their place; only when BASIC.BIN
; and KERNAL.BIN are loaded (boot.s: LoadRoms).  geoCalc does its maths
; with BASIC's floating point routines (text to number and back, powers,
; LOG, EXP, SIN, COS, TAN, ATN, SQR, RND), between these two.  X, Y changed
X16_PatGC:
	ldy #5                  ; the calculator's two: "lda $01 / ora #$02 /
@c1:	lda (r0),y              ; sta $01" and "lda $01 / and #$FD / sta $01"
	cmp calon,y
	bne @c2
	dey
	bpl @c1
	lda #<X16_C64On2
	ldx #>X16_C64On2
	bra @cp
@c2:	ldy #5
@c3:	lda (r0),y
	cmp caloff,y
	bne @gc
	dey
	bpl @c3
	lda #<X16_C64Off2
	ldx #>X16_C64Off2
@cp:	ldy #0
	jsr PutJsr
	lda #$EA
	sta (r0),y
	iny
	sta (r0),y
	iny
	sta (r0),y
	rts
@gc:	ldy #gcon_end - gcon - 1
@1:	lda (r0),y
	cmp gcon,y
	bne @off
	dey
	bpl @1
	ldy #5                  ; "jsr X16_C64On / nop" for "lda #$37 / sta $01"
	lda #<X16_C64On
	ldx #>X16_C64On
	jsr PutJsr
	lda #$EA
	sta (r0),y
@x:	rts
@off:	ldy #gcoff_end - gcoff - 1
@2:	lda (r0),y
	cmp gcoff,y
	bne @x
	dey
	bpl @2
	ldy #1                  ; "jsr X16_C64Off / nop / nop" for "lda $2FF3 /
	lda #<X16_C64Off        ; sta $01"
	ldx #>X16_C64Off
	jsr PutJsr
	lda #$EA
	sta (r0),y
	iny
	sta (r0),y
	rts

calon:	.byte $A5, $01, $09, $02, $85, $01
caloff:	.byte $A5, $01, $29, $FD, $85, $01

; jsr A/X at (r0),y; Y = the byte after it
PutJsr:
	pha
	lda #$20
	sta (r0),y
	iny
	pla
	sta (r0),y
	iny
	txa
	sta (r0),y
	iny
	rts

; geoCalc 1.0: lda $01 / sta $2FF3 / lda #$37 / sta $01
gcon:	.byte $A5, $01, $8D, $F3, $2F, $A9, $37, $85, $01
gcon_end:
; sei / lda $2FF3 / sta $01 / lda $054D / sta $FF
gcoff:	.byte $78, $AD, $F3, $2F, $85, $01, $AD, $4D, $05, $85, $FF
gcoff_end:

; geoCalc's swap: zero page $80-$FA with $0334-$03AE, but $D7-$D9 with
; zs_save instead of $038B-$038D (the interrupt entry is not touched).
; A, X, Y changed, as by the loop it replaces.
X16_ZpSwap:
	ldx #$7A
@l:	cpx #$57
	bcc @p
	cpx #$5A
	bcs @p
	ldy $80,x
	lda zs_save - $57,x
	sta $80,x
	tya
	sta zs_save - $57,x
	bra @n
@p:	ldy $80,x
	lda $0334,x
	sta $80,x
	tya
	sta $0334,x
@n:	dex
	bpl @l
	rts

;---------------------------------------------------------------------------
; the interrupt entry: "jmp X16_IrqEntry" at $038B, "jmp X16_NmiEntry" at
; $03B7 (not while the program has its own bytes there).  A changed.
;---------------------------------------------------------------------------
X16_FixEntry:
	lda #$4C
	sta $038B
	lda #<X16_IrqEntry
	sta $038C
	lda #>X16_IrqEntry
	sta $038D
	bit p3_own
	bvs @1
	lda #$4C
	sta $03B7
	lda #<X16_NmiEntry
	sta $03B8
	lda #>X16_NmiEntry
	sta $03B9
@1:	rts

; end of ReadFile, interrupts off: did the file go over the entries?  X kept.
X16_P3Grab:
	phx
	ldx #2
@1:	lda $038B,x
	cmp jmpirq,x
	bne @2
	dex
	bpl @1
	bra @4
@2:	ldx #2
@3:	lda $038B,x
	sta p3_save,x
	dex
	bpl @3
	phy
	jsr X16_P3Build         ; x16io.s -> P3_Build (helper.s)
	ply
	lda #$80
	tsb p3_own
@4:	ldx #2
@5:	lda $03B7,x
	cmp jmpnmi,x
	bne @6
	dex
	bpl @5
	bra @7
@6:	lda #$40
	tsb p3_own
@7:	jsr X16_FixEntry
	plx
	jmp P_Patch             ; known programs' patches (serial.s)

jmpirq:	.byte $4C, <X16_IrqEntry, >X16_IrqEntry
jmpnmi:	.byte $4C, <X16_NmiEntry, >X16_NmiEntry

; the program's jsr: push the return address it would push, go to its
; target.  A, X, Y and the flags kept.
P3_Jsr:
	pha                     ; room for the return address
	pha
	php
	pha
	phx
	tsx
	lda p3_jret+1
	sta $0105,x
	lda p3_jret
	sta $0104,x
	plx
	pla
	plp
	jmp (p3_jtgt)

; the deskTop's clearing of $0334-$03C3, without the interrupt entry
; (X16_PatchAppl, x16io.s, points the deskTop's loop here)
X16_DTClear:
	php
	sei
	lda #0
	ldx #$90
@l:	sta $0333,x
	dex
	bne @l
	jsr X16_FixEntry
	plp
	lda #0
	ldx #0
	rts
