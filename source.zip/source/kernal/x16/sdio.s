; GEOS for the Commander X16: the blocks of the disk images
;
; The disk images stay on the X16's disk (SD card, or the emulator's host
; folder), opened by the boot code: drive A GEOSDISK on channel 2, drive B
; GEOSDSK2 on channel 3, drive C GEOSDSK3 on channel 4, each a D64 (a 1541
; disk) or a D81 (a 1581 disk).  drvx16.s calls H_SdRead or H_SdWrite here,
; in the helper bank, with interrupts off (X16_HCall), for block r1L/r1H
; (track/sector) of the current drive's image.
;
; Reads go through a cache of disk lines, one per RAM bank (X16_BANK_CACHE
; and up): a D64 track, or half a D81 track.  A line is read with one seek
; and MACPTR (x16io.s: X16_SdLine); GEOS fills a track with one file
; before it goes on to the next, so most blocks then come from RAM.
; Writes go to the file at once (X16_SdOut, through page $A000 of RAM bank
; X16_BANK_DBUF) and to the cached line, when there is one.
;
; Each image's last block is kept at $A100 + drive * $100 of RAM bank
; X16_BANK_DBUF: reading the last byte of a file makes the DOS close it
; (CMDR-DOS and x16emu alike), so that block is only ever written to the
; file.

.include "const.inc"
.include "geossym.inc"
.include "c64.inc"
.include "kernal.inc"
.include "x16.inc"

.setcpu "65SC02"

.import X16_SdLine, X16_SdOut, wt_ch, wt_sec, x16_wtok
.global H_SdRead, H_SdWrite, H_ChDev, H_RamOp, H_Mount, H_GetName
.global x16_dopen, x16_last, x16_dmap, x16_itype
.global sd_ptr, sd_rem, sd_t, sd_n, sd_bank

.segment "x16bss2"      ; low RAM ($9Exx), cleared at boot

x16_dopen:  .res 1      ; $80/$40/$20: image 0/1/2 (GEOSDISK.D64,
                        ; GEOSDSK2.D64, GEOSDSK3.D64) is open
x16_dmap:   .res 4      ; devices 8-11: their image (boot: 0, 1, 2, 3)
x16_itype:  .res 4      ; per image: DRV_1541 (a D64) or DRV_1581 (a D81)
x16_last:   .res 6      ; each drive's last block (lo, hi)
sd_ptr:     .res 2      ; X16_SdLine: where the next bytes go
sd_rem:     .res 2      ;             bytes still to read
sd_t:       .res 2      ;             bytes read by one MACPTR
sd_n:       .res 1      ;             blocks to read
sd_bank:    .res 1      ;             into this RAM bank
sd_tdrv:    .res X16_CACHE_SLOTS    ; per slot: drive + 1, 0: empty
sd_tline:   .res X16_CACHE_SLOTS    ;           its track (drvx16: sd_ln)
sd_next:    .res 1      ; the slot used last
sd_ls:      .res 2      ; SdBlock: the block's line: first block
sd_lc:      .res 1      ;          its blocks
sd_ln:      .res 1      ;          its number (the cache tag)
sd_pg:      .res 1      ;          the block's place in it

.segment "helper"

; block r1 of the current drive -> (r4).  X = error, Y = 0
H_SdRead:
	jsr SdPrep
	bcs SdFail
	jsr SdLook
	bcc @h
	jsr SdFill              ; not in the cache yet: read its line
	bcs SdErr
@h:	lda sd_pg
	ora #>$A000
	sta z8c
	stz z8b
	txa
	clc
	adc #X16_BANK_CACHE
	sta z8d
	ldx CPU_DDR
	ldy #0
@l:	lda z8d
	sta CPU_DDR
	lda (z8b),y
	stx CPU_DDR
	sta (r4),y
	iny
	bne @l
	ldx #0
	rts
SdFail:	ldy #0                  ; (X = the error)
	rts
SdErr:	ldx #DBLK_NOT_THERE     ; (the DOS gave less than the image holds)
	ldy #0
	rts

; (r4) -> block r1 of the current drive.  X = error, Y = 0
H_SdWrite:
	jsr SdPrep
	bcs SdFail
	lda x16_wtok
	and dbits,y
	bne @w
	ldx #WR_PR_ON           ; the file could only be opened for reading
	ldy #0
	rts
@w:	lda #>$A000             ; (r4) -> the block buffer -> the file
	ldx #X16_BANK_DBUF
	jsr SdPut
	jsr SdLast
	bne @o
	tya
	clc
	adc #>$A100
	ldx #X16_BANK_DBUF
	jsr SdPut               ; the last block: its copy too
@o:	phy
	jsr X16_SdOut
	ply
	jsr SdLook              ; and the cached line, when there is one
	bcs @x
	txa
	clc
	adc #X16_BANK_CACHE
	tax
	lda sd_pg
	ora #>$A000
	jsr SdPut
@x:	ldx #0
	ldy #0
	rts

; Y = the current drive's image (0-2), wt_ch = its channel, wt_sec = its
; block r1, and that block's cache line (SdBlock).  C = 1: X =
; DEV_NOT_FOUND (no image in that drive) or INV_TRACK (no such block)
SdPrep:
	ldy curDrive
	lda x16_dmap-8,y
	and #3
	tay
	ldx #DEV_NOT_FOUND
	lda x16_dopen
	and dbits,y
	beq @no
	jsr SdBlock
	ldx #INV_TRACK
	bcs @no
	tya
	clc
	adc #2
	sta wt_ch
	clc
	rts
@no:	sec
	rts

; block r1 (track/sector) of image Y -> wt_sec, and its cache line: sd_ls
; (its first block), sd_lc (its blocks), sd_ln (its number), sd_pg (the
; block's place in it).  A D64 line is a track; a D81 line is half a track
; (20 blocks: all 40 would not fit in a RAM bank).  C = 1: no such block.
; Y kept
SdBlock:
	ldx r1L
	beq @bad
	lda x16_itype,y
	cmp #DRV_1581
	beq @d81
	cpx #N_TRACKS+1
	bcs @bad
	lda TrackL,x
	sec
	sbc TrackL-1,x          ; the track's blocks
	sta sd_lc
	lda r1H
	cmp sd_lc
	bcs @bad
	sta sd_pg
	lda TrackL-1,x
	sta sd_ls
	clc
	adc r1H
	sta wt_sec
	lda TrackH-1,x
	sta sd_ls+1
	adc #0
	sta wt_sec+1
	dex
	stx sd_ln
	clc
	rts
@bad:	sec
	rts
@d81:	cpx #80+1
	bcs @bad
	lda r1H
	cmp #40
	bcs @bad
	dex                     ; line (track - 1) * 2, + 1 from sector 20 on
	txa
	asl a
	sta sd_ln
	lda r1H
	cmp #20
	bcc @1
	sbc #20
	inc sd_ln
@1:	sta sd_pg
	lda #20
	sta sd_lc
	lda sd_ln               ; its first block: line * 20
	stz sd_ls+1
	asl a
	rol sd_ls+1
	asl a
	rol sd_ls+1
	sta sd_ls               ; (* 4)
	ldx sd_ls+1
	asl a
	rol sd_ls+1
	asl a
	rol sd_ls+1             ; (* 16)
	clc
	adc sd_ls
	sta sd_ls
	txa
	adc sd_ls+1
	sta sd_ls+1
	lda sd_ls
	clc
	adc sd_pg
	sta wt_sec
	lda sd_ls+1
	adc #0
	sta wt_sec+1
	clc
	rts

; D64: each track's first block (35 tracks, and the end)
TrackL:
	.byte $00, $15, $2a, $3f, $54, $69, $7e, $93
	.byte $a8, $bd, $d2, $e7, $fc, $11, $26, $3b
	.byte $50, $65, $78, $8b, $9e, $b1, $c4, $d7
	.byte $ea, $fc, $0e, $20, $32, $44, $56, $67
	.byte $78, $89, $9a, $ab
TrackH:
	.byte $00, $00, $00, $00, $00, $00, $00, $00
	.byte $00, $00, $00, $00, $00, $01, $01, $01
	.byte $01, $01, $01, $01, $01, $01, $01, $01
	.byte $01, $01, $02, $02, $02, $02, $02, $02
	.byte $02, $02, $02, $02

dbits:	.byte $80, $40, $20, $00

; ChangeDiskDevice: the current drive's image goes to device sd_t (8-11).
; GEOS 2.0's deskTop uses it to swap drive C with drive A or B ("disk,
; open" while a disk is open); it moves the drive types itself
H_ChDev:
	ldx sd_t
	cpx #8
	bcc @no
	cpx #12
	bcs @no
	ldy curDrive
	lda x16_dmap-8,y
	sta x16_dmap-8,x
	stx curDrive
	stx curDevice
	ldx #0
	rts
@no:	ldx #DEV_NOT_FOUND
	rts

; GEOS-X16 call 10 (SD CARD's "Put it in a drive"): image X (0-2) is now the file r0
; names, opened by calypso.s's Mount job (with the X16 KERNAL in): its last
; block is at $BD00 of RAM bank X16_BANK_NET, Y = $80 when it opened
; read-only.  Its last-block copy, the open/write bits, and its name (for
; call 11, at $A400 + image * 64 of RAM bank X16_BANK_DBUF); its cached
; tracks go.  (Same type as before: the drive type stays.)
H_Mount:
	lda CPU_DDR
	pha
	lda r5L                 ; (r5: kept)
	pha
	lda r5H
	pha
	stx z8d
	txa                     ; the last block -> $A100 + image * $100
	clc
	adc #>$A100
	sta r5H
	stz r5L
	phy
	ldy #0
@c:	lda #X16_BANK_NET
	sta CPU_DDR
	lda $BD00,y
	ldx #X16_BANK_DBUF
	stx CPU_DDR
	sta (r5),y
	iny
	bne @c
	ldx z8d
	lda dbits,x
	tsb x16_dopen
	ply
	bmi @ro
	tsb x16_wtok
	bra @w
@ro:	trb x16_wtok
@w:	inx                     ; its tracks out of the cache
	txa
	ldy #X16_CACHE_SLOTS-1
@k:	cmp sd_tdrv,y
	bne :+
	lda #0
	sta sd_tdrv,y
	txa
:	dey
	bpl @k
	jsr NameAt              ; the name -> $A400 + image * 64
	ldy #0
@n:	lda (r0),y
	sta (r5),y
	beq @x
	iny
	cpy #63
	bne @n
	lda #0
	sta (r5),y
@x:	pla
	sta r5H
	pla
	sta r5L
	pla
	sta CPU_DDR
	rts

; call 11: image X's file name -> (r0) (0-terminated; "" when none)
H_GetName:
	lda CPU_DDR
	pha
	lda r5L                 ; (r5: kept)
	pha
	lda r5H
	pha
	stx z8d
	jsr NameAt
	ldy #0
@n:	lda (r5),y
	sta (r0),y
	beq @x
	iny
	cpy #63
	bne @n
	lda #0
	sta (r0),y
@x:	pla
	sta r5H
	pla
	sta r5L
	pla
	sta CPU_DDR
	rts

; r5 = image z8d's name in RAM bank X16_BANK_DBUF (switched in)
NameAt:
	lda #X16_BANK_DBUF
	sta CPU_DDR
	lda z8d                 ; (0-2: * 64 stays in one page)
	asl a
	asl a
	asl a
	asl a
	asl a
	asl a
	sta r5L
	lda #>$A400
	sta r5H
	rts

; Z = 1: wt_sec is the last block of drive Y's image
SdLast:
	tya
	asl a
	tax
	lda wt_sec
	cmp x16_last,x
	bne @1
	lda wt_sec+1
	cmp x16_last+1,x
@1:	rts

; X = the slot holding line sd_ln of drive Y.  C = 1: not in the cache
SdLook:
	iny
	sty z8d                 ; drive + 1
	dey
	ldx #X16_CACHE_SLOTS-1
@f:	lda sd_tdrv,x
	cmp z8d
	bne @n
	lda sd_tline,x
	cmp sd_ln
	beq @y
@n:	dex
	bpl @f
	sec
	rts
@y:	clc
	rts

; track sd_ln of drive Y (sd_lc blocks from block sd_ls) -> the next
; slot, X = that slot.  C = 1: read error
SdFill:
	ldx sd_next
	inx
	cpx #X16_CACHE_SLOTS
	bcc @1
	ldx #0
@1:	stx sd_next
	stz sd_tdrv,x           ; (empty while it is read)
	txa
	clc
	adc #X16_BANK_CACHE
	sta sd_bank
	phx
	lda sd_ls
	sta wt_sec
	lda sd_ls+1
	sta wt_sec+1
	lda sd_lc
	sta sd_n
	tya                     ; the track with the image's last block: up to
	asl a                   ; the block before it, and that one from its
	tax                     ; copy
	lda sd_ls
	clc
	adc sd_lc
	sta sd_t
	lda sd_ls+1
	adc #0
	sta sd_t+1
	lda sd_t
	bne @2
	dec sd_t+1
@2:	dec sd_t                ; the track's last block
	lda sd_t
	cmp x16_last,x
	bne @3
	lda sd_t+1
	cmp x16_last+1,x
	bne @3
	dec sd_n
@3:	lda sd_n
	beq @r
	phy
	jsr X16_SdLine          ; low RAM: the blocks -> sd_bank
	ply
	bcs @e
@r:	lda sd_n
	cmp sd_lc
	beq @ok
	tya                     ; page sd_n of the slot <- the last block's
	clc                     ; copy
	adc #>$A100
	sta z8c
	stz z8b
	lda sd_n
	ora #>$A000
	sta z8f
	stz z8e
	ldx CPU_DDR
	phy
	ldy #0
@c:	lda #X16_BANK_DBUF
	sta CPU_DDR
	lda (z8b),y
	pha
	lda sd_bank
	sta CPU_DDR
	pla
	sta (z8e),y
	iny
	bne @c
	ply
	stx CPU_DDR
@ok:	plx
	iny
	tya
	dey
	sta sd_tdrv,x
	lda sd_ln
	sta sd_tline,x
	clc
	rts
@e:	plx
	sec
	rts

; (r4) -> page A of RAM bank X.  Y kept
SdPut:
	sta z8c
	stz z8b
	stx z8d
	phy
	ldx CPU_DDR
	ldy #0
@l:	lda (r4),y
	pha
	lda z8d
	sta CPU_DDR
	pla
	sta (z8b),y
	stx CPU_DDR
	iny
	bne @l
	ply
	rts

;---------------------------------------------------------------------------
; DoRAMOp (StashRAM, FetchRAM, SwapRAM, VerifyRAM): GEOS's RAM expansion
; is X16 banked RAM, X16_REU_SIZE banks of 64K (8 RAM banks each) from RAM
; bank X16_BANK_REU.  GEOS 2.0 wants one for a third drive: its deskTop
; only looks for drive C when ramExpSize is not 0.
; Y = operation (low bits: 0 stash, 1 fetch, 2 swap, 3 verify), r0 = C64
; address, r1 = address in the expansion, r2 = bytes, r3L = its 64K bank.
; X = 0, DEV_NOT_FOUND (no such bank, or the C64 side goes past $BFFF: the
; kernel banks are not mapped here) or WR_VER_ERR (verify: they differ).
; r0-r3 kept.
;---------------------------------------------------------------------------
H_RamOp:
	ldx #DEV_NOT_FOUND
	lda r3L
	cmp ramExpSize
	bcs @no
	tya
	and #3
	sta z8b                 ; the operation
	lda r2L
	ora r2H
	beq @no                 ; (0 = 64K)
	clc                     ; the C64 side ends at $C000 at most
	lda r0L
	adc r2L
	tay
	lda r0H
	adc r2H
	bcs @no
	cmp #>$C000
	bcc @ok
	bne @no
	cpy #0
	beq @ok
@no:	rts
@ok:	ldx #5
@sv:	lda r0L,x
	pha
	dex
	bpl @sv
	lda r3L                 ; expansion address -> RAM bank, $A000-$BFFF
	asl a
	asl a
	asl a
	sta z8c
	lda r1H
	lsr a
	lsr a
	lsr a
	lsr a
	lsr a
	clc
	adc z8c
	adc #X16_BANK_REU
	sta z8c
	lda r1H
	and #$1F
	ora #>$A000
	sta r1H
	lda CPU_DDR
	sta z8d                 ; GEOS's RAM bank: the C64's $A000-$BFFF
	ldy #0
@l:	lda z8d
	sta CPU_DDR
	lda (r0),y
	tax
	lda z8c
	sta CPU_DDR
	lda z8b
	beq @st
	lsr a
	bcs @fv
	lda (r1),y              ; swap
	pha
	txa
	sta (r1),y
	pla
	tax
	bcc @toc                ; (C = 0)
@st:	txa                     ; stash
	sta (r1),y
	bra @nx
@fv:	bne @ve
	lda (r1),y              ; fetch
	tax
@toc:	lda z8d
	sta CPU_DDR
	txa
	sta (r0),y
	bra @nx
@ve:	txa                     ; verify
	cmp (r1),y
	bne @df
@nx:	inc r0L
	bne @1
	inc r0H
@1:	inc r1L
	bne @2
	inc r1H
	lda r1H
	cmp #>$C000
	bne @2
	lda #>$A000
	sta r1H
	inc z8c
@2:	lda r2L
	bne @3
	dec r2H
@3:	dec r2L
	lda r2L
	ora r2H
	bne @l
	ldx #0
	.byte $2c
@df:	ldx #WR_VER_ERR
	lda z8d
	sta CPU_DDR
	ldy #0
@rs:	pla
	sta r0L,y
	iny
	cpy #6
	bne @rs
	rts
