; GEOS for the Commander X16: input driver ($FE80, in the kernel mirror
; banks).  The driver itself is in low RAM (x16io.s), so its state is the
; same whichever mirror bank is mapped when the kernel calls it.

.import X16MouseInit
.import X16SlowMouse
.import X16UpdateMouse

.segment "inputdrv"

MouseInit:
	jmp X16MouseInit
SlowMouse:
	jmp X16SlowMouse
UpdateMouse:
	jmp X16UpdateMouse
SetMouse:
	rts
	.byte "X16 SMC MOUSE"
