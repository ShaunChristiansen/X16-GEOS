; GEOS for the Commander X16: the serial port (TexElec's serial and network
; card) for terminal programs, and the patches that point them at it.
;
; The card has a TL16C2550: two 16550-type UARTs, at $9FE0 (wired to its
; ESP32 WiFi modem, Zimodem firmware) and $9FE8 (the DB9 RS-232 port), with
; a 14.7456 MHz crystal (divisor = 921600 / baud).  The UART is used
; directly, without interrupts: 8N1, FIFOs on, auto RTS/CTS (the ESP32, or
; a modem, waits while the receive FIFO is full).  Received bytes go into a
; 512-byte ring here: when a program asks for one, and once a frame from the
; VSYNC interrupt (prn.s: Tick).  Programs reach it through the GEOS-X16
; calls at $FF7D (prn.s: Ext), A = the call:
;   2  open: X = a baud code (no card at the address: nothing happens, and
;      the other calls do nothing either: no bytes, no carrier)
;      (geoTelnet's: 0 300, 1 1200, 2 2400, 3 4800,
;      4 7200, 5 9600, 6 14400, 7 19200).  The WiFi port always runs at
;      115200 (the ESP32's own speed); the DB9 port at that rate, unless
;      GEOSSER.CFG names another.  (Open again: the new rate)
;   3  close (DTR and RTS off)
;   4  send X (waits while the UART's FIFO is full; gives up after ~0.1 s)
;   5  receive: C = 0 and A = the byte, or C = 1 and A = 0 (none yet)
;   6  carrier: A = $10 (Z = 0) when DCD is on, else A = 0 (Z = 1)
;   7  pump: X/Y = a program's own receive buffer (6 bytes there: the
;      buffer's address, the address of its write index, of its read index;
;      256 bytes, full when write + 1 = read); received bytes then go
;      straight into it, as the program's own NMI routine put them.  Y = 0:
;      back to the ring
;   8  pump now (the program is about to read its buffer)
; GEOSSER.CFG (boot.s) sets ser_port (0 WiFi, 1 DB9) and ser_div (a
; divisor, 0: the program's rate).
;
; The Calypso card instead (calypso.s, RAM bank X16_BANK_NET): when its
; NET.BIN loaded at boot (net_ok) and there is no TexElec card, or
; GEOSSER.CFG says CALYPSO (ser_force), open picks it, and the calls go to
; calypso.s.  The carrier (asked from programs' interrupts) is answered
; here, from what calypso.s said last.
;
; Patches: after every ReadFile (X16_P3Grab, compat.s) PatchScan looks
; through the table below: where memory holds a known program's bytes,
; they are replaced.  The program on the disk is not changed.

.include "x16.inc"

.setcpu "65SC02"

.import Back, e_a, e_x, e_y, e_c
.global SerCall, SerDrain, PatchScan, ser_port, ser_div, ser_base
.global net_ok, ser_force, CalGo

UART    = $9F00                 ; + ser_base ($E0 or $E8) + register
U_RBR   = UART + 0              ; (DLL with DLAB)
U_THR   = UART + 0
U_IER   = UART + 1              ; (DLM with DLAB)
U_FCR   = UART + 2
U_LCR   = UART + 3
U_MCR   = UART + 4
U_LSR   = UART + 5
U_MSR   = UART + 6
U_SCR   = UART + 7              ; scratch: is a UART there?
RING    = $BE00                 ; 512 bytes (prn.s: BUF stops below)
CPU_DDR = $00                   ; the X16's RAM bank

.segment "prnram"

; the serial calls (A = 2-6), from Ext
SerCall:
	sec
	sbc #2
	asl a
	tax
	beq @t                  ; (open: picks again)
	lda ser_kind
	beq @t
	cpx #(6-2)*2
	beq CStat               ; the Calypso's carrier: from here
	cpx #(7-2)*2
	beq @t                  ; (pump: both)
	txa                     ; the Calypso's: calypso.s
	lsr a
	clc
	adc #2
	ldx e_x
	ldy s_frame
	jsr CalGo
	jmp Back
@t:	jmp (ser_tab,x)

CStat:	lda c_car
	sta e_a
	jmp Back

; calypso.s's call A (X, Y): A -> e_a, C -> e_c, Y: the carrier.  Through a
; trampoline in zero page $1C-$2B (kept), interrupts off
CalGo:
	php
	sei
	sta cg_a
	stx cg_x
	sty cg_y
	ldx #15
:	lda $1C,x
	sta cg_zs,x
	lda tramp,x
	sta $1C,x
	dex
	bpl :-
	lda cg_a
	ldx cg_x
	ldy cg_y
	jsr $001C
	sta e_a
	sty c_car
	lda #0
	rol a
	sta e_c
	ldx #15
:	lda cg_zs,x
	sta $1C,x
	dex
	bpl :-
	plp
	rts
tramp:	pha                     ; (16 bytes, run at $1C)
	lda #X16_BANK_NET
	sta CPU_DDR
	pla
	jsr NET_CODE
	pha
	lda #X16_BANK_PRN
	sta CPU_DDR
	pla
	rts

; open the Calypso: X = its port, Y = its DB9 speed code
COpen:
	lda #1
	sta ser_kind
	stz ser_open            ; (no UART)
	ldy #0
	lda ser_div+1
	bne @go                 ; (slower than 9600)
	lda ser_div
	beq @app
@sp:	cmp cspd,y
	bcs @go
	iny
	cpy #7
	bne @sp
	bra @go
@app:	lda e_x                 ; the program's: 14400, 19200 -> 19200
	cmp #6
	bcc @go
	iny
@go:	ldx ser_port
	lda #2
	jsr CalGo
	jmp Back
cspd:	.byte 96, 48, 24, 16, 8, 4, 2   ; divisors: 9600 .. 460800
ser_tab: .word SOpen, SClose, SPut, SGet, SStat, SPump, SNow

; 2: open, X = a baud code
SOpen:
	lda ser_kind            ; (the Calypso open: closed first)
	beq :+
	lda #3
	jsr CalGo
	stz ser_kind
:	bit ser_force           ; GEOSSER.CFG: CALYPSO
	bpl SOpenU
	bit net_ok
	bpl :+
	jmp COpen
:	stz ser_open
	jmp Back
SOpenU:	lda ser_port
	beq @wifi
	lda #$E8                ; DB9
	sta ser_base
	lda ser_div
	ora ser_div+1
	beq @code
	lda ser_div
	ldy ser_div+1
	bra @set
@code:	lda e_x
	cmp #8
	bcc :+
	lda #5                  ; (9600)
:	tax
	lda divl,x
	ldy divh,x
	bra @set
@wifi:	lda #$E0
	sta ser_base
	lda ser_div             ; (a GEOSSER.CFG speed for the ESP32 too)
	ldy ser_div+1
	bne @set
	cmp #0
	bne @set
	lda #8                  ; 115200
	ldy #0
@set:	ldx ser_base
	pha
	lda #$55                ; a UART there? (its scratch register keeps
	sta U_SCR,x             ; what is written; nothing there: open bus)
	cmp U_SCR,x
	bne @none
	lda #$AA
	sta U_SCR,x
	cmp U_SCR,x
	beq @card
@none:	pla                     ; no card: the Calypso, if it is there,
	bit net_ok              ; or the calls do nothing
	bpl :+
	jmp COpen
:	stz ser_open
	jmp Back
@card:	lda #$80                ; DLAB
	sta U_LCR,x
	pla
	sta U_RBR,x             ; divisor
	tya
	sta U_IER,x
	lda #$03                ; 8N1
	sta U_LCR,x
	lda #$87                ; FIFOs on and empty, receive trigger 8
	sta U_FCR,x
	stz U_IER,x             ; no interrupts
	lda #$23                ; DTR, RTS, auto flow control (OUT1/2 off:
	sta U_MCR,x             ;   the card's option pins stay high)
	stz r_rd
	stz r_rd+1
	stz r_wr
	stz r_wr+1
	lda #$80
	sta ser_open
	jmp Back
divl:	.byte <3072, <768, <384, <192, <128, <96, <64, <48
divh:	.byte >3072, >768, >384, >192, >128, >96, >64, >48

; 3: close
SClose:
	bit ser_open
	bpl :+
	ldx ser_base
	stz U_MCR,x
	stz ser_open
:	jmp Back

; 4: send X
SPut:
	bit ser_open
	bpl @x
	ldx ser_base
	stz s_t
	stz s_t+1
@w:	lda U_LSR,x
	and #$20                ; THRE: room
	bne @go
	inc s_t
	bne @w
	inc s_t+1
	lda s_t+1
	cmp #4
	bne @w
	bra @x                  ; (CTS stayed off: dropped)
@go:	lda e_x
	sta U_THR,x
@x:	jmp Back

; 5: receive
SGet:
	jsr SerDrain
	lda r_rd
	cmp r_wr
	bne @b
	lda r_rd+1
	cmp r_wr+1
	bne @b
	stz e_a                 ; none
	lda #1
	sta e_c
	jmp Back
@b:	lda r_rd+1
	clc
	adc #>RING
	sta @ld+2
	ldx r_rd
@ld:	lda RING,x
	sta e_a
	inc r_rd
	bne :+
	lda r_rd+1
	eor #1
	sta r_rd+1
:	jmp Back

; 6: carrier
SStat:
	stz e_a
	bit ser_open
	bpl @x
	ldx ser_base
	lda U_MSR,x
	bpl @x
	lda #$10
	sta e_a
@x:	jmp Back

; 7: pump into a program's buffer (X/Y), or not (Y = 0)
SPump:
	lda e_y
	sta pm_on
	beq @x
	sta @d+2
	lda e_x
	sta @d+1
	ldy #5
@d:	lda $FFFF,y
	sta pm_desc,y
	dey
	bpl @d
	lda pm_desc             ; the buffer, its write and read index
	sta pm_st+1
	lda pm_desc+1
	sta pm_st+2
	lda pm_desc+2
	sta pm_w1+1
	sta pm_w2+1
	sta pm_w3+1
	lda pm_desc+3
	sta pm_w1+2
	sta pm_w2+2
	sta pm_w3+2
	lda pm_desc+4
	sta pm_r+1
	lda pm_desc+5
	sta pm_r+2
@x:	bit net_ok              ; the Calypso's too
	bpl :+
	lda #7
	ldx e_x
	ldy e_y
	jsr CalGo
:	jmp Back

; 8: pump now
SNow:
	jsr SerDrain
	jmp Back

; the UART's received bytes -> the ring, while it has room (the rest wait in
; the FIFO: auto RTS holds the sender), or into the program's own buffer
; (SPump).  From SGet, SNow and the VSYNC interrupt
SerDrain:
	inc s_frame             ; (the Calypso: once a frame, calypso.s)
	bit ser_open
	bpl @x
	ldx ser_base
	lda pm_on
	bne Pump
@l:	lda U_LSR,x
	lsr a
	bcc @x                  ; nothing more
	lda r_wr                ; full? (wr + 1 = rd)
	clc
	adc #1
	tay
	lda r_wr+1
	adc #0
	and #1
	cmp r_rd+1
	bne @in
	cpy r_rd
	beq @x
@in:	lda r_wr+1
	clc
	adc #>RING
	sta @st+2
	ldy r_wr
	lda U_RBR,x
@st:	sta RING,y
	inc r_wr
	bne @l
	lda r_wr+1
	eor #1
	sta r_wr+1
	bra @l
@x:	rts

; -> the program's buffer, while it has room.  X = ser_base
Pump:
	lda U_LSR,x
	lsr a
	bcc PumpX
pm_w1:	ldy $FFFF               ; write index + 1 = read index: full
	iny
pm_r:	cpy $FFFF
	beq PumpX
pm_w2:	ldy $FFFF
	lda U_RBR,x
pm_st:	sta $FFFF,y
pm_w3:	inc $FFFF
	bra Pump
PumpX:	rts

ser_open: .byte 0
ser_kind: .byte 0               ; 1: the Calypso (calypso.s)
ser_force: .byte 0              ; $80: GEOSSER.CFG says CALYPSO
net_ok:	.byte 0                 ; $80: its NET.BIN is loaded (boot.s)
c_car:	.byte 0                 ; its carrier, as calypso.s said last
s_frame: .byte 0
cg_a:	.byte 0
cg_x:	.byte 0
cg_y:	.byte 0
cg_zs:	.res 16
pm_on:	.byte 0                 ; SPump: the program's buffer, not the ring
pm_desc: .res 6
ser_base: .byte $E0
ser_port: .byte 0               ; 0 WiFi ($9FE0), 1 DB9 ($9FE8)
ser_div:  .word 0               ; GEOSSER.CFG's divisor (0: none)
r_rd:	.word 0                 ; the ring: next to read, next to write
r_wr:	.word 0
s_t:	.word 0

;---------------------------------------------------------------------------
; the patches (RAM bank X16_BANK_NET with calypso.s: prn.s's Patch calls
; them through CalGo, calypso.s's call 10)
;---------------------------------------------------------------------------
.segment "netram"

PatchScan:
	lda #<patches
	sta PByte+1
	lda #>patches
	sta PByte+2
@e:	jsr PByte               ; address (0: the end)
	sta p_a
	jsr PByte
	sta p_a+1
	ora p_a
	beq @x
	lda p_a
	sta @cmp+1
	sta @put+1
	lda p_a+1
	sta @cmp+2
	sta @put+2
	jsr PByte               ; the bytes there now
	sta p_n
	stz p_ok
	ldx #0
@c:	jsr PByte
@cmp:	cmp $FFFF,x
	beq :+
	dec p_ok                ; (differs)
:	inx
	cpx p_n
	bne @c
	jsr PByte               ; the new bytes
	sta p_n
	ldx #0
@n:	jsr PByte
	bit p_ok
	bmi :+
@put:	sta $FFFF,x
:	inx
	cpx p_n
	bne @n
	bra @e
@x:	rts
PByte:	lda $FFFF               ; the next table byte (address set above)
	inc PByte+1
	bne :+
	inc PByte+2
:	rts

p_a:	.word 0
p_n:	.byte 0
p_ok:	.byte 0

; each: address, n, the n bytes there, m, the m bytes that replace them
patches:
	.include "apppatch.inc"
	.word 0
