; GEOS by Berkeley Softworks
; reverse engineered by Maciej Witkowiak, Michael Steil
;
; Commander X16 disk image driver, for D64 images (a 1541) and D81 images
; (a 1581): one driver serves every drive, and goes by curType.  The
; directory code is the Commodore 1541 and 1581 drivers' (drv1541.s,
; drv1581.s); the block level I/O is new: each block is read from and
; written to the image file on the X16's disk (sdio.s), so changes are
; kept.  The BAM routines are in the helper bank (bam.s), for want of
; room here: a 1581's dir3Head ($9C80-$9D7F) must stay free, as GEOS
; 2.0's deskTop uses it.

.include "const.inc"
.include "geossym.inc"
.include "geosmac.inc"
.include "config.inc"
.include "kernal.inc"
.include "jumptab.inc"
.include "c64.inc"
.include "x16.inc"

.import X16_HCall, sd_t

dir3Head = $9C80                ; a 1581's BAM, tracks 41-80

.segment "drvx16"

_InitForIO:
	.word __InitForIO
_DoneWithIO:
	.word __DoneWithIO
_ExitTurbo:
	.word __ExitTurbo
_PurgeTurbo:
	.word __PurgeTurbo
_EnterTurbo:
	.word __EnterTurbo
_ChangeDiskDevice:
	.word __ChangeDiskDevice
_NewDisk:
	.word __NewDisk
_ReadBlock:
	.word __ReadBlock
_WriteBlock:
	.word __WriteBlock
_VerWriteBlock:
	.word __VerWriteBlock
_OpenDisk:
	.word __OpenDisk
_GetBlock:
	.word __GetBlock
_PutBlock:
	.word __PutBlock
_GetDirHead:
	.word __GetDirHead
_PutDirHead:
	.word __PutDirHead
_GetFreeDirBlk:
	.word __GetFreeDirBlk
_CalcBlksFree:
	.word __CalcBlksFree
_FreeBlock:
	.word __FreeBlock
_SetNextFree:
	.word __SetNextFree
_FindBAMBit:
	.word __FindBAMBit
_NxtBlkAlloc:
	.word __NxtBlkAlloc
_BlkAlloc:
	.word __BlkAlloc
_ChkDkGEOS:
	.word __ChkDkGEOS
_SetGEOSDisk:
	.word __SetGEOSDisk

Get1stDirEntry:
	jmp _Get1stDirEntry
GetNxtDirEntry:
	jmp _GetNxtDirEntry
GetBorder:
	jmp _GetBorder
AddDirBlock:
	jmp _AddDirBlock
ReadBuff:
	jmp _ReadBuff
WriteBuff:
	jmp _WriteBuff
	jmp DUNK4_2
	jmp GetDOSError
AllocateBlock:
	jmp _AllocateBlock
ReadLink:
	jmp _ReadLink

; C = 1: the current drive is a 1581.  A = its directory track
DirTrk:
	lda curType
	and #%00001111
	cmp #DRV_1581
	lda #DIR_TRACK
	bcc @1
	lda #DIR_1581_TRACK
@1:	rts

; r1 = the first directory block: 18/1, or 40/3 on a 1581
DirStart:
	jsr DirTrk
	sta r1L
	lda #1
	bcc @1
	lda #3
@1:	sta r1H
	rts

; GetDirHead, PutDirHead: 1541 block 18/0 <-> curDirHead; 1581 blocks
; 40/0, 40/1 and 40/2 <-> curDirHead, dir2Head and dir3Head
__PutDirHead:
	lda #<__PutBlock
	.byte $2c
__GetDirHead:
	lda #<__GetBlock
	sta DHop+1
	jsr DirTrk
	sta r1L
	lda #1
	bcc @1
	lda #3
@1:	sta DHn
	ldy #0
DHl:	sty r1H
	lda DHlo,y
	sta r4L
	lda DHhi,y
	sta r4H
	tya
	pha
DHop:	jsr __GetBlock          ; (or __PutBlock)
	pla
	tay
	txa
	bne DHx
	iny
	cpy DHn
	bne DHl
DHx:	rts
DHlo:	.byte <curDirHead, <dir2Head, <dir3Head
DHhi:	.byte >curDirHead, >dir2Head, >dir3Head
DHn:	.byte 0
.assert >__GetBlock = >__PutBlock, error, "GetDirHead: __GetBlock, __PutBlock"

_ReadBuff:
	LoadW r4, diskBlkBuf
__GetBlock:
	jsr EnterTurbo
	bnex GetBlk0
	jsr InitForIO
	jsr ReadBlock
	jsr DoneWithIO
GetBlk0:
	rts

_WriteBuff:
	LoadW r4, diskBlkBuf
__PutBlock:
	jsr EnterTurbo
	bnex PutBlk1
	jsr InitForIO
	jsr WriteBlock
	bnex PutBlk0
	jsr VerWriteBlock
PutBlk0:
	jsr DoneWithIO
PutBlk1:
	rts

__OpenDisk:
	ldy curDrive
	lda _driveType,y
	sta tmpDriveType
	and #%10111111
	sta _driveType,y
	jsr NewDisk
	bnex OpenDsk1
	jsr GetDirHead
	bnex OpenDsk1
	LoadW r5, curDirHead
	jsr ChkDkGEOS
	LoadW r4, curDirHead+OFF_DISK_NAME
	ldx #r5
	jsr GetPtrCurDkNm
	ldx #r4
	ldy #r5
	lda #18
	jsr CopyFString
	ldx #0
OpenDsk1:
	lda tmpDriveType
	ldy curDrive
	sta _driveType,y
	rts
tmpDriveType:
	.byte 0

__BlkAlloc:
	jsr DirTrk              ; from track 1, on a 1581 from track 39 down
	lda #1
	bcc @1
	lda #$27
@1:	sta r3L
	lda #0
	sta r3H
__NxtBlkAlloc:
	PushW r9
	PushW r3
	LoadW r3, $00fe
	ldx #r2
	ldy #r3
	jsr Ddiv
	lda r8L
	beq BlkAlc0
	inc r2L
	bne BlkAlc0
	inc r2H
BlkAlc0:
	LoadW r5, curDirHead
	jsr CalcBlksFree
	PopW r3
	ldx #INSUFF_SPACE
	CmpW r2, r4
	beq BlkAlc1
	bcs BlkAlc4
BlkAlc1:
	MoveW r6, r4
	MoveW r2, r5
BlkAlc2:
	jsr SetNextFree
	bnex BlkAlc4
	ldy #0
	lda r3L
	sta (r4),y
	iny
	lda r3H
	sta (r4),y
	AddVW 2, r4
	lda r5L
	bne @X
	dec r5H
@X:	dec r5L
	lda r5L
	ora r5H
	bne BlkAlc2
	ldy #0
	tya
	sta (r4),y
	iny
	lda r8L
	bne BlkAlc3
	lda #$fe
BlkAlc3:
	clc
	adc #1
	sta (r4),y
	ldx #0
BlkAlc4:
	PopW r9
	rts

_Get1stDirEntry:
	jsr DirStart
	jsr ReadBuff
	LoadW r5, diskBlkBuf+FRST_FILE_ENTRY
	lda #0
	sta borderFlag
	rts

_GetNxtDirEntry:
	ldx #0
	ldy #0
	AddVW $20, r5
	CmpWI r5, diskBlkBuf+$ff
	bcc GNDirEntry1
	ldy #$ff
	MoveW diskBlkBuf, r1
	bne GNDirEntry0
	lda borderFlag
	bne GNDirEntry1
	lda #$ff
	sta borderFlag
	jsr GetBorder
	bnex GNDirEntry1
	tya
	bne GNDirEntry1
GNDirEntry0:
	jsr ReadBuff
	ldy #0
	LoadW r5, diskBlkBuf+FRST_FILE_ENTRY
GNDirEntry1:
	rts

_GetBorder:
	jsr GetDirHead
	bnex GetBord2
	LoadW r5, curDirHead
	jsr ChkDkGEOS
	bne GetBord0
	ldy #$ff
	bne GetBord1
GetBord0:
	MoveW curDirHead+OFF_OP_TR_SC, r1
	ldy #0
GetBord1:
	ldx #0
GetBord2:
	rts

__ChkDkGEOS:
	ldy #OFF_GS_ID
	ldx #0
	LoadB isGEOS, 0
ChkDkG0:
	lda (r5),y
	cmp GEOSDiskID,x
	bne ChkDkG1
	iny
	inx
	cpx #11
	bne ChkDkG0
	LoadB isGEOS, $ff
ChkDkG1:
	lda isGEOS
	rts

GEOSDiskID:
	.byte "GEOS format V1.0",NULL

__GetFreeDirBlk:
	php
	sei
	PushB r6L
	PushW r2
	ldx r10L
	inx
	stx r6L
	jsr DirStart
GFDirBlk0:
	jsr ReadBuff
GFDirBlk1:
	bnex GFDirBlk5
	dec r6L
	beq GFDirBlk3
GFDirBlk11:
	lda diskBlkBuf
	bne GFDirBlk2
	jsr AddDirBlock
	bra GFDirBlk1
GFDirBlk2:
	sta r1L
	MoveB diskBlkBuf+1, r1H
	bra GFDirBlk0
GFDirBlk3:
	ldy #FRST_FILE_ENTRY
	ldx #0
GFDirBlk4:
	lda diskBlkBuf,y
	beq GFDirBlk5
	tya
	addv $20
	tay
	bcc GFDirBlk4
	LoadB r6L, 1
	ldx #FULL_DIRECTORY
	ldy r10L
	iny
	sty r10L
	cpy #$12
	bcc GFDirBlk11
GFDirBlk5:
	PopW r2
	PopB r6L
	plp
	rts

_AddDirBlock:
	PushW r6
	ldx #FULL_DIRECTORY
	jsr DirTrk              ; blocks free on the directory track?
	lda curDirHead+$48
	bcc @1
	lda dir2Head+$fa
@1:	beq ADirBlk0
	MoveW r1, r3
	jsr SetNextFree
	MoveW r3, diskBlkBuf
	jsr WriteBuff
	bnex ADirBlk0
	MoveW r3, r1
	jsr ClearAndWrite
ADirBlk0:
	PopW r6
	rts

ClearAndWrite:
	lda #0
	tay
CAndWr0:
	sta diskBlkBuf,y
	iny
	bne CAndWr0
	dey
	sty diskBlkBuf+1
	jmp WriteBuff

; the BAM routines: bam.s, in the helper bank
__SetNextFree:
	lda #<H_SETNEXTFREE
	.byte $2c
_AllocateBlock:
	lda #<H_ALLOCATEBLOCK
	.byte $2c
__FindBAMBit:
	lda #<H_FINDBAMBIT
	.byte $2c
__FreeBlock:
	lda #<H_FREEBLOCK
	.byte $2c
__CalcBlksFree:
	lda #<H_CALCBLKSFREE
	jmp X16_HCall

__SetGEOSDisk:
	jsr GetDirHead
	bnex SetGDisk2
	LoadW r5, curDirHead
	jsr CalcBlksFree
	ldx #INSUFF_SPACE
	lda r4L
	ora r4H
	beq SetGDisk2
	jsr DirTrk              ; the border block: from track 19, or 40/18
	ldy #0
	bcc @1
	lda #DIR_1581_TRACK-1
	ldy #$12
@1:	sta r3L
	inc r3L
	sty r3H
	jsr SetNextFree
	beqx SetGDisk0
	LoadB r3L, 1
	jsr SetNextFree
	bnex SetGDisk2
SetGDisk0:
	MoveW r3, r1
	jsr ClearAndWrite
	bnex SetGDisk2
	MoveW r1, curDirHead+OFF_OP_TR_SC
	ldy #OFF_GS_ID+15
	ldx #15
SetGDisk1:
	lda GEOSDiskID,x
	sta curDirHead,y
	dey
	dex
	bpl SetGDisk1
	jsr PutDirHead
SetGDisk2:
	rts


;---------------------------------------------------------------------------
; X16 block level I/O
;---------------------------------------------------------------------------

__InitForIO:
	php
	pla
	sta tmpPS
	sei
	lda CPU_DATA
	sta tmpCPU_DATA
	rts

__DoneWithIO:
	sei
	lda tmpCPU_DATA
	sta CPU_DATA
	lda tmpPS
	pha
	plp
	rts

__EnterTurbo:
__ExitTurbo:
__PurgeTurbo:
__NewDisk:
GetDOSError:
DUNK4_2:
GiveNoError:
	ldx #0
	rts

; the current drive's image -> device A (deskTop: swapping drive C in)
__ChangeDiskDevice:
	sta sd_t
	lda #<H_CHDEV           ; sdio.s, in the helper bank
	jmp X16_HCall

; block r1 <-> (r4): sdio.s, in the helper bank
__ReadBlock:
_ReadLink:
	lda #<H_SDREAD
	.byte $2c
__WriteBlock:
	lda #<H_SDWRITE
	jmp X16_HCall

__VerWriteBlock:
	ldx #0
	rts

tmpPS:
	.byte 0
tmpCPU_DATA:
	.byte 0
borderFlag:
	.byte 0
