; GEOS for the Commander X16: hardware support
;
; Lives in low RAM after the RAM disk driver ($9xxx), so it can switch the
; ROM bank ($01) and the RAM bank ($00) freely.
;
;   X16_IRQStart / X16_IRQEnd   called by the kernel's IRQ handler (the
;                    VERA VSYNC interrupt) with CPU_DATA = $35, i.e. the
;                    mirror bank with the C64 I/O shadow at $D000-$DFFF
;   keyboard         SMC (I2C $42) key numbers -> GEOS key codes, queued
;                    with the kernel's own KbdScanHelp2; GEOS's own key
;                    repeat (KbdQueFlag/KbdNextKey) is kept
;   mouse            SMC PS/2 packets; input driver entry points for $FE80
;   screen           the C64 bitmap at $A000 (RAM bank $2F) and the colour
;                    matrix ($8C00) are converted to two VERA tile layers by
;                    code in cartridge bank 33, the rows drawn into first
;   sprites          VIC sprite registers (shadow) -> VERA sprites
;   colours          the VIC border colour -> VERA
;   clock            CIA1 TOD registers (shadow) tick in software
;   disk             write-through of RAM disk blocks to GEOSDISK.D64
;                    via the X16 KERNAL (state swapped in and out)

.include "const.inc"
.include "geossym.inc"
.include "geosmac.inc"
.include "config.inc"
.include "kernal.inc"
.include "c64.inc"
.include "x16.inc"

.setcpu "65SC02"         ; after geosmac.inc: its "bra" macro must exist first

.import KbdScanHelp2
.import _GetScanLine
.import KbdQueFlag
.import KbdQueHead
.import KbdQueTail
.import KbdNextKey
.import dateCopy
.import _IRQHandler

.global X16_IRQStart, X16_IRQEnd
.global X16_PatchDA
.global X16_KernalIrq, X16_PatchAppl, X16_IrqEntry, X16_NmiEntry, X16_P3Build
.global X16_Poke, X16_DateCopy
.global X16_Reboot, X16_ExitToBasic, CloseAll
.global X16_SdLine, X16_SdOut, X16_HCall, X16_KRun, wt_ch, wt_sec
.import P_Tick
.global x16_c64rom, X16_C64On, X16_C64Off, X16_C64On2, X16_C64Off2
.import sd_ptr, sd_rem, sd_t, sd_n, sd_bank
.global X16MouseInit, X16SlowMouse, X16UpdateMouse
.global x16_rtc, x16_msize, x16_wtok, x16_drv2
.global kbmods, kbcaps, x16_dirty
.global X16_DirtyFill, X16_DirtyMove, X16_FontScan
.global c64pal_gb, c64pal_r
.global x16_desk, x16_wpok, x16_scrok, snd_menu, snd_dlg, snd_close
.import X16_PatZS, X16_PatGC, X16_FixEntry, X16_DTClear, p3_own, p3_exec, zs_save
.global kcode, mpkt, mvalid, msumx, msumy, mbtns, todacc, joybtn

H_Frame         = $C000         ; helper bank entry points
H_SprConvert    = $C003
H_KeyDecode     = $C006
H_P3Build       = $C009
H_SmcPoll       = $C00C
H_SmcReset      = $C00F

ZPK_FIRST       = $80           ; zero page swapped for X16 KERNAL calls
ZPK_LAST        = $A8
DIRTY_COPIES    = 2             ; frames a row is converted after drawing
TOD_STEP        = 11010         ; 65536 * 10 / 59.52 Hz: tenths per frame

.segment "x16bss"

x16_rtc:        .res 8          ; X16 clock: year-1900 month day h m s
x16_msize:      .res 1          ; mouse packet size (3, or 4 with a wheel)
x16_wtok:       .res 1          ; $80/$40/$20: drive A/B/C image writable
x16_drv2:       .res 1          ; $80: drive B (GEOSDSK2.D64) there
wt_ch:          .res 1
hc_a:           .res 1          ; X16_HCall: A from the helper bank
x16_c64rom:     .res 1          ; $80: BASIC.BIN and KERNAL.BIN are loaded
c64_p:          .res 1          ; X16_C64On2: P and the ROM bank to go back to
c64_d:          .res 1
irqbank00:      .res 1
kcode:          .res 1
mpkt:           .res 4
mvalid:         .res 1
msumx:          .res 2
msumy:          .res 2
mbtns:          .res 1
joybtn:         .res 1          ; bit 0: an SNES controller's A or B (joy.s)
kpolls:         .res 1
rawhead:        .res 1
rawtail:        .res 1
maccx:          .res 1
maccy:          .res 1
mbutton:        .res 1
kbheld:         .res 1
kbmods:         .res 1
kbcaps:         .res 1
todacc:         .res 2
x16_desk:       .res 1          ; $80: the deskTop is the application
x16_wpok:       .res 1          ; $80: a wallpaper is loaded
snd_menu:       .res 1          ; sound requests (snd.s): menu, dialog box,
snd_dlg:        .res 1          ;   dialog box closed (a DEC each from the
snd_close:      .res 1          ;   kernel: nonzero = wanted)
x16_scrok:      .res 1          ; 0: the helper's screen state needs a reset
lastbrd:        .res 1
x16_dirty:      .res 32         ; per card row: frames left to copy it
sprsum:         .res 16
sprkey:         .res 8
kc_bank:        .res 1
wt_sec:         .res 2
wt_dd:          .res 1
dr_end:         .res 2
dr_off:         .res 2
dr_tmp:         .res 1
pa_end:         .res 2

.segment "x16io"

;---------------------------------------------------------------------------
; interrupt entry.  On the X16 the vector pull maps ROM bank 0, whose
; vectors lead to RAM: IRQ/BRK -> $038B, NMI -> $03B7 (normally the X16
; KERNAL's trampolines).  GEOS puts its own entries there; reading $01
; still gives the bank that was mapped when the interrupt came (the RAM
; copy of the bank register), so writing it back maps it again.
; deskTop clears $0334-$03C3 when it starts (with interrupts off), so the
; entries are put back before every "cli" of the main loop (X16_FixEntry,
; compat.s, which also deals with programs that load into page 3).
;---------------------------------------------------------------------------

; StartAppl, the program in memory: the GEOS 2.0 deskTop clears
; $0334-$03C3 (its variables) when it starts, and again when a desk
; accessory has run, then with interrupts on: the clearing loop is replaced
; by a call to X16_DTClear, which keeps the interrupt entry.  (The deskTop
; does not read the bytes at $038B-$038D or $03B7-$03B9.)
X16_PatchAppl:
	lda r0L
	pha
	lda r0H
	pha
	stz x16_desk            ; the deskTop?  (its pattern below)
	lda fileHeader+O_GHST_ADDR
	sta r0L
	lda fileHeader+O_GHST_ADDR+1
	sta r0H
	cmp #>$0400             ; loaded at $0400 or above: none of its bytes
	bcc pa_scan             ; are in page 3 (X16_P3Grab, compat.s)
	stz p3_own
	jsr X16_FixEntry
	bra pa_scan
; LdDeskAcc, the desk accessory in memory: the same patches (the
; calculator does its maths with the C64's BASIC ROM: X16_PatGC)
X16_PatchDA:
	lda r0L
	pha
	lda r0H
	pha
	lda fileHeader+O_GHST_ADDR
	sta r0L
	lda fileHeader+O_GHST_ADDR+1
	sta r0H
pa_scan:
	lda fileHeader+O_GHEND_ADDR     ; to the end address; for a VLIR
	ldx fileHeader+O_GHEND_ADDR+1   ; program (start - 1 there) and above
	cmp r0L                         ; $8000: to $8000
	txa
	sbc r0H
	bcc @v
	cpx #$80
	bcc @s
@v:	lda #0
	ldx #$80
@s:	sta pa_end
	stx pa_end+1
@l:	lda (r0)
	cmp dtpat
	beq @d                  ; $A2: the deskTop's loop, geoCalc's swap?
	cmp #$A5                ; geoCalc's switches to BASIC's ROM and back?
	beq @g
	cmp #$78
	bne @n
@g:	jsr X16_PatGC           ; (compat.s)
	bra @n
@d:	ldy #dtpat_end - dtpat - 1
@c:	lda (r0),y
	cmp dtpat,y
	bne @z
	dey
	bpl @c
	lda #$80
	sta x16_desk
	ldy #0                  ; jsr X16_DTClear, then nops
	lda #$20
	sta (r0),y
	iny
	lda #<X16_DTClear
	sta (r0),y
	iny
	lda #>X16_DTClear
	sta (r0),y
	lda #$EA
@f:	iny
	sta (r0),y
	cpy #dtpat_end - dtpat - 1
	bne @f
	bra @n
@z:	jsr X16_PatZS           ; geoCalc's zero page swap (compat.s)
@n:	inc r0L
	bne @e
	inc r0H
@e:	lda r0L
	cmp pa_end
	lda r0H
	sbc pa_end+1
	bcc @l
	pla
	sta r0H
	pla
	sta r0L
	rts

dtpat:	.byte $A2, $90, $A9, $00, $9D, $33, $03, $CA, $D0, $FA
dtpat_end:


; An interrupt has mapped ROM bank 0, whose IRQ vector is $038B: a program
; loaded into page 3 that runs into its own code at $038B has a mirror bank
; mapped there instead (compat.s).
X16_IrqEntry:
	php
	pha
	lda $FFFF
	eor #>$038B
	bne @p
	lda CPU_DATA
	sta CPU_DATA            ; the interrupted mirror bank again
	pla
	plp
	jmp _IRQHandler
@p:	pla                     ; the program's own bytes there
	plp
	jmp p3_exec

X16_NmiEntry:
	pha
	lda CPU_DATA
	sta CPU_DATA
	pla
	rti

; CINV of the X16 KERNAL state used for the disk write-through: an
; interrupt while the KERNAL runs is only acknowledged (GEOS's own
; handler gets the next frame's)
X16_KernalIrq:
	lda #1
	sta VERA_ISR
	ply
	plx
	pla
	rti

;---------------------------------------------------------------------------
; IRQ, first part: before the kernel's interrupt routines
;---------------------------------------------------------------------------
X16_IRQStart:
	lda CPU_DDR
	sta irqbank00
	lda #X16_BANK_GEOSRAM   ; the interrupt may come during RAM disk I/O
	sta CPU_DDR
	lda #1
	sta VERA_ISR            ; acknowledge VSYNC
	stz cia1base+13         ; no CIA interrupt flags in the shadow
	jsr TodTick
	; key repeat, as the C64 keyboard scan does it (not while key events
	; are still waiting: the key may have been released already)
	lda rawhead
	cmp rawtail
	bne @1
	lda KbdQueFlag
	bne @1
	lda KbdNextKey
	jsr KbdScanHelp2
	lda #15
	sta KbdQueFlag
@1:	; SMC -> raw key event queue: up to 6 events a frame
	lda #6
	sta kpolls
@p:	ldx rawtail
	inx
	cpx rawhead
	beq @f                  ; queue full: the events wait in the SMC
	jsr SmcPoll
	lda kcode
	beq @f
	ldx #X16_BANK_KSAVE
	stx CPU_DDR
	ldx rawtail
	sta X16_RAWQ,x
	inc rawtail
	ldx #X16_BANK_GEOSRAM
	stx CPU_DDR
	dec kpolls
	bne @p
@f:	; raw key events -> GEOS, while its key queue has room for a key
	; (GEOS keeps 15 keys; this queue holds 255 events more while an
	; application is busy)
	ldx rawhead
	cpx rawtail
	beq @2
	lda KbdQueTail
	inc a
	and #15
	cmp KbdQueHead
	beq @2
	lda #X16_BANK_KSAVE
	sta CPU_DDR
	lda X16_RAWQ,x
	ldy #X16_BANK_GEOSRAM
	sty CPU_DDR
	inc rawhead
	sta kcode
	jsr KeyEvent
	bra @f
@2:	jmp P_Tick              ; the printer's idle time (c64kernal.s)

;---------------------------------------------------------------------------
; IRQ, last part: after the kernel has positioned the sprites
;---------------------------------------------------------------------------
X16_IRQEnd:
	stz VERA_CTRL           ; ADDRSEL = 0, DCSEL = 0
	jsr Colours
	jsr Sprites
	jsr Refresh
	lda irqbank00
	sta CPU_DDR
	rts

;---------------------------------------------------------------------------
; CIA1 time of day clock (BCD, 12 hours + PM flag), in the I/O shadow
;---------------------------------------------------------------------------
TodTick:
	clc
	lda todacc
	adc #<TOD_STEP
	sta todacc
	lda todacc+1
	adc #>TOD_STEP
	sta todacc+1
	bcc @x
	lda cia1base+8
	inc a
	cmp #10
	bcc @t
	stz cia1base+8
	sed
	lda cia1base+9
	clc
	adc #1
	cmp #$60
	bcc @s
	stz cia1base+9
	lda cia1base+10
	clc
	adc #1
	cmp #$60
	bcc @m
	stz cia1base+10
	lda cia1base+11
	and #$80
	sta r0L
	lda cia1base+11
	and #$1F
	clc
	adc #1
	cmp #$12
	bne @h1
	tax
	lda r0L
	eor #$80                ; 11 -> 12 switches AM/PM
	sta r0L
	txa
@h1:	cmp #$13
	bne @h2
	lda #1
@h2:	ora r0L
	sta cia1base+11
	cld
	rts
@m:	sta cia1base+10
	cld
	rts
@s:	sta cia1base+9
	cld
	rts
@t:	sta cia1base+8
@x:	rts

; call the helper bank's entry $C0xx (A = xx) with interrupts off.  A, X
; and Y come back from it (N and Z go by A)
X16_HCall:
	sta @j+1
	php
	sei
	lda CPU_DATA
	pha
	lda #X16_BANK_HELPER
	sta CPU_DATA
@j:	jsr $C000
	sta hc_a
	pla
	sta CPU_DATA
	plp
	lda hc_a
	rts

; geoCalc's maths (X16_PatGC in compat.s puts the calls in): its "lda #$37
; / sta $01" (BASIC and KERNAL ROM in) and "lda $2FF3 / sta $01" (its
; saved $01 back).  BASIC's RAM bank goes in at $A000, the C64 view
; (GEOS's $C000-$DFFF, then the C64 KERNAL) at $C000; interrupts are off
; meanwhile (geoCalc's own sei)
X16_C64On:
	lda #X16_BANK_C64BAS    ; (without the ROM files: a bank of RTS, see
	sta CPU_DDR             ; LoadRoms in boot.s)
	bit x16_c64rom
	bpl :+
	lda #X16_BANK_C64VIEW
	sta CPU_DATA
:	rts
; the calculator's: the same, with its own "lda $01 / ora #$02 / sta $01"
; and "lda $01 / and #$FD / sta $01" (interrupts are on there: off
; meanwhile, the C64 KERNAL has the interrupt vectors)
X16_C64On2:
	php
	sei
	pla
	sta c64_p
	lda CPU_DATA
	sta c64_d
	bra X16_C64On
X16_C64Off2:
	lda #X16_BANK_GEOSRAM
	sta CPU_DDR
	lda c64_d
	sta CPU_DATA
	lda c64_p
	pha
	plp
	rts
X16_C64Off:
	lda #X16_BANK_GEOSRAM
	sta CPU_DDR
	lda $2FF3
	sta CPU_DATA
	rts

; p3_exec from the program's bytes at $038B (compat.s)
X16_P3Build:
	lda #<H_P3Build
	bra X16_HCall

;---------------------------------------------------------------------------
; SMC: one key code and one mouse packet (helper bank)
;---------------------------------------------------------------------------
SmcPoll:
	lda CPU_DATA
	pha
	lda #X16_BANK_HELPER
	sta CPU_DATA
	jsr H_SmcPoll
	pla
	sta CPU_DATA
	rts

;---------------------------------------------------------------------------
; keyboard: A = SMC key code (IBM key number, +$80 = released)
;---------------------------------------------------------------------------
KeyEvent:
	cmp #$7F                ; extended key prefixes
	beq @x
	cmp #$FF
	beq @x
	and #$7F
	tay
	ldx #(modtab_end - modtab - 1)
@m:	cmp modtab,x
	beq @mod
	dex
	bpl @m
	lda kcode
	bmi @release
	cpy kbheld
	beq @x                  ; typematic repeat: GEOS repeats by itself
	jsr KeyDecode
	bcs @x
	sty kbheld
	sta KbdNextKey
	ldx #15
	stx KbdQueFlag
	jmp KbdScanHelp2
@release:
	cpy kbheld
	bne @x
	stz kbheld
	lda #$FF
	sta KbdQueFlag
	stz KbdNextKey
@x:	rts
@mod:	lda modbit,x
	bit kcode
	bmi @up
	cpy #30                 ; caps lock toggles
	beq @caps
	tsb kbmods
	rts
@up:	trb kbmods
	rts
@caps:	lda kbcaps
	eor #$FF
	sta kbcaps
	rts

; shift: bits 0-1, ctrl: bits 2-3, C= (Alt or the Windows keys): bits 4-6
modtab:	.byte 44, 57, 58, 64, 60, 62, 59, 63, 30
modtab_end:
modbit:	.byte $01, $02, $04, $08, $10, $20, $40, $40, $00

; Y = key number -> A = GEOS key code; C = 1: no such key (helper bank)
KeyDecode:
	lda CPU_DATA
	pha
	lda #X16_BANK_HELPER
	sta CPU_DATA
	jsr H_KeyDecode
	tax
	pla
	sta CPU_DATA
	txa
	rts

;---------------------------------------------------------------------------
; mouse: input driver entry points (jumped to from $FE80)
;---------------------------------------------------------------------------
X16MouseInit:
	LoadW mouseXPos, 8
	LoadB mouseYPos, 8
	stz maccx
	stz maccy
	stz mvalid
	lda #$80
	sta mbutton
X16SlowMouse:
	rts

X16UpdateMouse:
	bit mouseOn             ; MOUSEON_BIT = 7
	bpl @x
	lda mvalid
	bne @1
@x:	rts
@1:	php                     ; take the movement the IRQ has added up
	sei
	stz mvalid
	lda msumx
	sta r0L
	lda msumx+1
	sta r0H
	lda msumy
	sta r1L
	lda msumy+1
	sta r1H
	stz msumx
	stz msumx+1
	stz msumy
	stz msumy+1
	lda mbtns
	ora joybtn              ; (an SNES controller's A or B: joy.s)
	plp
	; left button: mouseData $80 = released, $00 = pressed
	and #1
	eor #1
	lsr a
	ror a
	cmp mbutton
	beq @mv
	sta mbutton
	sta mouseData
	smbf MOUSE_BIT, pressFlag
@mv:	stz r3L                 ; direction bits for inputData
	; X: 9 bit signed, halved (x16emu: 2 host pixels per GEOS pixel)
	ldx #r0
	ldy #maccx-maccx
	jsr Halve
	lda r0L
	ora r0H
	beq @y
	lda #4                  ; right
	bit r0H
	bpl @xr
	lda #8                  ; left
@xr:	sta r3L
	clc
	lda mouseXPos
	adc r0L
	sta mouseXPos
	lda mouseXPos+1
	adc r0H
	sta mouseXPos+1
@y:	ldx #r1                 ; Y: up is positive
	ldy #maccy-maccx
	jsr Halve
	lda r1L
	ora r1H
	beq @dir
	lda #2                  ; up
	bit r1H
	bpl @yu
	lda #1                  ; down
@yu:	tsb r3L
	; beyond the top or the bottom is left to the kernel's CheckMsePos,
	; which clamps and sets OFFTOP_BIT / OFFBOTTOM_BIT (228-255 = above)
	sec
	lda mouseYPos
	sbc r1L
	sta r2L
	lda #0
	sbc r1H
	bmi @y0
	bne @ymax
	lda r2L
	cmp #228
	bcc @yst
@ymax:	lda #227
	bra @yst
@y0:	lda #$FF
@yst:	sta mouseYPos
@dir:	ldx r3L
	lda mseDirTab,x
	sta inputData
	rts

; zp word at X += accumulator (bit 0) at maccx+Y, then halved
Halve:
	clc
	lda 0,x
	adc maccx,y
	sta 0,x
	lda 1,x
	adc #0
	sta 1,x
	lda 0,x
	and #1
	sta maccx,y
	lda 1,x
	cmp #$80
	ror 1,x
	ror 0,x
	rts

mseDirTab:
	.byte $ff, $06, $02, $ff, $00, $07, $01, $ff
	.byte $04, $05, $03, $ff, $ff, $ff, $ff, $ff

;---------------------------------------------------------------------------
; colours: the VIC border colour (palette entry 16*c+1 = C64 colour c; the
; screen's colours are the helper bank's business)
;---------------------------------------------------------------------------
Colours:
	lda extclr
	and #$0F
	cmp lastbrd
	beq @x
	sta lastbrd
	asl a
	asl a
	asl a
	asl a
	ora #1
	stz VERA_CTRL
	sta VERA_DC_BORDER
@x:	rts

c64pal_gb: .byte $00, $FF, $33, $AA, $48, $84, $27, $C7, $52, $30, $65, $44, $66, $C8, $6B, $99
c64pal_r:  .byte $00, $0F, $06, $07, $07, $05, $03, $0B, $07, $04, $09, $04, $06, $09, $06, $09

;---------------------------------------------------------------------------
; sprites: VIC registers (I/O shadow) -> VERA sprites 0-7
;   data   VRAM_SPRDATA + n * $800 (room for 64x64 4bpp), rebuilt only when
;          the 63 bytes or the expansion bits change
;---------------------------------------------------------------------------
Sprites:
	stz r0L
@l:	ldx r0L
	lda #$01 | VERA_INC_1
	sta VERA_ADDR_H
	lda #>(VRAM_SPRATTR & $FFFF)
	sta VERA_ADDR_M
	txa
	asl a
	asl a
	asl a
	sta VERA_ADDR_L         ; attribute block of sprite n
	lda mobenble
	and bittab,x
	bne @on
	lda VERA_ADDR_L
	ora #6
	sta VERA_ADDR_L
	stz VERA_DATA0          ; Z depth 0: off
	jmp @next
@on:	jsr SprData             ; (sets VERA address again when it converts)
	ldx r0L
	lda #$01 | VERA_INC_1
	sta VERA_ADDR_H
	lda #>(VRAM_SPRATTR & $FFFF)
	sta VERA_ADDR_M
	txa
	asl a
	asl a
	asl a
	sta VERA_ADDR_L
	; 0-1: address >> 5 = VRAM_SPRDATA >> 5 + n*$40, 4bpp
	txa
	lsr a
	ror a
	ror a
	and #$C0
	sta VERA_DATA0
	txa
	lsr a
	lsr a
	clc
	adc #>(VRAM_SPRDATA >> 5)
	sta VERA_DATA0
	; the mouse pointer (sprite 0, not expanded) has an outline: its
	; image is 1 pixel right and down in the VERA sprite (see helper.s)
	stz r7L
	txa
	bne @no
	lda mobx2
	ora moby2
	lsr a
	bcs @no
	inc r7L
@no:	; 2-3: X - 24
	txa
	asl a
	tay                     ; Y = 2n
	lda msbxpos
	and bittab,x
	cmp #1                  ; C = MSB of X
	lda #0
	rol a
	sta r1H
	lda #24
	clc
	adc r7L
	sta r7H
	sec
	lda mob0xpos,y
	sbc r7H
	sta VERA_DATA0
	lda r1H
	sbc #0
	and #3
	sta VERA_DATA0
	; 4-5: Y - 50
	lda #50
	clc
	adc r7L
	sta r7H
	sec
	lda mob0ypos,y
	sbc r7H
	sta VERA_DATA0
	lda #0
	sbc #0
	and #3
	sta VERA_DATA0
	; 6: Z depth: in front, or behind the bitmap's set pixels (layer 1)
	lda mobprior
	and bittab,x
	beq @z3
	lda #$08
	bra @z
@z3:	lda #$0C
@z:	sta VERA_DATA0
	; 7: size (32 or 64 when expanded) and colour
	lda #$A0
	ldy mobx2
	pha
	tya
	and bittab,x
	beq @nx
	pla
	ora #$10
	pha
@nx:	lda moby2
	and bittab,x
	beq @ny
	pla
	ora #$40
	pha
@ny:	lda mob0clr,x
	and #$0F
	sta r1H
	pla
	ora r1H
	sta VERA_DATA0
@next:	inc r0L
	lda r0L
	cmp #8
	beq @done
	jmp @l
@done:	rts

bittab:	.byte 1, 2, 4, 8, 16, 32, 64, 128

; sprite r0L: checksum its data; convert it when it changed
SprData:
	ldx r0L
	lda COLOR_MATRIX+$3F8,x ; sprite pointer: data at $8000 + 64 * ptr
	stz r1L
	lsr a
	ror r1L
	lsr a
	ror r1L
	ora #$80
	sta r1H
	stz r2L                 ; mode: bit 0 X expanded, bit 1 Y expanded
	lda mobx2
	and bittab,x
	beq @1
	inc r2L
@1:	lda moby2
	and bittab,x
	beq @2
	lda #2
	tsb r2L
@2:	ldy #62
	lda r2L
	sta r6L
	sta r6H
@c:	lda (r1),y
	clc
	adc r6L
	sta r6L
	clc
	adc r6H
	sta r6H
	dey
	bpl @c
	txa
	asl a
	tay
	lda r2L
	ora #$80
	cmp sprkey,x
	bne @conv
	lda r6L
	cmp sprsum,y
	bne @conv
	lda r6H
	cmp sprsum+1,y
	beq @x
@conv:	lda r2L
	ora #$80
	sta sprkey,x
	lda r6L
	sta sprsum,y
	lda r6H
	sta sprsum+1,y
	jmp SprConvert
@x:	rts

; convert sprite r0L from (r1), mode r2L (helper bank)
SprConvert:
	lda CPU_DATA
	pha
	lda #X16_BANK_HELPER
	sta CPU_DATA
	jsr H_SprConvert
	pla
	sta CPU_DATA
	rts

;---------------------------------------------------------------------------
; screen: the helper bank converts the bitmap and the colour matrix
;---------------------------------------------------------------------------
; Rows GEOS has drawn into are marked in x16_dirty (by GetScanLine, which
; the kernel and applications use to find a line's address, and by
; FillRam/MoveData into the screen); each is converted in the next
; DIRTY_COPIES frames, so drawing that ends after the first conversion
; shows too.  One more row per frame covers anything drawn some other way.
Refresh:
	lda CPU_DATA
	pha
	lda #X16_BANK_HELPER
	sta CPU_DATA
	jsr H_Frame
	pla
	sta CPU_DATA
	rts

; The font code (Font_2) gets a character's first line from here; then
; FontPutChar walks down its other lines itself (adding 320 at each card
; row), so the card rows below the first are marked here too.
; X = r1H = the first line, r10H = the number of lines.
X16_FontScan:
	jsr _GetScanLine
	bit dispBufferOn
	bpl @x                  ; not drawing on the screen
	phy
	lda r1H
	ldy r10H
	beq @d
@m:	cmp #200                ; each line's card row
	bcs @d
	pha
	lsr a
	lsr a
	lsr a
	tax
	lda #DIRTY_COPIES
	sta x16_dirty,x
	pla
	inc a
	dey
	bne @m
@d:	ply
@x:	rts

; FillRam (r1 = address, r0 = count) and MoveData (r1 = target,
; r2 = count) into the screen bitmap: mark the rows
X16_DirtyFill:
	php
	pha
	phx
	phy
	ldx #r1
	ldy #r0
	bra DirtyRange
X16_DirtyMove:
	php
	pha
	phx
	phy
	ldx #r1
	ldy #r2
DirtyRange:
	; end = start + count - 1 -> dr_end
	clc
	lda 0,x
	adc 0,y
	sta dr_end
	lda 1,x
	adc 1,y
	sta dr_end+1
	lda dr_end
	bne @1
	dec dr_end+1
@1:	dec dr_end
	; no overlap with $A000-$BF3F?
	lda dr_end+1
	cmp #$A0
	bcc @o
	lda 1,x
	cmp #$BF
	bcc @2
	bne @o
	lda 0,x
	cmp #$40
	bcc @2
@o:	jmp @x
@2:	; first row: (max(start, $A000) - $A000) / 320
	lda 1,x
	sec
	sbc #$A0
	bcs @3
	lda #0                  ; starts below the screen
	sta dr_off
	sta dr_off+1
	bra @4
@3:	sta dr_off+1
	lda 0,x
	sta dr_off
@4:	ldx #0
@5:	lda dr_off              ; while off >= 320: off -= 320, row++
	sec
	sbc #<320
	tay
	lda dr_off+1
	sbc #>320
	bcc @6
	sta dr_off+1
	sty dr_off
	inx
	cpx #25
	bcc @5
@6:	; last row from the end address (clamped to the screen)
	lda dr_end+1
	cmp #$C0
	bcc @7
	lda #24
	bra @9
@7:	sec
	sbc #$A0
	sta dr_off+1
	lda dr_end
	sta dr_off
	ldy #0
@8:	lda dr_off
	sec
	sbc #<320
	sta dr_tmp
	lda dr_off+1
	sbc #>320
	bcc @8x
	sta dr_off+1
	lda dr_tmp
	sta dr_off
	iny
	cpy #24
	bcc @8
@8x:	tya
@9:	sta dr_tmp              ; mark rows X..dr_tmp
	lda #DIRTY_COPIES
@10:	sta x16_dirty,x
	cpx dr_tmp
	inx
	bcc @10
@x:	ply
	plx
	pla
	plp
	rts


;---------------------------------------------------------------------------
; store A at address X/Y in every kernel mirror bank (kernel RAM that is
; written at run time)
;---------------------------------------------------------------------------
X16_Poke:
	php
	sei
	stx @w+1
	sty @w+2
	ldx CPU_DATA
	phx
	ldx #X16_BANK_RAMVIEW
@l:	stx CPU_DATA
@w:	sta $FFFF
	inx
	cpx #X16_BANK_RAMVIEW + X16_NUM_MIRRORS
	bne @l
	plx
	stx CPU_DATA
	plp
	rts

; dateCopy ($C018-$C01A) follows year/month/day in every mirror bank
X16_DateCopy:
	ldy #2
@1:	lda year,y
	cmp dateCopy,y
	beq @2
	phy
	pha
	tya
	clc
	adc #<dateCopy
	tax
	lda #>dateCopy
	adc #0
	tay
	pla
	jsr X16_Poke
	ply
@2:	dey
	bpl @1
	rts

;---------------------------------------------------------------------------
; disk images (sdio.s).  The boot code left the image files open (channels
; 2-4 for drives A-C, modify or read mode; command channel 15).  The X16 KERNAL's
; zero page and $0200-$03FF are swapped in around the calls.  Interrupts
; off.
;
; X16_SdLine: sd_n blocks (1-32) from block wt_sec of the image on channel
; wt_ch -> $A000 of RAM bank sd_bank, with MACPTR.  C = 1: not all read
;---------------------------------------------------------------------------
X16_SdLine:
	jsr SdEnter
	ldx wt_ch
	jsr K_CHKIN
	stz sd_ptr
	lda #>$A000
	sta sd_ptr+1
	stz sd_rem
	lda sd_n
	sta sd_rem+1
@m:	lda sd_rem+1
	beq @lt
	cmp #2
	lda #0                  ; 512 bytes or more left: up to 512 (x16emu: 256)
	bcs @go
	lda #255
	bra @go
@lt:	lda sd_rem
	beq @ok                 ; all read
@go:	ldx sd_bank
	stx CPU_DDR
	ldx sd_ptr
	ldy sd_ptr+1
	clc
	jsr K_MACPTR
	bcs @x                  ; no MACPTR
	stx sd_t
	sty sd_t+1
	txa
	ora sd_t+1
	sec
	beq @x                  ; nothing more: the file ended
	clc
	lda sd_ptr
	adc sd_t
	sta sd_ptr
	lda sd_ptr+1
	adc sd_t+1
	sta sd_ptr+1
	sec
	lda sd_rem
	sbc sd_t
	sta sd_rem
	lda sd_rem+1
	sbc sd_t+1
	sta sd_rem+1
	bra @m
@ok:	clc
@x:	php
	jsr K_CLRCHN
	jsr SdLeave
	plp
	rts

; X16_SdOut: page $A000 of RAM bank X16_BANK_DBUF -> block wt_sec of the
; image on channel wt_ch
X16_SdOut:
	jsr SdEnter
	ldx wt_ch
	jsr K_CHKOUT
	ldy #0
@l:	lda #X16_BANK_DBUF
	sta CPU_DDR
	lda $A000,y
	phy
	jsr K_CHROUT
	ply
	iny
	bne @l
	jsr K_CLRCHN
	stz wt_sec              ; then the start of the file: the DOS writes
	stz wt_sec+1            ; its buffer back (x16emu: the seek flushes)
	jsr WtSeek
SdLeave:
	jsr SwapToGeos
	lda wt_dd
	sta CPU_DDR
	lda kc_bank
	sta CPU_DATA
	rts

; banks kept, X16 KERNAL state, ROM bank 0, then the seek
SdEnter:
	jsr KEnter
; "P" chr$(channel) <32 bit position: block wt_sec * 256> on channel 15
WtSeek:
	ldx #15
	jsr K_CHKOUT
	lda #'P'
	jsr K_CHROUT
	lda wt_ch
	jsr K_CHROUT
	lda #0
	jsr K_CHROUT
	lda wt_sec
	jsr K_CHROUT
	lda wt_sec+1
	jsr K_CHROUT
	lda #0
	jsr K_CHROUT
	jmp K_CLRCHN

; banks kept, X16 KERNAL state in, ROM bank 0
KEnter:
	lda CPU_DATA
	sta kc_bank
	lda CPU_DDR
	sta wt_dd
	jsr SwapToKernal
	stz CPU_DATA
	rts

; X16_KRun: prn.s's PRN_KJOB (RAM bank X16_BANK_PRN) with the X16 KERNAL
; in, called from that bank with interrupts off
X16_KRun:
	jsr KEnter
	lda #X16_BANK_PRN
	sta CPU_DDR
	jsr PRN_KJOB
	jmp SdLeave

; the X16 KERNAL's $02-$FF and $0200-$03FF, snapshot at boot, are kept in
; RAM bank $2E: $A000-$A2FF; GEOS's own are kept at $A300-$A5FF while the
; KERNAL runs
; The X16 KERNAL's file I/O uses zero page $80-$9B (KERNAL, DOS, FAT32;
; $9C-$A8 is kept for growth), its variables and RAM code in $0200-$03FF,
; and RAM bank 0.  $02-$7F belong to the program, $A9-$FF to BASIC.
SwapToKernal:
	lda #X16_BANK_KSAVE
	sta CPU_DDR
	ldx #ZPK_LAST
@1:	lda $00,x
	sta $A300,x
	lda $A000,x
	sta $00,x
	dex
	cpx #ZPK_FIRST-1
	bne @1
	ldx #0
@2:	lda $0200,x
	sta $A400,x
	lda $A100,x
	sta $0200,x
	lda $0300,x
	sta $A500,x
	lda $A200,x
	sta $0300,x
	inx
	bne @2
	rts

SwapToGeos:
	lda #X16_BANK_KSAVE
	sta CPU_DDR
	ldx #ZPK_LAST
@1:	lda $00,x
	sta $A000,x
	lda $A300,x
	sta $00,x
	dex
	cpx #ZPK_FIRST-1
	bne @1
	ldx #0
@2:	lda $0200,x
	sta $A100,x
	lda $A400,x
	sta $0200,x
	lda $0300,x
	sta $A200,x
	lda $A500,x
	sta $0300,x
	inx
	bne @2
	rts

;---------------------------------------------------------------------------
; leaving GEOS: SMC reset.  The cartridge boots GEOS again, unless the
; quit marker at $0400 (kept by a reset) asks for X16 BASIC.
;---------------------------------------------------------------------------
X16_ExitToBasic:
	sei
	ldx #7
@1:	lda quitmagic,x
	sta $0400,x
	dex
	bpl @1
	bra CloseAll
X16_Reboot:
	sei
	stz $0400
CloseAll:                       ; close the disk image files first
	jsr SwapToKernal
	stz CPU_DATA
	lda #2
	jsr K_CLOSE
	lda #3
	jsr K_CLOSE
	lda #4
	jsr K_CLOSE
	lda #5                  ; a print file (prn.s)
	jsr K_CLOSE
	lda #15
	jsr K_CLOSE
	sei
SmcReset:
	lda #X16_BANK_HELPER
	sta CPU_DATA
	jmp H_SmcReset

quitmagic: .byte "GEOSQUIT"

