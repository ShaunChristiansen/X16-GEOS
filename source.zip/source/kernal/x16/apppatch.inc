; geoTelnet 1.3 (Bo Zimmerman, 2017): its C64 program (record 1, at $1795),
; whose MODmodem library (user-port RS-232) becomes calls to the serial
; port (serial.s).  Function names from MODmodem's source.
	.word $211E		; ComInit: baud A3L ($72) and flow A3H ($73) kept, then open (and CLI, as it did)
	.byte 8, $20, $B0, $21, $A5, $72, $20, $73, $23
	.byte 18, $A5, $72, $8D, $A2, $24, $AA, $A5, $73, $8D, $9E, $24, $A9, $02, $20, $7D, $FF, $58, $60
	.word $2189		; ComUninst: close (CLI, as it did)
	.byte 8, $78, $A5, $01, $48, $A9, $35, $85, $01
	.byte 8, $A9, $03, $20, $7D, $FF, $58, $18, $60
	.word $21BE		; ComReInit: open again at CLL2Baud (CLI)
	.byte 8, $78, $A5, $01, $48, $A9, $35, $85, $01
	.byte 10, $AE, $A2, $24, $A9, $02, $20, $7D, $FF, $58, $60
	.word $21EB		; ComDisable: nothing to stop (no NMIs)
	.byte 8, $20, $6D, $24, $AD, $91, $24, $30, $FB
	.byte 2, $18, $60
	.word $2209		; ComEnable
	.byte 8, $A5, $01, $48, $A9, $35, $85, $01, $AD
	.byte 2, $18, $60
	.word $2235		; ComOnline: carrier
	.byte 8, $A5, $01, $48, $A9, $35, $85, $01, $AD
	.byte 5, $A9, $06, $4C, $7D, $FF
	.word $224A		; ComSend: X kept (at $2257)
	.byte 8, $08, $48, $AD, $91, $24, $30, $FB, $78
	.byte 14, $8E, $57, $22, $AA, $A9, $04, $20, $7D, $FF, $AE, $57, $22, $60, $00
	.word $2357		; ComSPut: no raster wait, ComSend
	.byte 8, $08, $48, $A5, $01, $48, $A9, $35, $85
	.byte 3, $4C, $4A, $22
	.word $2373		; CLL2BSet: the new rate
	.byte 8, $8D, $A2, $24, $0A, $0A, $A8, $A9, $24
	.byte 9, $8D, $A2, $24, $AA, $A9, $02, $4C, $7D, $FF
	.word $23A9		; IsNTSC: NTSC (no raster test)
	.byte 8, $A9, $00, $F0, $03, $C9, $01, $60, $78
	.byte 2, $A9, $01
	.word $241A		; ComGet: receive
	.byte 8, $AD, $92, $24, $CD, $93, $24, $D0, $04
	.byte 5, $A9, $05, $4C, $7D, $FF
	.word $2449		; ComFlon: auto RTS does it
	.byte 8, $48, $2C, $9E, $24, $10, $15, $A5, $01
	.byte 1, $60
	.word $246D		; ComFloff
	.byte 8, $48, $2C, $9E, $24, $10, $15, $A5, $01
	.byte 1, $60
	.word $3242		; FixBaud: up to 48 bytes a frame (mdmRdRate), not (baud code + 1) * 2
	.byte 8, $AD, $A2, $24, $18, $69, $01, $0A, $8D
	.byte 7, $A9, $30, $EA, $EA, $EA, $EA, $EA

; GeoTerm64 2.0: its user-port RS-232 driver (the C64 KERNAL's NMI way,
; record 0 at $0400, record 9 at $3C00) becomes calls to the serial port.
; Its receive buffer stays: serial.s pumps the UART's bytes into it.
	.word $0448		; get: through $0513 (pump first)
	.byte 8, $78, $98, $48, $8A, $48, $AC, $49, $7F
	.byte 5, $4C, $13, $05, $EA, $EA
	.word $0487		; (receive on, $0481): nothing
	.byte 8, $A9, $35, $85, $01, $AD, $4C, $7F, $29
	.byte 3, $4C, $2F, $04
	.word $04A7		; (receive off): nothing, as $0481
	.byte 8, $AD, $4C, $7F, $F0, $15, $A9, $35, $85
	.byte 3, $4C, $2F, $04
	.word $04D6		; baud ($78: 0 300, 1 1200): open the port at it
	.byte 8, $A5, $78, $29, $01, $85, $78, $A8, $B9
	.byte 10, $A5, $78, $29, $01, $AA, $A9, $02, $4C, $7D, $FF
	.word $050D		; (the NMI routine, unused now): the buffer descriptor ($7D00, write $7F48, read $7F49), and get's start: pump, then its own code
	.byte 8, $78, $D8, $48, $98, $48, $8A, $48, $A5
	.byte 19, $00, $7D, $48, $7F, $49, $7F, $A9, $08, $20, $7D, $FF, $78, $98, $48, $8A, $48, $4C, $4D, $04
	.word $0575		; NMI install: pump into its buffer (descriptor at $050D)
	.byte 8, $AD, $64, $7F, $D0, $28, $AD, $19, $03
	.byte 9, $A2, $0D, $A0, $05, $A9, $07, $4C, $7D, $FF
	.word $05A3		; NMI restore: pump off, close
	.byte 8, $AD, $64, $7F, $F0, $1A, $8D, $19, $03
	.byte 12, $A0, $00, $A9, $07, $20, $7D, $FF, $A9, $03, $4C, $7D, $FF
	.word $06D3		; send $79: to the UART
	.byte 8, $AC, $4B, $7F, $C8, $CC, $4A, $7F, $F0
	.byte 7, $A6, $79, $A9, $04, $4C, $7D, $FF
	.word $0714		; CIA2 set up / stop: nothing (no CIA)
	.byte 8, $A9, $7F, $8D, $0D, $DD, $A9, $06, $8D
	.byte 1, $60
	.word $0C92		; carrier light (interrupt): DCD from the card
	.byte 8, $A5, $01, $48, $A9, $35, $85, $01, $AD
	.byte 18, $A9, $06, $20, $7D, $FF, $8D, $00, $31, $EA, $EA, $EA, $EA, $EA, $EA, $EA, $EA, $EA, $EA
	.word $110C		; hang up: no DTR to drop ("+++" and ATH follow)
	.byte 8, $A9, $20, $8D, $03, $DD, $A9, $00, $8D
	.byte 10, $EA, $EA, $EA, $EA, $EA, $EA, $EA, $EA, $EA, $EA
	.word $3D8B		; record 9 (at $3C00): carrier
	.byte 8, $78, $A9, $35, $85, $01, $AD, $01, $DD
	.byte 7, $A9, $06, $20, $7D, $FF, $58, $60
	.word $3E7F		; record 9: DTR on/off: nothing
	.byte 8, $78, $A9, $35, $85, $01, $A9, $20, $8D
	.byte 2, $58, $60
