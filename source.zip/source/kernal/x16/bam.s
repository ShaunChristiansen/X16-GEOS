; GEOS for the Commander X16: the BAM routines of the disk driver
;
; In the helper bank, for want of room in low RAM: drvx16.s calls them
; through X16_HCall (interrupts off; A, X and Y come back).  They only
; use the BAM in memory, never the kernel.  The 1541 versions (D64
; images) are drv1541.s's, the 1581 versions (D81 images) drv1581.s's:
; tracks 1-40 in dir2Head, tracks 41-80 in dir3Head, track 40 holds the
; header, the BAM and the directory.

.include "const.inc"
.include "geossym.inc"
.include "geosmac.inc"
.include "config.inc"
.include "kernal.inc"
.include "diskdrv.inc"

.global H_SetNextFree, H_AllocateBlock, H_FindBAMBit, H_FreeBlock, H_CalcBlksFree

.segment "helper"

; Z = 1: the current drive is a 1581 (a D81 image)
Is81:
	lda curType
	and #%00001111
	cmp #DRV_1581
	rts

; SetNextFree: r3 = a block -> r3 = the next free block, now allocated.
; X = 0 or INSUFF_SPACE
H_SetNextFree:
	jsr Is81
	bne @1
	jmp SNF81
@1:	jmp SNF41

; AllocateBlock, FreeBlock: block r6.  X = 0 or BAD_BAM
H_AllocateBlock:
	jsr Is81
	bne @1
	jmp Alloc81
@1:	jmp Alloc41
H_FreeBlock:
	jsr Is81
	bne @1
	jmp Free81
@1:	jmp Free41

; FindBAMBit: block r6 -> A = its BAM bit (Z = 1: in use), X = its BAM
; byte, r7H = the track's free count byte, r8H = the bit
H_FindBAMBit:
	jsr Is81
	bne @1
	jmp FindBAM81
@1:	jmp FindBAM41

; CalcBlksFree: r4 = free blocks (1541: in the BAM at r5), r3 = all blocks
H_CalcBlksFree:
	jsr Is81
	bne @1
	jmp Calc81
@1:	jmp Calc41

; r6H = r6H mod r7L (sectors on the track), then allocate block r6.
; Z = 1: it was free
SNFMod:
	lda r6H
@1:	cmp r7L
	bcc @2
	sub r7L
	bra @1
@2:	sta r6H
	jsr Is81
	bne @3
	jmp Alloc81
@3:	jmp Alloc41

;---------------------------------------------------------------------------
; 1541
;---------------------------------------------------------------------------
SNF41:
	lda r3H
	add interleave
	sta r6H
	MoveB r3L, r6L
	cmp #25
	bcc @0
	dec r6H
@0:	cmp #DIR_TRACK
	beq @1
@00:	lda r6L
	cmp #DIR_TRACK
	beq @3
@1:	asl
	asl
	tax
	lda curDirHead,x
	beq @3
	lda r6L
	jsr Zone41
	lda SecScTab,x
	sta r7L
	tay
@2:	jsr SNFMod
	beq @4
	inc r6H
	dey
	bne @2
@3:	inc r6L
	CmpBI r6L, N_TRACKS+1
	bcs @5
	sub r3L
	sta r6H
	asl
	adc #4
	adc interleave
	sta r6H
	bra @00
@4:	MoveW_ r6, r3
	ldx #0
	rts
@5:	ldx #INSUFF_SPACE
	rts

; X = the speed zone of track A
Zone41:
	ldx #0
@0:	cmp SecTrTab,x
	bcc @1
	inx
	bne @0
@1:	rts

SecTrTab:
	.byte 18, 25, 31, 36
SecScTab:
	.byte 21, 19, 18, 17

Alloc41:
	jsr FindBAM41
	beq BadBAM
	lda r8H
	eor #$ff
	and curDirHead,x
	sta curDirHead,x
	ldx r7H
	dec curDirHead,x
	ldx #0
	rts
BadBAM:	ldx #BAD_BAM
	rts

Free41:
	jsr FindBAM41
	bne BadBAM
	lda r8H
	eor curDirHead,x
	sta curDirHead,x
	ldx r7H
	inc curDirHead,x
	ldx #0
	rts

FindBAM41:
	lda r6L
	asl
	asl
	sta r7H
	lda r6H
	and #%00000111
	tax
	lda FBBBitTab,x
	sta r8H
	lda r6H
	lsr
	lsr
	lsr
	sec
	adc r7H
	tax
	lda curDirHead,x
	and r8H
	rts

FBBBitTab:
	.byte $01, $02, $04, $08
	.byte $10, $20, $40, $80

Calc41:
	LoadW_ r4, 0
	ldy #OFF_TO_BAM
@0:	lda (r5),y
	add r4L
	sta r4L
	bcc @1
	inc r4H
@1:	tya
	clc
	adc #4
	tay
	cpy #$48
	beq @1
	cpy #$90
	bne @0
	LoadW r3, $0298
	rts

;---------------------------------------------------------------------------
; 1581
;---------------------------------------------------------------------------
SNF81:
	jsr @1
	bne @0
	rts
@0:	LoadB r3L, $27          ; nothing from there on: from track 39 down
@1:	lda r3H
	addv 1
	sta r6H
	MoveB r3L, r6L
	cmp #DIR_1581_TRACK
	beq @3
@2:	lda r6L
	cmp #DIR_1581_TRACK
	beq @8
@3:	cmp #DIR_1581_TRACK+1
	bcc @4
	subv DIR_1581_TRACK
@4:	subv $01
	asl
	sta r7L
	asl
	clc
	adc r7L
	tax
	CmpBI r6L, DIR_1581_TRACK+1
	bcc @5
	lda dir3Head+$10,x
	bra @6
@5:	lda dir2Head+$10,x
@6:	beq @8
	LoadB r7L, DIR_1581_TRACK
	tay
@7:	jsr SNFMod
	beq @11
	inc r6H
	dey
	bne @7
@8:	CmpBI r6L, DIR_1581_TRACK+1
	bcs @9
	dec r6L
	bne @10
	LoadB r6L, DIR_1581_TRACK+1
	bne @10
@9:	inc r6L
@10:	CmpBI r6L, $51
	bcs @12
	LoadB r6H, 0
	beq @2
@11:	MoveW r6, r3
	ldx #0
	rts
@12:	ldx #INSUFF_SPACE
	rts

Alloc81:
	jsr FindBAM81
	bne AB81
	ldx #BAD_BAM
	rts
Free81:
	jsr FindBAM81
	beq AB81
	ldx #BAD_BAM
	rts
AB81:	php                     ; Z = 0: allocate, 1: free
	CmpBI r6L, DIR_1581_TRACK+1
	bcc @2
	lda r8H
	eor dir3Head+$10,x
	sta dir3Head+$10,x
	ldx r7H
	plp
	beq @1
	dec dir3Head+$10,x
	bra @4
@1:	inc dir3Head+$10,x
	bra @4
@2:	lda r8H
	eor dir2Head+$10,x
	sta dir2Head+$10,x
	ldx r7H
	plp
	beq @3
	dec dir2Head+$10,x
	bra @4
@3:	inc dir2Head+$10,x
@4:	ldx #0
	rts

FindBAM81:
	lda r6H
	and #%00000111
	tax
	lda FBBBitTab,x
	sta r8H
	CmpBI r6L, DIR_1581_TRACK+1
	bcc @1
	subv DIR_1581_TRACK
@1:	subv $1
	asl
	sta r7H
	asl
	add r7H
	sta r7H
	lda r6H
	lsr
	lsr
	lsr
	sec
	adc r7H
	tax
	CmpBI r6L, DIR_1581_TRACK+1
	bcc @2
	lda dir3Head+$10,x
	and r8H
	rts
@2:	lda dir2Head+$10,x
	and r8H
	rts

Calc81:
	LoadW r4, 0
	ldy #$10
@0:	lda dir2Head,y
	add r4L
	sta r4L
	bcc @1
	inc r4H
@1:	tya
	addv 6
	tay
	cpy #$FA                ; (track 40)
	beq @1
	cpy #$00
	bne @0
	ldy #$10
@2:	lda dir3Head,y
	add r4L
	sta r4L
	bcc @3
	inc r4H
@3:	tya
	addv 6
	tay
	bne @2
	LoadW r3, $0c58
	rts
