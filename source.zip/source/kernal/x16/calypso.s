; GEOS for the Commander X16: the Calypso card (Wavicle / smrobtzz) for the
; terminal programs: its WiFi (TCP, with a small Hayes-style modem in front
; of it, as the TexElec card's Zimodem has) or its DB9 RS-232 port.
;
; Calypso's own network code, NET.BIN, comes from its firmware (a file on
; its DOS device) and is loaded at boot into RAM bank X16_BANK_NET at $A000
; (boot.s: LoadNet).  This code sits above it, at $B000, so it calls
; NET.BIN directly; serial.s forwards the serial calls here (CalCall), with
; this bank switched in by a small trampoline in zero page.
;
; NET.BIN: a jump table at $A000 (open, close, send, recv, poll,
; gethostbyname), its arguments and results in zero page $02-$1B (the X16's
; r0-r13: GEOS's r0-r13), and it sets $02B3 (its SPI lock) while it talks
; to the card.  All are kept and put back here; serial.s turns interrupts
; off for the whole call, so GEOS's interrupt never sees them changed.
;
; Here, A = the call (as serial.s's), X and Y as below; returns A, C, and
; Y = the carrier ($10: connected).
;   2 open: X = 0 WiFi, 1 DB9; Y = the DB9's speed code (0 9600 .. 7 921600)
;   3 close
;   4 send: X = the byte; Y = the frame counter
;   5 receive: C = 0 and A = the byte, or C = 1; Y = the frame counter
;   7 pump: X/Y = a program's buffer descriptor (as serial.s's), Y = 0: off
;   8 pump now; Y = the frame counter
; The card is asked for new bytes at most once a frame (unless the last
; answer filled the request), from calls 5 and 8 only: never from an
; interrupt.
;
; The modem (WiFi): commands echo; "ATD[T|P]host[:port]" (port 23 if none)
; looks the host up, opens a TCP connection and answers CONNECT (or NO
; CARRIER); other AT commands answer OK.  Online: "+++" goes back to
; commands (connected still): ATH hangs up, ATO goes back online.

.include "x16.inc"

.setcpu "65SC02"

.import MountJob        ; (call 9 here: another disk image, mount.s)
.import PatchScan       ; (call 10: the programs' patches, serial.s)
.global c_x

NET_OPEN  = $A000
NET_CLOSE = $A003
NET_SEND  = $A006
NET_RECV  = $A009
NET_POLL  = $A00C
NET_DNS   = $A00F

SPI_LOCK  = $02B3
ZA        = $02                 ; NET.BIN's zero page: $02-$1B
ZA_N      = $1A
R1        = $04                 ; its r1 ...

SOCK_TCP    = 1
SOCK_SERIAL = 3
ST_DATA     = 1                 ; poll: data to read
ST_CONN     = 2                 ;       connected
ST_ERR      = 4                 ;       an error

; st: the connection
S_CMD     = 0                   ; commands, not connected
S_DIAL    = 1                   ; connecting
S_ON      = 2                   ; online
S_ESC     = 3                   ; commands, connected (after +++)

CHUNK_TCP = 64
CHUNK_SER = 16
RING      = $BE00               ; 512 bytes

.segment "netram"

	jmp CalEntry            ; $B000

CalEntry:
	sty c_y
	stx c_x
	asl a
	tax
	jsr @go
	php                     ; (A and C: the call's)
	pha
	ldy #0                  ; the carrier
	bit c_open
	bpl :+
	lda st
	cmp #S_ON
	bcc :+
	ldy #$10
:	pla
	plp
	rts
@go:	jmp (tab-4,x)
tab:	.word COpen, CClose, CPut, CGet, CStat, CPump, CNow, MountJob, PatchScan

CStat:	clc                     ; (serial.s answers this itself)
	rts

; ---------------------------------------------------------------- open/close
COpen:
	jsr CClose
	lda #0
	ldx #c_end - c_clr - 1
:	sta c_clr,x
	dex
	bpl :-
	lda c_x
	sta c_db9
	beq @wifi
	jsr NSave               ; DB9: a serial socket
	lda c_y
	ora #(2 << 3) | (3 << 5) ; RTS/CTS, 8 bits
	sta $17
	lda #1                  ; 1 stop bit, no parity
	sta $18
	lda #SOCK_SERIAL
	jsr NOpen
	jsr NRest
	lda #S_ON
	sta st
@wifi:	lda #$80
	sta c_open
	clc
	rts

CClose:
	bit c_open
	bpl @x
	lda c_db9
	bne @c
	lda st
	beq @n
@c:	jsr NSave
	stz R1                  ; socket 0
	jsr NET_CLOSE
	jsr NRest
@n:	stz st
	stz c_open
@x:	clc
	rts

; ------------------------------------------------------------------ send
CPut:
	bit c_open
	bpl @x
	lda c_db9
	bne @out
	lda st
	cmp #S_ON
	beq @on
	cmp #S_DIAL
	beq @x                  ; (dialling: dropped)
	jmp Command             ; commands
@on:	lda c_x                 ; online: "+++"?
	cmp #'+'
	bne @np
	inc c_plus
	lda c_plus
	cmp #3
	bne @out
	stz c_plus
	lda #S_ESC
	sta st
	jsr Flush
	ldx #m_ok - msgs
	jsr Say
	bra @x
@np:	stz c_plus
@out:	ldx c_on                ; to the send buffer
	lda c_x
	sta obuf,x
	inx
	stx c_on
	cpx #OBUF
	bcc @x
	jsr Flush
@x:	clc
	rts

; the send buffer -> the card
Flush:
	lda c_on
	beq @x
	jsr NSave
	stz R1                  ; socket 0
	lda c_on
	sta R1+1                ; size
	stz R1+2
	lda #<obuf
	sta R1+3
	lda #>obuf
	sta R1+4
	jsr NET_SEND
	jsr NRest
	stz c_on
@x:	rts

; ------------------------------------------------------------------ receive
CGet:
	jsr Fetch
	lda r_rd
	cmp r_wr
	bne @b
	lda r_rd+1
	cmp r_wr+1
	bne @b
	lda #0
	sec
	rts
@b:	lda r_rd+1
	clc
	adc #>RING
	sta @ld+2
	ldx r_rd
@ld:	lda RING,x
	inc r_rd
	bne :+
	pha
	lda r_rd+1
	eor #1
	sta r_rd+1
	pla
:	clc
	rts

CNow:
	jsr Fetch
	clc
	rts

; 7: pump into the program's buffer (X/Y) or the ring (Y = 0)
CPump:
	lda c_y
	sta pm_on
	beq @x
	sta @d+2
	lda c_x
	sta @d+1
	ldy #5
@d:	lda $FFFF,y
	sta pm_desc,y
	dey
	bpl @d
	lda pm_desc             ; the buffer
	sta dv_st+1
	lda pm_desc+1
	sta dv_st+2
	lda pm_desc+2           ; its write index
	sta dv_w1+1
	sta dv_w2+1
	sta dv_w3+1
	sta dv_w4+1
	lda pm_desc+3
	sta dv_w1+2
	sta dv_w2+2
	sta dv_w3+2
	sta dv_w4+2
	lda pm_desc+4           ; its read index
	sta dv_r+1
	sta dv_r2+1
	lda pm_desc+5
	sta dv_r+2
	sta dv_r2+2
@x:	clc
	rts

; new bytes from the card, if it is time (once a frame, or straight again
; when the last answer was full)
Fetch:
	jsr Flush
	bit c_open
	bpl @x
	lda c_full
	bne @go
	lda c_y
	cmp c_frame
	beq @x
@go:	lda c_y
	sta c_frame
	stz c_full
	lda st
	cmp #S_DIAL
	beq Dialing
	cmp #S_ON
	beq Online
@x:	rts

Dialing:
	jsr Poll
	bit #ST_CONN
	bne @on
	bit #ST_ERR
	bne @no
	inc c_wait              ; ~15 seconds
	bne @x
	inc c_wait+1
	lda c_wait+1
	cmp #4
	bcc @x
@no:	jmp HangUp
@on:	lda #S_ON
	sta st
	ldx #m_conn - msgs
	jmp Say
@x:	rts

Online:
	jsr Poll
	bit #ST_DATA
	bne @data
	ldx c_db9
	bne @x
	bit #ST_ERR
	bne @gone
	bit #ST_CONN
	bne @x
@gone:	jmp HangUp              ; (the other end closed)
@data:	jsr Room
	beq @x                  ; (no room: the bytes wait in the card)
	ldx #CHUNK_TCP
	ldy c_db9
	beq :+
	ldx #CHUNK_SER
:	stx c_n
	cmp c_n
	bcs :+
	sta c_n
:	jsr NSave
	stz R1                  ; socket 0
	lda c_n
	sta R1+1
	stz R1+2
	lda #<nbuf
	sta R1+3
	lda #>nbuf
	sta R1+4
	jsr NET_RECV
	lda R1+1                ; how many
	sta c_got
	jsr NRest
	lda c_got
	beq @x
	cmp c_n
	bne :+
	inc c_full              ; (all asked for: maybe more)
:	ldx #0
@put:	phx
	lda nbuf,x
	jsr Dlv
	plx
	inx
	cpx c_got
	bne @put
@x:	rts

; A = socket 0's status
Poll:
	jsr NSave
	jsr NET_POLL
	lda R1
	sta c_stat
	jsr NRest
	lda c_stat
	rts

HangUp:
	jsr NSave
	stz R1
	jsr NET_CLOSE
	jsr NRest
	stz st
	ldx #m_noc - msgs
	jmp Say

; ------------------------------------------------------------- the modem
; a byte in command mode: echo, keep, and on RETURN do the line
Command:
	lda c_x
	cmp #13
	beq @do
	cmp #10
	beq @x
	cmp #8
	beq @bs
	cmp #$14
	beq @bs
	cmp #$7F
	beq @bs
	cmp #' '
	bcc @x
	ldx c_ln
	cpx #LBUF-1
	bcs @x
	sta lbuf,x
	inc c_ln
	jsr Dlv                 ; echo
@x:	clc
	rts
@bs:	lda c_ln
	beq @x
	dec c_ln
	lda c_x
	jsr Dlv
	bra @x
@do:	lda #13
	jsr Dlv
	ldx c_ln
	stz lbuf,x
	stz c_ln
	jsr Line
	clc
	rts

Line:
	ldx #0
	jsr Skip
	lda lbuf,x
	beq @x                  ; (empty)
	and #$DF
	cmp #'A'
	bne @x
	lda lbuf+1,x
	and #$DF
	cmp #'T'
	bne @x
	inx
	inx
	jsr Skip
	lda lbuf,x
	and #$DF
	cmp #'D'
	beq Dial
	cmp #'H'
	beq @h
	cmp #'O'
	beq @o
@ok:	ldx #m_ok - msgs
	jmp Say
@h:	lda st
	cmp #S_ESC
	bne @ok
	jsr NSave
	stz R1
	jsr NET_CLOSE
	jsr NRest
	stz st
	bra @ok
@o:	lda st
	cmp #S_ESC
	bne @err
	lda #S_ON
	sta st
	ldx #m_conn - msgs
	jmp Say
@err:	ldx #m_err - msgs
	jmp Say
@x:	rts

Skip:	lda lbuf,x              ; past spaces and quotes
	cmp #' '
	beq :+
	cmp #'"'
	bne @x
:	inx
	bra Skip
@x:	rts

; ATD[T|P] host[:port]
Dial:
	lda st
	beq :+
	ldx #m_err - msgs       ; (connected already)
	jmp Say
:	inx
	lda lbuf,x
	and #$DF
	cmp #'T'
	beq :+
	cmp #'P'
	bne :++
:	inx
:	jsr Skip
	stx c_h                 ; the host's start
@h:	lda lbuf,x
	beq @he
	cmp #':'
	beq @he
	cmp #'"'
	beq @he
	cmp #' '
	beq @he
	inx
	bra @h
@he:	txa
	sec
	sbc c_h
	bne :+
	ldx #m_err - msgs       ; (no host)
	jmp Say
:	sta c_hl
	lda #23                 ; the port
	sta c_port
	stz c_port+1
	lda lbuf,x
	cmp #':'
	bne @dns
	stz c_port
@d:	inx                     ; port = port * 10 + digit
	lda lbuf,x
	sec
	sbc #'0'
	bcc @dns
	cmp #10
	bcs @dns
	pha
	lda c_port
	ldy c_port+1
	asl c_port
	rol c_port+1
	asl c_port
	rol c_port+1
	clc
	adc c_port
	sta c_port
	tya
	adc c_port+1
	sta c_port+1
	asl c_port
	rol c_port+1
	pla
	clc
	adc c_port
	sta c_port
	bcc @d
	inc c_port+1
	bra @d
@dns:	jsr NSave
	lda #<lbuf              ; look the host up
	clc
	adc c_h
	sta R1
	lda #>lbuf
	adc #0
	sta R1+1
	lda c_hl
	sta R1+2
	jsr NET_DNS
	lda R1                  ; an address? (0.0.0.0: no)
	ora R1+1
	ora R1+2
	ora R1+3
	beq @fail
	lda c_port              ; open: the address is where DNS left it
	sta $17
	lda c_port+1
	sta $18
	lda #SOCK_TCP
	jsr NOpen
	jsr NRest
	lda #S_DIAL
	sta st
	stz c_wait
	stz c_wait+1
	rts
@fail:	jsr NRest
	ldx #m_noc - msgs
	jmp Say

; NET.BIN's open, socket 0, of type A ($17/$18 set)
NOpen:
	sta $16
	stz $15
	jmp NET_OPEN

; ------------------------------------------------------------ bytes out
; the message at msgs+X, to the program
Say:
	lda msgs,x
	beq @x
	phx
	jsr Dlv
	plx
	inx
	bra Say
@x:	rts

; A -> the program's buffer (pump) or the ring; full: dropped
Dlv:
	ldx pm_on
	bne @pm
	pha
	lda r_wr                ; the ring full? (wr + 1 = rd)
	clc
	adc #1
	tay
	lda r_wr+1
	adc #0
	and #1
	cmp r_rd+1
	bne @in
	cpy r_rd
	bne @in
	pla
	rts
@in:	lda r_wr+1
	clc
	adc #>RING
	sta @st+2
	ldy r_wr
	pla
@st:	sta RING,y
	inc r_wr
	bne :+
	lda r_wr+1
	eor #1
	sta r_wr+1
:	rts
@pm:	pha
dv_w1:	ldy $FFFF
	iny
dv_r:	cpy $FFFF
	bne :+
	pla                     ; (full)
	rts
:
dv_w2:	ldy $FFFF
	pla
dv_st:	sta $FFFF,y
dv_w3:	inc $FFFF
	rts

; A = the room where Dlv puts bytes (at most 255), Z if none
Room:
	lda pm_on
	beq RoomR
dv_r2:	lda $FFFF               ; read - write - 1
	clc
dv_w4:	sbc $FFFF
	rts
RoomR:	lda r_rd                ; (read - write - 1) & 511
	clc
	sbc r_wr
	tax
	lda r_rd+1
	sbc r_wr+1
	and #1
	beq :+
	ldx #255
:	txa
	rts

; ------------------------------------------------- NET.BIN's zero page
NSave:
	ldx #ZA_N-1
:	lda ZA,x
	sta zsave,x
	dex
	bpl :-
	lda SPI_LOCK
	sta zsave+ZA_N
	rts

NRest:
	ldx #ZA_N-1
:	lda zsave,x
	sta ZA,x
	dex
	bpl :-
	lda zsave+ZA_N
	sta SPI_LOCK
	rts

msgs:
m_ok:	.byte 13, 10, "OK", 13, 10, 0
m_conn:	.byte 13, 10, "CONNECT 115200", 13, 10, 0
m_noc:	.byte 13, 10, "NO CARRIER", 13, 10, 0
m_err:	.byte 13, 10, "ERROR", 13, 10, 0

OBUF = 32
LBUF = 64

c_open:	.byte 0
c_db9:	.byte 0
c_x:	.byte 0
c_y:	.byte 0
pm_on:	.byte 0
pm_desc: .res 6
c_clr:                          ; (cleared by open)
st:	.byte 0
c_plus:	.byte 0
c_on:	.byte 0
c_ln:	.byte 0
c_full:	.byte 0
c_frame: .byte 0
c_wait:	.word 0
r_rd:	.word 0
r_wr:	.word 0
c_end:
c_n:	.byte 0
c_got:	.byte 0
c_stat:	.byte 0
c_h:	.byte 0
c_hl:	.byte 0
c_port:	.word 0
zsave:	.res ZA_N+1
obuf:	.res OBUF
lbuf:	.res LBUF
nbuf:	.res CHUNK_TCP
