; GEOS for the Commander X16: cartridge bank 33, the helper bank
;
; Code that runs only inside the IRQ handler (called from x16io.s, which
; maps this bank for the call): there is no room for it in low RAM.
; It may use r0-r15, which the kernel's IRQ handler has saved.  The bank
; is RAM (as all of the cartridge for x16emu -cartbin): it holds variables
; and the screen conversion patches its own load addresses.
;
;   $C000  Frame         the screen: bitmap + colour matrix -> VERA
;   $C003  SprConvert    C64 sprite -> VERA 4bpp sprite image
;   $C006  KeyDecode     X16 key number -> GEOS key code
;   $C009  P3_Build      p3_exec from a program's bytes at $038B (compat.s)
;   $C00C  SmcPoll       read one key code and one mouse packet from the SMC
;   $C00F  SmcReset      reset the machine through the SMC (does not return)
;   $C012  SdRead        a disk block -> (r4), through the cache (sdio.s)
;   $C015  SdWrite       (r4) -> a disk block (sdio.s)
;   $C018  ChDev         ChangeDiskDevice: an image to another device number
;   $C01B  RamOp         DoRAMOp: the RAM expansion, in X16 banked RAM
;   $C01E  SetNextFree   the disk driver's BAM routines (bam.s)
;   $C021  AllocateBlock
;   $C024  FindBAMBit
;   $C027  FreeBlock
;   $C02A  CalcBlksFree

.include "const.inc"
.include "geossym.inc"
.include "x16.inc"

.setcpu "65SC02"

.import kbmods, kbcaps, x16_dirty
.import kcode, mpkt, mvalid, msumx, msumy, mbtns, x16_msize
.import x16_desk, x16_wpok, x16_scrok, c64pal_gb, c64pal_r
.import p3_save, p3_exec, p3_jret, p3_jtgt, p3_x, P3_Jsr
.import H_SdRead, H_SdWrite, H_ChDev, H_RamOp
.import H_SetNextFree, H_AllocateBlock, H_FindBAMBit, H_FreeBlock, H_CalcBlksFree
.import H_Mount, H_GetName

cr_src  = r0                    ; bitmap address of the row
cr_cp   = r1                    ; its colours (COLOR_MATRIX + 40 * row)
cr_sp   = r2                    ; their shadow
cr_n    = r3                    ; tile number (= card number)
cr_row  = r4L
cr_cb   = r4H
cr_end  = r5L
cr_card = r5H
cr_cnt  = r6L
cr_any  = r6H                   ; wallpaper cards (see helpconv.inc):
cr_rows = r7L                   ;   lines drawn (bit r = line r)
cr_edge = r7H                   ;   bit 7: no row below, bit 6: none above
cr_s    = r9L                   ;   a run of lines: first, end
cr_e    = r9H
cr_acc  = r10L                  ;   its columns that differ
cr_m    = r11H                  ;   its columns drawn
cr_t    = r12L
cr_t2   = r12H

CSCAN_ROWS = 5                  ; colour rows compared with the shadow per frame

.segment "helper"

	jmp Frame
	jmp SprConvert
	jmp KeyDecode
	jmp P3_Build
	jmp SmcPoll
	jmp SmcReset
	jmp H_SdRead
	jmp H_SdWrite
	jmp H_ChDev
	jmp H_RamOp
	jmp H_SetNextFree
	jmp H_AllocateBlock
	jmp H_FindBAMBit
	jmp H_FreeBlock
	jmp H_CalcBlksFree
	jmp H_Mount
	jmp H_GetName

;---------------------------------------------------------------------------
; The screen, VERA side (set up by VeraSetup in boot.s):
;   layer 1  2bpp tiles: tile n (VRAM 16 * n) = card n of the bitmap;
;            map entry palette offset = the card's foreground colour, so
;            bit 1 pixels show palette entry 16 * fg + 1 = C64 colour fg,
;            bit 0 pixels are transparent
;   layer 0  8bpp tiles: tile 1023 is solid (pixel value 1, so the map
;            entry's palette offset = background colour gives 16 * bg + 1);
;            tiles 0-999 are the wallpaper picture (a BMX file, prn.s)
; Per frame: rows marked in x16_dirty, CSCAN_ROWS rows of colours, and one
; more row when its checksum changed (anything drawn without GetScanLine)
; or another pass converted it since (perhaps half drawn).
;---------------------------------------------------------------------------
Frame:
	lda x16_scrok
	bne @1
	jsr ScreenVars
	lda #1
	sta x16_scrok
@1:	jsr CheckMode
	; rows GEOS has drawn into
	ldx #0
@d:	lda x16_dirty,x
	beq @dn
	dec x16_dirty,x
	phx
	jsr ConvRow
	plx
	lda #1                  ; maybe while it was being drawn: the
	sta rowstale,x          ; background pass converts it once more
@dn:	inx
	cpx #25
	bne @d
	; colours: a few rows a frame
	lda #CSCAN_ROWS
	sta cr_cnt
@c:	ldx cscan
	jsr ColourRow
	bcc @cn
	bit cv_wp               ; colours changed: with a wallpaper, the tile
	bpl @cn                 ; data depends on them too
	ldx cr_row
	jsr TilesRow
	ldx cr_row
	lda #1
	sta rowstale,x
@cn:	ldx cscan
	inx
	cpx #25
	bcc @c2
	ldx #0
@c2:	stx cscan
	dec cr_cnt
	bne @c
	; one row regardless, when its bitmap changed (anything drawn
	; without GetScanLine) or another pass converted it since
	ldx refrow
	lda m320lo,x
	sta cr_src
	lda m320hi,x
	sta cr_src+1
	jsr RowSum
	ldx refrow
	ldy rowstale,x
	bne @conv
	cmp rowsum,x
	bne @conv
	tay
	lda rs_s1
	cmp rowsum1,x
	php
	tya
	plp
	beq @same
@conv:	sta rowsum,x
	lda rs_s1
	sta rowsum1,x
	stz rowstale,x
	jsr ConvRow
@same:	ldx refrow
	inx
	cpx #25
	bcc @r
	ldx #0
@r:	stx refrow
	rts

; card row X: colours and bitmap
ConvRow:
	jsr ColourRow
	ldx cr_row
	; fall through

; card row X: tile data of layer 1
TilesRow:
	stz VERA_CTRL
	lda #VERA_INC_1
	sta VERA_ADDR_H
	lda m640hi,x
	sta VERA_ADDR_M
	lda m640lo,x
	sta VERA_ADDR_L
	lda m320lo,x
	sta cr_src
	lda m320hi,x
	sta cr_src+1
	bit cv_wp
	bmi @wp
	jsr PatchFast
	jmp TilesFast
@wp:	stz cr_edge
	cpx #24
	bcc @e1
	lda #$80
	sta cr_edge
@e1:	cpx #0
	bne @e2
	lda #$40
	sta cr_edge
@e2:	lda m40lo,x
	clc
	adc #<COLOR_MATRIX
	sta cr_cp
	lda m40hi,x
	adc #>COLOR_MATRIX
	sta cr_cp+1
	jsr PatchWP
	jmp TilesWP

; card row X: compare its colours with the shadow; when they differ (or the
; row is marked invalid), write the row's map entries of both layers and
; update the shadow.  C = 1: written.
ColourRow:
	stx cr_row
	lda m40lo,x
	clc
	adc #<COLOR_MATRIX
	sta cr_cp
	lda m40hi,x
	adc #>COLOR_MATRIX
	sta cr_cp+1
	lda m40lo,x
	clc
	adc #<cshadow
	sta cr_sp
	lda m40hi,x
	adc #>cshadow
	sta cr_sp+1
	lda rowvalid,x
	beq @wr
	ldy #39
@cmp:	lda (cr_cp),y
	cmp (cr_sp),y
	bne @wr
	dey
	bpl @cmp
	clc
	rts
@wr:	lda #1
	sta rowvalid,x
	; ADDR1 -> layer 0 map row, ADDR0 -> layer 1 map row
	lda #1
	sta VERA_CTRL
	lda #VERA_INC_1
	sta VERA_ADDR_H
	lda m128hi,x
	ora #>VRAM_MAP0
	sta VERA_ADDR_M
	lda m128lo,x
	sta VERA_ADDR_L
	stz VERA_CTRL
	lda #VERA_INC_1
	sta VERA_ADDR_H
	lda m128hi,x
	ora #>VRAM_MAP1
	sta VERA_ADDR_M
	lda m128lo,x
	sta VERA_ADDR_L
	lda m40lo,x
	sta cr_n
	lda m40hi,x
	sta cr_n+1
	ldy #0
@m:	lda (cr_cp),y
	sta (cr_sp),y
	sta cr_cb
	lda cr_n                ; layer 1: tile n, palette offset = foreground
	sta VERA_DATA0
	lda cr_cb
	and #$F0
	ora cr_n+1
	sta VERA_DATA0
	bit cv_wp               ; layer 0: wallpaper tile n for screencolors
	bpl @solid              ; cards on the deskTop (when there is one)
	lda cr_cb
	cmp cv_scol
	bne @solid
	lda cr_n
	sta VERA_DATA1
	lda cr_n+1
	sta VERA_DATA1
	bra @nx
@solid:	lda #<1023              ; else the solid tile in the background colour
	sta VERA_DATA1
	lda cr_cb
	asl a
	asl a
	asl a
	asl a
	ora #>1023
	sta VERA_DATA1
@nx:	inc cr_n
	bne @2
	inc cr_n+1
@2:	iny
	cpy #40
	bne @m
	sec
	rts

; wallpaper on (deskTop running, picture loaded) and screencolors: when
; either changes, every row is converted again.  Palette entry 16 * fg + 2
; is the background colour of screencolors (bit 0 pixels of e2 tiles).
CheckMode:
	lda x16_wpok
	and x16_desk
	ldx screencolors
	cmp cv_wp
	bne @ch
	cpx cv_scol
	beq @x
@ch:	sta cv_wp
	stx cv_scol
	stz VERA_CTRL
	lda #1 | VERA_INC_1
	sta VERA_ADDR_H
	txa
	and #$F0
	asl a                   ; 32 * fg (C = bit 8)
	ora #4                  ; entry 16 * fg + 2: offset 32 * fg + 4
	sta VERA_ADDR_L
	lda #>(VRAM_PALETTE & $FFFF)
	adc #0
	sta VERA_ADDR_M
	txa
	and #$0F
	tay
	lda c64pal_gb,y
	sta VERA_DATA0
	lda c64pal_r,y
	sta VERA_DATA0
	ldx #24
@i:	stz rowvalid,x
	lda x16_dirty,x
	bne @3
	inc x16_dirty,x
@3:	dex
	bpl @i
@x:	rts

; after a boot: every row must be converted; the deskTop pattern
ScreenVars:
	ldx #24
@1:	stz rowvalid,x
	dex
	bpl @1
	lda #$FF                ; no mode yet: CheckMode converts everything
	sta cv_wp
	stz refrow
	stz cscan
	ldx #7
@2:	lda deskpat,x
	sta cv_pat,x
	dex
	bpl @2
	rts

deskpat: .byte $AA, $55, $AA, $55, $AA, $55, $AA, $55

; Y = key number -> A = GEOS key code; C = 1: no such key
;   CTRL + letter = 1..26, C= (Alt / Windows key) sets bit 7, as the C64
;   GEOS keyboard driver does
;---------------------------------------------------------------------------
KeyDecode:
	lda kbmods
	and #$0C
	beq @noctrl
	lda keytab_s,y
	cmp #'A'
	bcc @noctrl
	cmp #'Z'+1
	bcs @noctrl
	sbc #$3F                ; C = 0: A - $40
	bra @cbm
@noctrl:
	lda kbmods
	and #$03
	beq @n
	lda keytab_s,y
	bra @c
@n:	lda keytab_n,y
	ldx kbcaps
	beq @c
	cmp #'a'
	bcc @c
	cmp #'z'+1
	bcs @c
	and #$DF                ; caps lock
@c:	cmp #0
	beq @none
@cbm:	tax
	lda kbmods
	and #$70
	beq @plain
	txa
	ora #$80
	clc
	rts
@plain:	txa
	clc
	rts
@none:	sec
	rts

.include "keytab.inc"

;---------------------------------------------------------------------------
; sprite r0L from (r1), mode r2L (bit 0 X expanded, bit 1 Y expanded) ->
; VRAM_SPRDATA + n*$800 as 32 or 64 pixels square, 4bpp, pixel value 1
;---------------------------------------------------------------------------
SprConvert:
	lda r0L                 ; the mouse pointer (sprite 0, not expanded)
	ora r2L
	bne @plain
	jmp SprOutline
@plain:	lda #^VRAM_SPRDATA | VERA_INC_1
	sta VERA_ADDR_H
	lda r0L
	asl a
	asl a
	asl a
	clc
	adc #>(VRAM_SPRDATA & $FFFF)
	sta VERA_ADDR_M
	stz VERA_ADDR_L
	stz r2H                 ; rows written
	ldy #0
@r:	lda (r1),y
	sta r3L
	iny
	lda (r1),y
	sta r3H
	iny
	lda (r1),y
	sta r4L
	iny
	phy
	jsr SprRow
	lda r2L
	and #2
	beq @1
	jsr SprRow              ; Y expanded: every row twice
@1:	ply
	cpy #63
	bne @r
	lda #32
	ldx r2L
	cpx #2
	bcc @2
	lda #64
@2:	sec
	sbc r2H
	tax                     ; empty rows left
	lda r2L
	lsr a
	lda #16
	bcc @3
	lda #32
@3:	sta r5L
@z:	ldy r5L
@zz:	stz VERA_DATA0
	dey
	bne @zz
	dex
	bne @z
	rts

; one sprite row (r3L, r3H, r4L) -> 16 bytes, or 32 when X expanded
SprRow:
	inc r2H
	ldx #0
@b:	lda r3L,x
	sta r5H
	lda r2L
	lsr a
	bcs @xe
	lda r5H
	lsr a
	lsr a
	lsr a
	lsr a
	tay
	lda pair_hi,y
	sta VERA_DATA0
	lda pair_lo,y
	sta VERA_DATA0
	lda r5H
	and #$0F
	tay
	lda pair_hi,y
	sta VERA_DATA0
	lda pair_lo,y
	sta VERA_DATA0
	bra @nx
@xe:	ldy #8
@e:	asl r5H
	lda #0
	bcc @0
	lda #$11
@0:	sta VERA_DATA0
	dey
	bne @e
@nx:	inx
	cpx #3
	bne @b
	ldy #4
	lda r2L
	lsr a
	bcc @p
	ldy #8
@p:	stz VERA_DATA0
	dey
	bne @p
	rts

;---------------------------------------------------------------------------
; the mouse pointer (sprite 0, not expanded) with a black outline, so it
; shows on any colour: its 24x21 image at (1,1) of the 32x32 VERA sprite
; (the Sprites routine places it 1 pixel up and left), pixel value 1, and
; the pixels around it value 3 (palette entry 16 * colour + 3 is black)
;---------------------------------------------------------------------------
SprOutline:
	ldx #4 * 26 - 1         ; (variables are not 0 at the start: clear)
@c:	stz so_s-4,x
	dex
	bpl @c
	ldy #0                  ; C64 row i -> row i + 1, shifted right 1 pixel
	ldx #4
@r:	lda (r1),y
	sta so_s,x
	iny
	lda (r1),y
	sta so_s+1,x
	iny
	lda (r1),y
	sta so_s+2,x
	iny
	lsr so_s,x
	ror so_s+1,x
	ror so_s+2,x
	ror so_s+3,x
	inx
	inx
	inx
	inx
	cpy #63
	bne @r
	lda #^VRAM_SPRDATA | VERA_INC_1
	sta VERA_ADDR_H
	lda #>(VRAM_SPRDATA & $FFFF)
	sta VERA_ADDR_M
	stz VERA_ADDR_L
	ldx #0                  ; 4 * row
@v:	; T = the row and those above and below; D = T and T moved 1 pixel
	; left and right; outline = D without the row's own pixels
	ldy #3
@t:	lda so_s-4+0,x
	ora so_s+0,x
	ora so_s+4+0,x
	sta so_t,y
	inx
	dey
	bpl @t
	dex                     ; back to the row (x was advanced by 4)
	dex
	dex
	dex
	; so_t is little endian now (so_t+3 = leftmost byte)
	lda so_t
	asl a
	sta so_l
	lda so_t+1
	rol a
	sta so_l+1
	lda so_t+2
	rol a
	sta so_l+2
	lda so_t+3
	rol a
	sta so_l+3
	lda so_t+3
	lsr a
	sta so_rr+3
	lda so_t+2
	ror a
	sta so_rr+2
	lda so_t+1
	ror a
	sta so_rr+1
	lda so_t
	ror a
	sta so_rr
	ldy #3
@o:	lda so_t,y
	ora so_l,y
	ora so_rr,y
	sta so_o,y
	dey
	bpl @o
	; 32 pixels: 4 bytes of shape (so_s+k,x) and outline (so_o+3-k)
	ldy #3
@b:	phy
	lda so_s,x
	eor #$FF
	and so_o,y
	sta so_q                ; outline without the shape
	lda so_s,x
	and #$F0
	sta so_p
	lda so_q
	lsr a
	lsr a
	lsr a
	lsr a
	ora so_p
	tay
	lda olH,y
	sta VERA_DATA0
	lda olL,y
	sta VERA_DATA0
	lda so_s,x
	asl a
	asl a
	asl a
	asl a
	sta so_p
	lda so_q
	and #$0F
	ora so_p
	tay
	lda olH,y
	sta VERA_DATA0
	lda olL,y
	sta VERA_DATA0
	inx
	ply
	dey
	bpl @b
	cpx #4 * 24
	beq @z
	jmp @v
@z:	ldx #8 * 16             ; rows 24-31: empty
@zz:	stz VERA_DATA0
	dex
	bne @zz
	rts

; 4 sprite pixels (a nibble) -> 2 bytes of 4bpp
pair_hi: .byte $00, $00, $00, $00, $01, $01, $01, $01, $10, $10, $10, $10, $11, $11, $11, $11
pair_lo: .byte $00, $01, $10, $11, $00, $01, $10, $11, $00, $01, $10, $11, $00, $01, $10, $11

;---------------------------------------------------------------------------
; SMC: one key code and one mouse packet (default read operation $43, set
; up at boot); the packet's movement is added to msumx/msumy
;---------------------------------------------------------------------------
SmcPoll:
	stz kcode
	jsr i2c_start
	lda #(SMC_I2C << 1) | 1
	jsr i2c_write
	bcs @stop
	jsr i2c_read
	sta kcode
	jsr i2c_ack
	jsr i2c_read
	sta mpkt
	tax                     ; (i2c_read leaves Z from its bit counter)
	beq @nack               ; no complete mouse packet
	ldy #1
@m:	phy
	jsr i2c_ack
	jsr i2c_read
	ply
	sta mpkt,y
	iny
	cpy x16_msize
	bne @m
	jsr i2c_nack
	jsr i2c_stop
	; add the packet's movement to msumx/msumy (9 bit signed each)
	lda mpkt
	and #$10
	beq @xp
	lda #$FF
@xp:	tax
	clc
	lda mpkt+1
	adc msumx
	sta msumx
	txa
	adc msumx+1
	sta msumx+1
	lda mpkt
	and #$20
	beq @yp
	lda #$FF
@yp:	tax
	clc
	lda mpkt+2
	adc msumy
	sta msumy
	txa
	adc msumy+1
	sta msumy+1
	lda mpkt
	sta mbtns
	lda #$80
	sta mvalid
	rts
@nack:	jsr i2c_nack
@stop:	jmp i2c_stop


; Leaving GEOS.  x16io.s CloseAll has closed the disk image files and put
; the X16 KERNAL's zero page and $0200-$03FF back.  "GEOSQUIT" at $0400
; (X16_ExitToBasic: deskTop's BASIC): X16 BASIC, handed over directly,
; without a reset, as C64 GEOS hands over to BASIC.  No marker
; (X16_Reboot): a reset, and GEOS starts again.
SmcReset:
	ldx #7
@q:	lda $0400,x
	cmp @mq,x
	bne Reset
	dex
	bpl @q
	stz $0400               ; (marker used up)
	ldx #handover_end - handover - 1
@cp:	lda handover,x          ; the hand-over runs in low RAM: it maps the
	sta HANDOVER,x          ; KERNAL's ROM bank
	dex
	bpl @cp
	jmp HANDOVER
@mq:	.byte "GEOSQUIT"

; the SMC's "reset button pressed" command
Reset:
	jsr i2c_start
	lda #SMC_I2C << 1
	jsr i2c_write
	lda #2
	jsr i2c_write
	lda #0
	jsr i2c_write
	jsr i2c_stop
@h:	bra @h

;---------------------------------------------------------------------------
; I2C master on VIA1 port A (SDA = bit 0, SCL = bit 1; a line is driven
; low by setting its DDR bit), as in the X16 KERNAL
;---------------------------------------------------------------------------
.macro scl_high
	lda #I2C_SCL
	trb VIA1_DDRA
:	lda VIA1_PRA            ; wait while a device stretches the clock
	and #I2C_SCL
	beq :-
.endmacro
.macro scl_low
	lda #I2C_SCL
	tsb VIA1_DDRA
.endmacro
.macro sda_high
	lda #I2C_SDA
	trb VIA1_DDRA
.endmacro
.macro sda_low
	lda #I2C_SDA
	tsb VIA1_DDRA
.endmacro
.macro send_bit                 ; C = bit
	bcs :+
	sda_low
	bra :++
:	sda_high
:	scl_high
	scl_low
.endmacro
.macro rec_bit                  ; -> C
	sda_high
	scl_high
	lda VIA1_PRA
	lsr a
	scl_low
.endmacro

i2c_start:
	lda #I2C_SDA | I2C_SCL
	trb VIA1_PRA
	sda_high
	scl_high
	sda_low
	jsr i2c_delay
	scl_low
	rts

i2c_stop:
	sda_low
	jsr i2c_delay
	scl_high
	jsr i2c_delay
	sda_high
i2c_delay:
	pha
	pla
	pha
	pla
	rts

i2c_ack:
	clc
	send_bit
	rts

i2c_nack:
	sec
	send_bit
	rts

; A = byte -> C = 0: acknowledged
i2c_write:
	ldx #8
@l:	rol a
	tay
	send_bit
	tya
	dex
	bne @l
	rec_bit
	rts

i2c_read:
	ldx #8
@l:	tay
	rec_bit
	tya
	rol a
	dex
	bne @l
	rts

;---------------------------------------------------------------------------
.include "helpconv.inc"

; variables (this bank is RAM; the image has $FF here, nothing may rely
; on a start value)
cshadow:  .res 1000             ; the colours the maps show
rowvalid: .res 25               ; 0: write the row's maps again
cv_wp:    .res 1                ; $80: wallpaper on
cv_scol:  .res 1                ; screencolors the maps were made for
cv_pat:   .res 8                ; the deskTop pattern
cl:       .res 8                ; wallpaper cards: the lines
cd:       .res 8                ;   the lines XOR the pattern
mk:       .res 8                ;   the pixels drawn
          .res 4                ; SprOutline: a row of nothing (row -1),
so_s:     .res 4 * 25           ;   the pointer's rows (32 bits each)
so_t:     .res 4
so_l:     .res 4
so_rr:    .res 4
so_o:     .res 4
so_p:     .res 1
so_q:     .res 1
refrow:   .res 1
cscan:    .res 1
rowsum:   .res 25               ; checksums of the rows' bitmap (Fletcher:
rowsum1:  .res 25               ;   sum of sums, sum)
rs_s1:    .res 1                ; RowSum
rs_s2:    .res 1
rowstale: .res 25               ; 1: converted by another pass since

HelpRti:
	rti

.segment "helpvectors"
	.word HelpRti, HelpRti, HelpRti

;---------------------------------------------------------------------------
; a program loaded into page 3 (compat.s), called with interrupts off
;---------------------------------------------------------------------------

.segment "helper"

; p3_exec <- the instructions that start at $038B-$038D, then a jmp to the
; one after them.  A jsr pushes the return address it would push there
; (P3_Jsr), a branch becomes the opposite branch over a jmp to its target.
; A, X, Y changed.
P3_Build:
	stz p3_x
	ldy #0                  ; offset from $038B
@ins:	cpy #3
	bcc @in
	jmp @end
@in:	jsr P3_Byte
	cmp #$20
	beq @jsr
	cmp #$4C                ; jmp, jmp (): as they are, and done
	beq @jmp
	cmp #$6C
	beq @jmp
	tax
	and #$1F
	cmp #$10
	beq @br
	txa
	and #$9F                ; brk, rti, rts: as they are, and done
	beq @one
	txa
	and #$1F
	tax
	lda oplen,x
	tax
@cp:	jsr P3_Byte             ; any other instruction: as it is
	jsr P3_Out
	iny
	dex
	bne @cp
	bra @ins
@one:	jsr P3_Byte
	bra P3_Out
@jmp:	ldx #3
@j:	jsr P3_Byte
	jsr P3_Out
	iny
	dex
	bne @j
	rts
@jsr:	iny
	jsr P3_Byte
	sta p3_jtgt
	iny
	jsr P3_Byte
	sta p3_jtgt+1
	tya                     ; return address: the jsr's last byte
	jsr P3_Addr
	sta p3_jret
	stx p3_jret+1
	lda #<P3_Jsr
	ldx #>P3_Jsr
	jmp P3_Jmp
@br:	txa
	eor #$20                ; the opposite branch
	jsr P3_Out
	lda #3
	jsr P3_Out
	lda #$4C
	jsr P3_Out
	iny
	tya                     ; target: the next instruction + offset
	inc a
	jsr P3_Addr
	sta p3_jret             ; (p3_jret as scratch: a jsr comes after it)
	stx p3_jret+1
	jsr P3_Byte
	tax
	clc
	adc p3_jret
	jsr P3_Out
	txa
	and #$80
	beq @p
	lda #$FF
@p:	adc p3_jret+1
	jsr P3_Out
	iny
	jmp @ins
@end:	tya
	jsr P3_Addr
P3_Jmp:	pha
	lda #$4C
	jsr P3_Out
	pla
	jsr P3_Out
	txa
P3_Out:	phx
	ldx p3_x
	sta p3_exec,x
	inc p3_x
	plx
	rts

; A = offset -> A/X = $038B + offset
P3_Addr:
	clc
	adc #<$038B
	ldx #>$038B
	bcc @1
	inx
@1:	rts

; A = the program's byte at $038B + Y
P3_Byte:
	cpy #3
	bcs @1
	lda p3_save,y
	rts
@1:	lda $038B,y
	rts

; instruction length by the low five bits of the opcode (6502)
oplen:	.byte 2,2,2,2, 2,2,2,2, 1,2,1,2, 3,3,3,3
	.byte 2,2,1,2, 2,2,2,2, 1,3,1,3, 3,3,3,3

;---------------------------------------------------------------------------
; The hand-over to X16 BASIC (copied to $0500 by SmcReset): what the X16
; KERNAL does at reset before BASIC, minus its RAM test and the DOS's start
; (so the SD card's current folder stays): the zero page and $0200-$03FF
; are the KERNAL's again already.
;---------------------------------------------------------------------------
HANDOVER = $0500

handover:
.org HANDOVER
	sei
	cld
	ldx #$FF
	txs
	stz $01                 ; the KERNAL's ROM bank (this runs in low RAM)
	stz $00
	jsr $FF84               ; IOINIT: VIAs, interrupt sources, IEC bus, VSYNC IRQ
	jsr $FF8A               ; RESTOR: the KERNAL's vectors ($0314 ...)
	lda #0
	jsr $FF68               ; mouse_config: mouse off
	stz VERA_CTRL           ; PSG silent (GEOS's sounds are on voice 15)
	lda #$C0
	sta VERA_ADDR_L
	lda #$F9
	sta VERA_ADDR_M
	lda #$11
	sta VERA_ADDR_H
	ldx #64
@z:	stz VERA_DATA0
	dex
	bne @z
	jsr $FF81               ; CINT: screen editor; VERA text mode, palette, no sprites
	cli
	jsr $FF6E               ; jsrfar: BASIC's cold start, as the KERNAL's reset ends
	.word $C000
	.byte 4                 ; (BASIC's ROM bank)
.reloc
handover_end:
.assert handover_end - handover <= $100, error, "hand-over code over a page"
