@echo off
rem Real-hardware rehearsal for GEOS-X16.PRG, in x16emu R49: the X16 starts
rem with an EMPTY RAM cartridge (ramcart.crt, banks 32-63) instead of
rem -cartbin geosx16.bin, as a real X16 with a RAM cartridge does.  Then type:
rem     LOAD "GEOS-X16.PRG",8
rem     RUN
setlocal
cd /d "%~dp0"
if not defined X16EMU if exist "%~dp0x16emu.exe" set "X16EMU=%~dp0x16emu.exe"
if not defined X16EMU if exist "%~dp0..\x16emu.exe" set "X16EMU=%~dp0..\x16emu.exe"
if not defined X16EMU (
  echo Cannot find x16emu.exe. Put this folder next to x16emu.exe, inside
  echo the x16emu folder, or set X16EMU in this file.
  pause
  exit /b 1
)
rem Ctrl+M in the emulator window releases (and recaptures) the mouse.
"%X16EMU%" -cart ramcart.crt -rtc -scale 2 -capture %*
