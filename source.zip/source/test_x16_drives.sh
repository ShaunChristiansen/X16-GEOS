#!/bin/sh
# Two-drive test of GEOS-X16 in x16emu: GEOSDISK.D64 (drive A) and
# GEOSDSK2.D64 (drive B).  The deskTop opens drive B and copies a file from
# it to drive A (dragged onto drive A's icon); after quitting to BASIC both
# host images must have a consistent BAM, and the copy must match the
# original.
#   X16EMU=path/to/x16emu X16ROM=path/to/rom.bin ./test_x16_drives.sh
set -e
cd "$(dirname "$0")"
HERE=$(pwd)
X16EMU=${X16EMU:-/home/claude/ext/x16-emulator/x16emu}
X16ROM=${X16ROM:-/home/claude/ext/x16-rom/build/x16/rom.bin}
DISKA=${DISKA:-../disks/WORK.D64}
DISKB=${DISKB:-../disks/WRUTIL64.D64}
FILE="text manager"
T=$HERE/build/test_drives
export DISPLAY=${DISPLAY:-:99}
pgrep -x Xvfb >/dev/null || { Xvfb $DISPLAY -screen 0 1024x768x24 >/dev/null 2>&1 & sleep 1; }
. tools/x16ui.sh
pkill -x "$(basename "$X16EMU")" 2>/dev/null || true; sleep 1
rm -rf $T; mkdir -p $T
cp geosx16.bin $T/
cp $DISKA $T/GEOSDISK.D64
cp $DISKB $T/GEOSDSK2.D64
GEOSIMG="python3 tools/geosimg.py"        # (check: the BAM; sum: the file)
SRC=$($GEOSIMG sum $DISKB "$FILE" | sed -n "s/^  $FILE: //p")
[ -n "$SRC" ] || fail "'$FILE' is not on $DISKB"

echo "boot with two drives, open drive B"
start
shot 1_desktop
goto 291 68; dclick; sleep 3; shot 2_drive_b
echo "drag '$FILE' onto drive A"
goto 52 100; click; sleep 0.5; click; sleep 0.6
rel 80 0; rel 80 -34; rel 79 -30; sleep 0.3; click; sleep 8; shot 3_copied
echo "quit to BASIC (closes the image files)"
goto 180 7; click; sleep 1; goto 175 47; click; sleep 6; shot 4_basic
python3 tools/x16basic.py $T/4_basic.png || fail "did not get to X16 BASIC"
pkill -x "$(basename "$X16EMU")" || true; sleep 0.5
$GEOSIMG check $T/GEOSDSK2.D64 || fail "drive B's BAM is wrong"
$GEOSIMG check $T/GEOSDISK.D64 || fail "drive A's BAM is wrong"
OUT=$($GEOSIMG sum $T/GEOSDISK.D64 "$FILE") || { echo "$OUT"; fail "the file is missing on drive A"; }
echo "$OUT"
case "$OUT" in *"$FILE: $SRC"*) ;; *) fail "the copy differs from the original";; esac
echo "PASS (screenshots in $T)"
