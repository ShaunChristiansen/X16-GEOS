#!/bin/sh
# Printing test of GEOS-X16 in x16emu (Linux, needs Xvfb, xdotool,
# ImageMagick "import", python3-pil):
#   a printer driver (MPS-803, from your GEOS64.D64) is copied onto a copy
#   of drive A; geoWrite makes a document and prints it twice.  x16emu has
#   no printer on its IEC port, so both jobs must land in print files
#   (PRINT1.PRN, PRINT2.PRN) in the emulator's folder, with the same bytes;
#   tools/prnview.py draws the first as PRINT1.png.
#   X16EMU=path/to/x16emu X16ROM=path/to/rom.bin ./test_x16_print.sh
#   DRIVER="Star NL-10(com)" ./test_x16_print.sh tries another driver
#   (DRAFT=1 for "ASCII Only", which prints only in draft or NLQ mode)
# With an x16emu built with a test printer on device 4 (X16PRN=file), the
# bytes go to that file instead and no print file may appear.
set -e
cd "$(dirname "$0")"
HERE=$(pwd)
X16EMU=${X16EMU:-/home/claude/ext/x16-emulator/x16emu}
X16ROM=${X16ROM:-/home/claude/ext/x16-rom/build/x16/rom.bin}
DISK=${DISK:-../disks/WORK.D64}
GEOS64=${GEOS64:-../disks/GEOS64.D64}
DRIVER=${DRIVER:-MPS-803}
T=$HERE/build/test_print
rm -rf $T; mkdir -p $T
cp geosx16.bin $T/
cp $DISK $T/GEOSDISK.D64
python3 tools/geosimg.py cp $GEOS64 $T/GEOSDISK.D64 "$DRIVER" >/dev/null
export DISPLAY=${DISPLAY:-:99}
pgrep -x Xvfb >/dev/null || { Xvfb $DISPLAY -screen 0 1024x768x24 >/dev/null 2>&1 & sleep 1; }

. tools/x16ui.sh

echo "boot ($DRIVER on drive A)"
start
shot 1_desktop
echo "geoWrite: a document"
goto 107 60; dclick; sleep 4
goto 103 63; click; sleep 2
typetext "Print Test"; key Return; sleep 3
typetext "Printed by GEOS-X16 on the Commander X16."; key Return
sleep 1; shot 2_typed
for j in 1 2; do
  echo "print, job $j"
  goto 38 7; click; sleep 1; goto 40 92; click; sleep 3; shot 3_dialog$j
  [ -n "$DRAFT" ] && { goto 144 67; click; sleep 1; }
  goto 111 120; click
  sleep 12                      # the job ends 5 s after the last byte
  shot 4_after$j
done
pkill -x "$(basename "$X16EMU")" || true
if [ -n "$X16PRN" ]; then
  [ ! -f $T/PRINT1.PRN ] || fail "a print file, with a printer on device 4"
  [ -s "$X16PRN" ] || fail "nothing reached the printer on device 4"
  echo "printer on device 4: $(wc -c < "$X16PRN") bytes"
else
  [ -s $T/PRINT1.PRN ] || fail "no PRINT1.PRN"
  [ -s $T/PRINT2.PRN ] || fail "no PRINT2.PRN (second job)"
  cmp -s $T/PRINT1.PRN $T/PRINT2.PRN || fail "the two jobs differ"
  echo "print files: $(wc -c < $T/PRINT1.PRN) bytes each"
  python3 tools/prnview.py $T/PRINT1.PRN
fi
echo "PASS (screenshots in $T)"
