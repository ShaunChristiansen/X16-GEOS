GEOS-X16 wallpapers
===================

Five wallpapers for the GEOS-X16 deskTop. Each one has a .BMX (the
wallpaper itself, in BMX, the Commander X16's own bitmap format) and a
.png (a picture of it, to see what it looks like).

  SYNTHWAVE.BMX   a striped sun over a neon grid
  SPACE.BMX       a ringed planet, a moon and a nebula
  MOUNTAINS.BMX   snowy peaks, a lake and pine trees at dawn
  TROPICAL.BMX    a bay, a beach and palm trees
  AURORA.BMX      northern lights over a snowy cabin

To use one: with the WALLPAPER program
--------------------------------------

Keep this folder (named GeosWallpapers) in your GEOS-X16 folder, next to
geosx16.bin. On the deskTop, double-click WALLPAPER (on drive A) and
choose:

  Your own: GEOSWALL.BMX   the GEOSWALL.BMX next to geosx16.bin
  Synthwave ... Aurora     the five here
  No wallpaper             GEOS's usual grey background pattern

The deskTop shows it straight away, and GEOS-X16 remembers it for the next
time it starts (in a small file it writes next to the disk images,
GEOSWALL.CFG). Delete GEOSWALL.CFG to go back to GEOSWALL.BMX.

On a real X16, put the folder on the SD card, next to the disk images.

To use one: by hand
-------------------

1. Copy it into your GEOS-X16 folder (where geosx16.bin is).
2. Rename it GEOSWALL.BMX, replacing the GEOSWALL.BMX that is there.
   (Keep a copy of the old one if you want it back.)
3. Start GEOS-X16. The wallpaper shows behind the deskTop's file window.

   (If you have used WALLPAPER, delete GEOSWALL.CFG too: it picks the
   wallpaper while it is there.)

On a real X16, put it on the SD card next to the disk images instead.

No GEOSWALL.BMX in the folder (and no GEOSWALL.CFG): no wallpaper, just
GEOS's usual grey background pattern (in your screen colours).

Your own wallpaper
------------------

Any BMX file works, from mkwall.py or from an X16 paint program or
converter, if it is 256 colours (8 bits a pixel), 320 pixels wide and at
least 200 high (a taller one loses rows at the top and bottom equally).
GEOS keeps 64 of the 256 colours for itself: pixels in those get the
nearest of the picture's other colours.

mkwall.py (Python 3 with Pillow) turns any picture into a wallpaper:

    python mkwall.py mypicture.png GEOSWALL.BMX

It scales the picture to 320x200 and converts it to the 207 colours GEOS
leaves free, so nothing needs changing. An old GEOSWALL.BIN (the format
before BMX) converts with:

    python mkwall.py --frombin GEOSWALL.BIN GEOSWALL.BMX

The deskTop's file window covers the top left of the screen,
so pictures with something to see along the right edge and the bottom
work best.

These pictures were drawn for GEOS-X16 (tools/wallpapers.py in the
source draws them again): share them as you like.
