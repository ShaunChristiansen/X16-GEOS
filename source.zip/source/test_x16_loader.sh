#!/bin/sh
# GEOS-X16.PRG, the loader for a real X16 with a RAM cartridge, in x16emu
# without -cartbin (an empty RAM cartridge, random contents as at power-on):
#   A  RAM cartridge, emulator folder: LOAD/RUN -> GEOS -> options > BASIC
#      -> X16 BASIC (really running)
#   B  no cartridge: LOAD/RUN -> its message, still X16 BASIC
#   C  RAM only in banks 32-34 (none in 48-56): its message, still X16 BASIC
#   D  as A, but everything on an SD card image (FAT32, file names as copied
#      from Windows: geosx16.bin in lower case): the real CMDR-DOS path
#   E  as D, but in a folder of the card (DOS"CD:GEOS-X16" first): nothing
#      resets on the way, so GEOS finds its disks there
# Needs: Xvfb, xdotool, ImageMagick, python3 + Pillow, mtools, dosfstools,
# x16emu's makecart.
set -e
cd "$(dirname "$0")"
X16EMU=${X16EMU:-/home/claude/ext/x16-emulator/x16emu}
MAKECART=${MAKECART:-$(dirname $X16EMU)/makecart}
X16ROM=${X16ROM:-/home/claude/ext/x16-rom/build/x16/rom.bin}
DISKS=${DISKS:-../disks}
ROMS=${ROMS:-../roms}
T=${T:-$(pwd)/build/test_loader}
export DISPLAY=${DISPLAY:-:99}
pgrep -x Xvfb >/dev/null || { Xvfb :99 -screen 0 1024x768x24 >/dev/null 2>&1 & sleep 1; }
. tools/x16ui.sh
fail() { echo "FAIL: $*"; pkill -x x16emu || true; exit 1; }

rm -rf $T; mkdir -p $T/keep
$MAKECART -ram 32 63 -o $T/ram.crt >/dev/null
$MAKECART -ram 32 34 -o $T/ram_no48.crt >/dev/null
files() {   # $1 = folder
  cp GEOS-X16.PRG $1/GEOS-X16.PRG
  cp geosx16.bin $1/GEOSX16.BIN
  cp $DISKS/WORK.D64 $1/GEOSDISK.D64
  cp $ROMS/BASIC.BIN $ROMS/KERNAL.BIN $1/
}
files $T
# start x16emu with $1 as its cartridge/SD arguments, no -cartbin
startx() {
  pkill -x "$(basename "$X16EMU")" 2>/dev/null || true; sleep 0.3
  (cd $T && "$X16EMU" -rom "$X16ROM" -sound none -scale 1 -rtc -capture -randram $1 > $T/x16emu.log 2>&1 &)
  sleep 7
  W=$(WIN)
  WX=$(xdotool getwindowgeometry $W | sed -n 's/.*Position: \([0-9]*\),\([0-9]*\).*/\1/p')
  WY=$(xdotool getwindowgeometry $W | sed -n 's/.*Position: \([0-9]*\),\([0-9]*\).*/\2/p')
}
loadrun() {
  typetext 'load"geos-x16.prg",8'; key Return; sleep 2
  typetext 'run'; key Return
}
geos_to_basic() {   # $1 = shot prefix: GEOS up, then options > BASIC
  sleep 14; shot ${1}_geos
  python3 tools/x16basic.py $T/${1}_geos.png >/dev/null 2>&1 && fail "$1: GEOS did not start"
  goto 180 7; click; sleep 1; goto 175 47; click; sleep 5; shot ${1}_basic
  basic_alive ${1}_alive || fail "$1: X16 BASIC is not running after GEOS"
}

echo "A: RAM cartridge"
startx "-cart ram.crt"
shot a0_basic
loadrun
geos_to_basic a

echo "B: no cartridge"
startx ""
loadrun; sleep 3; shot b_msg
basic_alive b_alive || fail "B: not back in a working X16 BASIC"

echo "C: no RAM in banks 48-56"
startx "-cart ram_no48.crt"
loadrun; sleep 3; shot c_msg
basic_alive c_alive || fail "C: not back in a working X16 BASIC"

echo "D: SD card image"
mkdir -p $T/sd
files $T/sd
mv $T/sd/GEOSX16.BIN $T/sd/geosx16.bin
dd if=/dev/zero of=$T/sd.img bs=1M count=64 2>/dev/null
mkfs.fat -F 32 -s 1 -n X16 --offset 2048 $T/sd.img $(( (64 * 1024 - 1024) )) >/dev/null
python3 - $T/sd.img <<'PY'
import struct, sys
# MBR with one FAT32 (LBA) partition from sector 2048 to the end
f = open(sys.argv[1], "r+b"); n = 64 * 2048
f.seek(446); f.write(struct.pack("<B3sB3sII", 0, b"\0\0\0", 0x0C, b"\0\0\0", 2048, n - 2048))
f.seek(510); f.write(b"\x55\xAA"); f.close()
PY
for f in $T/sd/*; do mcopy -i $T/sd.img@@1M "$f" ::$(basename "$f"); done
startx "-cart ram.crt -sdcard sd.img"
loadrun
geos_to_basic d

echo "E: SD card image, files in a folder"
cp $T/sd.img $T/sd2.img
mmd -i $T/sd2.img@@1M ::GEOS-X16
for f in $T/sd/*; do mcopy -i $T/sd2.img@@1M "$f" ::GEOS-X16/$(basename "$f"); done
for f in $T/sd/*; do mdel -i $T/sd2.img@@1M ::$(basename "$f"); done
startx "-cart ram.crt -sdcard sd2.img"
typetext 'dos"cd:geos-x16"'; key Return; sleep 1
loadrun
geos_to_basic e

cp $T/*.png $T/keep/
pkill -x x16emu || true
echo PASS
