#!/bin/sh
# Builds GEOS 2.0 for the Commander X16: geosx16.bin, a raw cartridge image
# for x16emu (-cartbin).  Needs cc65 (ca65/ld65) and python3.
set -e
cd "$(dirname "$0")"
command -v ca65 >/dev/null 2>&1 || PATH=/home/claude/ext/cc65/bin:$PATH
B=build/x16
mkdir -p $B

python3 tools/x16tables.py >/dev/null

# the C64 kernel sources (Makefile, VARIANT=bsw), without the C64-only
# start, keyboard matrix scan, BASIC and RTC parts, plus the X16 parts
SRC="
kernal/bitmask/bitmask1.s kernal/bitmask/bitmask2.s kernal/bitmask/bitmask3.s
kernal/bswfont/bswfont.s
kernal/conio/conio1.s kernal/conio/conio2.s kernal/conio/conio3a.s kernal/conio/conio3b.s
kernal/conio/conio4.s kernal/conio/conio5.s kernal/conio/conio6.s
kernal/dlgbox/dlgbox1a.s kernal/dlgbox/dlgbox1b.s kernal/dlgbox/dlgbox1c.s kernal/dlgbox/dlgbox1d.s
kernal/dlgbox/dlgbox1e1.s kernal/dlgbox/dlgbox1e2.s kernal/dlgbox/dlgbox1f.s kernal/dlgbox/dlgbox1g.s
kernal/dlgbox/dlgbox1h.s kernal/dlgbox/dlgbox1i.s kernal/dlgbox/dlgbox1j.s kernal/dlgbox/dlgbox1k.s
kernal/dlgbox/dlgbox2.s
kernal/files/files10.s kernal/files/files1a2a.s kernal/files/files1a2b.s kernal/files/files1b.s
kernal/files/files2.s kernal/files/files3.s kernal/files/files6a.s kernal/files/files6b.s
kernal/files/files6c.s kernal/files/files7.s kernal/files/files8.s kernal/files/files9.s
kernal/fonts/fonts1.s kernal/fonts/fonts2.s kernal/fonts/fonts3.s kernal/fonts/fonts4.s
kernal/fonts/fonts4a.s kernal/fonts/fonts4b.s
kernal/graph/clrscr.s kernal/graph/inlinefunc.s kernal/graph/graphicsstring.s kernal/graph/graph2l1.s
kernal/graph/pattern.s kernal/graph/inline.s kernal/graph/bitmapclip.s kernal/graph/bitmapup.s
kernal/graph/line.s kernal/graph/point.s kernal/graph/rect.s kernal/graph/scanline.s
kernal/header/header.s
kernal/hw/hw1a.s kernal/hw/hw1b.s kernal/hw/hw2.s kernal/hw/hw3.s
kernal/icon/icon1.s kernal/icon/icon2.s
kernal/init/init1.s kernal/init/init2.s kernal/init/init3.s kernal/init/init4.s
kernal/irq/irq.s
kernal/jumptab/jumptab.s
kernal/keyboard/keyboard3.s
kernal/load/deskacc.s kernal/load/load1a.s kernal/load/load1b.s kernal/load/load1c.s
kernal/load/load2.s kernal/load/load3.s kernal/load/load4b.s
kernal/mainloop/mainloop1.s kernal/mainloop/mainloop2.s kernal/mainloop/mainloop3.s
kernal/math/shl.s kernal/math/shr.s kernal/math/muldiv.s kernal/math/neg.s kernal/math/dec.s
kernal/math/random.s kernal/math/crc.s
kernal/memory/memory1a.s kernal/memory/memory1b.s kernal/memory/memory2.s kernal/memory/memory3.s
kernal/menu/menu1.s kernal/menu/menu2.s kernal/menu/menu3.s
kernal/misc/misc.s
kernal/mouse/mouse1.s kernal/mouse/mouse2.s kernal/mouse/mouse3.s kernal/mouse/mouse4.s
kernal/mouse/mouseptr.s
kernal/panic/panic.s
kernal/patterns/patterns.s
kernal/process/process1.s kernal/process/process2.s kernal/process/process3a.s
kernal/process/process3aa.s kernal/process/process3b.s kernal/process/process3c.s
kernal/rename.s
kernal/reu/reu.s
kernal/serial/serial1.s kernal/serial/serial2.s
kernal/sprites/sprites.s
kernal/time/time1.s kernal/time/time2.s
kernal/tobasic/tobasic2.s
kernal/vars/vars.s
kernal/start/start_x16.s
kernal/x16/boot.s kernal/x16/drvx16.s kernal/x16/x16io.s kernal/x16/inputx16.s kernal/x16/c64kernal.s
kernal/x16/vectors.s kernal/x16/helper.s kernal/x16/compat.s kernal/x16/sdio.s
kernal/x16/bam.s kernal/x16/prn.s kernal/x16/calypso.s kernal/x16/serial.s kernal/x16/snd.s kernal/x16/mount.s kernal/x16/joy.s
"
OBJS=""
for s in $SRC; do
	o=$B/$(echo $s | sed 's|/|_|g; s|\.s$|.o|')
	ca65 -D x16=1 -D drv1541=1 -I inc -I . -I kernal/x16 --cpu 6502X $s -o $o
	OBJS="$OBJS $o"
done
ld65 -C kernal/kernal_x16.cfg -o $B $OBJS -m $B/kernal.map -Ln $B/kernal.lab
python3 tools/mkcart.py $B geosx16.bin
# GEOS-X16.PRG: the loader for a real X16 with a RAM cartridge (loader/loader.s)
ca65 --cpu 65C02 loader/loader.s -o $B/loader.o -l $B/loader.lst
ld65 -C loader/loader.cfg -o GEOS-X16.PRG $B/loader.o
