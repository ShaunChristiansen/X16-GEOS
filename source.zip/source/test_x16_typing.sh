#!/bin/sh
# Keyboard stress test of GEOS-X16 in x16emu: 22 lines typed into a new
# geoWrite document at about 60 keys per second (faster than GEOS reads
# them, so the SMC's key buffer fills up), scrolling the page.  The saved
# document must hold every line, in order, with nothing lost or repeated.
#   X16EMU=path/to/x16emu X16ROM=path/to/rom.bin ./test_x16_typing.sh
set -e
cd "$(dirname "$0")"
HERE=$(pwd)
X16EMU=${X16EMU:-/home/claude/ext/x16-emulator/x16emu}
X16ROM=${X16ROM:-/home/claude/ext/x16-rom/build/x16/rom.bin}
DISK=${DISK:-../disks/WORK.D64}
DELAY=${DELAY:-15}
T=$HERE/build/test_typing
rm -rf $T; mkdir -p $T
cp geosx16.bin $T/
cp $DISK $T/GEOSDISK.D64
export DISPLAY=${DISPLAY:-:99}
pgrep -x Xvfb >/dev/null || { Xvfb $DISPLAY -screen 0 1024x768x24 >/dev/null 2>&1 & sleep 1; }
. tools/x16ui.sh

echo "boot, geoWrite: new document"
start
goto 107 60; dclick; sleep 4
goto 103 63; click; sleep 2
typetext "Fast Typing"; key Return; sleep 3
echo "typing 22 lines (key delay ${DELAY} ms)"
for i in $(seq 1 22); do
  xdotool type --window $W --delay $DELAY "Line $i of the scroll test."
  xdotool key --window $W --delay $DELAY Return
done
sleep 4
echo "key repeat: hold x for 1.5 s"
xdotool keydown --window $W x; sleep 1.5; xdotool keyup --window $W x
sleep 0.5; typetext "END"; sleep 1; shot 1_typed
echo "close, quit"
goto 38 7; click; sleep 0.8; goto 40 21; click; sleep 3
goto 103 111; click; sleep 5; shot 2_desktop
pkill -x "$(basename "$X16EMU")" || true; sleep 0.5
TXT=$(doctext "Fast Typing")
echo "$TXT" > $T/document.txt
python3 - "$T/document.txt" <<'PY' || fail "typed text was lost or garbled (see $T/document.txt)"
import re, sys
t = open(sys.argv[1]).read()
want = "".join("Line %d of the scroll test." % i for i in range(1, 23))
i = t.find("Line 1 of")
got = t[i:i + len(want)] if i >= 0 else ""
if got != want:
    for k, (a, b) in enumerate(zip(got, want)):
        if a != b:
            print("first difference at %d: %r / expected %r" % (k, got[k:k+30], want[k:k+30]))
            break
    else:
        print("text ends early: %d of %d characters" % (len(got), len(want)))
    sys.exit(1)
print("all 22 lines intact (%d characters)" % len(want))
m = re.search(r"(x+)END", t)
if not m or not 3 <= len(m.group(1)) <= 12:
    print("key repeat: %r" % (m.group(0) if m else t[-40:]))
    sys.exit(1)
print("key repeat: %d x, stopped on release" % len(m.group(1)))
PY
echo "PASS (screenshots in $T)"
