#!/bin/sh
# Runs every GEOS-X16 test in x16emu (see the scripts for what each checks).
cd "$(dirname "$0")"
fail=0
for t in test_x16.sh test_x16_typing.sh test_x16_drives.sh test_x16_da.sh test_x16_colour.sh test_x16_print.sh test_x16_wallpaper.sh test_x16_x16call.sh; do
  r=$(./$t 2>&1 | tail -1)
  case "$r" in PASS*) echo "PASS  $t";; *) echo "FAIL  $t: $r"; fail=1;; esac
done
exit $fail
