#!/bin/sh
# Builds the ready-to-run folder dist/GEOS-X16 (and dist/GEOS-X16.zip):
# the cartridge, the Windows launcher, the README, the wallpaper (five more
# in GeosWallpapers, and the tool to make others), the print file viewer
# prnview.py, the disk tool geosimg.py, and three disk images made
# from the GEOS disks in ../disks (APPS64, GEOS64, SPELL64, WRUTIL64,
# geocalc_s1, GeoCalc_Unkeyed):
#   GEOSDISK.D64  drive A: DESK TOP, GEOWRITE, calculator, note pad,
#                 preference mgr, pad color mgr, six fonts, ReadMe, and
#                 colour settings (Preferences, Pad Color Pref)
#   GEOSDSK2.D64  drive B: GEOPAINT, photo manager, California, Roma,
#                 University
#   GEOSDSK3.D81  drive C, a 1581 disk: every program that works (geoWrite,
#                 geoPaint, geoCalc, geoSpell + dictionary, geoMerge, Text
#                 Grabber, geoText, geoLaser, CONVERT, PAINT DRIVERS), the
#                 desk accessories, the fonts and forms, and DESK TOP (so it
#                 can be drive A on its own as GEOSDISK.D81)
# The disk images hold Berkeley Softworks software: for your own use.
set -e
cd "$(dirname "$0")"
D=../disks
T="python3 ../tools"
OUT=dist/GEOS-X16
rm -rf dist; mkdir -p $OUT
./build_x16.sh >/dev/null
cp geosx16.bin GEOS-X16.bat GEOS-X16.PRG LOADER-TEST.bat tools/ramcart.crt tools/mkwall.py tools/geosimg.py tools/prnview.py $OUT/
cp -r GeosWallpapers $OUT/
cp README-X16.md $OUT/README.txt
python3 tools/mkwall.py --default $OUT/GEOSWALL.BMX >/dev/null
python3 tools/geosimg.py new $OUT/GEOSSD.D81 "SD Card" SD >/dev/null   # SD CARD: a folder as drive C
A=$OUT/GEOSDISK.D64; B=$OUT/GEOSDSK2.D64
$T/d64rm.py $D/APPS64.D64 $A "GEOPAINT" "photo manager" >/dev/null
$T/d64cp.py $D/GEOS64.D64 $A "preference mgr" "pad color mgr" >/dev/null
$T/d64cp.py --compact $A
# colours, as saved by the preference manager and the pad color manager:
# white on blue, a white file window with an icon colour per file type,
# a yellow pointer, a light blue border
$T/geoscolours.py $A --screen white blue --mouse yellow --border lightblue \
    --pad white blue --icons darkgrey brown brown darkgrey purple red blue \
    green orange darkgrey darkgrey darkgrey purple darkgrey purple darkgrey
$T/d64cp.py --rename $A "GEOS X16 A" XA
python3 tools/mkwallapp.py $A >/dev/null    # WALLPAPER, the 8th file
$T/d64rm.py $D/APPS64.D64 $B "DESK TOP" "GEOWRITE" "calculator" "note pad" \
    "Cory" "Dwinelle" "Commodore" "ReadMe" >/dev/null
$T/d64cp.py --compact $B
$T/d64cp.py --rename $B "GEOS X16 B" XB
$T/d64check.py $A
$T/d64check.py $B
# drive C: the apps D81
C=$OUT/GEOSDSK3.D81
G="python3 tools/geosimg.py"
$G new $C "GEOS X16 Apps" X8 >/dev/null
{
$G cp $D/APPS64.D64 $C "DESK TOP" GEOWRITE GEOPAINT
$G cp $D/geocalc_s1.d64 $C GEOCALC
$G cp $D/SPELL64.D64 $C GEOSPELL
$G cp $D/WRUTIL64.D64 $C GEOMERGE "TEXT GRABBER"
$G cp $D/GeoCalc_Unkeyed.d64 $C geoText
$G cp $D/WRUTIL64.D64 $C GEOLASER
$G cp $D/GEOS64.D64 $C CONVERT "PAINT DRIVERS"
$G cp $D/APPS64.D64 $C calculator "note pad" "photo manager"
$G cp $D/WRUTIL64.D64 $C "text manager"
$G cp $D/GEOS64.D64 $C "alarm clock" "preference mgr" "pad color mgr"
$G cp $D/APPS64.D64 $C ReadMe
$G cp $D/SPELL64.D64 $C GeoDictionary
$G cp $D/geocalc_s1.d64 $C "New Car" "1987 budget"
$G cp $D/WRUTIL64.D64 $C "EasyScript Form" "PaperClip Form" "SpeedScript Form" \
    "WordWriter Form" "Generic I Form" "Generic II Form" "Generic III Form"
$G cp $D/GeoCalc_Unkeyed.d64 $C LaserWriter
$G cp $D/APPS64.D64 $C California Cory Dwinelle Roma University Commodore
$G cp $D/WRUTIL64.D64 $C LW_Roma LW_Cal LW_Greek LW_Barrows
} >/dev/null
$G check $C
(cd dist && rm -f GEOS-X16.zip && zip -qr GEOS-X16.zip GEOS-X16)
ls -l $OUT dist/GEOS-X16.zip
