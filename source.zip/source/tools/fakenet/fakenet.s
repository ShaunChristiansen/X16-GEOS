; A stand-in for the Calypso card's NET.BIN, for test_x16_calypso.sh: the
; same jump table and zero page arguments (doc/usage/Network API.md in
; smrobtzz/x16-esp-fw), but its one socket is the test x16emu's UART at
; $9FE0 (tools/x16emu-testcards.patch), connected to tools/fakebbs.py raw.
; gethostbyname sends "DNS name" and answers 10.1.2.3; a TCP open sends
; "ATDTa.b.c.d:port" and is connected after 20 polls.

.setcpu "65SC02"

U_RBR = $9FE0
U_THR = $9FE0
U_IER = $9FE1
U_FCR = $9FE2
U_LCR = $9FE3
U_MCR = $9FE4
U_LSR = $9FE5

.segment "CODE"
	jmp Open
	jmp Close
	jmp Send
	jmp Recv
	jmp Poll
	jmp Dns

Init:	bit inited
	bmi @x
	lda #$80
	sta U_LCR
	lda #8
	sta U_RBR
	stz U_IER
	lda #3
	sta U_LCR
	lda #$87
	sta U_FCR
	stz U_IER
	lda #$23
	sta U_MCR
	lda #$80
	sta inited
@x:	rts

Out:	pha
:	lda U_LSR
	and #$20
	beq :-
	pla
	sta U_THR
	rts

Open:	jsr Init
	stz conn
	lda $16
	cmp #3                  ; serial: there
	bne :+
	lda #1
	sta conn
	stz $04
	rts
:	lda #'A'
	jsr Out
	lda #'T'
	jsr Out
	lda #'D'
	jsr Out
	lda #'T'
	jsr Out
	ldx #0
@ip:	phx
	lda $04,x               ; the address, where gethostbyname put it
	sta n
	stz n+1
	jsr PrDec
	plx
	inx
	cpx #4
	beq :+
	lda #'.'
	jsr Out
	bra @ip
:	lda #':'
	jsr Out
	lda $17
	sta n
	lda $18
	sta n+1
	jsr PrDec
	lda #13
	jsr Out
	lda #20
	sta wait
	stz $04
	rts

Close:	stz conn
	stz wait
	stz $04
	rts

Send:	jsr Init
	ldy #0
@l:	cpy $05
	beq @x
	lda ($07),y
	jsr Out
	iny
	bra @l
@x:	stz $04
	rts

Recv:	jsr Init
	ldy #0
@l:	cpy $05
	beq @x
	lda U_LSR
	lsr a
	bcc @x
	lda U_RBR
	sta ($07),y
	iny
	bra @l
@x:	sty $05
	stz $06
	stz $04
	rts

Poll:	jsr Init
	lda wait
	beq :+
	dec wait
	bne :+
	lda #1
	sta conn
:	lda conn
	asl a
	sta $04
	lda U_LSR
	and #1
	ora $04
	sta $04
	stz $05
	stz $06
	stz $07
	rts

Dns:	jsr Init
	lda #'D'
	jsr Out
	lda #'N'
	jsr Out
	lda #'S'
	jsr Out
	lda #' '
	jsr Out
	ldy #0
@l:	cpy $06
	beq @e
	lda ($04),y
	jsr Out
	iny
	bra @l
@e:	lda #13
	jsr Out
	ldx #15
:	stz $04,x
	dex
	bpl :-
	lda #10
	sta $04
	sta ip0
	lda #1
	sta $05
	lda #2
	sta $06
	lda #3
	sta $07
	lda #4
	sta $14
	stz $15
	rts

; n in decimal
PrDec:	ldx #0
	stz lead
@d:	ldy #'0'
@s:	lda n
	sec
	sbc tl,x
	pha
	lda n+1
	sbc th,x
	bcc @n
	sta n+1
	pla
	sta n
	iny
	bra @s
@n:	pla
	cpy #'0'
	bne @o
	bit lead
	bmi @o
	cpx #4
	bne @k
@o:	tya
	jsr Out
	lda #$80
	sta lead
@k:	inx
	cpx #5
	bne @d
	rts
tl:	.byte <10000, <1000, <100, <10, <1
th:	.byte >10000, >1000, >100, >10, >1

inited:	.byte 0
conn:	.byte 0
wait:	.byte 0
lead:	.byte 0
ip0:	.byte 0
n:	.word 0
