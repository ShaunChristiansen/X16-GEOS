#!/usr/bin/env python3
"""Checks that VERA shows what GEOS drew: a memory dump of x16emu (-dump RBV,
Ctrl+S) against the C64 bitmap (RAM bank $2F) and colour matrix ($8C00).

   x16vramcheck.py DUMP.bin [LABELS]

LABELS is the kernel's label file (default build/x16/kernal.lab), for the
addresses of x16_desk and x16_wpok.

Every card: layer 1's tile = the bitmap's 8 bytes, 2 bits per pixel (bit 1 ->
value 1); map entries: layer 1 tile n with palette offset = foreground,
layer 0 the solid tile with offset = background.  On the deskTop with a
wallpaper, cards in screencolors: every pixel that differs from the deskTop
pattern must be drawn (1 for a set bit, 2 for a clear one); the others may
be transparent; layer 0 shows the wallpaper tile n.  Prints the bad cards,
exits 1 when there are any."""
import sys

RAMSZ, BANKS = 0xA000, 64
PAT = [0xAA, 0x55] * 4


def main(path, labels='build/x16/kernal.lab'):
    lab = {}
    for line in open(labels):
        p = line.split()
        if len(p) == 3:
            lab[p[2].lstrip('.')] = int(p[1], 16)
    d = open(path, 'rb').read()
    ram = d[:RAMSZ]
    br = d[RAMSZ:RAMSZ + BANKS * 8192]
    v = d[RAMSZ + BANKS * 8192:RAMSZ + BANKS * 8192 + 0x20000]
    bm = br[0x2F * 8192:0x2F * 8192 + 8000]
    cm = ram[0x8C00:0x8C00 + 1000]
    scol = ram[0x851E]
    wp = ram[lab['x16_desk']] & ram[lab['x16_wpok']] & 0x80
    bad = []
    for n in range(1000):
        row, col = divmod(n, 40)
        cb = cm[n]
        lines = bm[row * 320 + col * 8:row * 320 + col * 8 + 8]
        tile = v[n * 16:n * 16 + 16]
        m1 = v[0x4000 + (row * 64 + col) * 2:0x4000 + (row * 64 + col) * 2 + 2]
        m0 = v[0x5000 + (row * 64 + col) * 2:0x5000 + (row * 64 + col) * 2 + 2]
        why = []
        if m1[0] != n & 255 or m1[1] != (cb & 0xF0 | n >> 8):
            why.append('map1 %02x%02x' % (m1[0], m1[1]))
        wall = wp and cb == scol
        want0 = (n & 255, n >> 8) if wall else (0xFF, (cb & 15) << 4 | 3)
        if tuple(m0) != want0:
            why.append('map0 %02x%02x' % (m0[0], m0[1]))
        for r in range(8):
            got = tile[2 * r] << 8 | tile[2 * r + 1]
            for x in range(8):
                bit = lines[r] >> (7 - x) & 1
                px = got >> (14 - 2 * x) & 3
                if not wall:
                    ok = px == bit
                elif (lines[r] ^ PAT[r]) >> (7 - x) & 1:
                    ok = px == (1 if bit else 2)
                else:
                    ok = px in (0, 1 if bit else 2)
                if not ok:
                    why.append('line %d pixel %d' % (r, x))
                    break
            if len(why) > 2:
                break
        if why:
            bad.append((row, col, cb, why))
    for row, col, cb, why in bad[:20]:
        print('card row %2d col %2d colour %02x: %s' % (row, col, cb, ', '.join(why)))
    rows = sorted(set(b[0] for b in bad))
    print('%d bad cards%s' % (len(bad), (' in rows ' + ' '.join(map(str, rows))) if bad else ''))
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main(*sys.argv[1:3]))
