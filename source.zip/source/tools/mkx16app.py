#!/usr/bin/env python3
"""Builds a GEOS-X16 program and puts it on a GEOS disk image (D64 or D81),
replacing an older copy:

   mkx16app.py [sdcard] IMAGE [SLOT]   (needs ca65/ld65; SLOT: as
                                       mkwallapp.py, default 7)

X16 FILES (apps/x16files.s: a "hybrid" program, GEOS-X16's call 9), or with
"sdcard", SD CARD (apps/sdcard.s: the SD card's files and folders; copying
.CVT and .TXT files to and from GEOS disks, a disk image into a drive, a
.BMX wallpaper, a folder as drive C)."""
import os, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import geosimg
import mkwallapp

NAME = "X16 FILES"
LOAD = 0x0400

# 24 x 21 icon: an SD card
ICON = """
........................
.....##############.....
.....#.#.#.#.#.#..##....
.....#.#.#.#.#.#...##...
.....#.#.#.#.#.#....#...
.....#..............#...
.....#..............#...
.....#...###..###...#...
.....#..#.....#..#..#...
.....#...##...#..#..#...
.....#.....#..#..#..#...
.....#..###...###...#...
.....#..............#...
.....#..............#...
.....#....X16.......#...
.....#..............#...
.....#..............#...
.....#..............#...
.....#..............#...
.....################...
........................
""".replace("X16", "###")


APPS = {
    "x16files": ("X16 FILES", "x16files.s", ICON, b"X16 Files   V1.0",
                 b"Reads HELLO.TXT from the X16's SD card through the X16 KERNAL "
                 b"(GEOS-X16 call 9) and shows it."),
    "sdcard": ("SD CARD", "sdcard.s", ICON, b"SD Card     V1.0",
               b"A window on the X16's SD card: its files and folders; copy, "
               b"mount, wallpaper, rename, delete (GEOS-X16)."),
}
CPU = {"sdcard": "65sc02"}
APP = "x16files"


def build():
    tmp = tempfile.mkdtemp()
    o, b = os.path.join(tmp, "a.o"), os.path.join(tmp, "a.bin")
    apps = os.path.join(ROOT, "apps")
    subprocess.check_call(["ca65", "-I", os.path.join(ROOT, "inc"), "--cpu", CPU.get(APP, "6502"),
                           os.path.join(apps, APPS[APP][1]), "-o", o])
    subprocess.check_call(["ld65", "-C", os.path.join(apps, "wallpaper.cfg"), "-o", b, o])
    return open(b, "rb").read()


def header(prog):
    name, src, icon, cls, desc = APPS[APP]
    mkwallapp.ICON = icon
    h = bytearray(mkwallapp.header(prog))
    h[0x4D:0x4D + 20] = bytes(20)
    h[0x4D:0x4D + len(cls)] = cls
    h[0xA0:0x100] = bytes(0x60)
    h[0xA0:0xA0 + len(desc[:95])] = desc[:95]
    return bytes(h)


def main(argv):
    global APP, NAME
    if argv[:1] and argv[0] in APPS:
        APP = argv.pop(0)
    NAME = APPS[APP][0]
    if len(argv) not in (1, 2):
        raise SystemExit(__doc__)
    prog = build()
    hdr = header(prog)
    slot = int(argv[1]) if len(argv) > 1 else 7
    img = geosimg.Image(open(argv[0], "rb").read())
    for e in img.entries():
        if img.d[e + 2] and img.name_of(e) == NAME:
            for t, s in img.chain(img.d[e + 21], img.d[e + 22]) + img.chain(img.d[e + 3], img.d[e + 4]):
                img.free(t, s)
            img.d[e + 2:e + 32] = bytes(30)
    ents = list(img.entries())
    while len(ents) <= slot:
        img.add_dir_block()
        ents = list(img.entries())
    want = ents[slot]
    if img.d[want + 2]:
        free = [e for e in img.entries() if e != want and not img.d[e + 2]]
        e2 = free[0] if free else img.add_dir_block()
        img.d[e2 + 2:e2 + 32] = img.d[want + 2:want + 32]
        img.d[want + 2:want + 32] = bytes(30)
    geosimg.add_file(img, NAME, hdr, prog)
    new = [e for e in img.entries() if img.d[e + 2] and img.name_of(e) == NAME][0]
    if new != want:
        img.d[want + 2:want + 32] = img.d[new + 2:new + 32]
        img.d[new + 2:new + 32] = bytes(30)
    open(argv[0], "wb").write(img.d)
    print("blocks free:", img.free_blocks())


if __name__ == "__main__":
    main(sys.argv[1:])
