#!/usr/bin/env python3
"""Draws the five GEOS-X16 wallpapers in GeosWallpapers/ (original pictures,
drawn here in code) and converts each with mkwall.py:

   wallpapers.py OUTDIR        OUTDIR/<name>.BMX + OUTDIR/<name>.png (preview)

The deskTop's file window covers the top left, so each picture keeps its
interest along the right edge and the bottom."""
import math, os, random, sys
from PIL import Image, ImageDraw, ImageFilter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mkwall

W, H = 320, 200


def mix(c1, c2, t):
    t = max(0.0, min(1.0, t))
    return tuple(int(a + (b - a) * t) for a, b in zip(c1, c2))


def grad(stops, t):
    for (t0, c0), (t1, c1) in zip(stops, stops[1:]):
        if t <= t1:
            return mix(c0, c1, (t - t0) / max(1e-6, t1 - t0))
    return stops[-1][1]


def vgrad(img, stops, y0=0, y1=H):
    d = ImageDraw.Draw(img)
    for y in range(y0, y1):
        d.line([(0, y), (W, y)], fill=grad(stops, (y - y0) / max(1, y1 - y0 - 1)))


def ridge(d, base, amp, freq, phase, col, seed, bottom=H, step=2, rough=0.08):
    r = random.Random(seed)
    pts = []
    for x in range(-2, W + 3, step):
        v = (math.sin(x * freq + phase) * amp
             + math.sin(x * freq * 2.7 + phase * 1.3) * amp * 0.35
             + r.uniform(-1.0, 1.0) * amp * rough)
        pts.append((x, base - v))
    d.polygon(pts + [(W + 3, bottom), (-2, bottom)], fill=col)
    return pts


def stars(d, rnd, n, ymax, xmin=0):
    for _ in range(n):
        x, y = rnd.randrange(xmin, W), rnd.randrange(ymax)
        b = rnd.randrange(130, 256)
        d.point((x, y), fill=(b, b, min(255, b + 25)))
        if rnd.random() < 0.08:
            d.point([(x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)],
                    fill=(b // 2, b // 2, b // 2 + 30))


# 1. Synthwave: a striped sun over a neon grid
def synthwave():
    img = Image.new("RGB", (W, H))
    hz = 118
    vgrad(img, [(0, (10, 4, 40)), (0.55, (60, 10, 90)), (1, (220, 60, 140))], 0, hz)
    d = ImageDraw.Draw(img)
    rnd = random.Random(3)
    stars(d, rnd, 70, 70)
    sx, sy, sr = 236, 86, 46
    for y in range(sy - sr, hz):
        t = (y - (sy - sr)) / (2 * sr)
        hw = math.sqrt(max(0, sr * sr - (y - sy) ** 2))
        gap = y > sy - 8 and (y - sy) % 7 < 1 + (y - sy) // 9
        if not gap:
            d.line([(sx - hw, y), (sx + hw, y)], fill=mix((255, 230, 90), (255, 40, 150), t))
    # mountains in front of the sun
    ridge(d, hz - 6, 10, 0.03, 0.4, (40, 8, 70), 4, hz)
    # the floor
    for y in range(hz, H):
        t = (y - hz) / (H - hz)
        d.line([(0, y), (W, y)], fill=mix((40, 6, 60), (12, 2, 30), t))
    vx = 236
    for i in range(-14, 15):
        x1 = vx + i * 48
        d.line([(vx + i * 6, hz), (x1, H)], fill=(255, 60, 200))
    y, k = hz + 1.0, 1.0
    while y < H:
        d.line([(0, int(y)), (W, int(y))], fill=mix((255, 80, 200), (90, 200, 255), (y - hz) / (H - hz)))
        k *= 1.32
        y += k
    d.line([(0, hz), (W, hz)], fill=(255, 150, 220))
    return img.filter(ImageFilter.SMOOTH)


# 2. Deep space: a ringed planet, a moon and a nebula
def space():
    img = Image.new("RGB", (W, H), (4, 4, 16))
    px = img.load()
    rnd = random.Random(7)
    # nebula: soft blobs of colour
    blobs = [(250, 60, 90, (120, 30, 140)), (290, 150, 70, (30, 80, 160)),
             (180, 170, 60, (150, 40, 90)), (120, 40, 70, (20, 40, 100))]
    for y in range(H):
        for x in range(W):
            c = (4, 4, 16)
            n = math.sin(x * 0.05 + y * 0.03) * 0.5 + math.sin(x * 0.013 - y * 0.07) * 0.5
            for bx, by, br, bc in blobs:
                dd = math.hypot(x - bx, y - by) / br
                g = max(0.0, 1.0 - dd) ** 2 * (0.75 + 0.25 * n)
                c = mix(c, bc, g)
            px[x, y] = c
    d = ImageDraw.Draw(img)
    stars(d, rnd, 260, H)
    # the planet
    cx, cy, r = 250, 128, 44
    for y in range(cy - r, cy + r + 1):
        for x in range(cx - r, cx + r + 1):
            dx, dy = x - cx, y - cy
            if dx * dx + dy * dy <= r * r:
                band = math.sin((dy + dx * 0.25) * 0.32) * 0.5 + 0.5
                base = mix((210, 140, 70), (240, 200, 130), band)
                lit = max(0.0, (-dx * 0.6 - dy * 0.5) / r + 0.6)
                px[x, y] = mix((30, 14, 20), base, min(1.0, lit))
    # the ring: an ellipse in front, the back half hidden by the planet
    for a in range(0, 3600):
        t = a / 3600 * 2 * math.pi
        for rr, col in ((70, (200, 180, 150)), (64, (150, 130, 110)), (76, (120, 110, 100))):
            x = cx + rr * math.cos(t)
            y = cy + rr * 0.28 * math.sin(t) - (x - cx) * 0.18
            if math.sin(t) < 0 and (x - cx) ** 2 + (y - cy) ** 2 < r * r:
                continue
            if 0 <= x < W and 0 <= y < H:
                px[int(x), int(y)] = col
    # a small moon
    mx, my, mr = 152, 168, 11
    for y in range(my - mr, my + mr + 1):
        for x in range(mx - mr, mx + mr + 1):
            if (x - mx) ** 2 + (y - my) ** 2 <= mr * mr:
                lit = max(0.0, (-(x - mx) - (y - my) * 0.3) / mr + 0.5)
                px[x, y] = mix((20, 20, 30), (190, 190, 200), min(1.0, lit))
    return img


# 3. Mountain dawn: snowy peaks, a lake and pine trees
def mountains():
    img = Image.new("RGB", (W, H))
    lake = 150
    vgrad(img, [(0, (40, 70, 140)), (0.6, (150, 170, 210)), (1, (255, 200, 150))], 0, lake)
    d = ImageDraw.Draw(img)
    # far peaks with snow
    r = random.Random(11)
    peaks = [(150, 60), (205, 34), (262, 52), (310, 40), (360, 70)]
    for i, (px_, py) in enumerate(peaks):
        w = 70 + r.randrange(30)
        d.polygon([(px_ - w, lake), (px_, py), (px_ + w, lake)], fill=(90, 100, 140))
        d.polygon([(px_ - w * 0.5, lake - (lake - py) * 0.5), (px_, py), (px_ + w * 0.5, lake - (lake - py) * 0.5)],
                  fill=(120, 130, 170))
        s = 0.28
        pts = [(px_ - w * s, py + (lake - py) * s), (px_, py), (px_ + w * s, py + (lake - py) * s)]
        for k in range(5):
            pts.append((px_ + w * s - k * w * s * 0.5, py + (lake - py) * s + (4 if k % 2 else -2)))
        d.polygon(pts, fill=(245, 245, 255))
    ridge(d, lake - 8, 7, 0.035, 2.0, (40, 70, 70), 12, lake)
    # the lake reflects the sky
    for y in range(lake, H):
        t = (y - lake) / (H - lake)
        d.line([(0, y), (W, y)], fill=mix((180, 170, 190), (30, 50, 90), t))
    for y in range(lake + 3, H, 4):
        for x in range(r.randrange(0, 20), W, r.randrange(24, 44)):
            d.line([(x, y), (x + r.randrange(6, 18), y)], fill=(220, 210, 220))
    # pines along the right and the bottom
    def pine(x, base, h):
        for k in range(6):
            y0 = base - h + k * h / 6
            w = (k + 1) * h / 13
            d.polygon([(x, y0 - h / 6), (x - w, y0 + h / 6), (x + w, y0 + h / 6)], fill=(14, 40, 30))
        d.line([(x, base - 4), (x, base + 2)], fill=(50, 30, 20), width=2)
    for x in range(200, 330, 9):
        pine(x + r.randrange(-3, 4), lake + 2, 26 + r.randrange(18))
    for x in range(-6, 120, 13):
        pine(x + r.randrange(-3, 4), H + 6, 30 + r.randrange(16))
    return img.filter(ImageFilter.SMOOTH)


# 4. Tropical bay: sea, sand and palm trees at midday
def tropical():
    img = Image.new("RGB", (W, H))
    sea = 112
    vgrad(img, [(0, (40, 120, 220)), (1, (170, 220, 250))], 0, sea)
    d = ImageDraw.Draw(img)
    r = random.Random(5)
    # clouds
    for cx, cy, s in ((230, 30, 1.0), (120, 18, 0.7), (300, 60, 0.6)):
        for k in range(7):
            ox, oy = r.randrange(-30, 30) * s, r.randrange(-6, 6) * s
            rr = (10 + r.randrange(10)) * s
            d.ellipse([cx + ox - rr * 1.6, cy + oy - rr, cx + ox + rr * 1.6, cy + oy + rr], fill=(250, 252, 255))
    # an island on the horizon
    d.polygon([(150, sea), (175, sea - 9), (195, sea - 12), (220, sea - 7), (240, sea)], fill=(60, 120, 90))
    # the sea: turquoise near the shore
    for y in range(sea, H):
        t = (y - sea) / (H - sea)
        d.line([(0, y), (W, y)], fill=mix((20, 90, 170), (60, 210, 200), t))
    for y in range(sea + 3, 170, 4):
        for x in range(r.randrange(0, 20), W, r.randrange(20, 40)):
            d.line([(x, y), (x + r.randrange(4, 12), y)], fill=(200, 240, 250))
    # the beach curving along the bottom right
    pts = [(W, 132), (300, 146), (260, 162), (210, 176), (150, 186), (90, 194), (40, 198), (0, 200), (W, 200)]
    d.polygon(pts, fill=(240, 220, 160))
    d.line(pts[:-1], fill=(255, 255, 240), width=2)
    # palm trees
    def palm(bx, by, h, lean):
        pts = []
        for k in range(h):
            t = k / h
            pts.append((bx + lean * t * t * h, by - k))
        for k, (x, y) in enumerate(pts):
            d.ellipse([x - 3, y - 1, x + 3, y + 1], fill=mix((120, 80, 40), (90, 60, 30), (k % 4) / 4))
        tx, ty = pts[-1]
        for a in range(0, 360, 40):
            t = math.radians(a + 10)
            for k in range(26):
                s = k / 26
                x = tx + math.cos(t) * 30 * s
                y = ty + math.sin(t) * 12 * s + 14 * s * s
                d.ellipse([x - 2.5 * (1 - s) - 1, y - 2, x + 2.5 * (1 - s) + 1, y + 2], fill=(30, 120, 50))
        d.ellipse([tx - 4, ty - 2, tx + 4, ty + 5], fill=(110, 70, 30))
    palm(282, 170, 92, -0.35)
    palm(250, 182, 66, 0.3)
    return img.filter(ImageFilter.SMOOTH)


# 5. Aurora: green and violet lights over snowy hills and a cabin
def aurora():
    img = Image.new("RGB", (W, H))
    vgrad(img, [(0, (2, 6, 22)), (0.7, (10, 30, 60)), (1, (20, 60, 90))], 0, H)
    px = img.load()
    for y in range(0, 150):
        for x in range(W):
            # curtains: a wavy band whose brightness falls off upwards
            c = 0.0
            for k, (amp, f, ph, base, col) in enumerate((
                    (18, 0.020, 0.0, 70, (60, 255, 140)),
                    (12, 0.031, 2.0, 50, (140, 90, 255)),
                    (22, 0.015, 4.0, 95, (40, 220, 170)))):
                yc = base + math.sin(x * f + ph) * amp + math.sin(x * f * 3.1) * amp * 0.25
                dy = yc - y
                if 0 <= dy < 60:
                    g = (1 - dy / 60) ** 1.5 * (0.6 + 0.4 * math.sin(x * 0.4 + k) ** 2)
                elif -6 < dy < 0:
                    g = (1 + dy / 6)
                else:
                    g = 0
                px[x, y] = mix(px[x, y], col, g * 0.6)
    d = ImageDraw.Draw(img)
    stars(d, random.Random(9), 120, 120)
    ridge(d, 160, 10, 0.02, 1.0, (180, 200, 230), 21, H)
    ridge(d, 178, 8, 0.03, 3.0, (230, 240, 255), 22, H)
    for x in range(140, 330, 11):          # pines behind the cabin
        if 240 <= x <= 300:
            continue
        h = 18 + (x * 7) % 13
        d.polygon([(x, 172 - h), (x - 6, 174), (x + 6, 174)], fill=(10, 30, 30))
    # a cabin with a lit window, bottom right
    x0, y0 = 248, 156
    d.polygon([(x0 - 4, y0), (x0 + 22, y0 - 16), (x0 + 48, y0)], fill=(240, 245, 255))
    d.rectangle([x0, y0, x0 + 44, y0 + 22], fill=(70, 40, 30))
    d.rectangle([x0 + 8, y0 + 7, x0 + 18, y0 + 15], fill=(255, 210, 110))
    d.rectangle([x0 + 28, y0 + 8, x0 + 36, y0 + 22], fill=(40, 22, 16))
    d.rectangle([x0 + 34, y0 - 16, x0 + 39, y0 - 6], fill=(60, 40, 30))
    for k in range(6):
        d.ellipse([x0 + 34 + k * 3, y0 - 22 - k * 6, x0 + 40 + k * 4, y0 - 17 - k * 6], fill=(150, 160, 180))
    return img.filter(ImageFilter.SMOOTH)


WALLPAPERS = [
    ("SYNTHWAVE", synthwave, "striped sun over a neon grid"),
    ("SPACE", space, "ringed planet, moon and nebula"),
    ("MOUNTAINS", mountains, "snowy peaks, lake and pines at dawn"),
    ("TROPICAL", tropical, "bay, beach and palm trees"),
    ("AURORA", aurora, "northern lights over a snowy cabin"),
]


def main(out):
    os.makedirs(out, exist_ok=True)
    for name, fn, _ in WALLPAPERS:
        idx, colours = mkwall.convert(fn())
        mkwall.write_bmx(idx, colours, os.path.join(out, name + ".BMX"))
        mkwall.preview(idx, colours, os.path.join(out, name + ".png"))
        print("wrote", name)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "GeosWallpapers")
