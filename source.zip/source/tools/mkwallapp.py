#!/usr/bin/env python3
"""Builds the WALLPAPER GEOS application (apps/wallpaper.s) and puts it on
a GEOS disk image (D64 or D81), replacing an older copy:

   mkwallapp.py IMAGE [SLOT]     (assembled with ca65/ld65 when they are on
                                 the PATH, else apps/wallpaper.bin is used)

SLOT (default 7, the 8th file: the deskTop's first page) is the directory
slot it goes in; a file already there moves to the first free slot.
   mkwallapp.py --header OUT.hdr OUT.bin   just the header and the program"""
import os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import geosimg

LOAD = 0x0400

# 24 x 21 icon: a framed picture of a sun over hills
ICON = """
########################
#......................#
#.####################.#
#.#..................#.#
#.#..............##..#.#
#.#.............####.#.#
#.#.............####.#.#
#.#..............##..#.#
#.#..................#.#
#.#......##..........#.#
#.#.....####.....#...#.#
#.#....######...###..#.#
#.#...########.#####.#.#
#.#..#################.#
#.#.##################.#
#.####################.#
#......................#
#.......########.......#
#.......#......#.......#
#......##########......#
########################
"""


def icon_bytes():
    rows = [r for r in ICON.strip().split("\n")]
    assert len(rows) == 21 and all(len(r) == 24 for r in rows)
    out = bytearray()
    for r in rows:
        for b in range(3):
            v = 0
            for k in range(8):
                v = v << 1 | (r[b * 8 + k] == "#")
            out.append(v)
    return bytes(out)


def build():
    pre = os.path.join(ROOT, "apps", "wallpaper.bin")
    if not shutil.which("ca65") and os.path.exists(pre):
        return open(pre, "rb").read()   # no cc65: the ready-built program
    tmp = tempfile.mkdtemp()
    o, b = os.path.join(tmp, "w.o"), os.path.join(tmp, "w.bin")
    apps = os.path.join(ROOT, "apps")
    subprocess.check_call(["ca65", "-I", os.path.join(ROOT, "inc"), "--cpu", "6502",
                           os.path.join(apps, "wallpaper.s"), "-o", o])
    subprocess.check_call(["ld65", "-C", os.path.join(apps, "wallpaper.cfg"), "-o", b, o])
    return open(b, "rb").read()


def header(prog):
    h = bytearray(256)
    h[0], h[1] = 0, 0xFF
    h[2], h[3], h[4] = 3, 21, 0x80 | 63       # icon: 3 bytes x 21 lines
    h[5:5 + 63] = icon_bytes()
    h[0x44] = 0x83                            # USR
    h[0x45] = 6                               # APPLICATION
    h[0x46] = 0                               # sequential
    end = LOAD + len(prog)
    h[0x47], h[0x48] = LOAD & 255, LOAD >> 8
    h[0x49], h[0x4A] = end & 255, end >> 8
    h[0x4B], h[0x4C] = LOAD & 255, LOAD >> 8  # start
    cls = b"Wallpaper   V1.0"
    h[0x4D:0x4D + len(cls)] = cls
    au = b"GEOS-X16"
    h[0x61:0x61 + len(au)] = au
    desc = (b"Chooses the deskTop's wallpaper on GEOS-X16: your GEOSWALL.BMX, "
            b"one from the GeosWallpapers folder, or none.")
    h[0xA0:0xA0 + len(desc)] = desc[:95]
    return bytes(h)


def main(argv):
    prog = build()
    hdr = header(prog)
    if argv[:1] == ["--bin"]:                 # apps/wallpaper.bin, ready-built
        open(os.path.join(ROOT, "apps", "wallpaper.bin"), "wb").write(prog)
        return
    if argv[:1] == ["--header"]:
        open(argv[1], "wb").write(hdr)
        open(argv[2], "wb").write(prog)
        return
    if len(argv) not in (1, 2):
        raise SystemExit(__doc__)
    slot = int(argv[1]) if len(argv) > 1 else 7
    img = geosimg.Image(open(argv[0], "rb").read())
    for e in img.entries():                   # an older copy goes first
        if img.d[e + 2] and img.name_of(e) == "WALLPAPER":
            for t, s in img.chain(img.d[e + 21], img.d[e + 22]) + img.chain(img.d[e + 3], img.d[e + 4]):
                img.free(t, s)
            img.d[e + 2:e + 32] = bytes(30)
    ents = list(img.entries())
    while len(ents) <= slot:
        img.add_dir_block()
        ents = list(img.entries())
    want = ents[slot]
    if img.d[want + 2]:                       # the file there: to a free slot
        free = [e for e in img.entries() if e != want and not img.d[e + 2]]
        e2 = free[0] if free else img.add_dir_block()
        img.d[e2 + 2:e2 + 32] = img.d[want + 2:want + 32]
        img.d[want + 2:want + 32] = bytes(30)
    geosimg.add_file(img, "WALLPAPER", hdr, prog)
    new = [e for e in img.entries() if img.d[e + 2] and img.name_of(e) == "WALLPAPER"][0]
    if new != want:
        img.d[want + 2:want + 32] = img.d[new + 2:new + 32]
        img.d[new + 2:new + 32] = bytes(30)
    open(argv[0], "wb").write(img.d)
    print("blocks free:", img.free_blocks())


if __name__ == "__main__":
    main(sys.argv[1:])
