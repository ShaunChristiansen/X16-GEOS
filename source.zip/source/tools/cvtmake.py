#!/usr/bin/env python3
"""CVT (GEOS Convert) files from a GEOS disk image, and checks:

   cvtmake.py IMAGE "NAME" OUT.CVT     the file NAME as a CVT file
   cvtmake.py same IMAGE "NAME" FILE.CVT    exit 0 when the CVT holds the
                                        same file (entry type and name,
                                        header from $44 on, data/records)
   cvtmake.py same2 IMAGE1 "NAME" IMAGE2   the same, file to file
   cvtmake.py text IMAGE "NAME"        a geoWrite document's text (stdout)"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import geosimg


def find(img, name):
    for e in img.entries():
        if img.d[e + 2] and img.name_of(e) == name:
            return bytes(img.d[e + 2:e + 32])
    raise SystemExit("not there: " + name)


def chain_data(img, t, s):
    out = b""
    for (tt, ss) in img.chain(t, s):
        b = img.block(tt, ss)
        out += bytes(b[2:]) if b[0] else bytes(b[2:b[1] + 1])
    return out


def parts(img, name):
    """(entry, header, data or [records])"""
    ent = find(img, name)
    hdr = bytes(img.block(ent[19], ent[20]))
    if ent[21] == 1:
        idx = img.block(ent[1], ent[2])
        recs = []
        for r in range(127):
            t, s = idx[2 + 2 * r], idx[3 + 2 * r]
            if t == 0:
                if s == 0:
                    break
                recs.append(None)
                continue
            recs.append(chain_data(img, t, s))
        while recs and recs[-1] is None:      # (trailing empties: as none)
            recs.pop()
        return ent, hdr, recs
    return ent, hdr, chain_data(img, ent[1], ent[2])


def make(img, name):
    ent, hdr, body = parts(img, name)
    b0 = bytearray(254)
    b0[0:30] = ent
    sig = (b"SEQ" if ent[0] & 7 == 1 else b"PRG") + b" formatted GEOS file V1.0"
    b0[30:30 + len(sig)] = sig
    out = bytes(b0) + hdr[2:]
    if isinstance(body, list):
        tab = bytearray(254)
        data = b""
        for r, rec in enumerate(body):
            if rec is None:
                tab[2 * r + 1] = 0xFF
                continue
            nb = max(1, (len(rec) + 253) // 254)
            tab[2 * r], tab[2 * r + 1] = nb, len(rec) - (nb - 1) * 254 + 1
            data += rec + bytes(nb * 254 - len(rec))
        out += bytes(tab) + data
    else:
        out += body
    return out


def norm(ent, hdr, body):
    if isinstance(body, list):
        while body and body[-1] is None:
            body = body[:-1]
    return (ent[0], ent[3:19], ent[21], ent[22], hdr[0x44:], body)


def main(a):
    if a[0] == "same":
        img = geosimg.Image(open(a[1], "rb").read())
        ent, hdr, body = geosimg.parse_cvt(open(a[3], "rb").read())
        if isinstance(body, list):
            body = [None if r is None else bytes(r) for r in body]
        else:
            body = bytes(body)
        x = norm(*parts(img, a[2]))
        y = norm(bytes(ent), bytes(hdr), body)
        if x != y:
            for i, (u, v) in enumerate(zip(x, y)):
                if u != v:
                    print("differs: part", i)
            sys.exit(1)
        return
    if a[0] == "same2":
        i1 = geosimg.Image(open(a[1], "rb").read())
        i2 = geosimg.Image(open(a[3], "rb").read())
        x, y = norm(*parts(i1, a[2])), norm(*parts(i2, a[2]))
        if x != y:
            for i, (u, v) in enumerate(zip(x, y)):
                if u != v:
                    print("differs: part", i)
            sys.exit(1)
        return
    if a[0] == "text":
        img = geosimg.Image(open(a[1], "rb").read())
        ent, hdr, recs = parts(img, a[2])
        out = bytearray()
        for rec in recs[:61]:
            if rec is None:
                continue
            i = 0
            while i < len(rec):
                c = rec[i]
                if c == 0x11:
                    i += 27
                    continue
                if c == 0x17:
                    i += 4
                    continue
                if c == 0x10:
                    i += 5
                    continue
                out.append(c)
                i += 1
        sys.stdout.buffer.write(bytes(out))
        return
    img = geosimg.Image(open(a[0], "rb").read())
    open(a[2], "wb").write(make(img, a[1]))


if __name__ == "__main__":
    main(sys.argv[1:])
