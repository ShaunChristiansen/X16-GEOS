# GEOS-X16 test helper: find the GEOS mouse pointer (sprite 0, C64 blue) in
# an x16emu screenshot (640x480, GEOS screen at y 40-439, 2x scale).
# Prints the top-left corner of the largest blue shape at least 8x8 screen
# pixels big (the text cursor, a thin bar of the same colour, is not), in
# GEOS pixels, or "none".  Pixels up to 3 apart count as one shape, so thin
# diagonal pointers (geoPaint's pencil) and broken ones (its crosshair) do.
# Solid blocks (a colour swatch, as in geoPaint's palette) are not pointers.
#   x16pointer.py SHOT.png [SHOT2.png]
# With a second screenshot, taken after the mouse moved right and down a
# little, the pointer is the shape that moved that way (a blue arrow drawn
# on the screen, as in the preference manager, does not move).
# The pointer's colour: C64 blue (GEOS's default), else C64 yellow (the
# colour GEOS-X16's disks set); X16PTR=r,g,b for another.
import os, sys
from PIL import Image
COLOURS = [tuple(int(v) for v in os.environ["X16PTR"].split(","))] if "X16PTR" in os.environ \
    else [(51, 34, 119), (187, 204, 119)]

def shapes(path, BLUE):
    im = Image.open(path).convert('RGB')
    W, H = im.size
    px = im.load()
    seen = set(); out = []
    for y in range(40, 440):
        for x in range(W):
            if px[x, y] == BLUE and (x, y) not in seen:
                stack = [(x, y)]; comp = []
                seen.add((x, y))
                while stack:
                    a, b = stack.pop(); comp.append((a, b))
                    for c in range(a - 3, a + 4):
                        for d in range(b - 3, b + 4):
                            if 0 <= c < W and 40 <= d < 440 and (c, d) not in seen and px[c, d] == BLUE:
                                seen.add((c, d)); stack.append((c, d))
                xs = [p[0] for p in comp]; ys = [p[1] for p in comp]
                if max(xs) - min(xs) < 8 or max(ys) - min(ys) < 8:
                    continue
                if len(comp) > 0.8 * (max(xs) - min(xs) + 1) * (max(ys) - min(ys) + 1):
                    continue
                if len(comp) >= 6:
                    out.append((len(comp), min(xs), min(ys)))
    return sorted(out, reverse=True)

best = None
for col in COLOURS:
    a = shapes(sys.argv[1], col)
    if not a:
        continue
    if len(sys.argv) > 2:
        b = shapes(sys.argv[2], col)
        moved = [s for s in a if any(0 < t[1] - s[1] <= 24 and 0 < t[2] - s[2] <= 24
                                     and abs(t[0] - s[0]) <= s[0] // 3 for t in b)]
        if moved:
            best = moved[0]
            break
    if best is None:
        best = a[0]
print("%d %d" % (best[1] // 2, (best[2] - 40) // 2) if best else "none")
