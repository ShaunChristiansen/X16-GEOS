# GEOS-X16 test helper: is this x16emu screenshot the X16 BASIC screen?
# (most of it the default BASIC background blue)  exit 0 = yes
import sys
from PIL import Image
im = Image.open(sys.argv[1]).convert('RGB')
px = im.load()
W, H = im.size
blue = sum(1 for y in range(0, H, 4) for x in range(0, W, 4) if px[x, y] == (0, 0, 170))
sys.exit(0 if blue > (W // 4) * (H // 4) * 0.8 else 1)
