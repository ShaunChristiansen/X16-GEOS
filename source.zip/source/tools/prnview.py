#!/usr/bin/env python3
"""Shows a GEOS-X16 print file (PRINT1.PRN ...) as a picture of the page.

   prnview.py PRINT1.PRN [PAGE.png]       (PAGE.png: PRINT1.png by default)

The file holds the bytes the GEOS printer driver sent to the printer.  This
draws what a printer would make of them:
  - Commodore printers (MPS-801/803 and compatibles, GEOS's "MPS-803" and
    "Star NL-10(com)" drivers): CHR$(8) bit image mode, bytes $80-$FF are
    columns of 7 dots (bit 0 at the top), CHR$(26) n b repeats b, ESC
    CHR$(16) hi lo moves to a dot position, CR starts a new line
  - Epson ESC/P printers (FX-80 and compatibles): ESC K/L/Y/Z/* bit image
    data (8 dots a column, bit 7 at the top), ESC J/3/A/0/1/2 line feeds
  - plain text (GEOS's "ASCII Only" driver, or text from either printer)
Pages are drawn one under the other, split at form feeds."""
import sys
from PIL import Image, ImageDraw, ImageFont


class Page:
    def __init__(self):
        self.dots = {}              # (x, y) -> 1
        self.text = []              # (x, y, str)
        self.x = 0
        self.y = 0
        self.maxx = 1920            # x in 1/240", y in 1/72" (one pin)
        self.top = 0

    def dot(self, x, y):
        self.dots[(x, y)] = 1
        if x > self.maxx:
            self.maxx = x


def render(data):
    pg = Page()
    gfx = False                 # Commodore bit image mode (CHR$(8))
    spacing = 12                # Epson line spacing, in dots (1/72")
    cr_lf = 7                   # a Commodore CR in bit image mode: 7 dots
    font_w = 24
    i = 0
    n = len(data)
    pages = []

    def col(x, y, bits, nb, top_msb):
        for b in range(nb):
            on = bits & (1 << (nb - 1 - b if top_msb else b))
            if on:
                pg.dot(x, y + b)

    STEP = {0x4B: 4, 0x4C: 2, 0x59: 2, 0x5A: 1}     # ESC K L Y Z: 60 120 120 240 dpi
    STAR = {0: 4, 1: 2, 2: 2, 3: 1, 4: 3, 5: 3, 6: 3, 32: 4, 33: 2, 38: 3, 39: 1, 40: 1}

    while i < n:
        c = data[i]
        i += 1
        if gfx and c >= 0x80:                       # Commodore: 7 dots
            col(pg.x, pg.y, c & 0x7F, 7, False)
            pg.x += 4
            continue
        if c == 0x1B and i < n:                     # ESC
            e = data[i]
            i += 1
            if e in (0x4B, 0x4C, 0x59, 0x5A) and i + 1 < n:   # K L Y Z
                cnt = data[i] | data[i + 1] << 8
                i += 2
                for k in range(cnt):
                    if i + k < n:
                        col(pg.x, pg.y, data[i + k], 8, True)
                    pg.x += STEP[e]
                i += cnt
            elif e == 0x2A and i + 2 < n:               # * m n1 n2
                m = data[i]
                cnt = data[i + 1] | data[i + 2] << 8
                i += 3
                per = 3 if m >= 32 else 1
                for k in range(cnt):
                    for p in range(per):
                        if i < n:
                            col(pg.x, pg.y + p * 8, data[i], 8, True)
                        i += 1
                    pg.x += STAR.get(m, 2)
            elif e == 0x4A and i < n:                   # J n: n/216"
                pg.y += max(1, round(data[i] / 3))
                i += 1
            elif e == 0x33 and i < n:                   # 3 n
                spacing = max(1, round(data[i] / 3))
                i += 1
            elif e == 0x41 and i < n:                   # A n
                spacing = data[i]
                i += 1
            elif e == 0x30:
                spacing = 9
            elif e == 0x31:
                spacing = 7
            elif e == 0x32:
                spacing = 12
            elif e == 0x10 and i + 1 < n:               # Commodore dot position
                pg.x = ((data[i] << 8) | data[i + 1]) * 4
                i += 2
            elif e in (0x40,):                          # @ reset
                spacing = 12
            elif e in (0x21, 0x2D, 0x57, 0x6C, 0x51, 0x43, 0x78, 0x6B, 0x4E, 0x55, 0x53, 0x52):
                i += 1                                  # one parameter byte
            continue
        if c == 0x08:
            gfx = True
        elif c == 0x0F:
            gfx = False
        elif c == 0x1A and gfx and i + 1 < n:           # repeat
            cnt, b = data[i], data[i + 1]
            i += 2
            for _ in range(cnt or 256):
                col(pg.x, pg.y, b & 0x7F, 7, False)
                pg.x += 4
        elif c == 0x0D:
            pg.x = 0
            pg.y += cr_lf if gfx else spacing
        elif c == 0x0A:
            pg.y += cr_lf if gfx else spacing
        elif c == 0x0C:
            pages.append(pg)
            pg = Page()
        elif 0x20 <= c < 0x80 or 0xC1 <= c <= 0xDA:
            ch = chr(c - 0x80) if c >= 0xC1 else chr(c)
            pg.text.append((pg.x, pg.y, ch))
            pg.x += font_w
    pages.append(pg)
    return [p for p in pages if p.dots or p.text] or pages[:1]


def draw(pages, out):
    font = ImageFont.load_default()
    W = max(p.maxx for p in pages) + 24
    ims = []
    for p in pages:
        h = max([y for (_, y) in p.dots] + [y + 10 for (_, y, _) in p.text] + [100]) + 20
        im = Image.new("L", (W, h), 255)
        px = im.load()
        for (x, y) in p.dots:
            for k in range(3):
                if x + 10 + k < W:
                    px[x + 10 + k, y + 10] = 0
        # 1/240" x 1/72" -> 120 dpi both ways
        im = im.resize((W // 2, round(h * 120 / 72)), Image.BOX).point(lambda v: 0 if v < 200 else 255)
        d = ImageDraw.Draw(im)
        for (x, y, ch) in p.text:
            d.text(((x + 10) // 2, round((y + 10) * 120 / 72)), ch, fill=0, font=font)
        ims.append(im)
    W = ims[0].width
    H = sum(im.height for im in ims) + 8 * (len(ims) - 1)
    sheet = Image.new("L", (W, H), 160)
    y = 0
    for im in ims:
        sheet.paste(im, (0, y))
        y += im.height + 8
    sheet.save(out)
    return len(ims)


def main(argv):
    if not argv:
        raise SystemExit(__doc__)
    src = argv[0]
    out = argv[1] if len(argv) > 1 else src.rsplit(".", 1)[0] + ".png"
    pages = render(open(src, "rb").read())
    k = draw(pages, out)
    print("wrote %s (%d page%s)" % (out, k, "" if k == 1 else "s"))


if __name__ == "__main__":
    main(sys.argv[1:])
