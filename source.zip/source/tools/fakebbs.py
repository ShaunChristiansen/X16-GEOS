#!/usr/bin/env python3
"""A stand-in for the TexElec card's ESP32 (Zimodem) plus a tiny BBS, for
test_x16_serial.sh: listens on localhost:PORT for the test x16emu's UART
(tools/x16emu-testcards.patch, X16UART=PORT).

   fakebbs.py PORT LOG [raw]

AT commands get OK; ATD... gets CONNECT and the BBS (ANSI colours, 20
lines, a prompt); a typed line is echoed back; "SPEED" sends 300 numbered
lines at once (the flow control test).  Everything received goes to LOG.
raw: no modem (the Calypso test: GEOS-X16 is the modem, tools/fakenet's
NET.BIN sends "DNS name" and "ATDTa.b.c.d:port"): no OK, no CONNECT."""
import socket, sys, time, threading
PORT = int(sys.argv[1]); LOG = sys.argv[2]; RAW = len(sys.argv) > 3
srv = socket.socket(); srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
srv.bind(("127.0.0.1", PORT)); srv.listen(1)
c, _ = srv.accept()
log = open(LOG, "ab", buffering=0)
online = False; line = b""
def send(b): c.sendall(b)
def bbs():
    time.sleep(0.5)
    if not RAW:
        send(b"\r\nCONNECT 115200\r\n")
    time.sleep(0.5)
    send(b"\x1b[2J\x1b[1;1H\x1b[1;33mWelcome to the X16 TEST BBS\x1b[0m\r\n")
    send(b"\x1b[32mGEOS-X16, through the %s card.\x1b[0m\r\n" % (b"Calypso" if RAW else b"TexElec"))
    for i in range(1, 21):
        send(b"Line %02d: The quick brown fox jumps over the lazy dog.\r\n" % i)
    send(b"\r\nType something and press RETURN: ")
while True:
    d = c.recv(1)
    if not d: break
    log.write(d)
    if online:
        send(d)                       # the BBS echoes
        if d == b"\r":
            if line.strip() == b"SPEED":
                t0 = time.time()
                for i in range(1, 301):
                    send(b"%03d The quick brown fox jumps over the lazy dog %.6f\r\n" % (i, time.time()))
                open(LOG + ".speed", "w").write("sent %d bytes\n" % (300 * 62))
            else:
                send(b"\r\nYou typed: " + line + b"\r\nBYE\r\n")
            line = b""
        else:
            line += d
        continue
    if d in b"\r\n":
        cmd = line.strip().upper(); line = b""
        if cmd.startswith(b"ATD"):
            online = True; threading.Thread(target=bbs).start()
        elif cmd.startswith(b"AT") and not RAW:
            send(b"\r\nOK\r\n")
    else:
        line += d
