#!/usr/bin/env python3
"""Assembles the GEOS-X16 cartridge image (x16emu -cartbin) from the linker
   outputs:  bank 32 = boot + low-RAM parts, bank 33 = helper code,
             bank 34 = pristine kernel image (copied to banks 48-55 at boot)
   mkcart.py BUILDDIR OUT.BIN"""
import sys, os
b = sys.argv[1]
parts = [open(os.path.join(b, f), "rb").read() for f in ("bank32.bin", "bank33.bin", "kern.bin")]
for name, p in zip(("bank32.bin", "bank33.bin", "kern.bin"), parts):
    assert len(p) == 0x4000, (name, len(p))
assert parts[0][:4] == b"CX16"
open(sys.argv[2], "wb").write(b"".join(parts))
print("wrote %s (%d bytes: cartridge banks 32-34)" % (sys.argv[2], 3 * 0x4000))
