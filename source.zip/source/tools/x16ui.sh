# Helpers for driving GEOS-X16 in x16emu under Xvfb (sourced by the
# test scripts; needs xdotool, ImageMagick "import", python3).
# Expects X16EMU, X16ROM and T (the run directory, holding geosx16.bin and
# GEOSDISK.D64) to be set.
WIN() { xdotool search --name "Commander X16" | head -1; }
# x16emu runs with -capture: the mouse is in relative mode, so moves are
# exact and never run out of screen.  The GEOS pointer position is read
# from a screenshot (the pointer sprite, C64 blue).
start() {
  pkill -x "$(basename "$X16EMU")" 2>/dev/null || true; sleep 0.3
  (cd $T && "$X16EMU" -rom "$X16ROM" -sound none -scale 1 -cartbin geosx16.bin -rtc -capture $X16ARGS > $T/x16emu.log 2>&1 &)
  sleep 8
  W=$(WIN)
  WX=$(xdotool getwindowgeometry $W | sed -n 's/.*Position: \([0-9]*\),\([0-9]*\).*/\1/p')
  WY=$(xdotool getwindowgeometry $W | sed -n 's/.*Position: \([0-9]*\),\([0-9]*\).*/\2/p')
}
shot() { import -window root -crop 640x480+$WX+$WY $T/$1.png; }
# memory dump -> $T/NAME.bin (start with X16ARGS="-dump RBV"): Ctrl+M frees
# the mouse (the emulator ignores Ctrl+S while it has it), Ctrl+S, Ctrl+M
dumpmem() {
  rm -f $T/dump.bin
  xdotool key --window $W ctrl+m; sleep 0.3
  xdotool key --window $W ctrl+s; sleep 1
  xdotool key --window $W ctrl+m; sleep 0.3
  mv $T/dump.bin $T/$1.bin
}
gpos() {  # the pointer moves right and down a little between two screenshots
  for _t in 1 2 3 4; do       # (a menu's highlight can change too: again)
    shot _pos; xdotool mousemove_relative -- 8 8; sleep 0.25; shot _pos2
    xdotool mousemove_relative -- -8 -8; sleep 0.25
    _p=$(python3 ${X16TOOLS:-tools}/x16pointer.py $T/_pos.png $T/_pos2.png 2>/dev/null)
    [ -n "$_p" ] && [ "$_p" != "None" ] && { echo "$_p"; return; }
    xdotool mousemove_relative -- 600 0; sleep 0.5   # (off any menu: the right edge)
  done; }
rel() {  # move the GEOS pointer by ($1,$2) GEOS pixels, in steps
  dx=$(( $1 * 2 )); dy=$(( $2 * 2 ))
  while [ $dx -ne 0 ] || [ $dy -ne 0 ]; do
    sx=$dx; sy=$dy
    [ $sx -gt 80 ] && sx=80; [ $sx -lt -80 ] && sx=-80
    [ $sy -gt 80 ] && sy=80; [ $sy -lt -80 ] && sy=-80
    xdotool mousemove_relative -- $sx $sy; sleep 0.05
    dx=$(( dx - sx )); dy=$(( dy - sy ))
  done
  sleep 0.2
}
goto() { set -- $1 $2 $(gpos); rel $(( $1 - $3 )) $(( $2 - $4 )); set -- $1 $2 $(gpos); rel $(( $1 - $3 )) $(( $2 - $4 )); }
click() { xdotool mousedown 1; sleep 0.12; xdotool mouseup 1; sleep 0.2; }
dclick() { for i in 1 2; do xdotool mousedown 1; sleep 0.06; xdotool mouseup 1; sleep 0.06; done; sleep 0.3; }
typetext() { xdotool type --window $W --delay 130 "$1"; }
key() { xdotool key --window $W --delay 150 "$@"; }
fail() { echo "FAIL: $1"; pkill -x "$(basename "$X16EMU")" || true; exit 1; }
doctext() {  # the text of geoWrite document $1 on $T/GEOSDISK.D64 (or .D81)
python3 - "$T" "$1" "${X16TOOLS:-tools}" <<'EOF'
import os, sys
sys.path.insert(0, sys.argv[3])
from geosimg import Image
p = os.path.join(sys.argv[1], "GEOSDISK.D64")
if not os.path.exists(p):
    p = os.path.join(sys.argv[1], "GEOSDISK.D81")
img = Image(open(p, "rb").read())
for e in img.entries():
    if img.d[e + 2] and img.name_of(e) == sys.argv[2]:
        idx = img.block(img.d[e + 3], img.d[e + 4])
        rt, rs = idx[2], idx[3]
        data = b""
        while rt:
            b = img.block(rt, rs)
            nt, ns = b[0], b[1]
            data += bytes(b[2:256]) if nt else bytes(b[2:1 + ns])
            rt, rs = nt, ns
        print("".join(chr(c) for c in data if 32 <= c < 127))
EOF
}
# is X16 BASIC really running?  COLOR 1,2:CLS turns the screen red, which
# a crashed machine (e.g. in the monitor, also blue) would not: exit 0 = yes
basic_alive() {   # $1 = shot name
  typetext 'color 1,2:cls'; key Return; sleep 1.5; shot $1
  python3 -c "
from PIL import Image
im = Image.open('$T/$1.png').convert('RGB'); px = im.load(); W, H = im.size
n = sum(1 for y in range(0, H, 8) for x in range(0, W, 8) if px[x, y][0] > 100 and px[x, y][1] < 40 and px[x, y][2] < 40)
raise SystemExit(0 if n > (W // 8) * (H // 8) * 0.8 else 1)"
}
