#!/usr/bin/env python3
"""GEOS disk images: D64 (1541) and D81 (1581).

   geosimg.py new IMAGE.D81 "DISK NAME" ID   a blank GEOS disk (D64 or D81,
                                             by the file name's extension)
   geosimg.py cp FROM TO "FILE NAME" ...     copy files (GEOS-aware: the info
                                             block and the VLIR records go
                                             along); "*" copies them all
   geosimg.py clone FROM TO                  copy every file to the same
                                             directory slot (the deskTop
                                             shows the icons by slot)
   geosimg.py add IMAGE "NAME" HEADER DATA   a new GEOS file (sequential): its
                                             256-byte header block and its data
   geosimg.py cvt IMAGE FILE.CVT ...         GEOS files in CVT (convert) form
                                             (as GEOS's CONVERT makes them)
   geosimg.py cvtfrom IMAGE FROM "NAME" ...  the same, from CVT files kept on
                                             another disk image (plain files)
   geosimg.py rm IMAGE "FILE NAME" ...       delete files (GEOS-aware: the
                                             info block and the VLIR records
                                             are freed too)
   geosimg.py slot IMAGE "FILE NAME" N       move a file's directory entry to
                                             slot N (the deskTop shows the
                                             icons by slot)
   geosimg.py sum IMAGE "FILE NAME" ...      a checksum of each file's contents
                                             (its types, data or VLIR records,
                                             info block): equal for a copy
   geosimg.py ls IMAGE                       the directory
   geosimg.py check IMAGE                    every block of every file
                                             allocated once, the BAM agrees

A D81 gets what GEOS 2.0's 1581 driver expects: header 40/0 (the disk name
also at $90, where GEOS reads it, and the GEOS signature with the border
block at $AB), BAM 40/1 (tracks 1-40) and 40/2 (tracks 41-80), directory
from 40/3.  Files go from track 39 down, then from track 41 up, as the
1581 driver allocates them."""
import sys

GEOS_ID = b"GEOS format V1.0"


class Image:
    def __init__(self, data):
        self.d = bytearray(data)
        if len(self.d) == 819200:
            self.kind = "d81"
        elif len(self.d) in (174848, 175531):
            self.kind = "d64"
            del self.d[174848:]
        else:
            raise SystemExit("not a D64 or D81 image (%d bytes)" % len(self.d))
        k = self.kind == "d81"
        self.tracks = 80 if k else 35
        self.dirtrack = 40 if k else 18
        self.header = (40, 0) if k else (18, 0)
        self.firstdir = (40, 3) if k else (18, 1)

    # geometry
    def spt(self, t):
        if self.kind == "d81":
            return 40
        return 21 if t <= 17 else 19 if t <= 24 else 18 if t <= 30 else 17

    def off(self, t, s):
        if not (1 <= t <= self.tracks and 0 <= s < self.spt(t)):
            raise SystemExit("bad block %d/%d" % (t, s))
        if self.kind == "d81":
            return ((t - 1) * 40 + s) * 256
        return (sum(self.spt(i) for i in range(1, t)) + s) * 256

    def block(self, t, s):
        o = self.off(t, s)
        return self.d[o:o + 256]

    def put(self, t, s, data):
        o = self.off(t, s)
        self.d[o:o + 256] = bytes(data).ljust(256, b"\0")

    # BAM: (offset of the free count, offset of the bitmap)
    def bament(self, t):
        if self.kind == "d81":
            b = self.off(40, 1 if t <= 40 else 2)
            e = b + 0x10 + 6 * ((t - 1) % 40)
            return e, e + 1
        e = self.off(18, 0) + 4 * t
        return e, e + 1

    def is_free(self, t, s):
        _, m = self.bament(t)
        return self.d[m + s // 8] & (1 << (s % 8)) != 0

    def use(self, t, s):
        c, m = self.bament(t)
        if not self.is_free(t, s):
            raise SystemExit("block %d/%d already in use" % (t, s))
        self.d[m + s // 8] &= ~(1 << (s % 8)) & 255
        self.d[c] -= 1

    def free(self, t, s):
        c, m = self.bament(t)
        if self.is_free(t, s):
            return
        self.d[m + s // 8] |= 1 << (s % 8)
        self.d[c] += 1

    def free_blocks(self):
        return sum(self.d[self.bament(t)[0]] for t in range(1, self.tracks + 1)
                   if t != self.dirtrack)

    def order(self):
        if self.kind == "d81":        # 39 down to 1, then 41 up to 80
            return list(range(39, 0, -1)) + list(range(41, 81))
        out = []                      # outwards from the directory
        for k in range(1, 18):
            for t in (18 - k, 18 + k):
                if 1 <= t <= 35:
                    out.append(t)
        return out

    def alloc(self):
        for t in self.order():
            n = self.spt(t)
            for i in range(n):
                if self.kind == "d81":
                    s = i
                else:
                    s = (i * 10) % n if n % 10 else i
                if self.is_free(t, s):
                    self.use(t, s)
                    return t, s
        raise SystemExit("disk full")

    # directory
    def entries(self):
        t, s = self.firstdir
        seen = set()
        while t:
            if (t, s) in seen:
                raise SystemExit("directory loop")
            seen.add((t, s))
            o = self.off(t, s)
            for i in range(8):
                yield o + i * 32
            t, s = self.d[o], self.d[o + 1]

    def name_of(self, e):
        return bytes(c for c in self.d[e + 5:e + 21] if c != 0xA0).decode("latin1")

    def free_slot(self, want=None):
        if want is not None:            # slot number want, made if need be
            while len(list(self.entries())) <= want:
                self.add_dir_block()
            e = list(self.entries())[want]
            if self.d[e + 2]:
                raise SystemExit("slot %d in use" % want)
            return e
        for e in self.entries():
            if self.d[e + 2] == 0:
                return e
        return self.add_dir_block()

    def add_dir_block(self):
        last = list(self.entries())[-8]
        for s in range(self.spt(self.dirtrack)):
            if self.is_free(self.dirtrack, s):
                self.use(self.dirtrack, s)
                self.d[last], self.d[last + 1] = self.dirtrack, s
                o = self.off(self.dirtrack, s)
                self.d[o:o + 256] = bytes(256)
                self.d[o + 1] = 0xFF
                return o
        raise SystemExit("directory full")

    def chain(self, t, s):
        seen = []
        while t:
            if (t, s) in seen:
                raise SystemExit("chain loop")
            seen.append((t, s))
            o = self.off(t, s)
            t, s = self.d[o], self.d[o + 1]
        return seen

    def headerblock(self):
        return self.off(*self.header)

    def diskname(self):
        h = self.headerblock()
        return bytes(c for c in self.d[h + 0x90:h + 0xA0] if c != 0xA0).decode("latin1")


def new_image(path, name, did):
    nm = name.encode("latin1")[:16].ljust(16, b"\xA0")
    did = did.encode("latin1")[:2].ljust(2)
    if path.lower().endswith(".d81"):
        img = Image(bytes(819200))
        h = bytearray(256)
        h[0:4] = bytes([40, 3, 0x44, 0])
        h[4:20] = nm
        h[0x14:0x16] = b"\xA0\xA0"
        h[0x16:0x18] = did
        h[0x18:0x1D] = b"\xA0\x33\x44\xA0\xA0"
        info = nm + b"\xA0\xA0" + did + b"\xA0\x33\x44\xA0\xA0\xA0\xA0"
        h[0x90:0x90 + len(info)] = info
        img.put(40, 0, h)
        for n, (lt, ls) in ((1, (40, 2)), (2, (0, 0xFF))):
            b = bytearray(256)
            b[0:8] = bytes([lt, ls, 0x44, 0xBB]) + did + bytes([0xC0, 0])
            for i in range(40):
                e = 0x10 + 6 * i
                b[e:e + 6] = bytes([40, 255, 255, 255, 255, 255])
            img.put(40, n, b)
        for s in (0, 1, 2, 3):
            img.use(40, s)
        img.put(40, 3, bytes([0, 0xFF]))
        border = (40, 19)               # SetGEOSDisk: the first free after 40/18
    else:
        img = Image(bytes(174848))
        b = bytearray(256)
        b[0:4] = bytes([18, 1, 0x41, 0])
        for t in range(1, 36):
            n = img.spt(t)
            bits = (1 << n) - 1
            b[4 * t:4 * t + 4] = bytes([n, bits & 255, (bits >> 8) & 255, bits >> 16])
        b[0x90:0xAB] = nm + b"\xA0\xA0" + did + b"\xA0\x32\x41\xA0\xA0\xA0\xA0"
        img.put(18, 0, b)
        img.use(18, 0)
        img.use(18, 1)
        img.put(18, 1, bytes([0, 0xFF]))
        border = (19, 0)
    img.use(*border)
    img.put(border[0], border[1], bytes([0, 0xFF]))
    h = img.headerblock()
    img.d[h + 0xAB], img.d[h + 0xAC] = border
    img.d[h + 0xAD:h + 0xAD + 16] = GEOS_ID
    open(path, "wb").write(img.d)
    print("%s: %s, %d blocks free" % (path, img.kind.upper(), img.free_blocks()))


def copy_chain(src, dst, t, s):
    blocks = src.chain(t, s)
    new = [dst.alloc() for _ in blocks]
    for i, ((ot, os_), (nt, ns)) in enumerate(zip(blocks, new)):
        data = bytearray(src.block(ot, os_))
        if i + 1 < len(new):
            data[0], data[1] = new[i + 1]
        dst.put(nt, ns, data)
    return (new[0] if new else (0, 0)), len(new)


def copy_file(src, dst, name, keep_slot=False):
    se = None
    for i, e in enumerate(src.entries()):
        if src.d[e + 2] and src.name_of(e) == name:
            se, slot = e, i
    if se is None:
        raise SystemExit("not found: " + name)
    for e in dst.entries():
        if dst.d[e + 2] and dst.name_of(e) == name:
            raise SystemExit("already there: " + name)
    ent = bytearray(src.d[se + 2:se + 32])
    total = 0
    if src.d[se + 21]:                                  # GEOS info block
        (it, is_), n = copy_chain(src, dst, src.d[se + 21], src.d[se + 22])
        ent[19], ent[20] = it, is_
        total += n
    if src.d[se + 23] == 1:                             # VLIR
        idx = src.block(src.d[se + 3], src.d[se + 4])
        nidx = bytearray(idx)
        for r in range(127):
            rt, rs = idx[2 + 2 * r], idx[3 + 2 * r]
            if rt:
                (nt, ns), n = copy_chain(src, dst, rt, rs)
                nidx[2 + 2 * r], nidx[3 + 2 * r] = nt, ns
                total += n
        xt, xs = dst.alloc()
        dst.put(xt, xs, nidx)
        ent[1], ent[2] = xt, xs
        total += 1
    else:
        (ft, fs), n = copy_chain(src, dst, src.d[se + 3], src.d[se + 4])
        ent[1], ent[2] = ft, fs
        total += n
    ent[28], ent[29] = total & 255, total >> 8
    e = dst.free_slot(slot if keep_slot else None)
    dst.d[e + 2:e + 32] = ent
    print("copied %-16s %4d blocks" % (name, total))


def add_file(dst, name, header, data, date=(126, 11, 16, 12, 0)):
    """A sequential GEOS file: header (the info block, 256 bytes, bytes
    0-1 ignored) and data.  Its GEOS type and C64 file type come from the
    header ($44 and $45)."""
    for e in dst.entries():
        if dst.d[e + 2] and dst.name_of(e) == name:
            raise SystemExit("already there: " + name)
    ht, hs = dst.alloc()
    hb = bytearray(header[:256].ljust(256, b"\0"))
    hb[0], hb[1] = 0, 0xFF
    dst.put(ht, hs, hb)
    chunks = [data[i:i + 254] for i in range(0, len(data), 254)] or [b""]
    blocks = [dst.alloc() for _ in chunks]
    for i, (c, (t, s)) in enumerate(zip(chunks, blocks)):
        b = bytearray(256)
        if i + 1 < len(blocks):
            b[0], b[1] = blocks[i + 1]
        else:
            b[0], b[1] = 0, len(c) + 1
        b[2:2 + len(c)] = c
        dst.put(t, s, b)
    ent = bytearray(30)
    ent[0] = hb[0x44] or 0x83
    ent[1], ent[2] = blocks[0]
    nm = name.encode("latin1")[:16]
    ent[3:19] = nm + b"\xa0" * (16 - len(nm))
    ent[19], ent[20] = ht, hs
    ent[21] = 0                                         # sequential
    ent[22] = hb[0x45]
    ent[23:28] = bytes(date)
    total = len(blocks) + 1
    ent[28], ent[29] = total & 255, total >> 8
    e = dst.free_slot()
    dst.d[e + 2:e + 32] = ent
    print("added %-16s %4d blocks" % (name, total))


def parse_cvt(raw):
    """A CVT file -> (dir entry 30 bytes, header 256 bytes, [records] or data)"""
    if b"formatted GEOS file" not in raw[30:64]:
        raise SystemExit("not a CVT file")
    ent = bytearray(raw[0:30])
    hdr = bytearray(2) + raw[254:508]
    hdr[0], hdr[1] = 0, 0xFF
    if ent[21] == 1:                                    # VLIR
        tab = raw[508:762]
        pos = 762
        recs = []
        for r in range(127):
            nb, last = tab[2 * r], tab[2 * r + 1]
            if nb == 0 and last == 0:
                break
            if nb == 0:                                 # (0, $FF): empty
                recs.append(None)
                continue
            size = (nb - 1) * 254 + (last - 1)
            recs.append(raw[pos:pos + size])
            pos += nb * 254
        return ent, bytes(hdr), recs
    return ent, bytes(hdr), raw[508:]


def write_chain(dst, data):
    chunks = [data[i:i + 254] for i in range(0, len(data), 254)] or [b""]
    blocks = [dst.alloc() for _ in chunks]
    for i, (c, (t, s)) in enumerate(zip(chunks, blocks)):
        b = bytearray(256)
        if i + 1 < len(blocks):
            b[0], b[1] = blocks[i + 1]
        else:
            b[0], b[1] = 0, len(c) + 1
        b[2:2 + len(c)] = c
        dst.put(t, s, b)
    return blocks[0], len(blocks)


def add_cvt(dst, raw):
    ent, hdr, body = parse_cvt(raw)
    name = bytes(c for c in ent[3:19] if c != 0xA0).decode("latin1")
    for e in dst.entries():
        if dst.d[e + 2] and dst.name_of(e) == name:
            raise SystemExit("already there: " + name)
    ht, hs = dst.alloc()
    dst.put(ht, hs, bytearray(hdr))
    total = 1
    if isinstance(body, list):
        idx = bytearray(256)
        idx[0], idx[1] = 0, 0xFF
        for r, rec in enumerate(body):
            if rec is None:
                idx[2 + 2 * r], idx[3 + 2 * r] = 0, 0xFF
                continue
            (t, s), n = write_chain(dst, rec)
            idx[2 + 2 * r], idx[3 + 2 * r] = t, s
            total += n
        xt, xs = dst.alloc()
        dst.put(xt, xs, idx)
        first = (xt, xs)
        total += 1
    else:
        first, n = write_chain(dst, body)
        total += n
    e2 = bytearray(ent)
    e2[1], e2[2] = first
    e2[19], e2[20] = ht, hs
    e2[28], e2[29] = total & 255, total >> 8
    e = dst.free_slot()
    dst.d[e + 2:e + 32] = e2
    print("added %-16s %4d blocks (from CVT)" % (name, total))
    return name


TYPES = {0: "non-GEOS", 1: "BASIC", 2: "assembly", 3: "data", 4: "system",
         5: "desk acc", 6: "application", 7: "appl data", 8: "font",
         9: "printer", 10: "input", 11: "disk driver", 12: "boot",
         13: "temporary", 14: "auto-exec", 15: "input 128"}


def ls(img):
    h = img.headerblock()
    print("%s  disk: %r  GEOS: %s" % (img.kind.upper(), img.diskname(),
          bytes(img.d[h + 0xAD:h + 0xBD]) == GEOS_ID))
    for e in img.entries():
        if img.d[e + 2]:
            st = "VLIR" if img.d[e + 23] == 1 else "seq"
            print("%5d  %-16s  $%02X  %-12s %-4s %d/%d" % (
                img.d[e + 30] | img.d[e + 31] << 8, img.name_of(e), img.d[e + 2],
                TYPES.get(img.d[e + 24], "?"), st, img.d[e + 3], img.d[e + 4]))
    print("blocks free:", img.free_blocks())


def check(img):
    used = {}
    def mark(t, s, what):
        if (t, s) in used:
            raise SystemExit("%d/%d used twice: %s, %s" % (t, s, used[(t, s)], what))
        used[(t, s)] = what
    h = img.header
    mark(*h, what="header")
    if img.kind == "d81":
        mark(40, 1, "BAM 1")
        mark(40, 2, "BAM 2")
    for b in img.chain(*img.firstdir):
        mark(*b, what="directory")
    hb = img.headerblock()
    if bytes(img.d[hb + 0xAD:hb + 0xBD]) == GEOS_ID and img.d[hb + 0xAB]:
        mark(img.d[hb + 0xAB], img.d[hb + 0xAC], "border block")
    for e in img.entries():
        if not img.d[e + 2]:
            continue
        n = img.name_of(e)
        cnt = 0
        if img.d[e + 21]:
            for b in img.chain(img.d[e + 21], img.d[e + 22]):
                mark(*b, what=n)
                cnt += 1
        if img.d[e + 23] == 1:
            mark(img.d[e + 3], img.d[e + 4], n)
            cnt += 1
            idx = img.block(img.d[e + 3], img.d[e + 4])
            for r in range(127):
                if idx[2 + 2 * r]:
                    for b in img.chain(idx[2 + 2 * r], idx[3 + 2 * r]):
                        mark(*b, what=n)
                        cnt += 1
        else:
            for b in img.chain(img.d[e + 3], img.d[e + 4]):
                mark(*b, what=n)
                cnt += 1
        if cnt != (img.d[e + 30] | img.d[e + 31] << 8):
            print("note: %s says %d blocks, has %d" % (n, img.d[e + 30] | img.d[e + 31] << 8, cnt))
    bad = 0
    for t in range(1, img.tracks + 1):
        c, _ = img.bament(t)
        free = 0
        for s in range(img.spt(t)):
            f = img.is_free(t, s)
            free += f
            if f == ((t, s) in used):
                bad += 1
                if bad < 10:
                    print("BAM: %d/%d %s" % (t, s, "free but used" if f else "allocated but unused"))
        if free != img.d[c]:
            bad += 1
            print("BAM: track %d count %d, %d free" % (t, img.d[c], free))
    print("%s: %d blocks used, BAM %s" % (img.kind.upper(), len(used), "OK" if not bad else "has %d problems" % bad))
    return bad == 0


def remove_file(img, name):
    """Delete NAME: its blocks are freed in the BAM (the data chain, or a
    VLIR file's index block and every record's chain; the GEOS info block),
    and its directory entry is cleared."""
    ents = [e for e in img.entries() if img.d[e + 2] and img.name_of(e) == name]
    if not ents:
        raise SystemExit("not found: " + name)
    e = ents[0]
    t, s_ = img.d[e + 3], img.d[e + 4]
    if img.d[e + 21] and img.d[e + 23] == 1:        # GEOS VLIR: index block
        idx = img.block(t, s_)
        for i in range(2, 256, 2):
            if idx[i]:
                for rt, rs in img.chain(idx[i], idx[i + 1]):
                    img.free(rt, rs)
        img.free(t, s_)
    else:
        for bt, bs in img.chain(t, s_):
            img.free(bt, bs)
    if img.d[e + 21]:                               # GEOS info block
        img.free(img.d[e + 21], img.d[e + 22])
    img.d[e + 2:e + 32] = bytes(30)


def file_sum(img, name):
    """SHA-1 of NAME's contents, the same for any copy of the file: its CBM,
    GEOS and structure types, its data (a VLIR file's records, in order,
    each one marked), and its GEOS info block (not the block addresses)."""
    import hashlib
    ents = [e for e in img.entries() if img.d[e + 2] and img.name_of(e) == name]
    if not ents:
        raise SystemExit("not found: " + name)
    e = ents[0]
    h = hashlib.sha1(bytes([img.d[e + 2], img.d[e + 23], img.d[e + 24]]))

    def data(t, s_):
        out = b""
        for bt, bs in img.chain(t, s_):
            b = img.block(bt, bs)
            out += bytes(b[2:b[1] + 1]) if b[0] == 0 else bytes(b[2:])
        return out
    t, s_ = img.d[e + 3], img.d[e + 4]
    if img.d[e + 21] and img.d[e + 23] == 1:        # VLIR: the records
        idx = img.block(t, s_)
        for i in range(2, 256, 2):
            if idx[i]:
                h.update(b"R%d:" % i + data(idx[i], idx[i + 1]))
            elif idx[i + 1] == 0xFF:
                h.update(b"E%d" % i)                    # an empty record
    else:
        h.update(data(t, s_))
    if img.d[e + 21]:
        h.update(bytes(img.block(img.d[e + 21], img.d[e + 22])[2:]))
    return h.hexdigest()


def move_slot(img, name, slot):
    """Move NAME's directory entry to slot SLOT (0 = the first), which must
    be free."""
    ents = list(img.entries())
    while len(ents) <= slot:
        img.add_dir_block()
        ents = list(img.entries())
    src = [e for e in ents if img.d[e + 2] and img.name_of(e) == name]
    if not src:
        raise SystemExit("not found: " + name)
    dst = ents[slot]
    if dst == src[0]:
        return
    if img.d[dst + 2]:
        raise SystemExit("slot %d is not free" % slot)
    img.d[dst + 2:dst + 32] = img.d[src[0] + 2:src[0] + 32]
    img.d[src[0] + 2:src[0] + 32] = bytes(30)


def main():
    a = sys.argv[1:]
    if not a:
        raise SystemExit(__doc__)
    if a[0] == "new":
        new_image(a[1], a[2], a[3])
    elif a[0] == "ls":
        ls(Image(open(a[1], "rb").read()))
    elif a[0] == "rm":
        img = Image(open(a[1], "rb").read())
        for n in a[2:]:
            remove_file(img, n)
        open(a[1], "wb").write(img.d)
        print("blocks free:", img.free_blocks())
    elif a[0] == "sum":
        img = Image(open(a[1], "rb").read())
        for n in a[2:]:
            print("  %s: %s" % (n, file_sum(img, n)))
    elif a[0] == "slot":
        img = Image(open(a[1], "rb").read())
        move_slot(img, a[2], int(a[3]))
        open(a[1], "wb").write(img.d)
    elif a[0] == "check":
        sys.exit(0 if check(Image(open(a[1], "rb").read())) else 1)
    elif a[0] == "clone":
        src = Image(open(a[1], "rb").read())
        dst = Image(open(a[2], "rb").read())
        for e in src.entries():
            if src.d[e + 2]:
                copy_file(src, dst, src.name_of(e), keep_slot=True)
        open(a[2], "wb").write(dst.d)
        print("blocks free:", dst.free_blocks())
    elif a[0] == "add":
        dst = Image(open(a[1], "rb").read())
        add_file(dst, a[2], open(a[3], "rb").read(), open(a[4], "rb").read())
        open(a[1], "wb").write(dst.d)
        print("blocks free:", dst.free_blocks())
    elif a[0] == "cvt":
        dst = Image(open(a[1], "rb").read())
        for f in a[2:]:
            add_cvt(dst, open(f, "rb").read())
        open(a[1], "wb").write(dst.d)
        print("blocks free:", dst.free_blocks())
    elif a[0] == "cvtfrom":
        dst = Image(open(a[1], "rb").read())
        src = Image(open(a[2], "rb").read())
        for n in a[3:]:
            e = [e for e in src.entries() if src.d[e + 2] and src.name_of(e) == n]
            if not e:
                raise SystemExit("not found: " + n)
            raw = b""
            for t, s_ in src.chain(src.d[e[0] + 3], src.d[e[0] + 4]):
                b = src.block(t, s_)
                raw += bytes(b[2:b[1] + 1]) if b[0] == 0 else bytes(b[2:])
            add_cvt(dst, raw)
        open(a[1], "wb").write(dst.d)
        print("blocks free:", dst.free_blocks())
    elif a[0] == "cp":
        src = Image(open(a[1], "rb").read())
        dst = Image(open(a[2], "rb").read())
        names = a[3:]
        if names == ["*"]:
            names = [src.name_of(e) for e in src.entries() if src.d[e + 2]]
        for n in names:
            copy_file(src, dst, n)
        open(a[2], "wb").write(dst.d)
        print("blocks free:", dst.free_blocks())
    else:
        raise SystemExit(__doc__)


if __name__ == "__main__":
    main()
