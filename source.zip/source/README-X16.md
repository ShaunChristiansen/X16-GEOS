# GEOS 2.0 for the Commander X16

The Commodore 64 GEOS 2.0 kernel (from the reverse-engineered source at
github.com/mist64/geos), rebuilt as an X16 cartridge. It runs the C64's own
deskTop, geoWrite, geoPaint and desk accessories unchanged from C64 disk
images (D64 or D81, up to three drives, kept on the X16's SD card or the
emulator's folder), in colour as on a C64, with a wallpaper behind the
deskTop. Tested in x16emu R49 with the R49 ROM.

## Running it (Windows)

Put these in one folder:

    geosx16.bin      the cartridge (ROM banks 32-34)
    GEOSDISK.D64     drive A: a GEOS 2.0 disk image (must hold DESK TOP)
    GEOSDSK2.D64     drive B (optional): any GEOS disk image
    GEOSDSK3.D81     drive C (optional, needs a drive B): any GEOS disk image
    GEOSWALL.BIN     the deskTop's wallpaper (optional)
    BASIC.BIN        the C64's BASIC ROM (optional, for the calculator and geoCalc, see below)
    KERNAL.BIN       the C64's KERNAL ROM (optional, as above)
    GEOS-X16.bat     the launcher
    GEOS-X16.PRG     the loader for a real X16 (see "Real hardware")
    mkwall.py        makes a wallpaper from a picture (optional, see below)
    geosimg.py       makes GEOS D81s and copies files to them (optional)

Then either copy `x16emu.exe` (with its `rom.bin`) into that folder, put the
folder inside the x16emu folder, or edit the `X16EMU` line in the .bat. Run
`GEOS-X16.bat`. It starts:

    x16emu -cartbin geosx16.bin -rtc -scale 2 -capture

- `-capture` gives the mouse to the emulator, so the GEOS pointer follows
  every movement and pushing it against a screen edge works (geoWrite and
  geoPaint scroll that way). Ctrl+M releases and recaptures the mouse,
  as the window title says.
- `-rtc` gives GEOS the PC's date and time.
- Use x16emu without an SD card image: the disk images are read from the
  emulator's current folder (its host file system, device 8). With an SD
  card image (or on a real X16), they must be on the card instead.
- Each drive can be a D64 (a 1541 disk, 165K) or a D81 (a 1581 disk,
  790K), whatever the list above shows: GEOSDISK.D81 instead of
  GEOSDISK.D64, GEOSDSK3.D64 instead of GEOSDSK3.D81, and so on. When a
  drive has both, the .D64 is used.
- The disk images stay on the disk (SD card or folder): GEOS reads and
  writes their blocks there, through a cache in the X16's banked RAM. A
  standard 512K X16 is enough. An image that can only be read (a read-only
  file) works too; the boot screen says "(READ-ONLY)" and GEOS reports an
  error when it tries to write to it.

The shipped disks: drive A has DESK TOP, geoWrite, the calculator, note pad,
preference manager, pad color manager, six fonts and colour settings (170
blocks free). Drive B has geoPaint, photo manager and three
fonts (370 blocks free). Run geoPaint from drive B so its pictures go there.
Drive C (GEOSDSK3.D81, a 1581 disk) holds all the programs (geoWrite,
geoPaint, geoCalc, geoSpell with its dictionary, geoMerge, Text Grabber,
geoText, geoLaser, ...), the desk accessories, fonts and forms (300K
free).
It has DESK TOP too, so it can also be drive A on its own: rename it
GEOSDISK.D81 (and take GEOSDISK.D64 out of the folder). geosimg.py is the
disk tool (see "Using it").

## Real hardware: GEOS-X16.PRG

On a real X16, GEOS-X16 needs a cartridge (or an expansion card) with RAM
in the cartridge banks: 32-34 and 48-56. A ROM cartridge is not enough,
because GEOS works in those banks. Put these together on the SD card, in its
root folder or in a folder of their own: GEOS-X16.PRG, geosx16.bin, the disk
images (GEOSDISK.D81 etc.) and, if you have them, BASIC.BIN and KERNAL.BIN
(see "The calculator, geoCalc and the C64 ROMs"). Then, in X16 BASIC (with
DOS"CD:FOLDER" first if they are in a folder):

    LOAD "GEOS-X16.PRG",8
    RUN

It checks the cartridge's RAM, copies geosx16.bin into it and starts GEOS
the way the X16 starts a cartridge after a reset, but without a reset, so
GEOS finds its disks in the same folder. Without RAM in banks 32-34 and
48-56 it says so and stays in BASIC.

- The cartridge's RAM keeps GEOS over a reset, not over power-off: after
  switching on, LOAD and RUN it again. After a reset the X16 starts GEOS
  from the cartridge by itself, but then looks for its disks in the card's
  root folder.
- To get to X16 BASIC past the cartridge, hold SHIFT while switching on or
  resetting (ROM R49 and later).
- To try it in x16emu, start it with an empty RAM cartridge instead of
  -cartbin: LOADER-TEST.bat runs `x16emu -cart ramcart.crt` (made with
  x16emu's `makecart -ram 32 63 -o ramcart.crt`; tools/ramcart.crt), then
  LOAD and RUN as above.
- Tested in x16emu, with the files in the emulator's folder and on an SD
  card image. Not yet on a real X16.

## The calculator, geoCalc and the C64 ROMs

The calculator and geoCalc do their maths with the floating point routines
in the C64's BASIC ROM, which the X16 does not have: the calculator for
everything, geoCalc for all but adding up (turning what you type into a
number and back, powers, SQRT, LN, LOG, EXP, SIN, COS, TAN, ATAN). Put
your own copies of the C64's BASIC and KERNAL ROMs next to the disk images,
as BASIC.BIN and KERNAL.BIN (8K each; VICE has them in its C64 folder as
basic-901226-01.bin and kernal-901227-03.bin), and the boot screen says
"C64 ROMS: BASIC.BIN, KERNAL.BIN": both then work as on a C64, with the
same results to the last digit. Without them they open and nothing
crashes, but they do not calculate: the calculator's display stays empty.
GEOS-X16 cannot include the ROMs (Commodore's copyright).

## Colour and wallpaper

GEOS 2.0 on a C64 gives every 8x8 card of the screen its own two colours.
GEOS-X16 shows them all, as a C64 does: the preference manager's colour
swatches, the pad color manager, the deskTop's coloured file window and
icons, geoPaint's colour pictures.

- The shipped drive A sets white on blue for the screen (menus, dialog
  boxes, applications), a white file window with an icon colour for each
  kind of file, a yellow pointer and a light blue border. These are GEOS's
  own settings files ("Preferences" and "Pad Color Pref"), as the two
  managers save them.
- To change the screen colours: geos menu > preference manager. Click a
  swatch (BORDER, B.GROUND, F.GROUND, MOUSE) to step through the colours,
  CHANGE to apply them, SAVE to keep them, EXIT.
- To change the file window's colours: geos menu > pad color manager. Click
  a swatch to step its colour, or DEFAULT 1/2/3 for a ready set; SAVE,
  EXIT. COLOR OFF goes back to plain screen colours.
- The wallpaper (an X16 extra) replaces the deskTop's grey background
  pattern: wherever the deskTop shows its pattern in the screen colours,
  the picture in GEOSWALL.BIN shows instead; the file window, icons, menus
  and dialog boxes stay on top. Applications (geoWrite, geoPaint, ...) do
  not show it. No GEOSWALL.BIN in the folder: no wallpaper.
- Your own wallpaper: `python mkwall.py picture.png GEOSWALL.BIN` (needs
  Python 3 with Pillow) scales any picture to 320x200 and converts it to
  the 207 colours GEOS leaves free. `python mkwall.py --default
  GEOSWALL.BIN` makes the shipped one again.
- The mouse pointer has a thin black outline (also an X16 extra), so it
  shows on any colour.

## Using it

- Mouse: the X16 mouse (left button).
- Keyboard: the PC keys type what they show. GEOS's Commodore-key shortcuts
  (C=+letter in menus) are Alt+letter or Windows key+letter. Ctrl+letter
  gives the control codes. Cursor keys, Delete/Backspace, Return, Home as on
  the C64. Held keys repeat at GEOS's own rate.
- Two drives: the deskTop shows drive B when GEOSDSK2 is there. Drag a
  file onto the other drive's icon to copy it. File dialogs have a Drive
  button (it switches between A and B).
- Drive C: GEOS 2.0's deskTop shows drive C's icon below the other two
  but works with two drives at a time, as on a C64. To use drive C, drag
  its icon onto drive A's or drive B's icon: the two swap places, and the
  disk that was in drive C is open as drive A or B. Drag the drive C icon
  onto the same drive again to swap them back. (GEOS 2.0 wants a RAM
  expansion for a third drive; GEOS-X16 has one built in.)
- Saving: every block GEOS writes is written straight into the image file
  on the disk, so documents survive a crash or a closed window.
- Leaving: deskTop "options > BASIC" closes the disk images and returns to
  X16 BASIC (READY.), without resetting the X16: as C64 GEOS does, it puts
  the KERNAL's memory, interrupts and screen back the way they are at
  power-on and starts BASIC, so the SD card's current folder stays. A reset
  of the X16 starts GEOS again (in x16emu: Ctrl+M to release the mouse,
  then Ctrl+R).
- Your disks: any GEOS 2.0 disk image works as GEOSDISK.D64 (or .D81) if
  it holds DESK TOP. Keep a copy of the original. A disk needs some free
  space, or geoWrite and geoPaint refuse to run ("Disk near full").
- A D81 for GEOS: geosimg.py (Python 3) makes one ("geosimg.py new APPS.D81
  "Disk Name" ID") and copies GEOS files into it from D64s or other D81s
  ("geosimg.py cp FROM.D64 APPS.D81 GEOWRITE GEOPAINT ..."), with their
  icons and VLIR records. The deskTop can also copy files onto it.

## Programs tried

Run from C64 disk images in x16emu R49 (each opened from the deskTop and
used a little: a document typed, a picture drawn, an album made, ...). The
2.x programs and desk accessories below were also all opened from one D81:

- Work: deskTop 2.0, CONFIGURE 2.0, geoWrite 2.1 and 1.3, geoPaint 2.0
  and 1.3, geoSpell 1.1, geoMerge 2.1, geoLaser 2.0 and 2.1 (no printer,
  see below), Text Grabber 2.3, geoText 1.0, CONVERT 2.5, PAINT DRIVERS,
  note pad, alarm clock, preference mgr, pad color mgr, photo
  manager 2.1 and 1.3, text manager 2.1 and 1.3.
- The calculator and geoCalc 1.0, with BASIC.BIN and KERNAL.BIN (see "The
  calculator, geoCalc and the C64 ROMs"): new sheets, formulas with SQRT, LN, LOG, EXP, SIN, COS, TAN,
  ATAN, powers, SUM, RND; errors (LN(0), SQRT(-1)) show *RANGE* as they
  should; the "New Car" sample sheet's payments are right to the cent.
  Without the ROMs it stops at its first calculation.
- Graphics Grabber 2.0 starts (it loads into page 3, over the X16's
  interrupt entry; the kernel deals with that, see "How it works").
- Copy protection: geoWrite 2.0 and Graphics Grabber 2.0 copies that were
  installed on another GEOS system ask for "the GEOS disk used the first
  time" and stop, as they would on a C64.
- Damaged files: a disk image can hold a broken copy (a bad sector, a
  broken block chain); such a program cannot work on a C64 either.
- C64 BASIC programs on a GEOS disk (DISK COPY, BACKUP, ...): opening one
  leaves GEOS for X16 BASIC (a C64 program cannot run on the X16).

## What is not there (yet)

- Printing: GEOS sees no printer (device not present) and says so.
- No RAM disk (the built-in RAM expansion is 64K, for GEOS's own use).
- Input drivers: the X16 mouse driver is built in. Do not load another
  input driver from the deskTop.
- The alarm clock desk accessory's alarm does not ring (the C64's CIA alarm
  is not emulated). The clock itself runs.
- 1541 and 1581 disks only: D64 (35 tracks) and D81. No D71 (1571), no
  40-track D64.
- The deskTop's "format" and "erase" need a real drive's DOS: use
  geosimg.py to make an empty disk instead.
- Real hardware: needs an X16 cartridge with RAM, see "Real hardware:
  GEOS-X16.PRG" (the screen code keeps its variables in bank 33, GEOS its
  kernel in 48-55, geoCalc's maths uses 56). 512 KB of banked RAM is
  enough. Only x16emu has been tested.

## How it works (for the curious)

- The cartridge boot code (bank 32) opens the disk images on device 8
  (GEOSDISK, GEOSDSK2, GEOSDSK3: .D64, else .D81) on channels 2-4 for
  reading and writing (or reading only), loads GEOSWALL.BIN straight into
  video RAM, sets VERA up (two tile layers and sprites), copies the 16 KB
  GEOS kernel into cartridge RAM banks 48-55 and starts GEOS. It looks for
  each image in read mode first: CMDR-DOS's modify mode would make an
  empty file for an image that is not there.
- The C64's $01 banking value is used as the X16 ROM bank: $30-$37 are the
  eight copies of the kernel; banks 53-55 also hold a shadow of the C64's
  I/O area for GEOS to write VIC/CIA registers into.
- The screen: VERA layer 1 holds the C64 bitmap ($A000, in RAM bank 47)
  as 1000 tiles of 2 bits per pixel, one per 8x8 card, each with the card's
  foreground colour (its map entry's palette offset); bit 0 pixels are
  transparent. Layer 0 has a solid tile in each card's background colour,
  or, on the deskTop, the wallpaper's tile for that card. Every frame the
  VSYNC interrupt converts the card rows GEOS has drawn into (and a few
  rows of the colour matrix at $8C00, and one more row when its checksum
  changed or it was converted while being drawn), turns the VIC sprite registers into VERA sprites, reads keys
  and mouse packets from the SMC, and ticks the CIA time-of-day clock.
- The wallpaper: the deskTop's background pattern is a 50% checkerboard.
  In cards in the screen colours, the pixels that differ from it belong to
  something drawn on top; each card's runs of such lines are drawn from
  their leftmost to their rightmost differing column (an icon or a label
  may contain pattern pixels too), everything else is transparent.
- The disk driver ($9000) serves every drive. Its directory code is
  GEOS's 1541 and 1581 drivers' (it goes by the drive type: a D64 is a
  1541, a D81 a 1581), its BAM routines sit in the helper bank (bank 33),
  and $9C80-$9D7F stays free for a 1581's second BAM block, which the
  deskTop uses directly. Block reads and writes are new: a block is read
  from the image file through a cache of one disk line per RAM bank
  (banks 3-14: a D64 track or half a D81 track, read with one seek and
  MACPTR); a written block goes to the file at once (the X16 KERNAL's "P"
  positioning command, then 256 bytes) and into the cached line. Reading
  a file's last byte makes the DOS close it, so each image's last block
  is kept in RAM (bank 2) and only ever written.
- The RAM expansion: GEOS's StashRAM, FetchRAM, SwapRAM and VerifyRAM
  work on 64K of the X16's banked RAM (banks 15-22). GEOS 2.0's deskTop
  only looks for drive C when there is an expansion with the disk drivers
  "in it"; it swaps drive C in with ChangeDiskDevice, which here just moves
  an image to another device number. SetDevice has no driver to fetch, as
  the one driver serves all drives.
- The X16 sends interrupts through RAM at $038B, which the deskTop uses
  for variables and clears when it starts (and again after a desk
  accessory, with interrupts on). The kernel puts the entry back every
  time round the main loop, and replaces the deskTop's clearing loop with
  one that keeps it, when it starts the deskTop. geoCalc swaps its zero
  page with $0334-$03AE: its swap loop is pointed at a copy that leaves
  the entry alone. A program loaded over the entry (Graphics Grabber
  loads at $0340) gets the entry back at the end of the load, and the
  program's own three bytes there are kept aside; when the program itself
  runs into $038B (no interrupt has mapped ROM bank 0), the kernel does
  what those bytes do and goes on after them. All of this happens in
  memory: the programs on the disk are not changed.
- C64 KERNAL calls made by applications and printer drivers (LISTEN,
  OPEN, ...) reach a stub table at $FF81 that answers "device not
  present".
- geoCalc's maths: the boot loads BASIC.BIN into RAM bank 23 and puts
  KERNAL.BIN, behind a copy of GEOS's $C000-$DFFF, into cartridge bank 56:
  the C64's memory with $01 = $37 (BASIC and KERNAL ROM in). When geoCalc
  is loaded, its two instructions that switch the ROMs in and out ("lda
  #$37 / sta $01" and "lda $2FF3 / sta $01") become calls to GEOS-X16
  code that maps RAM bank 23 at $A000 and bank 56 at $C000, and back. geoCalc
  keeps interrupts off in between, and its own error handler (BASIC's
  error vector at $0300) still catches overflows. As with the other
  patches, the program on the disk is not changed.

## Building

Needs cc65 (ca65/ld65) and python3:

    ./build_x16.sh          -> geosx16.bin

Tests (Linux, x16emu R49 + ROM, Xvfb, xdotool, ImageMagick, python3-pil):

    ./test_x16.sh           boot, geoWrite: create, type, font, save; reopen; BASIC
                            (DISK=WORK.D81 ./test_x16.sh: the same from a D81)
    ./test_x16_typing.sh    22 lines typed at 60+ keys/s; key repeat
    ./test_x16_drives.sh    two drives: copy a file from B to A, check both BAMs
    ./test_x16_da.sh        preference manager opened and closed twice
    ./test_x16_colour.sh    colours, the preference manager's swatches, the
                            wallpaper on the deskTop (not in geoWrite);
                            this test and test_x16.sh also check from memory
                            dumps that the screen shows exactly what GEOS
                            drew (tools/x16vramcheck.py)
    ./test_all_x16.sh       all five
    ./mkdist.sh             dist/GEOS-X16 (+ .zip): cartridge, launcher, disks,
                            wallpaper

Disk tools: tools/geosimg.py (D64 and D81: make an empty GEOS disk, copy
GEOS files between images, list, check a BAM against the files). In
../tools: d64ls.py (list), d64cp.py (copy files between D64s, set the disk
name), d64rm.py (delete), d64check.py (check a D64's BAM against the
files), geoscolours.py (write the colour settings files).

Licence: the GEOS kernel source is the reverse-engineered GEOS by Maciej
Witkowiak and Michael Steil (github.com/mist64/geos). GEOS itself and its
applications are Berkeley Softworks / GeoWorks software: use your own disks.
