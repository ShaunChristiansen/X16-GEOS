#!/bin/sh
# SD CARD's "Make this folder drive C" in x16emu (Linux, needs Xvfb,
# xdotool, ImageMagick, python3, ca65/ld65): drive A a D64 with SD CARD,
# B GEOSDSK2.D81, C GEOSDSK3.D81; GEOSSD.D81 (blank) next to geosx16.bin;
# the folder WORK: MEMO.TXT, CALC.CVT, NOTES.BIN (bytes 0-299), SPACE.BMX,
# BIG.D81 (too big).  After it: drive C is GEOSSD.D81 with MEMO (a geoWrite
# document), calculator, NOTES.BIN (300 bytes, as they were) and SPACE.BMX;
# GEOSSD.CFG names GEOSDSK3.D81 and WORK.  Screenshots: build/test_sddrive_shots/.
set -e
cd "$(dirname "$0")"
HERE=$(pwd)
X16EMU=${X16EMU:-/home/claude/ext/x16-emulator/x16emu}
X16ROM=${X16ROM:-/home/claude/ext/x16-rom/build/x16/rom.bin}
DISK=${DISK:-../disks/WORK.D64}
command -v ca65 >/dev/null 2>&1 || PATH=/home/claude/ext/cc65/bin:$PATH
T=$HERE/build/test_sddrive
S=$HERE/build/test_sddrive_shots
rm -rf $T $S; mkdir -p $T/WORK $S
cp geosx16.bin $T/
cp $DISK $T/GEOSDISK.D64
python3 tools/mkx16app.py sdcard $T/GEOSDISK.D64 >/dev/null
G="python3 tools/geosimg.py"
$G new $T/GEOSDSK2.D81 "Disk Two" D2 >/dev/null
$G new $T/GEOSDSK3.D81 "Disk Three" D3 >/dev/null
$G new $T/GEOSSD.D81 "SD Card" SD >/dev/null
$G new $T/WORK/BIG.D81 "Big" BG >/dev/null
python3 tools/cvtmake.py $DISK calculator $T/WORK/CALC.CVT
printf 'A memo from the SD card.\r\nSecond line.\r\n' > $T/WORK/MEMO.TXT
python3 -c "open('$T/WORK/NOTES.BIN','wb').write(bytes(i&255 for i in range(300)))"
cp GeosWallpapers/SPACE.BMX $T/WORK/
export DISPLAY=${DISPLAY:-:99}
pgrep -x Xvfb >/dev/null || { Xvfb $DISPLAY -screen 0 1024x768x24 >/dev/null 2>&1 & sleep 1; }
. tools/x16ui.sh
shot() { import -window root -crop 640x480+$WX+$WY $S/$1.png; }
gpos() {
  for _t in 1 2 3 4; do
    shot _pos; xdotool mousemove_relative -- 8 8; sleep 0.25; shot _pos2
    xdotool mousemove_relative -- -8 -8; sleep 0.25
    _p=$(python3 tools/x16pointer.py $S/_pos.png $S/_pos2.png 2>/dev/null)
    [ -n "$_p" ] && [ "$_p" != "None" ] && { echo "$_p"; return; }
    xdotool mousemove_relative -- 600 0; sleep 0.5
  done; }
fail() { echo "FAIL: $*"; pkill -x "$(basename "$X16EMU")"; exit 1; }
idx() { python3 -c "import os,sys; print(os.listdir(sys.argv[1]).index(sys.argv[2])+1)" $T/${2:-.} "$1"; }
cnt() { python3 -c "import os,sys; print(len(os.listdir(sys.argv[1])))" $T/${1:-.}; }
up0() { for _i in 1 2 3 4 5 6 7 8 9 10; do rel 0 -25; sleep 0.15; done; }
dn() { _r=$1; while [ $_r -gt 0 ]; do _s=$_r; [ $_s -gt 20 ] && _s=20; rel 0 $_s; sleep 0.15; _r=$((_r-_s)); done; }
# to (60, row y): moves checked by the pointer's position, half-way each
# time (the moves overshoot), till within 3 pixels
item() { _ty=$(( 39 + $1 * 14 )); sleep 0.5
  for _k in 1 2 3 4 5 6 7 8; do set -- $(gpos); _dx=$(( 60 - $1 )); _dy=$(( _ty - $2 ))
    [ ${_dy#-} -le 3 ] && [ ${_dx#-} -le 20 ] && break
    rel $(( _dx / 2 )) $(( (_dy + (_dy > 0 ? 1 : -1)) / 2 )); done
  sleep 0.3; click; sleep 5; }
pick() { n=$(( $(idx $1 $2) - 1 )); p=$(( n / 7 )); while [ $p -gt 0 ]; do item 7; p=$((p-1)); done; item $(( n % 7 )); }
sdcard() { goto 220 97; dclick; sleep 12; }
start
sdcard
echo "into WORK"
pick WORK; shot 1_work
# the items: the files (5, a page), Up, Copy here, Make this folder drive C
goto 60 137; sleep 0.3; click; sleep 25; shot 2_done
goto 95 111; click; sleep 12; shot 3_desk
pkill -x "$(basename "$X16EMU")"; sleep 1
$G ls $T/GEOSSD.D81 || fail "GEOSSD.D81"
cat $T/GEOSSD.CFG | tr '\r' '\n'; cat $T/WORK/GEOSSD.LST | tr '\r\t' '\n|'
grep -q GEOSSD.D81 $T/GEOSDRV.CFG || fail "GEOSDRV.CFG: drive C"
# as if in GEOS: NOTES.BIN deleted, MEMO changed (its date), note pad new
python3 - $T/GEOSSD.D81 <<'PY'
import sys; sys.path.insert(0,'tools'); import geosimg
p=sys.argv[1]; img=geosimg.Image(bytearray(open(p,'rb').read()))
for e in img.entries():
    n=img.name_of(e) if img.d[e+2] else None
    if n=='NOTES.BIN': img.d[e+2]=0
    if n=='MEMO': img.d[e+2+27]=(img.d[e+2+27]+1)&255
open(p,'wb').write(img.d)
PY
$G cp $DISK $T/GEOSSD.D81 "note pad" >/dev/null
$G ls $T/GEOSSD.D81
echo "save drive C back (a new start)"
start
sdcard; shot 4_win
pick WORK; shot 5_work
# the items: the files (4: GEOSSD.LST hidden), Up, Copy here, Save drive C back
item $(( $(cnt WORK) - 1 + 2 )); sleep 30; shot 6_saved
goto 95 111; click; sleep 12; shot 7_desk
pkill -x "$(basename "$X16EMU")"; sleep 1
ls -la $T/WORK; cat $T/WORK/GEOSSD.LST | tr '\r\t' '\n|'
[ ! -f $T/WORK/NOTES.BIN ] || fail "NOTES.BIN not deleted"
[ -f "$T/WORK/note pad.CVT" ] || fail "note pad.CVT not new"
cat $T/GEOSDRV.CFG | tr '\r' '\n'
echo PASS
