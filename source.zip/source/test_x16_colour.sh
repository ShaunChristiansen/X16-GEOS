#!/bin/sh
# Colour and wallpaper test of GEOS-X16 in x16emu, with the shipped disks
# (dist/GEOS-X16: colour settings on drive A) and GEOSWALL.BMX:
#   - the deskTop: menu bar in the screen colours (white on blue), the file
#     window white (pad colours), the wallpaper around it, the pointer
#   - the preference manager's colour swatches show the four colours
#   - geoWrite: no wallpaper (it is the deskTop's); back on the deskTop: there
#   - drive B's file window
# and at each step, from a memory dump: VERA shows exactly the bitmap and
# the colour matrix (tools/x16vramcheck.py), so no text goes missing
#   X16EMU=path/to/x16emu X16ROM=path/to/rom.bin ./test_x16_colour.sh
set -e
cd "$(dirname "$0")"
HERE=$(pwd)
X16EMU=${X16EMU:-/home/claude/ext/x16-emulator/x16emu}
X16ROM=${X16ROM:-/home/claude/ext/x16-rom/build/x16/rom.bin}
T=$HERE/build/test_colour
export DISPLAY=${DISPLAY:-:99}
pgrep -x Xvfb >/dev/null || { Xvfb $DISPLAY -screen 0 1024x768x24 >/dev/null 2>&1 & sleep 1; }
. tools/x16ui.sh
export X16ARGS="-dump RBV"
pkill -x "$(basename "$X16EMU")" 2>/dev/null || true; sleep 1
[ -f dist/GEOS-X16/GEOSWALL.BMX ] || ./mkdist.sh >/dev/null
rm -rf $T; mkdir -p $T
cp geosx16.bin dist/GEOS-X16/GEOSDISK.D64 dist/GEOS-X16/GEOSDSK2.D64 dist/GEOS-X16/GEOSWALL.BMX $T/

# check SHOT WHAT: looks at GEOS screen areas (x0 y0 x1 y1 in GEOS pixels)
check() { python3 - "$T/$1.png" "$2" <<'PY'
import sys
from PIL import Image
from collections import Counter
im = Image.open(sys.argv[1]).convert('RGB')
def area(x0, y0, x1, y1):
    return Counter(im.getpixel((2 * x, 2 * y + 40)) for x in range(x0, x1) for y in range(y0, y1))
def top(c): return c.most_common(1)[0][0]
BLUE, WHITE, LBLUE, YELLOW = (51, 34, 119), (255, 255, 255), (102, 102, 187), (187, 204, 119)
C64 = {(0,0,0), (255,255,255), (102,51,51), (119,170,170), (119,68,136), (85,136,68), (51,34,119),
       (187,204,119), (119,85,34), (68,51,0), (153,102,85), (68,68,68), (102,102,102),
       (153,204,136), (102,102,187), (153,153,153)}
def wallpaper(c):          # many colours, mostly not C64 ones
    return len(c) >= 12 and sum(n for col, n in c.items() if col not in C64) > 0.8 * sum(c.values())
what = sys.argv[2]
ok = True
if what == "desktop":
    ok &= top(area(4, 2, 190, 10)) == BLUE              # menu bar background
    ok &= top(area(30, 30, 250, 60)) == WHITE           # file window
    ok &= wallpaper(area(296, 96, 318, 140))            # right of the window
    ok &= wallpaper(area(140, 150, 260, 198))           # below it
elif what == "pref":
    # BORDER, B.GROUND, F.GROUND, MOUSE swatches
    sw = [top(area(139, y, 150, y + 3)) for y in (34, 42, 50, 58)]
    print("swatches", sw)
    ok &= sw == [LBLUE, BLUE, WHITE, YELLOW]
elif what == "nowall":
    ok &= not wallpaper(area(296, 96, 318, 140)) and not wallpaper(area(140, 150, 260, 198))
sys.exit(0 if ok else 1)
PY
}

# vram NAME: memory dump; VERA must show what GEOS drew
vram() { dumpmem $1; python3 tools/x16vramcheck.py $T/$1.bin || fail "screen differs from the bitmap ($1)"; }

echo "boot: deskTop in colour, with the wallpaper"
start
shot 1_desktop
check 1_desktop desktop || fail "deskTop colours or wallpaper wrong"
vram 1_desktop
[ "$(gpos)" != "none" ] || fail "no GEOS pointer on screen"
echo "a menu: all of its text"
goto 10 6; click; sleep 1.5; shot 2_menu; vram 2_menu
echo "preference manager: its colour swatches"
goto 30 74; click; sleep 4; shot 3_pref
check 3_pref pref || fail "the preference manager's swatches are not in colour"
vram 3_pref
rel -330 -210; rel 176 12; sleep 0.3; click; sleep 4
echo "geoWrite: no wallpaper"
goto 107 60; dclick; sleep 5; shot 4_geowrite
check 4_geowrite nowall || fail "wallpaper shown in geoWrite"
vram 4_geowrite
goto 102 111; click; sleep 5; shot 5_back
check 5_back desktop || fail "deskTop not back in colour with the wallpaper"
echo "drive B: its file window"
goto 290 80; click; sleep 2; shot 6_driveb; vram 6_driveb
pkill -x "$(basename "$X16EMU")" || true
echo "PASS (screenshots in $T)"
