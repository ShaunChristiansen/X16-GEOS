#!/bin/sh
# SD CARD (a window on the SD card) in x16emu (Linux, needs Xvfb, xdotool,
# ImageMagick "import", python3, ca65/ld65):
#   drive A: a D64 with SD CARD on it (tools/mkx16app.py sdcard), drive B:
#   GEOSDSK2.D81; on the card: MEMO.TXT, CALC.CVT, OTHER.D81, a BMX, the
#   folder SUB with NESTED.D81 and OLD.TXT.  SD CARD lists them with their
#   sizes; SUB opens, and "Up a folder" comes back; OLD.TXT is renamed
#   NEW.TXT and then deleted; MEMO.TXT is copied onto drive B (a geoWrite
#   document there); SUB/NESTED.D81 goes into drive B (GEOSDRV.CFG names
#   it); SPACE.BMX becomes the wallpaper (GEOSWALL.CFG).  Screenshots go to build/test_sdcard_shots/.
#   X16EMU=path/to/x16emu X16ROM=path/to/rom.bin ./test_x16_sdcard.sh
set -e
cd "$(dirname "$0")"
HERE=$(pwd)
X16EMU=${X16EMU:-/home/claude/ext/x16-emulator/x16emu}
X16ROM=${X16ROM:-/home/claude/ext/x16-rom/build/x16/rom.bin}
DISK=${DISK:-../disks/WORK.D64}
command -v ca65 >/dev/null 2>&1 || PATH=/home/claude/ext/cc65/bin:$PATH
T=$HERE/build/test_sdcard
rm -rf $T; mkdir -p $T/SUB
cp geosx16.bin $T/
cp $DISK $T/GEOSDISK.D64
python3 tools/mkx16app.py sdcard $T/GEOSDISK.D64 >/dev/null
G="python3 tools/geosimg.py"
$G new $T/GEOSDSK2.D81 "Disk Two" D2 >/dev/null
$G new $T/OTHER.D81 "Other Disk" OD >/dev/null
$G new $T/SUB/NESTED.D81 "Nested Disk" ND >/dev/null
python3 tools/cvtmake.py $DISK calculator $T/CALC.CVT
printf 'A memo from the SD card.\r\nSecond line.\r\n' > $T/MEMO.TXT
printf 'old\r\n' > $T/SUB/OLD.TXT
cp GEOSWALL.BMX $T/
cp GeosWallpapers/SPACE.BMX $T/SPACE.BMX
export DISPLAY=${DISPLAY:-:99}
pgrep -x Xvfb >/dev/null || { Xvfb $DISPLAY -screen 0 1024x768x24 >/dev/null 2>&1 & sleep 1; }
. tools/x16ui.sh
# screenshots in their own folder (the SD card folder's list stays as it was)
S=$HERE/build/test_sdcard_shots; rm -rf $S; mkdir -p $S
shot() { import -window root -crop 640x480+$WX+$WY $S/$1.png; }
gpos() {
  for _t in 1 2 3 4; do
    shot _pos; xdotool mousemove_relative -- 8 8; sleep 0.25; shot _pos2
    xdotool mousemove_relative -- -8 -8; sleep 0.25
    _p=$(python3 tools/x16pointer.py $S/_pos.png $S/_pos2.png 2>/dev/null)
    [ -n "$_p" ] && [ "$_p" != "None" ] && { echo "$_p"; return; }
    xdotool mousemove_relative -- 600 0; sleep 0.5
  done; }
fail() { echo "FAIL: $*"; pkill -x "$(basename "$X16EMU")"; exit 1; }
# the window lists in the directory's order (the host's, as ls -f)
idx() { python3 -c "import os,sys; print(os.listdir(sys.argv[1]).index(sys.argv[2])+1)" $T/${2:-.} "$1"; }
cnt() { python3 -c "import os,sys; print(len(os.listdir(sys.argv[1])))" $T/${1:-.}; }
sdcard() { goto 220 97; dclick; sleep 12; }
up0() { for _i in 1 2 3 4 5 6 7 8 9 10; do rel 0 -25; sleep 0.15; done; }
dn() { _r=$1; while [ $_r -gt 0 ]; do _s=$_r; [ $_s -gt 20 ] && _s=20; rel 0 $_s; sleep 0.15; _r=$((_r-_s)); done; }
item() { goto 80 120; sleep 0.2; up0; dn $(( 39 + $1 * 14 )); sleep 0.3; click; sleep 5; }
# pick NAME [FOLDER]: "More..." as often as needed, then its line
pick() { n=$(( $(idx $1 $2) - 1 )); p=$(( n / 7 )); while [ $p -gt 0 ]; do item 7; p=$((p-1)); done; item $(( n % 7 )); }
# the items after the files on the first page: More (if more than 8), Up (in a folder)
after() { c=$(cnt $1); r=$c; [ $c -gt 8 ] && r=9; [ $c -gt 8 ] && [ $c -le 8 ] || true; echo $r; }
start
sdcard; shot 1_window
echo "into SUB"
pick SUB; shot 2_sub
echo "OLD.TXT: rename it NEW.TXT"
pick OLD.TXT SUB; shot 3_act
item 1; sleep 2; shot 4_ren
for i in 1 2 3 4 5 6 7 8 9 10; do key BackSpace; done
typetext "NEW.TXT"; key Return; sleep 6; shot 5_renamed
[ -f $T/SUB/NEW.TXT ] && [ ! -f $T/SUB/OLD.TXT ] || fail "not renamed"
echo "NEW.TXT: delete it"
pick NEW.TXT SUB; item 2; sleep 2; shot 6_del
goto 95 111; click; sleep 8; shot 7_deleted
[ ! -f $T/SUB/NEW.TXT ] || fail "not deleted"
echo "MEMO.TXT onto drive B (a new start)"
start; sdcard
pick MEMO.TXT; shot 9_act; item 0; shot 10_drv; item 1; sleep 12; shot 11_copied
$G ls $T/GEOSDSK2.D81 | grep -i memo || fail "MEMO not on drive B"
echo "SUB/NESTED.D81 into drive B (a new start)"
start; sdcard
pick SUB; pick NESTED.D81 SUB; shot 12_act; item 0; shot 13_drv; item 1; sleep 14; shot 14_desk
grep -q "NESTED.D81" $T/GEOSDRV.CFG || fail "GEOSDRV.CFG"
cat $T/GEOSDRV.CFG; echo
echo "SPACE.BMX: the wallpaper (a new start)"
start; sdcard
pick SPACE.BMX; shot 15_act; item 0; sleep 14; shot 16_wall
grep -qi "SPACE.BMX" $T/GEOSWALL.CFG || fail "GEOSWALL.CFG"
echo PASS
pkill -x "$(basename "$X16EMU")"
