#!/bin/sh
# End-to-end test of GEOS-X16 in x16emu (Linux, needs Xvfb, xdotool,
# ImageMagick "import", python3):
#   boot -> deskTop -> geoWrite: create a document, type, change font,
#   close -> quit -> deskTop (the screen checked against the bitmap from
#   memory dumps); the document must be in GEOSDISK.D64 on the
#   host afterwards; then a fresh boot opens it again; then BASIC.
#   X16EMU=path/to/x16emu X16ROM=path/to/rom.bin ./test_x16.sh
#   DISK=WORK.D81 ./test_x16.sh boots from a D81 (a 1581 disk) instead
# Screenshots go to build/test/.
set -e
cd "$(dirname "$0")"
HERE=$(pwd)
X16EMU=${X16EMU:-/home/claude/ext/x16-emulator/x16emu}
X16ROM=${X16ROM:-/home/claude/ext/x16-rom/build/x16/rom.bin}
DISK=${DISK:-../disks/WORK.D64}
T=$HERE/build/test
rm -rf $T; mkdir -p $T
cp geosx16.bin $T/
case "$DISK" in
  *.D81|*.d81) cp $DISK $T/GEOSDISK.D81;;   # a 1581 disk
  *) cp $DISK $T/GEOSDISK.D64;;
esac
export DISPLAY=${DISPLAY:-:99}
pgrep -x Xvfb >/dev/null || { Xvfb $DISPLAY -screen 0 1024x768x24 >/dev/null 2>&1 & sleep 1; }

. tools/x16ui.sh
export X16ARGS="-dump RBV"
# vram NAME: memory dump; VERA must show what GEOS drew
vram() { dumpmem $1; python3 tools/x16vramcheck.py $T/$1.bin || fail "screen differs from the bitmap ($1)"; }

echo "boot"
start
shot 1_desktop
[ "$(gpos)" != "none" ] || fail "no GEOS pointer on screen"
echo "geoWrite: create a document"
goto 107 60; dclick; sleep 4
goto 103 63; click; sleep 2
typetext "X16 Test"; key Return; sleep 3
typetext "Hello from GEOS on the Commander X16!"; key Return
typetext "geoWrite 2.1 running on x16emu R49."; key Return
sleep 1; shot 2_typed; vram 2_typed
echo "font menu: Roma 24"
goto 150 7; click; sleep 1; goto 165 77; click; sleep 2; goto 245 63; click; sleep 2
typetext "Roma 24"; sleep 1.5; shot 3_roma; vram 3_roma
echo "close, quit"
goto 38 7; click; sleep 0.8; goto 40 21; click; sleep 3
goto 103 111; click; sleep 5; shot 4_desktop_after
pkill -x "$(basename "$X16EMU")" || true; sleep 0.5
TXT=$(doctext "X16 Test")
echo "document on the host disk: $TXT"
case "$TXT" in *"Hello from GEOS on the Commander X16!"*"Roma 24"*) ;; *) fail "document text not saved";; esac
echo "fresh boot, open the document"
start
goto 166 60; dclick; sleep 5; shot 5_reopened; vram 5_reopened
echo "quit to deskTop, then BASIC"
goto 38 7; click; sleep 0.8; goto 40 105; click; sleep 5
goto 180 7; click; sleep 1; goto 175 47; click; sleep 5; shot 6_basic
python3 tools/x16basic.py $T/6_basic.png || fail "did not get to X16 BASIC"
basic_alive 7_alive || fail "X16 BASIC is not running"
pkill -x "$(basename "$X16EMU")" || true
echo "PASS (screenshots in $T)"
