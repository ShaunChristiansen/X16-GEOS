#!/bin/sh
# The Calypso card (its WiFi, through GEOS-X16's modem) with geoTelnet and
# GeoTerm in x16emu
# (Linux, needs Xvfb, xdotool, ImageMagick "import", python3):
#   no Calypso in x16emu: tools/fakenet/NET.BIN stands in for the card's
#   NET.BIN (same calls), its socket the test x16emu's UART
#   (tools/x16emu-testcards.patch, -midicard 9fe0, X16UART) and
#   tools/fakebbs.py raw behind it.  GEOSSER.CFG says CALYPSO (the UART
#   would be taken for a TexElec card otherwise).  Checked: GEOS-X16 looked
#   the host up (DNS bbs.test), opened 10.1.2.3:23, and the data both ways.
#   geoTelnet (from your geotelnet-v1.3.d64, as CVT files) and GeoTerm64
#   (from a GEOS disk) are put on a test drive A.  Each: open it, AT (OK),
#   dial (the BBS), type a line (the BBS gets it), SPEED (300 lines: the
#   last must be on screen, and the screen must match GEOS's bitmap).
#   X16EMU=path/to/test-x16emu GEOTELNET=geotelnet-v1.3.d64 \
#   GEOTERM=GEOSDSK3.D81 ./test_x16_serial.sh
set -e
cd "$(dirname "$0")"
HERE=$(pwd)
X16EMU=${X16EMU:-/tmp/x16emu-prn/x16emu}
X16ROM=${X16ROM:-/home/claude/ext/x16-rom/build/x16/rom.bin}
DISK=${DISK:-../disks/WORK.D64}
GEOTELNET=${GEOTELNET:-../disks/geotelnet-v1.3.d64}
GEOTERM=${GEOTERM:-../disks/GEOSDSK3.D81}
PORT=${PORT:-6412}
T=$HERE/build/test_calypso
rm -rf $T; mkdir -p $T
cp geosx16.bin $T/
(cd tools/fakenet && ca65 -o $T/fakenet.o fakenet.s && ld65 -C fakenet.cfg -o $T/NET.BIN $T/fakenet.o)
printf 'CALYPSO\r' > $T/GEOSSER.CFG
G="python3 tools/geosimg.py"
$G new $T/GEOSDISK.D64 "Serial Test" ST >/dev/null
$G cp $DISK $T/GEOSDISK.D64 "DESK TOP" >/dev/null
$G cvtfrom $T/GEOSDISK.D64 $GEOTELNET GEOTELNET.CVT >/dev/null
$G cp $GEOTERM $T/GEOSDISK.D64 GeoTerm64 >/dev/null
export DISPLAY=${DISPLAY:-:99} X16UART=$PORT X16ARGS="-midicard 9fe0 -dump RBV"
pgrep -x Xvfb >/dev/null || { Xvfb $DISPLAY -screen 0 1024x768x24 >/dev/null 2>&1 & sleep 1; }
. tools/x16ui.sh

run() {  # $1: icon x (107 geoTelnet, 166 GeoTerm), $2: name
  python3 tools/fakebbs.py $PORT $T/rx_$2.log raw & echo $! > $T/bbs.pid; sleep 0.5
  start
  goto $1 60; dclick; sleep 10; shot ${2}_1
  typetext "AT"; key Return; sleep 2
  typetext "ATDTbbs.test:23"; key Return; sleep 7; shot ${2}_2
  typetext "Hello"; key Return; sleep 3
  grep -q "DNS bbs.test" $T/rx_$2.log || fail "$2: no host look-up"
  grep -q "ATDT10.1.2.3:23" $T/rx_$2.log || fail "$2: no connection opened"
  grep -q "Hello" $T/rx_$2.log || fail "$2: the typed line did not reach the BBS"
  typetext "SPEED"; key Return; sleep 40; shot ${2}_3
  dumpmem ${2}_dump
  python3 tools/x16vramcheck.py $T/${2}_dump.bin >/dev/null || fail "$2: screen differs from the bitmap"
  python3 - $T/${2}_dump.bin <<'P' || fail "$2: line 300 not on screen"
import sys
d = open(sys.argv[1], 'rb').read()
bm = d[0xA000 + 0x2F * 8192:0xA000 + 0x2F * 8192 + 8000]
# "300" drawn in the bottom text rows: the bitmap there is not empty
sys.exit(0 if any(bm[r * 320:r * 320 + 320].count(0) < 300 for r in range(20, 25)) else 1)
P
  pkill -x "$(basename "$X16EMU")" || true
  kill $(cat $T/bbs.pid) 2>/dev/null || true; sleep 0.5
  echo "$2: OK"
}
run 107 geoTelnet
run 166 GeoTerm
echo "PASS (screenshots in $T)"
