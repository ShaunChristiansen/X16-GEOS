; GEOS-X16.PRG: start GEOS-X16 on a real Commander X16 that has a cartridge
; (or an expansion card) with RAM in the cartridge banks.
;
;     LOAD "GEOS-X16.PRG",8      then   RUN
;
; 1. Checks that the cartridge banks GEOS-X16 needs are RAM: 32-34 (it is
;    copied there), 33 and 48-56 (it works there).
; 2. Loads GEOSX16.BIN (the 48K cartridge image) into banked RAM 1-6.
; 3. Copies it into cartridge banks 32-34, checking every byte.
; 4. Starts it as the KERNAL starts a cartridge after a reset (jsrfar to
;    $C004 in bank 32, interrupts off), without a reset, so the SD card's
;    current folder stays and GEOS finds its disks there.
;
; Cartridge RAM keeps GEOS-X16 over a reset (the X16 then starts it by
; itself), not over power-off.  To get to X16 BASIC past a cartridge in RAM,
; hold SHIFT while resetting.
; In x16emu: -cart with RAM banks (makecart -ram 32 63) instead of -cartbin.

.setcpu "65C02"

CHROUT    = $FFD2
SETNAM    = $FFBD
SETLFS    = $FFBA
LOAD      = $FFD5
JSRFAR    = $FF6E               ; call .word address in .byte ROM bank
RAMBANK   = $00
ROMBANK   = $01
ptr1      = $22                 ; (zero page $22-$7F: free for programs)
ptr2      = $24
TA        = $C123               ; two test addresses in the cartridge window
TB        = $D234

.segment "LOADADDR"
	.word $0801
.segment "CODE"
	.word @nxt, 10          ; 10 SYS2061
	.byte $9E, "2061", 0
@nxt:	.word 0

start:	lda ROMBANK             ; (BASIC's ROM bank: put back when going
	sta savrom              ; back to BASIC; the KERNAL's meanwhile)
	stz ROMBANK
	ldx #<t_title
	ldy #>t_title
	jsr print

; 1. the cartridge banks
	sei
	ldx #0
@g:	lda banks,x             ; GEOS's banks, up to the 0
	beq @k
	jsr isram
	bcc @y
	jmp noram
@y:	inx
	bra @g
@k:	cli

; 2. GEOSX16.BIN -> banked RAM 1-6 ($A000 onwards)
	ldx #<t_load
	ldy #>t_load
	jsr print
	lda #fname_end - fname
	ldx #<fname
	ldy #>fname
	jsr SETNAM
	lda #1
	ldx #8
	ldy #2                  ; (headerless: the raw cartridge image)
	jsr SETLFS
	lda #1
	sta RAMBANK
	lda #0
	ldx #<$A000
	ldy #>$A000
	jsr LOAD
	bcc @l
	jmp nofile
@l:	lda RAMBANK             ; it must be 48K: up to bank 6 $BFFF
	cmp #7
	bne @bf
	cpy #$A0
	bne @bf
	cpx #0
	bne @bf
	lda #1
	sta RAMBANK
	ldx #3
@s:	lda $A000,x             ; and start with "CX16"
	cmp sig,x
	bne @bf
	dex
	bpl @s
	bra @cp
@bf:	jmp badfile
@cp:

; 3. banked RAM 1-6 -> cartridge banks 32-34
	sei
	lda #1
	sta srcbank
	lda #32
	sta dstbank
@b:	lda #$C0
	jsr half
	bcs @bc
	lda #$E0
	jsr half
	bcs @bc
	inc dstbank
	lda dstbank
	cmp #35
	bne @b
	cli
	bra @r
@bc:	jmp badcopy
@r:

; 4. start the cartridge as the KERNAL does after a reset, but without one
;    (so the SD card's current folder stays: GEOS finds its disks there)
	ldx #<t_start
	ldy #>t_start
	jsr print
	sei
	jsr JSRFAR
	.word $C004
	.byte 32
	cli                     ; (GEOS doesn't come back; if it did: BASIC)
	jmp back

noram:	cli
	pha
	ldx #<t_noram
	ldy #>t_noram
	jsr print
	pla
	jsr prdec
	ldx #<t_noram2
	ldy #>t_noram2
	bra pback

nofile:	ldx #<t_nofile
	ldy #>t_nofile
	bra pback

badfile:
	ldx #<t_badfile
	ldy #>t_badfile
pback:	jsr print
back:	lda savrom              ; back to BASIC, in its ROM bank
	sta ROMBANK
	rts

badcopy:
	cli
	ldx #<t_badcopy
	ldy #>t_badcopy
	jsr print
	lda dstbank
	jsr prdec
	lda #13
	jsr CHROUT
	bra back

; Is cartridge bank A RAM?  Carry clear = yes.  Call with interrupts off
; (the bank's own vectors are mapped meanwhile); the two test bytes are put
; back.  Keeps A and X.
isram:	phx
	pha
	sta ROMBANK
	ldx TA
	ldy TB
	lda #$A5
	sta TA
	lda #$5A
	sta TB
	lda TA
	cmp #$A5
	bne @no
	lda TB
	cmp #$5A
	bne @no
	lda #$5A                ; and the other way round
	sta TA
	lda #$A5
	sta TB
	lda TA
	cmp #$5A
	bne @no
	lda TB
	cmp #$A5
	bne @no
	clc
	bra @x
@no:	sec
@x:	stx TA
	sty TB
	stz ROMBANK
	pla
	plx
	rts

; Copy 8K: banked RAM bank srcbank ($A000-$BFFF) -> cartridge bank dstbank
; at page A ($C0 or $E0), reading every byte back.  srcbank +1.
; Carry set = a byte did not stick.
half:	sta ptr2+1
	stz ptr2
	stz ptr1
	lda #$A0
	sta ptr1+1
	lda srcbank
	sta RAMBANK
	inc srcbank
	lda dstbank
	sta ROMBANK
	ldx #$20
	ldy #0
@c:	lda (ptr1),y
	sta (ptr2),y
	cmp (ptr2),y
	bne @bad
	iny
	bne @c
	inc ptr1+1
	inc ptr2+1
	dex
	bne @c
	stz ROMBANK
	clc
	rts
@bad:	stz ROMBANK
	sec
	rts

; print the 0-terminated text at X/Y
print:	stx ptr1
	sty ptr1+1
	ldy #0
@l:	lda (ptr1),y
	beq @e
	jsr CHROUT
	iny
	bne @l
@e:	rts

; print A (0-99) in decimal
prdec:	ldx #0
@t:	cmp #10
	bcc @d
	sbc #10
	inx
	bra @t
@d:	pha
	txa
	ora #'0'
	jsr CHROUT
	pla
	ora #'0'
	jmp CHROUT

banks:	.byte 32, 33, 34, 48, 49, 50, 51, 52, 53, 54, 55, 56, 0
sig:	.byte "CX16"
fname:	.byte "GEOSX16.BIN"
fname_end:
savrom:	.byte 0
srcbank: .byte 0
dstbank: .byte 0

t_title:  .byte 13, "GEOS-X16 LOADER", 13, 0
t_load:   .byte "LOADING GEOSX16.BIN", 13, 0
t_start:  .byte "STARTING GEOS-X16", 13, 0
t_noram:  .byte "NO RAM IN CARTRIDGE BANK ", 0
t_noram2: .byte ".", 13, "GEOS-X16 NEEDS A CARTRIDGE WITH RAM IN", 13
	  .byte "BANKS 32-34 AND 48-56.", 13, 0
t_nofile: .byte "GEOSX16.BIN IS NOT ON THIS DISK.", 13, 0
t_badfile: .byte "GEOSX16.BIN IS NOT THE 48K GEOS-X16", 13
	  .byte "CARTRIDGE IMAGE.", 13, 0
t_badcopy: .byte "COPYING FAILED IN CARTRIDGE BANK ", 0
