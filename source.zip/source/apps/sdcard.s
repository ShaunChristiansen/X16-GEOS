; SD CARD: a GEOS application for GEOS-X16 - a window on the X16's SD card
; (the folder geosx16.bin is in, and the folders in it).  It lists every
; file and folder with its size; open a folder to go in, "Up a folder" to
; come back.  Pick a file for what can be done with it:
;   .CVT, .TXT  copy it onto a GEOS disk (a .CVT: the GEOS file as it was;
;               a .TXT: a geoWrite document)
;   .D81, .D64  put it in drive A, B or C (GEOS-X16 call 10)
;   .BMX        make it the deskTop's wallpaper (call 0, as WALLPAPER)
;   any file    rename it, delete it
; and "Copy a GEOS file here" brings a file from a GEOS disk into the
; folder shown (as NAME.CVT, a geoWrite document also as NAME.TXT).
; (The copying came from COPIER, an app it has replaced.)
;
; ca65 -I ../inc --cpu 65sc02 sdcard.s; ld65 -C wallpaper.cfg (load
; address $0400); tools/mkx16app.py sdcard puts it on a disk.

.include "const.inc"
.include "geossym.inc"
.include "jumptab.inc"
.include "geosx16.inc"

MAXF    = 40                    ; files listed
NLEN    = 40                    ; a name: up to 39 characters and a 0
PAGE    = 7                     ; files a menu page
MTOP    = 32
MLEFT   = 16
MRIGHT  = 250
LFN_DIR = 12
LFN_IN  = 12
LFN_OUT = 13
LFN_CMD = 14
LFN_CFG = 11
PGMAX   = 6000                  ; a geoWrite page: bytes at most
PGLINES = 50                    ;   lines (a long line counts as several)
LINEW   = 60                    ;   characters a line

; what a menu's items do (mode)
M_MAIN  = 0
M_SDF   = 1                     ; an SD card file to copy
M_DRV   = 2                     ; a drive (to copy to, or from)
M_GEOSF = 3                     ; a GEOS file to copy
M_FMT   = 4                     ; .CVT or .TXT
M_ACT   = 5                     ; what to do with an SD card file
M_MNT   = 6                     ; which drive gets a disk image

.segment "CODE"

Start:
	ldx #3                  ; GEOS-X16, version 3 or more?
@s:	lda X16_SIG,x
	cmp sig,x
	beq :+
	jmp NotX16
:	dex
	bpl @s
	lda X16_VER
	cmp #3
	bcc NotX16
	lda curDrive
	sta home
	stz depth
	stz path
	stz pg
	jmp Main
NotX16:	lda #<dlg_nox16
	ldx #>dlg_nox16
	jsr Box
	jmp EnterDeskTop

; ------------------------------------------------------------ the main menu
Main:
	jsr Drives
	jsr SdList
	jsr Pg7                 ; (the page shown still there?)
	cmp nf
	bcc Window
	stz pg

; the window: the folder's files and folders, a page at a time
Window:
	jsr Title
	lda #<hbuf
	ldx #>hbuf
	jsr Screen
	stz ni
	jsr Pg7                 ; first: pg * 7
	sta fi
@it:	lda fi
	cmp nf
	bcs @more
	lda ni
	cmp #PAGE
	bcs @more
	jsr EntText             ; "NAME/" or "NAME  (12K)" -> item ni
	ldx ni
	lda fi
	sta ifile,x
	jsr Action
	inc ni
	inc fi
	bra @it
@more:	lda nf
	cmp #PAGE+1
	bcc @up
	lda #<t_more
	ldx #>t_more
	ldy #$FE
	jsr Item
@up:	lda depth
	beq @here
	lda #<t_up
	ldx #>t_up
	ldy #$FD
	jsr Item
@here:	lda #<t_here
	ldx #>t_here
	ldy #$FC
	jsr Item
	jsr IsSdC                 ; (drive C the SD card's folder: save it back)
	bcs :+
	lda #<t_sync
	ldx #>t_sync
	ldy #$FA
	jsr Item
	bra :++
:	lda #<t_sdc
	ldx #>t_sdc
	ldy #$FB
	jsr Item
:
	lda #<t_quit
	ldx #>t_quit
	ldy #$FF
	jsr Item
	lda #M_MAIN
	ldx #MTOP
	jmp Show

; the window's line: "SD card:  /GAMES/WORK" (its folders' path)
Title:
	ldx #0
:	lda h_sd,x
	sta hbuf,x
	beq :+
	inx
	bra :-
:	ldy #0
	lda #'/'
	sta hbuf,x
	inx
:	lda path,y
	sta hbuf,x
	beq :+
	inx
	iny
	cpx #60
	bcc :-
	stz hbuf,x
:	rts

; entry fi's text -> item ni (r1): a folder "   NAME/", a file "   NAME  (12K)"
EntText:
	jsr ItemPtr
	lda fi
	jsr NamePtr
	ldy #0
	lda #' '
	sta (r1),y
	iny
	sta (r1),y
	iny
	jsr Append
	ldx fi
	lda isdir,x
	beq @f
	lda #'/'
	sta (r1),y
	iny
	lda #0
	sta (r1),y
	rts
@f:	sty ey
	jsr SizeTxt             ; "  (12K)" -> sbuf
	lda #<sbuf
	sta r2L
	lda #>sbuf
	sta r2H
	ldy ey
	jmp Append

; entry fi's size -> sbuf: "  (NK)", N = its 256-byte blocks / 4, rounded up
SizeTxt:
	ldx fi
	lda blk_l,x
	clc
	adc #3
	sta r3L
	lda blk_h,x
	adc #0
	sta r3H
	lsr r3H
	ror r3L
	lsr r3H
	ror r3L
	ldx #0
	lda #' '
	sta sbuf
	sta sbuf+1
	lda #'('
	sta sbuf+2
	ldx #3
	stz q                   ; (a digit written: the rest too)
	ldy #4
@dg:	stz dgt
@sb:	lda r3L                 ; r3 -= 10^y while it can
	sec
	sbc p10l,y
	pha
	lda r3H
	sbc p10h,y
	bcc @nx
	sta r3H
	pla
	sta r3L
	inc dgt
	bra @sb
@nx:	pla
	cpy #0                  ; (the last digit always)
	beq :+
	lda dgt
	ora q
	beq @sk
:	lda dgt
	ora #'0'
	sta sbuf,x
	inx
	sta q
@sk:	dey
	bpl @dg
	lda #'K'
	sta sbuf,x
	inx
	lda #')'
	sta sbuf,x
	inx
	stz sbuf,x
	rts
p10l:	.byte <1, <10, <100, <1000, <10000
p10h:	.byte >1, >10, >100, >1000, >10000

; a pick in the window: an entry, $FE more, $FD up, $FC copy here, $FF quit
DoMain:
	cmp #$FF
	bne :+
	jmp Quit
:	cmp #$FE
	bne :++
	inc pg
	jsr Pg7
	cmp nf
	bcc :+
	stz pg
:	jmp Window
:	cmp #$FD
	bne :+
	jsr CdUp
	stz pg
	jmp Main
:	cmp #$FC
	bne :+
	jmp ToSD
:	cmp #$FB
	bne :+
	jmp SdDrive
:	cmp #$FA
	bne :+
	jmp Sync
:	sta pick
	tax
	lda isdir,x
	beq :+
	jmp Into
:	jmp FileAct

ToSD:
	stz dir
	jmp DriveMenu

; ----------------------------------------------------------------- menus
; the files (names) as a menu, a page at a time
FileMenu:
	lda #<h_sdf
	ldx #>h_sdf
	ldy dir
	bne :+
	lda #<h_geosf
	ldx #>h_geosf
:	jsr Screen
	stz ni
	lda pg                  ; first: pg * 10
	asl a
	sta fi
	asl a
	asl a
	clc
	adc fi
	sta fi
@it:	lda fi
	cmp nf
	bcs @more
	lda ni
	cmp #PAGE
	bcs @more
	lda fi
	jsr NamePtr
	lda r2L
	ldx r2H
	ldy fi
	jsr Item
	inc fi
	bra @it
@more:	lda nf
	cmp #PAGE+1
	bcc @q
	lda #<t_more
	ldx #>t_more
	ldy #$FE
	jsr Item
@q:	lda #<t_back
	ldx #>t_back
	ldy #$FF
	jsr Item
	lda dir
	bne :+
	lda #M_GEOSF
	bra @sh
:	lda #M_SDF
@sh:	ldx #MTOP
	jmp Show

; an SD card file (dir 1) or a GEOS file (dir 0) picked: A = its number
DoFile:
	cmp #$FF
	bne :+
	jmp Main
:	cmp #$FE
	bne @f
	inc pg                  ; More...
	lda pg
	asl a
	sta fi
	asl a
	asl a
	clc
	adc fi
	cmp nf
	bcc :+
	stz pg
:	jmp FileMenu
@f:	sta pick
	lda dir
	bne :+
	jmp GeosPicked
:	jmp DriveMenu           ; from the SD card: to which drive?

; the drives there (the images in them, call 11)
DriveMenu:
	lda #<h_to
	ldx #>h_to
	ldy dir
	bne :+
	lda #<h_from
	ldx #>h_from
:	jsr Screen
	stz ni
	stz di
@d:	ldx di
	lda cur_l,x
	sta r2L
	lda cur_h,x
	sta r2H
	lda (r2)
	beq @nd
	jsr ItemPtr             ; "Drive A  (NAME)"
	ldy #0
	lda #<t_drive
	sta r2L
	lda #>t_drive
	sta r2H
	jsr Append
	lda di
	clc
	adc #'A'
	dey
	sta (r1),y
	iny
	lda #<t_open
	sta r2L
	lda #>t_open
	sta r2H
	jsr Append
	ldx di
	lda cur_l,x
	sta r2L
	lda cur_h,x
	sta r2H
	jsr Append
	lda #')'
	sta (r1),y
	iny
	lda #0
	sta (r1),y
	ldx ni
	lda di
	sta ifile,x
	jsr Action
	inc ni
@nd:	inc di
	lda di
	cmp #3
	bne @d
	lda #<t_back
	ldx #>t_back
	ldy #$FF
	jsr Item
	lda #M_DRV
	ldx #MTOP
	jmp Show

; a drive picked (A = 0-2)
DoDrive:
	cmp #$FF
	bne :+
	jmp Main
:	clc
	adc #8
	sta drv
	jsr UseDrive
	bcc :+
	jmp Failed
:	lda dir
	beq @list
	jmp CopyIn              ; SD card -> this drive
@list:	jsr GeosList            ; this drive -> SD card: which file?
	lda nf
	bne :+
	lda #<dlg_nogeos
	ldx #>dlg_nogeos
	jsr Box
	jmp Main
:	stz pg
	jmp FileMenu

; a GEOS file picked to copy out: a geoWrite document can go as .TXT too
GeosPicked:
	jsr IsWrite
	bcs @cvt
	lda #<h_fmt
	ldx #>h_fmt
	jsr Screen
	stz ni
	lda #<t_cvt
	ldx #>t_cvt
	ldy #0
	jsr Item
	lda #<t_txt
	ldx #>t_txt
	ldy #1
	jsr Item
	lda #<t_back
	ldx #>t_back
	ldy #$FF
	jsr Item
	lda #M_FMT
	ldx #MTOP
	jmp Show
@cvt:	lda #0
DoFmt:	cmp #$FF
	bne :+
	jmp Main
:	cmp #1
	bne :+
	jmp OutTxt
:	jmp OutCvt

; the menu: ni items (text pointers and picks set by Item), mode A, top X
Show:
	sta mode
	stx menu
	lda ni
	asl a                   ; * 14 = * 16 - * 2
	asl a
	asl a
	asl a
	sec
	sbc ni
	sbc ni
	clc
	adc menu
	sta menu+1
	lda #<MLEFT
	sta menu+2
	lda #>MLEFT
	sta menu+3
	lda #<MRIGHT
	sta menu+4
	lda #>MRIGHT
	sta menu+5
	lda ni
	ora #VERTICAL
	sta menu+6
	lda #<menu
	sta r0L
	lda #>menu
	sta r0H
	lda #0
	jmp DoMenu

; an item: the text at A/X ("  " before it), pick Y
Item:
	sta r2L
	stx r2H
	phy
	jsr ItemPtr
	ldy #0
	lda #' '
	sta (r1),y
	iny
	sta (r1),y
	iny
	jsr Append
	ply
	ldx ni
	tya
	sta ifile,x
	jsr Action
	inc ni
	rts

; r1 = item ni's text
ItemPtr:
	lda ni
	ldx #<items
	ldy #>items
	jmp Mul40

; menu entry ni: its text (r1), MENU_ACTION, Pick0 + ni * 3
Action:
	lda ni
	asl a
	asl a
	clc
	adc ni
	tax
	lda r1L
	sta menu+7,x
	lda r1H
	sta menu+8,x
	lda #MENU_ACTION
	sta menu+9,x
	lda ni
	asl a
	adc ni
	clc
	adc #<Pick0
	sta menu+10,x
	lda #>Pick0
	adc #0
	sta menu+11,x
	rts

Pick0:	lda #0
	.byte $2C
Pick1:	lda #1
	.byte $2C
Pick2:	lda #2
	.byte $2C
Pick3:	lda #3
	.byte $2C
Pick4:	lda #4
	.byte $2C
Pick5:	lda #5
	.byte $2C
Pick6:	lda #6
	.byte $2C
Pick7:	lda #7
	.byte $2C
Pick8:	lda #8
	.byte $2C
Pick9:	lda #9
	.byte $2C
Pick10:	lda #10
	.byte $2C
Pick11:	lda #11
	nop
	tax
	lda ifile,x
	pha
	jsr GotoFirstMenu
	pla
	ldx mode
	bne :+
	jmp DoMain
:	cpx #M_ACT
	bne :+
	jmp DoAct
:	cpx #M_MNT
	bne :+
	jmp DoMnt
:	cpx #M_DRV
	bne :+
	jmp DoDrive
:	cpx #M_FMT
	bne :+
	jmp DoFmt
:	jmp DoFile

Quit:	jsr GoHome              ; (geosx16.bin's folder: GEOS-X16's files)
	lda home                ; (the drive it started on)
	jsr SetDevice
	jmp EnterDeskTop

; the background, the title, and the line of help at A/X
Screen:
	pha
	phx
	jsr i_GraphicsString
	.byte NEWPATTERN, 0
	.byte MOVEPENTO
	.word 0
	.byte 0
	.byte RECTANGLETO
	.word 319
	.byte 199
	.byte NEWPATTERN, 1
	.byte MOVEPENTO
	.word 0
	.byte 0
	.byte RECTANGLETO
	.word 319
	.byte 15
	.byte 0
	jsr i_PutString
	.word 100
	.byte 11
	.byte BOLDON, "GEOS-X16 SD Card", PLAINTEXT, 0
	plx
	pla
Line26:	sta r0L
	stx r0H
	lda #26
	sta r1H
	lda #<MLEFT
	sta r11L
	lda #>MLEFT
	sta r11H
	jmp PutString

Hex:	cmp #10
	bcc :+
	adc #'A'-'0'-10-1
:	adc #'0'
	rts

; a dialog box (A/X)
Box:	sta r0L
	stx r0H
	jmp DoDlgBox

; the result: done (C = 0) or failed, then the main menu
Done:	lda batch
	beq :+
	jmp BOk
:	lda #<dlg_done
	ldx #>dlg_done
	jsr Box
	jmp Quit0
Failed:	lda batch
	beq :+
	jmp BBad
:	lda err                 ; (its error number, in hex)
	lsr a
	lsr a
	lsr a
	lsr a
	jsr Hex
	sta f_code
	lda err
	and #15
	jsr Hex
	sta f_code+1
	lda #<dlg_fail
	ldx #>dlg_fail
	jsr Box
Quit0:	lda home
	jsr SetDevice
	jsr OpenDisk
	jmp Main

; ---------------------------------------------------------------- the data
; the image in each drive now (call 11)
Drives:
	ldx #0
@d:	stx di
	lda cur_l,x
	sta r0L
	lda cur_h,x
	sta r0H
	txa
	clc
	adc #8
	tax
	lda #X16C_DRVNAME
	jsr X16_CALL
	ldx di
	inx
	cpx #3
	bne @d
	rts

; GEOS drive drv, its disk open.  C = 1: no
UseDrive:
	lda drv
	jsr SetDevice
	txa
	bne @no
	jsr OpenDisk
	txa
	bne @no
	clc
	rts
@no:	stx err
	sec
	rts

; the folder's files and folders (the directory, as a BASIC listing: per
; line a link, a size in 256-byte blocks, the text with the name in quotes
; and the type after it ("DIR": a folder), 0) -> names, isdir, blk_l/h
SdList:
	stz nf
	lda #1
	ldx #<dname
	ldy #>dname
	X16K X16K_SETNAM
	lda #LFN_DIR
	ldx #8
	ldy #0
	X16K X16K_SETLFS
	X16K X16K_OPEN
	bcc :+
	jmp @cl
:	ldx #LFN_DIR
	X16K X16K_CHKIN
	jsr SByte               ; the load address
	jsr SByte
	stz ln
@line:	jsr SByte               ; the link: 0 0 = the end
	sta lk
	jsr SByte
	ora lk
	bne :+
	jmp @end
:	lda st
	beq :+
	jmp @end
:	jsr SByte               ; the size
	ldx nf
	sta blk_l,x
	jsr SByte
	ldx nf
	sta blk_h,x
	stz q
	stz ltl
	lda nf
	jsr NamePtr
	ldy #0
@ch:	sty ny
	jsr SByte
	ldy ny
	cmp #0
	beq @eol
	ldx st
	beq :+
	jmp @end
:	cmp #'"'
	bne @c
	inc q
	bra @ch
@c:	ldx q
	cpx #1
	bne @t
	cpy #NLEN-1
	bcs @ch
	sta (r2),y
	iny
	bra @ch
@t:	cpx #2                  ; after the name: its type
	bne @ch
	cmp #' '
	beq @ch
	ldx ltl
	cpx #3
	bcs @ch
	sta ltype,x
	inc ltl
	bra @ch
@eol:	lda #0
	sta (r2),y
	inc ln
	lda ln
	cmp #1
	beq @ln                 ; (the disk's name)
	cpy #0
	beq @ln
	ldy #0                  ; "." and "..": no
	lda (r2),y
	cmp #'.'
	bne @ok
	iny
	lda (r2),y
	beq @ln
	cmp #'.'
	bne @ok
	iny
	lda (r2),y
	bne @ok
@ln:	jmp @line
@ok:	ldy #0                  ; (GEOSSD.LST: the folder-as-drive list, not shown)
:	lda (r2),y
	cmp n_lst,y
	bne @ok2
	iny
	cmp #0
	bne :-
	jmp @line
@ok2:	ldx nf
	stz isdir,x
	lda ltl
	cmp #3
	bne @kp
	lda ltype
	cmp #'D'
	bne @kp
	lda ltype+1
	cmp #'I'
	bne @kp
	lda ltype+2
	cmp #'R'
	bne @kp
	inc isdir,x
@kp:	inc nf
	lda nf
	cmp #MAXF
	bcs @end
	jmp @line
@end:	X16K X16K_CLRCHN
@cl:	lda #LFN_DIR
	X16K X16K_CLOSE
	rts

; ------------------------------------------------- a file: what to do?
FileAct:
	lda pick
	sta fi
	jsr NamePtr             ; the line: "NAME  (12K):"
	ldy #0
:	lda (r2),y
	sta hbuf,y
	beq :+
	iny
	bra :-
:	sty ey
	jsr SizeTxt
	ldx #0
	ldy ey
:	lda sbuf,x
	sta hbuf,y
	beq :+
	inx
	iny
	bra :-
:	lda #':'
	sta hbuf,y
	lda #0
	sta hbuf+1,y
	lda #<hbuf
	ldx #>hbuf
	jsr Screen
	stz ni
	jsr Kind
	sta kind
	beq @rn                 ; (another kind: rename, delete)
	cmp #3
	bcs @nc
	lda #<t_cpy             ; .CVT, .TXT
	ldx #>t_cpy
	ldy #1
	jsr Item
	bra @rn
@nc:	cmp #5
	bcs @nd
	lda #<t_mnt             ; .D81, .D64
	ldx #>t_mnt
	ldy #2
	jsr Item
	bra @rn
@nd:	bne @rn
	lda #<t_wall            ; .BMX
	ldx #>t_wall
	ldy #3
	jsr Item
@rn:	lda #<t_ren
	ldx #>t_ren
	ldy #4
	jsr Item
	lda #<t_del
	ldx #>t_del
	ldy #5
	jsr Item
	lda #<t_back
	ldx #>t_back
	ldy #$FF
	jsr Item
	lda #M_ACT
	ldx #MTOP
	jmp Show

DoAct:
	cmp #1
	bne :+
	lda #1                  ; copy onto a GEOS disk
	sta dir
	jmp DriveMenu
:	cmp #2
	bne :+
	jmp MntMenu
:	cmp #3
	bne :+
	jmp SetWall
:	cmp #4
	bne :+
	jmp Rename
:	cmp #5
	bne :+
	jmp Delete
:	jmp Window

; file pick's kind: 1 .CVT, 2 .TXT, 3 .D81, 4 .D64, 5 .BMX, 0 another
Kind:
	lda pick
	jsr NamePtr
	ldy #0
:	lda (r2),y
	beq :+
	iny
	bra :-
:	cpy #5
	bcc @no
	dey                     ; the last three letters -> e3 (upper case)
	ldx #2
:	lda (r2),y
	jsr Upper
	sta e3,x
	dey
	dex
	bpl :-
	lda (r2),y
	cmp #'.'
	bne @no
	ldx #0
@k:	lda kinds,x
	beq @no
	cmp e3
	bne @n
	lda kinds+1,x
	cmp e3+1
	bne @n
	lda kinds+2,x
	cmp e3+2
	bne @n
	lda kinds+3,x
	rts
@n:	inx
	inx
	inx
	inx
	bra @k
@no:	lda #0
	rts
kinds:	.byte "CVT", 1, "TXT", 2, "D81", 3, "D64", 4, "BMX", 5, 0

Upper:	cmp #'a'
	bcc :+
	cmp #'z'+1
	bcs :+
	and #$DF
:	rts

; ---------------------------------------------------------------- folders
; into folder pick: CD:NAME, and its name onto path
Into:
	lda pick
	jsr NamePtr
	ldy #0
:	lda (r2),y
	sta cmd+3,y
	beq :+
	iny
	bra :-
:	tya
	clc
	adc #3
	jsr CdCmd
	ldx #0                  ; path: + "/" + NAME
:	lda path,x
	beq :+
	inx
	bra :-
:	lda depth
	beq @c
	lda #'/'
	sta path,x
	inx
@c:	ldy #3
:	lda cmd,y
	sta path,x
	beq :+
	inx
	iny
	cpx #39
	bcc :-
	stz path,x
:	inc depth
	stz pg
	jmp Main

; up a folder: CD:<left arrow>, the path's last part off
CdUp:	lda depth
	beq @x
	lda #$5F                ; (the left arrow: the folder above)
	sta cmd+3
	lda #4
	jsr CdCmd
	dec depth
	ldx #$FF
	ldy #0
:	inx
	lda path,x
	beq :+
	cmp #'/'
	bne :-
	txa
	tay
	bra :-
:	lda #0
	sta path,y
@x:	rts

; back to geosx16.bin's folder
GoHome:
	lda depth
	beq :+
	jsr CdUp
	bra GoHome
:	stz path
	rts

; "CD:" + cmd+3..., A long
CdCmd:
	pha
	lda #'C'
	sta cmd
	lda #'D'
	sta cmd+1
	lda #':'
	sta cmd+2
	pla
; the drive command at cmd (A long); A = its status's first digit
Cmd:
	ldx #<cmd
	ldy #>cmd
	X16K X16K_SETNAM
	lda #LFN_CMD
	ldx #8
	ldy #15
	X16K X16K_SETLFS
	X16K X16K_OPEN
	ldx #LFN_CMD
	X16K X16K_CHKIN
	X16K X16K_CHRIN
	pha
@d:	X16K X16K_READST
	bne @de
	X16K X16K_CHRIN
	cmp #13
	bne @d
@de:	X16K X16K_CLRCHN
	lda #LFN_CMD
	X16K X16K_CLOSE
	pla
	rts

; pick's name as a path from geosx16.bin's folder -> mname: "/GAMES/:WORK.D81"
; (in geosx16.bin's folder: just the name)
MName:
	ldx #0
	lda depth
	beq @nm
	lda #'/'
	sta mname
	inx
	ldy #0
:	lda path,y
	beq :+
	sta mname,x
	inx
	iny
	bra :-
:	lda #'/'
	sta mname,x
	inx
	lda #':'
	sta mname,x
	inx
@nm:	stx ey                  ; (NamePtr: X goes)
	lda pick
	jsr NamePtr
	ldx ey
	ldy #0
:	lda (r2),y
	sta mname,x
	beq :+
	inx
	iny
	cpx #79
	bcc :-
	stz mname,x
:	rts

; --------------------------------------------- a disk image into a drive
MntMenu:
	jsr MName
	ldx #0                  ; in a drive already?
@a:	stx di
	lda cur_l,x
	sta r3L
	lda cur_h,x
	sta r3H
	ldy #0
	lda (r3),y
	beq @na
@c:	lda mname,y
	jsr Upper
	sta q
	lda (r3),y
	jsr Upper
	cmp q
	bne @na
	lda mname,y
	bne :+
	jmp @al
:	iny
	bne @c
@na:	ldx di
	inx
	cpx #3
	bne @a
	lda #<h_mnt
	ldx #>h_mnt
	jsr Screen
	stz ni
	stz di
@d:	ldx di
	lda cur_l,x
	sta r2L
	lda cur_h,x
	sta r2H
	lda (r2)
	beq @nd
	jsr ItemPtr             ; "Drive A  (now NAME)"
	ldy #0
	lda #<t_drive
	sta r2L
	lda #>t_drive
	sta r2H
	jsr Append
	lda di
	clc
	adc #'A'
	dey
	sta (r1),y
	iny
	lda #<t_now
	sta r2L
	lda #>t_now
	sta r2H
	jsr Append
	ldx di
	lda cur_l,x
	sta r2L
	lda cur_h,x
	sta r2H
	jsr Append
	lda #')'
	sta (r1),y
	iny
	lda #0
	sta (r1),y
	ldx ni
	lda di
	sta ifile,x
	jsr Action
	inc ni
@nd:	inc di
	lda di
	cmp #3
	bne @d
	lda #<t_back
	ldx #>t_back
	ldy #$FF
	jsr Item
	lda #M_MNT
	ldx #MTOP
	jmp Show
@al:	lda di
	clc
	adc #'A'
	sta t_alr_d
	lda #<dlg_already
	ldx #>dlg_already
	jsr Box
	jmp Window

DoMnt:
	cmp #$FF
	bne :+
	jmp Window
:	sta di
	jsr GoHome              ; (the name is a path from there)
	lda #<mname
	sta r0L
	lda #>mname
	sta r0H
	lda di
	clc
	adc #8
	tax
	lda #X16C_MOUNT
	jsr X16_CALL
	bcs @err
	jsr Drives              ; kept for next time (GEOSDRV.CFG)
	jsr SaveCfg
	lda home
	jsr SetDevice
	jmp EnterDeskTop        ; the deskTop reads it
@err:	tax
	dex
	cpx #4
	bcc :+
	ldx #0
:	lda m_err_l,x
	sta f_why
	lda m_err_h,x
	sta f_why+1
	lda #<dlg_mfail
	ldx #>dlg_mfail
	jsr Box
	stz pg
	jmp Main

; the drives' images -> GEOSDRV.CFG (a line each; GEOS-X16 opens them when
; it starts)
SaveCfg:
	lda #w_cfg_n
	ldx #<w_cfg
	ldy #>w_cfg
	X16K X16K_SETNAM
	lda #LFN_CFG
	ldx #8
	ldy #LFN_CFG
	X16K X16K_SETLFS
	X16K X16K_OPEN
	bcs @x
	ldx #LFN_CFG
	X16K X16K_CHKOUT
	stz di
@d:	ldx di
	lda cur_l,x
	sta r3L
	lda cur_h,x
	sta r3H
	ldy #0
@c:	lda (r3),y
	beq @e
	sty ny
	X16K X16K_CHROUT
	ldx di
	lda cur_l,x
	sta r3L
	lda cur_h,x
	sta r3H
	ldy ny
	iny
	bra @c
@e:	lda #13
	X16K X16K_CHROUT
	inc di
	lda di
	cmp #3
	bne @d
	X16K X16K_CLRCHN
@x:	lda #LFN_CFG
	X16K X16K_CLOSE
	rts

; ------------------------------------------------- a .BMX: the wallpaper
SetWall:
	jsr MName
	jsr GoHome
	lda #<mname
	sta r0L
	lda #>mname
	sta r0H
	lda #X16C_SETWALL
	jsr X16_CALL
	bcs @no
	lda home
	jsr SetDevice
	jmp EnterDeskTop        ; the deskTop shows it
@no:	lda #<dlg_wfail
	ldx #>dlg_wfail
	jsr Box
	stz pg
	jmp Main

; ------------------------------------------------- rename, delete
Rename:
	lda pick
	jsr NamePtr
	ldy #0
:	lda (r2),y
	sta newn,y
	beq :+
	iny
	cpy #NLEN-1
	bcc :-
	lda #0
	sta newn,y
:	lda #<newn
	sta r5L
	lda #>newn
	sta r5H
	lda #<dlg_ren
	ldx #>dlg_ren
	jsr Box
	lda r0L
	cmp #CANCEL
	beq @x
	lda newn
	beq @x
	ldx #0                  ; "R:NEW=OLD"
	lda #'R'
	sta cmd
	lda #':'
	sta cmd+1
	ldx #2
	ldy #0
:	lda newn,y
	beq :+
	sta cmd,x
	inx
	iny
	bra :-
:	lda #'='
	sta cmd,x
	inx
	stx ey                  ; (NamePtr: X goes)
	lda pick
	jsr NamePtr
	ldx ey
	ldy #0
:	lda (r2),y
	beq :+
	sta cmd,x
	inx
	iny
	bra :-
:	txa
	jsr Cmd
	cmp #'0'
	beq @x
	lda #<dlg_rfail
	ldx #>dlg_rfail
	jsr Box
@x:	jmp Main

Delete:
	lda pick
	jsr NamePtr
	lda r2L
	sta r6L
	lda r2H
	sta r6H
	lda #<dlg_del
	ldx #>dlg_del
	jsr Box
	lda r0L
	cmp #YES
	bne @x
	lda #'S'                ; "S:NAME"
	sta cmd
	lda #':'
	sta cmd+1
	lda pick
	jsr NamePtr
	ldx #2
	ldy #0
:	lda (r2),y
	beq :+
	sta cmd,x
	inx
	iny
	bra :-
:	txa
	jsr Cmd
@x:	jmp Main

; ------------------------------------------- the folder as drive C
; GEOSSD.D81 (in geosx16.bin's folder) goes in drive C, emptied, and every
; file of the folder is copied onto it: a .CVT as its GEOS file, a .TXT as
; a geoWrite document, any other file as a plain (non-GEOS) file.  What came
; from where goes in GEOSSD.CFG, for the way back (drive C's image before,
; the folder, then a line a file: its SD name, its GEOS name, its date and
; size as they were).
Pg7:	lda pg                  ; A = pg * 7
	asl a
	asl a
	asl a
	sec
	sbc pg
	rts

SdDrive:
	jsr Drives
	ldy #0                  ; drive C's image (kept: put back later)
@cn:	lda cur2,y
	jsr Upper
	cmp n_ssd,y
	bne @ot
	lda cur2,y
	beq @same               ; (GEOSSD.D81 there already: as it was)
	iny
	bne @cn
@ot:	ldy #0
:	lda cur2,y
	sta prevc,y
	beq @same
	iny
	cpy #NLEN-1
	bcc :-
	lda #0
	sta prevc,y
@same:	ldy #0                  ; the folder
:	lda path,y
	sta spath,y
	beq :+
	iny
	bra :-
:	lda depth
	sta sdepth
	jsr GoHome
	lda #<n_ssd
	sta r0L
	lda #>n_ssd
	sta r0H
	ldx #10
	lda #X16C_MOUNT
	jsr X16_CALL
	bcc :+
	jmp SdMErr
:	jsr Drives              ; (kept for next time: GEOSDRV.CFG)
	jsr SaveCfg
	jsr CdPath              ; back into the folder
	jsr Drives
	jsr SdList
	lda #10
	sta drv
	jsr UseDrive
	bcc :+
	jmp SdDErr
:	jsr Empty
	stz nimp
	stz nskip
	stz bi
	lda #<ImpOk
	sta bok_v
	lda #>ImpOk
	sta bok_v+1
	lda #<ImpBad
	sta bbad_v
	lda #>ImpBad
	sta bbad_v+1
	lda #1
	sta batch
BLoop:	lda bi
	cmp nf
	bcs SdEnd
	tax
	lda isdir,x
	bne BSkip
	lda #<curDirHead        ; (no room for it: not tried)
	sta r5L
	lda #>curDirHead
	sta r5H
	jsr CalcBlksFree        ; r4 = blocks free
	ldx bi
	lda r4L
	cmp blk_l,x
	lda r4H
	sbc blk_h,x
	bcs :+
	inc nskip
	bra BSkip
:	txa
	sta pick
	tsx
	stx bsp
	jmp CopyIn
BOk:	ldx bsp
	txs
	jmp (bok_v)
BBad:	ldx bsp
	txs
	jmp (bbad_v)
ImpOk:	jsr Record
	bra BSkip
ImpBad:	inc nskip
BSkip:	inc bi
	bra BLoop
SdEnd:	stz batch
	jsr SaveLst             ; (in the folder: GEOSSD.LST)
	jsr GoHome
	jsr SaveHome            ; (GEOSSD.CFG)
	lda nimp                ; "N files on drive C; M not (too big, ...)"
	jsr Dec8
	stx s_n
	sty s_n+1
	sta s_n+2
	lda nskip
	jsr Dec8
	stx s_m
	sty s_m+1
	sta s_m+2
	lda #<dlg_sdc
	ldx #>dlg_sdc
	jsr Box
	lda home
	jsr SetDevice
	jmp EnterDeskTop
SdMErr:	lda #<dlg_nossd
	ldx #>dlg_nossd
	jsr Box
	jsr CdPath
	jmp Main
SdDErr:	jsr GoHome
	stz pg
	jmp Main

; A -> three digits: X hundreds, Y tens, A ones (leading zeros as spaces)
Dec8:	ldx #'0'-1
:	inx
	sec
	sbc #100
	bcs :-
	adc #100
	ldy #'0'-1
:	iny
	sec
	sbc #10
	bcs :-
	adc #'0'+10
	cpx #'0'
	bne :+
	ldx #' '
	cpy #'0'
	bne :+
	ldy #' '
:	rts

; back into spath (sdepth folders) from geosx16.bin's folder
CdPath:
	ldx #0
@p:	lda spath,x
	beq @x
	ldy #3
@c:	lda spath,x
	beq @g
	cmp #'/'
	beq @g
	sta cmd,y
	inx
	iny
	bra @c
@g:	lda #0
	sta cmd,y
	phx
	tya
	jsr CdCmd
	plx
	lda spath,x
	beq @x
	inx
	bra @p
@x:	ldy #0
:	lda spath,y
	sta path,y
	beq :+
	iny
	bra :-
:	lda sdepth
	sta depth
	rts

; every file off the disk in the drive
Empty:
	jsr $9030               ; Get1stDirEntry: r5 -> an entry
@l:	txa
	bne @x
	ldy #0
	lda (r5),y
	bne @del
	jsr $9033               ; GetNxtDirEntry
	cpy #0
	beq @l
@x:	rts
@del:	ldy #3                  ; its name -> gname, deleted
	ldx #0
:	lda (r5),y
	cmp #$A0
	beq :+
	sta gname,x
	iny
	inx
	cpx #16
	bne :-
:	stz gname,x
	lda #<gname
	sta r0L
	lda #>gname
	sta r0H
	jsr DeleteFile
	txa
	bne @x
	bra Empty

; the file just copied: its line for GEOSSD.CFG (rec: SD number, its GEOS
; name, its date, its size)
Record:
	lda nimp
	cmp #MAXF
	bcs @x
	jsr RecPtr
	ldy #0
	lda bi
	sta (r3),y
	iny
	ldx #0
:	lda gname,x
	sta (r3),y
	iny
	inx
	cpx #17
	bne :-
	ldx #0
:	lda ent+23,x            ; date (5), blocks (2)
	sta (r3),y
	iny
	inx
	cpx #7
	bne :-
	inc nimp
@x:	rts
RECSZ = 25
RecPtr:	sta r3L                 ; r3 = rec + A * 25
	stz r3H
	lda #RECSZ
	sta r4L
	stz r4H
	ldx #r3
	ldy #r4
	jsr BMult
	clc
	lda r3L
	adc #<rec
	sta r3L
	lda r3H
	adc #>rec
	sta r3H
	rts

; GEOSSD.CFG (in geosx16.bin's folder): drive C's image before, the folder
SaveHome:
	lda #w_sd_n
	ldx #<w_sd
	ldy #>w_sd
	jsr WOpen
	bcs @x
	lda #<prevc
	ldx #>prevc
	jsr OutStr
	lda #<spath
	ldx #>spath
	jsr OutStr
@x:	jmp WClose

; GEOSSD.LST (in the folder): a line a file: SDNAME, tab, GEOS NAME, tab,
; its date and size (7 bytes, 14 hex digits)
SaveLst:
	lda #w_lst_n
	ldx #<w_lst
	ldy #>w_lst
	jsr WOpen
	bcs @x
	stz bi
@r:	lda bi
	cmp nimp
	bcs @x
	jsr RecPtr
	ldy #0
	lda (r3),y
	jsr NamePtr             ; the SD name
	lda r2L
	ldx r2H
	jsr OutStr0
	lda #9
	jsr OutC
	lda bi
	jsr RecPtr
	clc
	lda r3L
	adc #1
	ldx r3H
	bcc :+
	inx
:	jsr OutStr0             ; the GEOS name
	lda #9
	jsr OutC
	lda bi
	jsr RecPtr
	clc                     ; the 7 bytes at rec + 18
	lda r3L
	adc #18
	sta r3L
	bcc :+
	inc r3H
:	jsr OutHex7
	inc bi
	bra @r
@x:	jmp WClose

; the 7 bytes at r3 as 14 hex digits, a return
OutHex7:
	ldy #0
@h:	sty ny
	lda (r3),y
	pha
	lsr a
	lsr a
	lsr a
	lsr a
	jsr Hex
	jsr OutC
	pla
	and #15
	jsr Hex
	jsr OutC
	ldy ny
	iny
	cpy #7
	bne @h
	lda #13
	jmp OutC

; open the file named at X/Y (A long) to write, as the output.  C = 1: no
WOpen:
	X16K X16K_SETNAM
	lda #LFN_CFG
	ldx #8
	ldy #LFN_CFG
	X16K X16K_SETLFS
	X16K X16K_OPEN
	bcs @x
	ldx #LFN_CFG
	X16K X16K_CHKOUT
@x:	rts
WClose:	X16K X16K_CLRCHN
	lda #LFN_CFG
	X16K X16K_CLOSE
	rts

; the string at A/X, then a return (OutStr) or not (OutStr0)
OutStr:	jsr OutStr0
	lda #13
	jmp OutC
OutStr0:
	sta r2L
	stx r2H
	ldy #0
:	lda (r2),y
	beq :+
	sty ey
	jsr OutC
	ldy ey
	iny
	bne :-
:	rts
OutC:	X16K X16K_CHROUT
	rts

; ---- any other file: a plain (non-GEOS) sequential file of its bytes
RawIn:
	ldx #29
:	stz ent,x
	dex
	bpl :-
	lda #$81                ; SEQ, closed
	sta ent
	lda pick                ; its name (16 at most)
	jsr NamePtr
	ldy #0
@n:	lda (r2),y
	beq @ne
	sta ent+3,y
	iny
	cpy #16
	bne @n
@ne:	lda #$A0
@pad:	cpy #16
	beq :+
	sta ent+3,y
	iny
	bra @pad
:	ldx #4                  ; today's date
:	lda year,x
	sta ent+23,x
	dex
	bpl :-
	jsr EntName
	bcc :+
	jmp CvtFail
:	jsr InitAlloc
	jsr SeqIn
	bcc :+
	jmp CvtFail
:	jmp NewEntry

; C = 0: drive C holds GEOSSD.D81
IsSdC:	ldy #0
@c:	lda cur2,y
	jsr Upper
	cmp n_ssd,y
	bne @no
	lda cur2,y
	beq @y
	iny
	bne @c
@no:	sec
	rts
@y:	clc
	rts

; ------------------------------------- drive C back to its folder
; GEOSSD.CFG: the folder; GEOSSD.LST there: what came from where.  Each file
; on drive C: in the list and as it was -> nothing; in the list, changed ->
; written over its SD file (a .CVT as a .CVT, a .TXT from the geoWrite
; document, any other as its bytes); not in the list -> a new SD file
; (NAME.CVT, a plain file as NAME).  In the list, not on drive C: deleted
; from the folder.  Then GEOSSD.LST anew.
Sync:
	jsr GoHome              ; (GEOSSD.CFG is there)
	jsr ReadHome            ; prevc, spath
	bcc :+
	jmp SyErr
:	lda spath               ; (no folder read: not that file)
	bne :+
	jmp SyErr
:	jsr CdPath
	lda #10
	sta drv
	jsr UseDrive
	bcc :+
	jmp SyErr
:	lda #1
	sta allf
	jsr GeosList            ; drive C's files -> names, ents (nf)
	stz allf
	ldx #MAXF-1
:	lda #$FF
	sta m_idx,x
	stz m_chg,x
	dex
	bpl :-
	stz ndel
	stz nchg
	stz nnew
	stz nl
	jsr LOpen               ; the list: each line
	bcs @lend
@ln:	jsr LLine
	bcs @lend
	jsr FindG               ; its GEOS name on drive C: X
	bcs @gone
	lda nl
	sta m_idx,x
	jsr SameStamp
	beq @nx
	lda #1
	sta m_chg,x
	inc nchg
	bra @nx
@gone:	ldx ndel
	lda nl
	sta del,x
	inc ndel
@nx:	inc nl
	bra @ln
@lend:	jsr LClose
	lda #1                  ; the deleted ones
	sta batch
	stz bi
@dl:	lda bi
	cmp ndel
	bcs @ch
	tax
	lda del,x
	jsr LGet                ; its SD name -> lsd
	bcs @dn
	lda #'S'
	sta cmd
	lda #':'
	sta cmd+1
	ldx #0
:	lda lsd,x
	sta cmd+2,x
	beq :+
	inx
	bra :-
:	txa
	clc
	adc #2
	jsr Cmd
@dn:	inc bi
	bra @dl
@ch:	lda #<SyNext            ; changed and new ones: written out
	sta bok_v
	sta bbad_v
	lda #>SyNext
	sta bok_v+1
	sta bbad_v+1
	stz bi
SyLoop:	lda bi
	cmp nf
	bcs SyDone
	sta pick
	tax
	lda m_idx,x
	cmp #$FF
	beq @new
	lda m_chg,x
	beq SyNext
	lda m_idx,x             ; changed: over its own SD file
	jsr LGet
	bcs SyNext
	jsr LsdName             ; -> fname, and its kind (Kind's numbers): A
	ldx #1
	stx fixn
	tsx
	stx bsp
	cmp #1
	bne :+
	jmp OutCvt
:	cmp #2
	bne :+
	jmp OutTxt
:	jmp OutRaw
@new:	inc nnew
	stz fixn
	tsx
	stx bsp
	lda pick                ; a GEOS file: NAME.CVT; a plain one: NAME
	jsr EntPtr
	ldy #19
	lda (r3),y
	beq :+
	jmp OutCvt
:	lda pick
	jsr NamePtr
	ldy #0
:	lda (r2),y
	sta fname,y
	beq :+
	iny
	bra :-
:	sty flen
	lda #1
	sta fixn
	jmp OutRaw
SyNext:	inc bi
	bra SyLoop
SyDone:	stz batch
	stz fixn
	jsr NewLst              ; GEOSSD.LST as drive C is now
	lda nchg
	jsr Dec8
	stx y_c
	sty y_c+1
	sta y_c+2
	lda nnew
	jsr Dec8
	stx y_n
	sty y_n+1
	sta y_n+2
	lda ndel
	jsr Dec8
	stx y_d
	sty y_d+1
	sta y_d+2
	lda #<dlg_sync
	ldx #>dlg_sync
	jsr Box
	lda r0L
	cmp #YES
	bne @keep
	jsr GoHome              ; drive C's own disk back in
	lda prevc
	beq @keep
	lda #<prevc
	sta r0L
	lda #>prevc
	sta r0H
	ldx #10
	lda #X16C_MOUNT
	jsr X16_CALL
	bcs @keep
	jsr Drives
	jsr SaveCfg
@keep:	jsr GoHome
	lda home
	jsr SetDevice
	jmp EnterDeskTop
SyErr:	lda #<dlg_syerr
	ldx #>dlg_syerr
	jsr Box
	jsr GoHome
	stz pg
	jmp Main

; a plain file pick (ents) -> the SD file fname: its bytes
OutRaw:
	lda #'W'
	jsr SdOpen
	bcc :+
	jmp Failed
:	lda pick
	jsr EntPtr
	ldy #1
	lda (r3),y
	sta r1L
	iny
	lda (r3),y
	sta r1H
	jsr ChainOut
	bcc :+
	jmp OutFail
:	jsr SdClose
	jmp Done

; lsd -> fname (flen); A = its kind (1 .CVT, 2 .TXT, 0 another)
LsdName:
	ldy #0
:	lda lsd,y
	sta fname,y
	beq :+
	iny
	bra :-
:	sty flen
	cpy #5
	bcc @o
	lda fname-4,y
	cmp #'.'
	bne @o
	lda fname-3,y
	jsr Upper
	tax
	lda fname-2,y
	jsr Upper
	sta q
	lda fname-1,y
	jsr Upper
	cpx #'C'
	bne @t
	cmp #'T'
	bne @o
	lda q
	cmp #'V'
	bne @o
	lda #1
	rts
@t:	cpx #'T'
	bne @o
	cmp #'T'
	bne @o
	lda q
	cmp #'X'
	bne @o
	lda #2
	rts
@o:	lda #0
	rts

; X = drive C's file named lgeos, not taken yet.  C = 1: none
FindG:
	ldx #0
@f:	cpx nf
	bcs @x
	lda m_idx,x
	cmp #$FF
	bne @n
	phx
	txa
	jsr NamePtr
	plx
	ldy #0
@c:	lda (r2),y
	cmp lgeos,y
	bne @n
	iny
	cmp #0
	bne @c
	clc
	rts
@n:	inx
	bra @f
@x:	sec
	rts

; Z = 1: drive C's file X has the list's date and size (lstamp)
SameStamp:
	phx
	txa
	jsr EntPtr
	plx
	ldy #23
@c:	lda (r3),y
	cmp lstamp-23,y
	bne @x
	iny
	cpy #30
	bne @c
	lda #0
@x:	rts

; GEOSSD.LST anew: drive C's files, each with its SD name (the old list's,
; or the new file's), its GEOS name, its date and size now
NewLst:
	lda #w_new_n
	ldx #<w_new
	ldy #>w_new
	jsr WOpen
	bcc :+
	jmp WClose
:	jsr WClose
	stz bi
@f:	lda bi
	cmp nf
	bcc :+
	jmp @done
:	tax
	lda m_idx,x             ; its SD name
	cmp #$FF
	beq @nw
	jsr LGet
	bra @have
@nw:	lda bi
	jsr EntPtr
	ldy #19
	lda (r3),y
	pha
	lda bi
	jsr NamePtr
	ldy #0
:	lda (r2),y
	sta lsd,y
	beq :+
	iny
	bra :-
:	pla
	beq @have
	ldx #0                  ; (+ ".CVT")
:	lda t_ecvt,x
	sta lsd,y
	beq @have
	iny
	inx
	bra :-
@have:	lda #w_app_n            ; one line onto GEOSSD.NEW
	ldx #<w_app
	ldy #>w_app
	jsr WOpen
	bcs @nx
	lda #<lsd
	ldx #>lsd
	jsr OutStr0
	lda #9
	jsr OutC
	lda bi
	jsr NamePtr
	lda r2L
	ldx r2H
	jsr OutStr0
	lda #9
	jsr OutC
	lda bi
	jsr EntPtr
	clc
	lda r3L
	adc #23
	sta r3L
	bcc :+
	inc r3H
:	jsr OutHex7
	jsr WClose
@nx:	inc bi
	jmp @f
@done:	lda #<c_dlst            ; GEOSSD.LST out, GEOSSD.NEW in its place
	ldx #>c_dlst
	ldy #0
:	lda c_dlst,y
	sta cmd,y
	beq :+
	iny
	bra :-
:	tya
	jsr Cmd
	ldy #0
:	lda c_ren,y
	sta cmd,y
	beq :+
	iny
	bra :-
:	tya
	jmp Cmd

; GEOSSD.CFG -> prevc, spath (sdepth).  C = 1: not there
ReadHome:
	lda #r_sd_n
	ldx #<r_sd
	ldy #>r_sd
	jsr ROpen
	bcs @x
	ldy #0
	jsr RLine
	sta q
	ldy #0
:	lda lbuf,y
	sta prevc,y
	beq :+
	iny
	bra :-
:	jsr RLine
	ldy #0
	stz sdepth
:	lda lbuf,y
	sta spath,y
	beq :+
	cmp #'/'
	bne @s
	inc sdepth
@s:	iny
	bra :-
:	lda spath
	beq :+
	inc sdepth
:	jsr RClose
	clc
@x:	rts

; the list (GEOSSD.LST, in the folder): open; a line -> lsd, lgeos, lstamp
; (C = 1: no more); line A's SD name -> lsd (C = 1: none); close
LOpen:	lda #r_lst_n
	ldx #<r_lst
	ldy #>r_lst
	jmp ROpen
LClose:	jmp RClose
LGet:	sta lg
	jsr LOpen
	bcs @x
@l:	jsr LLine
	bcs @c
	lda lg
	beq @c
	dec lg
	bra @l
@c:	php
	jsr RClose
	plp
@x:	rts
LLine:	jsr RLine
	lda lbuf
	bne :+
	sec
	rts
:	ldx #0                  ; SDNAME
	ldy #0
@a:	lda lbuf,x
	beq @bad
	cmp #9
	beq @ae
	sta lsd,y
	inx
	iny
	bra @a
@ae:	lda #0
	sta lsd,y
	inx
	ldy #0                  ; GEOS NAME
@b:	lda lbuf,x
	beq @bad
	cmp #9
	beq @be
	sta lgeos,y
	inx
	iny
	cpy #16
	bcc @b
@be:	lda #0
	sta lgeos,y
	inx
	ldy #0                  ; 14 hex digits
@h:	lda lbuf,x
	jsr HexV
	asl a
	asl a
	asl a
	asl a
	sta q
	lda lbuf+1,x
	jsr HexV
	ora q
	sta lstamp,y
	inx
	inx
	iny
	cpy #7
	bne @h
	clc
	rts
@bad:	sec
	rts
HexV:	cmp #'A'
	bcc :+
	sbc #'A'-10
	rts
:	and #15
	rts

; open the file named at X/Y (A long) to read, as the input.  C = 1: no
ROpen:
	X16K X16K_SETNAM
	lda #LFN_IN
	ldx #8
	ldy #LFN_IN
	X16K X16K_SETLFS
	X16K X16K_OPEN
	bcs @x
	ldx #LFN_IN
	X16K X16K_CHKIN
	X16K X16K_READST
	and #$BF                ; (anything but the end: not there)
	beq :+
	jsr RClose
	sec
	rts
:	clc
@x:	rts
RClose:	X16K X16K_CLRCHN
	lda #LFN_IN
	X16K X16K_CLOSE
	rts
; a line -> lbuf (0 at its end; empty: the end of the file)
RLine:	ldy #0
@c:	sty ey
	X16K X16K_READST
	bne @e
	X16K X16K_CHRIN
	ldy ey
	cmp #13
	beq @e2
	cmp #10
	beq @c
	sta lbuf,y
	iny
	cpy #120
	bcc @c
@e:	ldy ey
@e2:	lda #0
	sta lbuf,y
	rts

; the directory's next byte; st = the X16 KERNAL's status (not the end)
SByte:
	X16K X16K_CHRIN
	pha
	X16K X16K_READST
	and #$BF
	sta st
	pla
	rts

; name r2 (Y long): A = 1 ".CVT", 2 ".TXT", 0 neither (Z = 1)
ExtOf:
	cpy #5
	bcc @no
	dey
	lda (r2),y
	and #$DF
	tax
	dey
	lda (r2),y
	and #$DF
	sta q
	dey
	lda (r2),y
	and #$DF
	sta ny
	dey
	lda (r2),y
	cmp #'.'
	bne @no
	lda ny
	cmp #'C'
	bne @t
	lda q
	cmp #'V'
	bne @no
	cpx #'T'
	bne @no
	lda #1
	rts
@t:	cmp #'T'
	bne @no
	lda q
	cmp #'X'
	bne @no
	cpx #'T'
	bne @no
	lda #2
	rts
@no:	lda #0
	rts

; the GEOS files on the open disk (the directory from curDirHead's link):
; their directory entries (30 bytes) -> ents, names -> names
GeosList:
	stz nf
	lda curDirHead
	sta r1L
	lda curDirHead+1
	sta r1H
@blk:	lda r1L
	beq @x
	lda #<blk
	sta r4L
	lda #>blk
	sta r4H
	jsr GetBlock
	txa
	bne @x
	ldx #0
@e:	stx ei
	lda blk+2,x             ; a file there, with a GEOS header?
	beq @n
	lda allf                ; (every file: GEOS or not)
	bne :+
	lda blk+2+19,x
	beq @n
:
	lda nf
	jsr EntPtr              ; its entry -> ents
	ldx ei
	ldy #0
@c:	lda blk+2,x
	sta (r3),y
	inx
	iny
	cpy #30
	bne @c
	lda nf                  ; its name -> names
	jsr NamePtr
	ldx ei
	ldy #0
@nm:	lda blk+2+3,x
	cmp #$A0
	beq @nz
	sta (r2),y
	inx
	iny
	cpy #16
	bne @nm
@nz:	lda #0
	sta (r2),y
	inc nf
	lda nf
	cmp #MAXF
	bcs @x
@n:	lda ei
	clc
	adc #32
	tax
	bcc @e
	lda blk                 ; the next directory block
	sta r1L
	lda blk+1
	sta r1H
	bra @blk
@x:	rts

; C = 0: GEOS file pick is a geoWrite document ("Write Image" class)
IsWrite:
	lda pick
	jsr EntPtr
	ldy #19                 ; its header
	lda (r3),y
	sta r1L
	iny
	lda (r3),y
	sta r1H
	jsr GetHdr
	bcs @no
	ldy #10
@c:	lda hdr+$4D,y
	cmp t_wclass,y
	bne @no
	dey
	bpl @c
	clc
	rts
@no:	sec
	rts

; header block r1 -> hdr.  C = 1: failed
GetHdr:
	lda #<hdr
	sta r4L
	lda #>hdr
	sta r4H
	jsr GetBlock
	txa
	bne :+
	clc
	rts
:	stx err
	sec
	rts

; ===================================================== SD card -> GEOS disk
CopyIn:
	jsr SdName              ; the SD file's name -> fname
	lda #'R'
	jsr SdOpen
	bcc :+
	jmp Failed
:	lda pick
	jsr NamePtr
	ldy #0
@l:	lda (r2),y
	beq :+
	iny
	bra @l
:	jsr ExtOf
	cmp #2
	bne :+
	jmp TxtIn
:	cmp #1
	bne :+
	jmp CvtIn
:	jmp RawIn

; ---- a .CVT file: its directory entry and signature, its header, then the
; data (sequential), or the record table and the records (VLIR)
CvtIn:
	lda #<buf
	ldx #>buf
	ldy #254
	jsr SdRead
	cpy #254
	bne @bad
	ldy #20                 ; "formatted GEOS file" at 30 + 4
@s:	lda buf+34,y
	cmp t_sig,y
	bne @bad
	dey
	bpl @s
	ldx #29                 ; its directory entry
@e:	lda buf,x
	sta ent,x
	dex
	bpl @e
	jsr EntName             ; its name -> gname, and not there yet
	bcs @fail
	lda #<(hdr+2)             ; its header
	ldx #>(hdr+2)
	ldy #254
	jsr SdRead
	cpy #254
	bne @bad
	stz hdr
	lda #$FF
	sta hdr+1
	jsr InitAlloc
	jsr Alloc               ; the header block
	bcs @full
	lda r3L
	sta ent+19
	lda r3H
	sta ent+20
	lda #<hdr
	ldx #>hdr
	jsr Put
	bcs @fail
	lda ent+21
	beq @seq
	jsr VlirIn
	bcs @fail
	bra @dir
@seq:	jsr SeqIn
	bcs @fail
@dir:	jmp NewEntry
@bad:	lda #$80                ; (not a CVT file)
	sta err
	bra CvtFail
@fail:	bra CvtFail
@full:	bra CvtFull

; failed: the SD file closed, the BAM read again (nothing allocated stays)
CvtFull:
	lda #INSUFF_SPACE
	sta err
CvtFail:
	jsr SdClose
	jsr GetDirHead
	jmp Failed

; the rest of the SD file -> a chain; ent+1/2 = its first block
SeqIn:
	lda #<(blk+2)
	ldx #>(blk+2)
	ldy #254
	jsr SdRead
	sty cnt
	jsr Alloc
	bcs @full
	lda r3L
	sta ent+1
	lda r3H
	sta ent+2
@l:	lda r3L
	sta curT
	lda r3H
	sta curS
	lda #<(blk2+2)            ; the next part: is there one?
	ldx #>(blk2+2)
	ldy #254
	jsr SdRead
	sty cnt2
	cpy #0
	beq @last
	jsr Alloc
	bcs @full
	lda r3L
	sta blk
	lda r3H
	sta blk+1
	jsr PutCur
	bcs @x
	ldx #253                ; blk <- blk2
@c:	lda blk2+2,x
	sta blk+2,x
	dex
	cpx #$FF
	bne @c
	lda cnt2
	sta cnt
	bra @l
@last:	stz blk
	ldx cnt
	inx
	stx blk+1
	jmp PutCur
@full:	lda #INSUFF_SPACE
	sta err
	sec
@x:	rts

; blk -> block curT/curS (r3 kept: the next block)
PutCur:
	lda r3L
	pha
	lda r3H
	pha
	lda curT
	sta r3L
	lda curS
	sta r3H
	lda #<blk
	ldx #>blk
	jsr Put
	pla
	sta r3H
	pla
	sta r3L
	rts

; the record table, then each record as a chain; the index block
VlirIn:
	lda #<tab
	ldx #>tab
	ldy #254
	jsr SdRead
	cpy #254
	beq :+
	lda #$80
	sta err
	sec
	rts
:	ldx #0                  ; the index: nothing yet
	txa
@z:	sta idx,x
	inx
	bne @z
	lda #$FF
	sta idx+1
	stz ri
@r:	lda ri
	asl a
	tax
	lda tab,x               ; blocks
	sta rnb
	lda tab+1,x             ; the last one's link byte
	sta rlast
	ora rnb
	beq @end                ; (0, 0): no more
	lda rnb
	bne @rec
	lda #$FF                ; (0, $FF): an empty record
	sta idx+3,x
	bra @nx
@rec:	jsr RecIn               ; -> its first block, r3... (rfirst)
	bcs @x
	lda ri
	asl a
	tax
	lda rfirst
	sta idx+2,x
	lda rfirst+1
	sta idx+3,x
@nx:	inc ri
	lda ri
	cmp #127
	bne @r
@end:	jsr Alloc               ; the index block
	bcs @full
	lda r3L
	sta ent+1
	lda r3H
	sta ent+2
	lda #<idx
	ldx #>idx
	jmp Put
@full:	lda #INSUFF_SPACE
	sta err
	sec
@x:	rts

; a record: rnb blocks in the SD file (254 bytes each), the last one's
; link byte rlast (its bytes + 1)
RecIn:
	jsr Alloc
	bcs @full
	lda r3L
	sta rfirst
	lda r3H
	sta rfirst+1
@l:	lda r3L
	sta curT
	lda r3H
	sta curS
	lda #<(blk+2)             ; (each block is 254 bytes in a CVT file)
	ldx #>(blk+2)
	ldy #254
	jsr SdRead
	dec rnb
	beq @last
	jsr Alloc
	bcs @full
	lda r3L
	sta blk
	lda r3H
	sta blk+1
	jsr PutCur
	bcs @x
	bra @l
@last:	stz blk
	lda rlast
	sta blk+1
	jmp PutCur
@full:	lda #INSUFF_SPACE
	sta err
	sec
@x:	rts

; the directory entry (ent: blocks counted) -> a free slot, and the BAM
NewEntry:
	jsr SdClose
	lda nblk
	sta ent+28
	lda nblk+1
	sta ent+29
	stz r10L
	jsr GetFreeDirBlk       ; r1 = the block (in diskBlkBuf), Y = the slot
	txa
	beq :+
	stx err
	jsr GetDirHead
	jmp Failed
:	ldx #0
@c:	lda ent,x
	sta diskBlkBuf,y
	iny
	inx
	cpx #30
	bne @c
	lda #<diskBlkBuf
	sta r4L
	lda #>diskBlkBuf
	sta r4H
	jsr PutBlock
	txa
	bne @f
	jsr PutDirHead
	txa
	bne @f
	jmp Done
@f:	stx err
	jmp Failed

; ent's name (3-18, $A0 after it) -> gname (0 after it).  C = 1: a file of
; that name is on the disk already (err = FILE_EXISTS)
EntName:
	ldx #0
@c:	lda ent+3,x
	cmp #$A0
	beq @z
	sta gname,x
	inx
	cpx #16
	bne @c
@z:	stz gname,x
	ldx #16                 ; (the name shown when it is done)
:	lda gname,x
	sta shown,x
	dex
	bpl :-
	lda #<gname
	sta r6L
	lda #>gname
	sta r6H
	jsr FindFile
	txa
	bne :+
	lda #ERR_EXISTS
	sta err
	sec
	rts
:	clc
	rts

; ---- a .TXT file -> a geoWrite document: a page record per PGLINES lines
TxtIn:
	lda pick                ; its name, without ".TXT" (16 at most)
	jsr NamePtr
	ldy #0
@n:	lda (r2),y
	cmp #'.'
	beq @ne
	cmp #0
	beq @ne
	sta ent+3,y
	iny
	cpy #16
	bne @n
@ne:	lda #$A0
@pad:	cpy #16
	beq :+
	sta ent+3,y
	iny
	bra @pad
:	jsr EntName
	bcc :+
	jmp CvtFail
:	ldx #0                  ; the header: geoWrite's document
@h:	lda wr_hdr,x
	sta hdr,x
	inx
	bne @h
	jsr InitAlloc
	jsr Alloc
	bcc :+
	jmp CvtFull
:	lda r3L
	sta ent+19
	lda r3H
	sta ent+20
	lda #<hdr
	ldx #>hdr
	jsr Put
	bcc :+
	jmp CvtFail
:	ldx #0                  ; the index: every record empty
@z:	lda #0
	sta idx,x
	lda #$FF
	sta idx+1,x
	inx
	inx
	bne @z
	stz idx
	stz ri
	stz eof
	stz pend
@pg:	jsr Page                ; a page's text -> page
	lda pglen+1             ; (just the ruler and font: no text)
	bne @wr
	lda pglen
	cmp #PGHEAD+1
	bcc @done
@wr:	jsr PageOut             ; -> a chain; its first block -> the index
	bcc :+
	jmp CvtFail
:	lda ri
	asl a
	tax
	lda rfirst
	sta idx+2,x
	lda rfirst+1
	sta idx+3,x
	inc ri
	lda ri
	cmp #61                 ; (61 pages at most)
	bcs @done
	lda eof
	beq @pg
@done:	lda ri                  ; (at least one page)
	bne :+
	jsr PageOut
	bcc :+
	jmp CvtFail
:	jsr Alloc               ; the index block
	bcc :+
	jmp CvtFull
:	lda r3L
	sta ent+1
	lda r3H
	sta ent+2
	lda #<idx
	ldx #>idx
	jsr Put
	bcc :+
	jmp CvtFail
:	lda #$83                ; the directory entry: USR, VLIR, application data
	sta ent
	lda #1
	sta ent+21
	lda #APPL_DATA
	sta ent+22
	lda year
	sta ent+23
	lda month
	sta ent+24
	lda day
	sta ent+25
	lda hour
	sta ent+26
	lda minutes
	sta ent+27
	jmp NewEntry

PGHEAD = 31                     ; the ruler (27 bytes) and the font (4)
ERR_EXISTS = $82

; the next page's text -> page (pglen bytes), the ruler and font first:
; CR LF, LF -> CR; a tab: spaces; other control characters go; not ASCII: "?"
Page:
	ldx #PGHEAD-1
@h:	lda pg_head,x
	sta page,x
	dex
	bpl @h
	lda #<PGHEAD
	sta pglen
	stz pglen+1
	stz lines
	stz col
@c:	lda eof
	bne @x2
	jsr TByte               ; the next byte (C = 1: the end)
	bcc :+
	inc eof
@x2:	rts
:	cmp #10
	bne @cr
	lda pend                ; (LF right after CR: that line is done)
	stz pend
	bne @c
	bra @nl
@cr:	stz pend
	cmp #13
	bne @ch
	inc pend                ; (an LF may follow)
@nl:	lda #13
	jsr PPut
	stz col
	inc lines
	lda lines
	cmp #PGLINES
	bcs @x
	bra @full
@ch:	cmp #9                  ; a tab: spaces to the next 4th column
	bne @nt
@tb:	lda #' '
	jsr PPut
	inc col
	lda col
	and #3
	bne @tb
	bra @full
@nt:	cmp #' '
	bcc @c
	cmp #$7F
	bcc @ok
	lda #'?'
@ok:	jsr PPut
	inc col
	lda col                 ; (a long line: more than one on the page)
	cmp #LINEW
	bcc @full
	stz col
	inc lines
	lda lines
	cmp #PGLINES
	bcs @x
@full:	lda pglen+1             ; the page full?
	cmp #>PGMAX
	bcc @go
	lda pglen
	cmp #<PGMAX
	bcs @x
@go:	jmp @c
@x:	rts

PPut:	ldx pglen               ; A -> page + pglen
	stx r5L
	ldx pglen+1
	pha
	txa
	clc
	adc #>page
	sta r5H
	lda r5L
	clc
	adc #<page
	sta r5L
	bcc :+
	inc r5H
:	pla
	sta (r5)
	inc pglen
	bne :+
	inc pglen+1
:	rts

; the next byte of the SD file (read a block at a time): A, C = 1 at the end
TByte:
	lda tpos
	cmp tlen
	bne @b
	lda tend
	bne @e
	lda #<tab
	ldx #>tab
	ldy #254
	jsr SdRead
	sty tlen
	stz tpos
	cpy #254
	beq :+
	inc tend
:	cpy #0
	beq @e
@b:	ldx tpos
	lda tab,x
	inc tpos
	clc
	rts
@e:	sec
	rts

; page (pglen bytes) -> a chain: rfirst = its first block
PageOut:
	lda #<page
	sta pp
	lda #>page
	sta pp+1
	jsr Alloc
	bcc :+
	lda #INSUFF_SPACE
	sta err
	rts
:	lda r3L
	sta rfirst
	lda r3H
	sta rfirst+1
@l:	lda r3L
	sta curT
	lda r3H
	sta curS
	lda pp                  ; up to 254 bytes -> blk
	sta r5L
	lda pp+1
	sta r5H
	ldy #0
@c:	lda pglen
	ora pglen+1
	beq @e
	lda (r5)
	sta blk+2,y
	inc r5L
	bne :+
	inc r5H
:	lda pglen
	bne :+
	dec pglen+1
:	dec pglen
	iny
	cpy #254
	bne @c
@e:	sty cnt
	lda r5L
	sta pp
	lda r5H
	sta pp+1
	lda pglen
	ora pglen+1
	beq @last
	jsr Alloc
	bcc :+
	lda #INSUFF_SPACE
	sta err
	rts
:	lda r3L
	sta blk
	lda r3H
	sta blk+1
	jsr PutCur
	bcs @x
	bra @l
@last:	stz blk
	ldx cnt
	inx
	stx blk+1
	jmp PutCur
@x:	rts

; ---- the GEOS side's blocks
InitAlloc:
	stz nblk
	stz nblk+1
	lda #1                  ; (from the start of the disk)
	sta hint
	stz hint+1
	rts

; r3 = a free block, now allocated (the BAM in memory).  C = 1: disk full
Alloc:
	lda hint
	sta r3L
	lda hint+1
	sta r3H
	jsr SetNextFree
	txa
	beq :+
	sec
	rts
:	lda r3L
	sta hint
	lda r3H
	sta hint+1
	inc nblk
	bne :+
	inc nblk+1
:	clc
	rts

; the block at A/X -> block r3.  C = 1: failed (err)
Put:	sta r4L
	stx r4H
	lda r3L
	sta r1L
	lda r3H
	sta r1H
	jsr PutBlock
	txa
	bne :+
	clc
	rts
:	stx err
	sec
	rts

; ===================================================== GEOS disk -> SD card
; the file as NAME.CVT: its entry and signature, its header, its data
OutCvt:
	ldx #0                  ; (".CVT")
	jsr OutName
	lda #'W'
	jsr SdOpen
	bcc :+
	jmp Failed
:	ldx #0                  ; block 0: the entry, the signature, zeros
	txa
@z:	sta buf,x
	inx
	bne @z
	lda pick
	jsr EntPtr
	ldy #29
@e:	lda (r3),y
	sta buf,y
	sta ent,y
	dey
	bpl @e
	ldx #0
@s:	lda t_sigw,x
	beq :+
	sta buf+30,x
	inx
	bra @s
:	lda ent                 ; ("SEQ" for a sequential CBM file)
	and #7
	cmp #1
	bne :+
	lda #'S'
	sta buf+30
	lda #'E'
	sta buf+31
	lda #'Q'
	sta buf+32
:	lda #<buf
	ldx #>buf
	ldy #254
	jsr SdWrite
	lda ent+19              ; block 1: the header
	sta r1L
	lda ent+20
	sta r1H
	jsr GetHdr
	bcs @f
	lda #<(hdr+2)
	ldx #>(hdr+2)
	ldy #254
	jsr SdWrite
	lda ent+1
	sta r1L
	lda ent+2
	sta r1H
	lda ent+21
	bne @vlir
	jsr ChainOut            ; sequential: the chain, as it is
	bcs @f
	bra @ok
@vlir:	jsr VlirOut
	bcs @f
@ok:	jsr SdClose
	jmp Done
@f:
OutFail:
	jsr SdClose
	jmp Failed

; the chain from block r1 -> the SD file (the last block: its bytes only)
ChainOut:
@l:	lda #<blk
	sta r4L
	lda #>blk
	sta r4H
	jsr GetBlock
	txa
	bne @e
	ldy #254
	lda blk
	bne :+
	ldy blk+1
	dey
:	lda #<(blk+2)
	ldx #>(blk+2)
	jsr SdWrite
	lda blk
	beq @x
	sta r1L
	lda blk+1
	sta r1H
	bra @l
@x:	clc
	rts
@e:	stx err
	sec
	rts

; a VLIR file: the record table (blocks, the last's link byte), then each
; record's blocks, 254 bytes each
VlirOut:
	lda #<idx
	sta r4L
	lda #>idx
	sta r4H
	jsr GetBlock            ; the index
	txa
	beq :+
	jmp VoErr
:	ldx #0
	txa
@z:	sta tab,x
	inx
	bne @z
	stz ri
@r:	lda ri                  ; the table
	asl a
	tax
	lda idx+2,x
	bne @rec
	lda idx+3,x
	beq @tw                 ; (0, 0): no more
	lda #$FF                ; (0, $FF): empty
	sta tab+1,x
	bra @nx
@rec:	sta r1L
	lda idx+3,x
	sta r1H
	stz rnb
@cl:	lda #<blk               ; count its blocks
	sta r4L
	lda #>blk
	sta r4H
	jsr GetBlock
	txa
	bne @e
	inc rnb
	lda blk
	beq :+
	sta r1L
	lda blk+1
	sta r1H
	bra @cl
:	lda ri
	asl a
	tax
	lda rnb
	sta tab,x
	lda blk+1
	sta tab+1,x
@nx:	inc ri
	lda ri
	cmp #127
	bne @r
@tw:	lda #<tab
	ldx #>tab
	ldy #254
	jsr SdWrite
	stz ri                  ; the records
@w:	lda ri
	asl a
	tax
	lda idx+2,x
	beq @nr
	sta r1L
	lda idx+3,x
	sta r1H
@bl:	lda #<blk
	sta r4L
	lda #>blk
	sta r4H
	jsr GetBlock
	txa
	bne @e
	lda #<(blk+2)
	ldx #>(blk+2)
	ldy #254
	jsr SdWrite
	lda blk
	beq @nr
	sta r1L
	lda blk+1
	sta r1H
	bra @bl
@nr:	inc ri
	lda ri
	cmp #127
	bne @w
	clc
	rts
@e:
VoErr:	stx err
	sec
	rts

; a geoWrite document as NAME.TXT: its pages' text (records 0-60), the
; escapes (ruler, font, picture) out, CR -> CR LF
OutTxt:
	ldx #t_etxt - t_ecvt    ; (".TXT")
	jsr OutName
	lda #'W'
	jsr SdOpen
	bcc :+
	jmp Failed
:	lda pick
	jsr EntPtr
	ldy #1
	lda (r3),y
	sta r1L
	iny
	lda (r3),y
	sta r1H
	lda #<idx
	sta r4L
	lda #>idx
	sta r4H
	jsr GetBlock
	txa
	beq :+
	stx err
	jmp OutFail
:	stz ri
	stz skip
	stz olen
@r:	lda ri
	asl a
	tax
	lda idx+2,x
	beq @nr
	sta r1L
	lda idx+3,x
	sta r1H
@bl:	lda #<blk
	sta r4L
	lda #>blk
	sta r4H
	jsr GetBlock
	txa
	beq :+
	stx err
	jmp OutFail
:	ldy #254
	lda blk
	bne :+
	ldy blk+1
	dey
:	sty cnt
	ldx #0
@b:	cpx cnt
	beq @be
	lda blk+2,x
	phx
	jsr TxtByte
	plx
	inx
	bra @b
@be:	lda blk
	beq @nr
	sta r1L
	lda blk+1
	sta r1H
	bra @bl
@nr:	inc ri
	lda ri
	cmp #61
	bne @r
	jsr OFlush
	jsr SdClose
	jmp Done

; a byte of a geoWrite page -> the text (escapes skipped)
TxtByte:
	ldx skip
	beq :+
	dec skip
	rts
:	cmp #$11                ; a ruler: 26 more
	bne :+
	lda #26
	sta skip
	rts
:	cmp #$17                ; a font: 3 more
	bne :+
	lda #3
	sta skip
	rts
:	cmp #$10                ; a picture: 4 more
	bne :+
	lda #4
	sta skip
	rts
:	cmp #13
	bne :+
	jsr OPut
	lda #10
	jmp OPut
:	cmp #9
	beq OPut
	cmp #' '
	bcc @x
	cmp #$7F
	bcc OPut
@x:	rts

OPut:	ldx olen                ; -> obuf, out when it has 254
	sta obuf,x
	inx
	stx olen
	cpx #254
	bcc :+
OFlush:	lda #<obuf
	ldx #>obuf
	ldy olen
	beq :+
	jsr SdWrite
	stz olen
:	rts

; GEOS file pick's name, the characters FAT32 takes, and the extension
; (t_ecvt + X) -> fname
OutName:
	lda fixn                ; (fname given: the SD file's own name)
	beq :+
	rts
:	stx ei
	lda pick
	jsr NamePtr
	ldy #0
@c:	lda (r2),y
	beq @e
	cmp #' '
	bcc @u
	cmp #'/'
	beq @u
	cmp #':'
	beq @u
	cmp #','
	beq @u
	cmp #'*'
	beq @u
	cmp #'?'
	beq @u
	cmp #'='
	beq @u
	cmp #'"'
	beq @u
	cmp #$7F
	bcc @k
@u:	lda #'_'
@k:	sta fname,y
	iny
	bra @c
@e:	ldx ei
@x:	lda t_ecvt,x            ; the extension
	sta fname,y
	beq :+
	iny
	inx
	bra @x
:	sty flen
	ldy #0                  ; (the name shown when it is done)
:	lda fname,y
	sta shown,y
	beq :+
	iny
	bra :-
:	rts

; the SD file pick's name -> fname
SdName:
	lda pick
	jsr NamePtr
	ldy #0
@c:	lda (r2),y
	sta fname,y
	beq :+
	iny
	bra @c
:	sty flen
	rts

; ------------------------------------------------- the SD card (call 9)
; open fname: A = 'R' (file LFN_IN) or 'W' (LFN_OUT, "@:" first, replaced).
; C = 1: failed (err)
SdOpen:
	sta q
	cmp #'W'
	bne @r
	ldy flen                ; "@:" + name + ",S,W"
@m:	lda fname,y
	sta fname+2,y
	dey
	bpl @m
	lda #'@'
	sta fname
	lda #':'
	sta fname+1
	inc flen
	inc flen
@r:	ldy flen
	lda #','
	sta fname,y
	lda #'S'
	sta fname+1,y
	lda #','
	sta fname+2,y
	lda q
	sta fname+3,y
	lda flen
	clc
	adc #4
	ldx #<fname
	ldy #>fname
	X16K X16K_SETNAM
	ldx #LFN_IN
	lda q
	cmp #'W'
	bne :+
	ldx #LFN_OUT
:	stx lfn
	txa
	ldx #8
	ldy lfn
	X16K X16K_SETLFS
	X16K X16K_OPEN
	bcs @no
	ldx #15                 ; the drive's status: "00, OK"?
	X16K X16K_CHKIN
	X16K X16K_CHRIN
	pha
@d:	X16K X16K_READST
	bne @de
	X16K X16K_CHRIN
	cmp #13
	bne @d
@de:	X16K X16K_CLRCHN
	pla
	cmp #'0'
	bne @no
	stz tpos                ; (TByte: nothing read yet)
	stz tlen
	stz tend
	clc
	rts
@no:	jsr SdClose
	lda #$81
	sta err
	sec
	rts

SdClose:
	X16K X16K_CLRCHN
	lda lfn
	X16K X16K_CLOSE
	rts

; Y bytes (1-254) of the SD file -> A/X; Y = how many there were
SdRead:
	sta rp
	stx rp+1
	sty want
	stz got
	ldx #LFN_IN
	X16K X16K_CHKIN
@l:	lda want
	sec
	sbc got
	bne :+
	jmp @x
:	pha                     ; MACPTR: up to that many -> rp + got
	lda rp
	clc
	adc got
	tax
	lda rp+1
	adc #0
	tay
	pla
	X16K X16K_MACPTR
	bcs @slow               ; (no MACPTR here: a byte at a time)
	txa
	bne :+
	jmp @x                  ; (none: the end)
:
	clc
	adc got
	sta got
	bra @l
@slow:	lda got
	cmp want
	beq @x
	X16K X16K_READST
	and #$40
	bne @x
	X16K X16K_CHRIN
	pha
	X16K X16K_READST
	sta st
	pla
	ldx st                  ; (a byte only if it was there)
	cpx #$42
	beq @x
	pha
	lda rp
	sta r5L
	lda rp+1
	sta r5H
	pla
	ldy got
	sta (r5),y
	inc got
	lda st
	and #$40
	beq @slow
@x:	X16K X16K_CLRCHN
	ldy got
	rts

; Y bytes (0-254) at A/X -> the SD file
SdWrite:
	sta rp
	stx rp+1
	sty want
	cpy #0
	beq @z
	ldx #LFN_OUT
	X16K X16K_CHKOUT
	stz got
	lda want                ; MCIOUT: all of it at once
	ldx rp
	ldy rp+1
	clc
	X16K X16K_MCIOUT
	bcs @l                  ; (no MCIOUT here: a byte at a time)
	cpx want
	beq @x
	stx got                 ; (some: the rest a byte at a time)
@l:	lda rp
	sta r5L
	lda rp+1
	sta r5H
	ldy got
	cpy want
	beq @x
	lda (r5),y
	X16K X16K_CHROUT
	inc got
	bra @l
@x:	X16K X16K_CLRCHN
@z:	rts

; ------------------------------------------------------------ small things
; r2 = file A's name (r1 kept)
NamePtr:
	pha
	lda r1L
	pha
	lda r1H
	pha
	tsx
	lda $0103,x
	ldx #<names
	ldy #>names
	jsr Mul40
	lda r1L
	sta r2L
	lda r1H
	sta r2H
	pla
	sta r1H
	pla
	sta r1L
	pla
	rts

; r3 = GEOS file A's directory entry (30 bytes) in ents
EntPtr:
	sta r3L
	stz r3H
	asl r3L                 ; * 32 - * 2
	rol r3H
	asl r3L
	rol r3H
	asl r3L
	rol r3H
	asl r3L
	rol r3H
	asl r3L
	rol r3H
	asl a
	sta q
	lda r3L
	sec
	sbc q
	sta r3L
	bcs :+
	dec r3H
:	lda r3L
	clc
	adc #<ents
	sta r3L
	lda r3H
	adc #>ents
	sta r3H
	rts

; r1 = X/Y + A * 40 (r3, r4 changed)
Mul40:
	stx r1L
	sty r1H
	sta r3L
	stz r3H
	asl r3L
	rol r3H
	asl r3L
	rol r3H
	asl r3L
	rol r3H
	lda r3L
	sta r4L
	lda r3H
	sta r4H
	asl r4L
	rol r4H
	asl r4L
	rol r4H
	lda r3L
	clc
	adc r4L
	sta r3L
	lda r3H
	adc r4H
	sta r3H
	lda r1L
	clc
	adc r3L
	sta r1L
	lda r1H
	adc r3H
	sta r1H
	rts

; (r2) -> (r1) from Y on (up to NLEN-1); Y after it, 0 written
Append:
	sty ny
	ldx #0
@c:	phx
	txa
	tay
	lda (r2),y
	ldy ny
	plx
	cpy #NLEN-1
	bcs @x
	sta (r1),y
	cmp #0
	beq @z
	inc ny
	inx
	bra @c
@x:	lda #0
	sta (r1),y
@z:	ldy ny
	rts

	X16K_CODE

sig:	.byte "X16G"
dname:	.byte "$"
t_sig:	.byte "formatted GEOS file V1"
t_sigw:	.byte "PRG formatted GEOS file V1.0", 0
t_wclass: .byte "Write Image"
t_ecvt:	.byte ".CVT", 0
t_etxt:	.byte ".TXT", 0
h_sdf:	.byte "Copy which file from the SD card?", 0
h_geosf: .byte "Copy which file to the SD card?", 0
h_to:	.byte "Copy it to which drive?", 0
h_from:	.byte "Copy from which drive?", 0
h_fmt:	.byte "A geoWrite document: copy it as", 0
t_quit:	.byte "Back to the deskTop", 0
h_sd:	.byte "SD card:  ", 0
t_up:	.byte "Up a folder", 0
t_here:	.byte "Copy a GEOS file here", 0
t_sdc:	.byte "Make this folder drive C", 0
t_sync:	.byte "Save drive C back to its folder", 0
n_lst:	.byte "GEOSSD.LST", 0
w_lst:	.byte "@:GEOSSD.LST,S,W"
w_lst_n = * - w_lst
w_new:	.byte "@:GEOSSD.NEW,S,W"
w_new_n = * - w_new
w_app:	.byte "GEOSSD.NEW,S,A"
w_app_n = * - w_app
r_sd:	.byte "GEOSSD.CFG,S,R"
r_sd_n = * - r_sd
r_lst:	.byte "GEOSSD.LST,S,R"
r_lst_n = * - r_lst
c_dlst:	.byte "S:GEOSSD.LST", 0
c_ren:	.byte "R:GEOSSD.LST=GEOSSD.NEW", 0
dlg_sync:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word t_y1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_2_Y
	.word t_y2
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_3_Y
	.word t_y3
	.byte YES, DBI_X_0, DBI_Y_2
	.byte NO, DBI_X_2, DBI_Y_2
	.byte 0
t_y1:	.byte BOLDON, "Saved to the folder:", PLAINTEXT, 0
t_y2:
y_c:	.byte "000 changed, "
y_n:	.byte "000 new, "
y_d:	.byte "000 deleted.", 0
t_y3:	.byte "Put drive C's own disk back?", 0
dlg_syerr:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word t_se
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
t_se:	.byte BOLDON, "Drive C's folder was not found.", PLAINTEXT, 0
n_ssd:	.byte "GEOSSD.D81", 0
w_sd:	.byte "@:GEOSSD.CFG,S,W"
w_sd_n = * - w_sd
dlg_sdc:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word t_sdc1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_2_Y
	.word t_sdc2
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
t_sdc1:	.byte BOLDON, "Drive C is this folder now:", PLAINTEXT, 0
t_sdc2:
s_n:	.byte "000 files copied, "
s_m:	.byte "000 not (no room).", 0
dlg_nossd:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word t_ns1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_2_Y
	.word t_ns2
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
t_ns1:	.byte BOLDON, "GEOSSD.D81 would not go in drive C:", PLAINTEXT, 0
t_ns2:	.byte "it must be next to geosx16.bin, drive C a D81.", 0
t_cpy:	.byte "Copy it onto a GEOS disk", 0
t_mnt:	.byte "Put it in a drive", 0
t_wall:	.byte "Make it the wallpaper", 0
t_ren:	.byte "Rename it", 0
t_del:	.byte "Delete it", 0
h_mnt:	.byte "Put it in which drive?", 0
t_now:	.byte "  (now ", 0
w_cfg:	.byte "@:GEOSDRV.CFG,S,W"
w_cfg_n = * - w_cfg
t_already: .byte BOLDON, "That disk is in drive "
t_alr_d: .byte "A", PLAINTEXT, 0
t_alr2:	.byte "already.", 0
dlg_already:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word t_already
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_2_Y
	.word t_alr2
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
dlg_mfail:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word t_mf
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_2_Y
f_why:	.word me1
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
t_mf:	.byte BOLDON, "It could not go in that drive:", PLAINTEXT, 0
me1:	.byte "the name or the drive is wrong.", 0
me2:	.byte "it is not a disk image.", 0
me3:	.byte "it is the other type (D81 / D64).", 0
me4:	.byte "it failed: that drive is empty now.", 0
m_err_l: .byte <me1, <me2, <me3, <me4
m_err_h: .byte >me1, >me2, >me3, >me4
dlg_wfail:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word t_wf
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
t_wf:	.byte BOLDON, "That wallpaper did not load.", PLAINTEXT, 0
dlg_ren:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word t_ren2
	.byte DBGETSTRING, TXT_LN_X, TXT_LN_2_Y, r5, 28
	.byte OK, DBI_X_0, DBI_Y_2
	.byte CANCEL, DBI_X_2, DBI_Y_2
	.byte 0
t_ren2:	.byte BOLDON, "Its new name:", PLAINTEXT, 0
dlg_rfail:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word t_rf
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
t_rf:	.byte BOLDON, "It could not be renamed.", PLAINTEXT, 0
dlg_del:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word t_dl
	.byte DBVARSTR, TXT_LN_X, TXT_LN_2_Y, r6
	.byte YES, DBI_X_0, DBI_Y_2
	.byte NO, DBI_X_2, DBI_Y_2
	.byte 0
t_dl:	.byte BOLDON, "Delete this from the SD card?", PLAINTEXT, 0
t_back:	.byte "Back", 0
t_more:	.byte "More...", 0
t_cvt:	.byte "NAME.CVT (the whole GEOS file)", 0
t_txt:	.byte "NAME.TXT (just its text)", 0
t_drive: .byte "Drive A", 0
t_open:	.byte "  (", 0

cur_l:	.byte <cur0, <cur1, <cur2
cur_h:	.byte >cur0, >cur1, >cur2

; a geoWrite page's start: a ruler (margins 0 and 320, no tabs) and BSW 9
pg_head: .byte $11, $00, $00, $40, $01, $40, $01, $40, $01, $40, $01
	.byte $40, $01, $40, $01, $40, $01, $40, $01, $40, $01, $00, $00
	.byte $10, $00, $00, $00
	.byte $17, $09, $00, $00

; a geoWrite 2.1 document's header (its icon: a page of text)
wr_hdr:	.byte $00, $FF, 3, 21, $80 | 63
	.byte $FF, $FF, $FF, $80, $00, $01, $BF, $FF, $FD, $80, $00, $01
	.byte $BF, $FF, $81, $80, $00, $01, $BF, $FF, $FD, $80, $00, $01
	.byte $BF, $F0, $01, $80, $00, $01, $BF, $FF, $FD, $80, $00, $01
	.byte $BF, $FF, $C1, $80, $00, $01, $BF, $FF, $FD, $80, $00, $01
	.byte $BF, $FE, $01, $80, $00, $01, $80, $00, $01, $80, $00, $01
	.byte $FF, $FF, $FF
	.assert * - wr_hdr = $44, error, "header: the icon"
	.byte $83, APPL_DATA, VLIR
	.word 0, $FFFF, 0
	.byte "Write Image V2.1", 0, 0, 0, 0          ; class ($4D)
	.res 20                                       ; author ($61)
	.byte "geoWrite    V2.1", 0, 0, 0, 0          ; parent ($75)
	.assert * - wr_hdr = $89, error, "header: $89"
	.byte 1, 0, 0, 0, 0, 0, 0                     ; ($89: the first page's number)
	.byte $F0, $02                                ; ($90: the page height)
	.res $A0 - $92
	.byte "From a text file on the SD card (GEOS-X16 Copier).", 0
	.res 256 - (* - wr_hdr)
	.assert * - wr_hdr = 256, error, "header: 256"

dlg_done:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word d1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_2_Y
	.word shown
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
d1:	.byte BOLDON, "Copied:", PLAINTEXT, 0

dlg_fail:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word f1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_2_Y
	.word f2
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_3_Y
	.word f3
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
f1:	.byte BOLDON, "That did not work.", PLAINTEXT, 0
f2:	.byte "(Full, already there, or not a GEOS file?)", 0
f3:	.byte "Error $"
f_code:	.byte "00", 0

dlg_nosd:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word s1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_2_Y
	.word s2
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
s1:	.byte BOLDON, "No .CVT or .TXT files", PLAINTEXT, 0
s2:	.byte "next to geosx16.bin.", 0

dlg_nogeos:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word g1
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
g1:	.byte BOLDON, "No GEOS files on that disk.", PLAINTEXT, 0

dlg_nox16:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word x1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_2_Y
	.word x2
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
x1:	.byte BOLDON, "This program needs GEOS-X16", PLAINTEXT, 0
x2:	.byte "(version 3 or newer).", 0

.segment "BSS"
home:	.res 1
depth:	.res 1
batch:	.res 1
allf:	.res 1
fixn:	.res 1
bok_v:	.res 2
bbad_v:	.res 2
ndel:	.res 1
nchg:	.res 1
nnew:	.res 1
nl:	.res 1
lg:	.res 1
lstamp:	.res 7
lgeos:	.res 17
lsd:	.res NLEN
lbuf:	.res 121
m_idx:	.res MAXF
m_chg:	.res MAXF
del:	.res MAXF
bsp:	.res 1
bi:	.res 1
nimp:	.res 1
nskip:	.res 1
sdepth:	.res 1
prevc:	.res NLEN
spath:	.res 40
dgt:	.res 1
ey:	.res 1
kind:	.res 1
ltl:	.res 1
ltype:	.res 3
e3:	.res 3
path:	.res 40
hbuf:	.res 80
sbuf:	.res 12
mname:	.res 80
cmd:	.res 90
newn:	.res NLEN
isdir:	.res MAXF
blk_l:	.res MAXF
blk_h:	.res MAXF
nf:	.res 1
pg:	.res 1
fi:	.res 1
ni:	.res 1
di:	.res 1
ei:	.res 1
mode:	.res 1
dir:	.res 1                  ; 1: from the SD card, 0: to it
drv:	.res 1
pick:	.res 1
err:	.res 1
ln:	.res 1
lk:	.res 1
q:	.res 1
ny:	.res 1
st:	.res 1
lfn:	.res 1
flen:	.res 1
rp:	.res 2
want:	.res 1
got:	.res 1
cnt:	.res 1
cnt2:	.res 1
curT:	.res 1
hint:	.res 2
pp:	.res 2
curS:	.res 1
nblk:	.res 2
ri:	.res 1
rnb:	.res 1
rlast:	.res 1
rfirst:	.res 2
eof:	.res 1
pend:	.res 1
lines:	.res 1
col:	.res 1
pglen:	.res 2
tpos:	.res 1
tlen:	.res 1
tend:	.res 1
skip:	.res 1
olen:	.res 1
ifile:	.res 12
menu:	.res 7 + 12 * 5
gname:	.res 17
shown:	.res 64
fname:	.res 64
ent:	.res 30
items:	.res 12 * NLEN
cur0:	.res 64
cur1:	.res 64
cur2:	.res 64
names:	.res MAXF * NLEN
ents:	.res MAXF * 30
rec = ents                      ; (the folder's copying: its lines, MAXF * 25)
buf:	.res 256
hdr:	.res 256
blk:	.res 256
blk2:	.res 256
idx:	.res 256
tab:	.res 256
obuf:	.res 256
page:	.res PGMAX + 300
