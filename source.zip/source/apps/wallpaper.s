; WALLPAPER: a GEOS application for GEOS-X16 that chooses the deskTop's
; wallpaper: your GEOSWALL.BMX, one of the five in the GeosWallpapers
; folder, or none.  It asks GEOS-X16 to load the file ($FF7D, call 0: see
; kernal/x16/prn.s), which also keeps the choice for the next boot
; (GEOSWALL.CFG), and goes back to the deskTop, which shows it.
;
; ca65 -I ../inc wallpaper.s; ld65 -C wallpaper.cfg (load address $0400);
; tools/mkwallapp.py adds the GEOS file header and puts it on a disk.

.include "const.inc"
.include "geossym.inc"
.include "jumptab.inc"

X16_SIG  = $FF78                ; "X16G", version
X16_CALL = $FF7D

NITEMS   = 8
MTOP     = 52
ITEMH    = 14
MLEFT    = 24
MRIGHT   = 175

.segment "CODE"

Start:
	ldx #3                  ; GEOS-X16?
@s:	lda X16_SIG,x
	cmp sig,x
	beq :+
	jmp NotX16
:	dex
	bpl @s
	lda #<curname           ; the wallpaper now
	sta r0L
	lda #>curname
	sta r0H
	lda #1
	jsr X16_CALL
	jsr Marks
	jsr i_GraphicsString
	.byte NEWPATTERN, 0
	.byte MOVEPENTO
	.word 0
	.byte 0
	.byte RECTANGLETO
	.word 319
	.byte 199
	.byte NEWPATTERN, 1
	.byte MOVEPENTO
	.word 0
	.byte 0
	.byte RECTANGLETO
	.word 319
	.byte 15
	.byte 0
	jsr i_PutString
	.word 92
	.byte 11
	.byte BOLDON, "GEOS-X16 Wallpaper", PLAINTEXT, 0
	jsr i_PutString
	.word MLEFT
	.byte 40
	.byte "Choose the deskTop's wallpaper:", 0
	jsr i_PutString
	.word 196
	.byte 66
	.byte "* = the one now.", 0
	jsr i_PutString
	.word 196
	.byte 86
	.byte "The pictures come", 0
	jsr i_PutString
	.word 196
	.byte 96
	.byte "from the folder", 0
	jsr i_PutString
	.word 196
	.byte 106
	.byte BOLDON, "GeosWallpapers", PLAINTEXT, 0
	jsr i_PutString
	.word 196
	.byte 116
	.byte "next to geosx16.bin.", 0
	jsr i_PutString
	.word 196
	.byte 136
	.byte "Your choice is kept", 0
	jsr i_PutString
	.word 196
	.byte 146
	.byte "for the next time", 0
	jsr i_PutString
	.word 196
	.byte 156
	.byte "GEOS-X16 starts.", 0
	lda #<menu
	sta r0L
	lda #>menu
	sta r0H
	lda #0
	jmp DoMenu

NotX16:
	lda #<dlg_nox16
	sta r0L
	lda #>dlg_nox16
	sta r0H
	jsr DoDlgBox
	jmp EnterDeskTop

; "*" before the wallpaper there is now, " " before the others
Marks:
	ldy #0
@i:	lda txt_l,y
	sta r1L
	lda txt_h,y
	sta r1H
	lda name_l,y
	sta r2L
	lda name_h,y
	sta r2H
	ldx #' '
	sty r3L
	ldy #$FF
@c:	iny
	lda (r2),y
	cmp curname,y
	bne @m
	cmp #0
	bne @c
	ldx #'*'
@m:	ldy #0
	txa
	sta (r1),y
	ldy r3L
	iny
	cpy #NITEMS - 1         ; (not "Quit")
	bne @i
	rts

Pick0:	lda #0
	.byte $2C
Pick1:	lda #1
	.byte $2C
Pick2:	lda #2
	.byte $2C
Pick3:	lda #3
	.byte $2C
Pick4:	lda #4
	.byte $2C
Pick5:	lda #5
	.byte $2C
Pick6:	lda #6
	tay
	lda name_l,y
	sta r0L
	lda name_h,y
	sta r0H
	cpy #6
	bne @go
	lda #0                  ; no wallpaper: r0 = 0
	sta r0L
	sta r0H
@go:	lda #0
	jsr X16_CALL
	bcs @err
	jmp EnterDeskTop        ; the deskTop shows it
@err:	jsr GotoFirstMenu
	lda #<dlg_err
	sta r0L
	lda #>dlg_err
	sta r0H
	jsr DoDlgBox
	jmp EnterDeskTop

Quit:	jmp EnterDeskTop

sig:	.byte "X16G"

menu:	.byte MTOP, MTOP + NITEMS * ITEMH
	.word MLEFT, MRIGHT
	.byte VERTICAL | NITEMS
	.word t0
	.byte MENU_ACTION
	.word Pick0
	.word t1
	.byte MENU_ACTION
	.word Pick1
	.word t2
	.byte MENU_ACTION
	.word Pick2
	.word t3
	.byte MENU_ACTION
	.word Pick3
	.word t4
	.byte MENU_ACTION
	.word Pick4
	.word t5
	.byte MENU_ACTION
	.word Pick5
	.word t6
	.byte MENU_ACTION
	.word Pick6
	.word t7
	.byte MENU_ACTION
	.word Quit

t0:	.byte " Your own: GEOSWALL.BMX", 0
t1:	.byte " Synthwave", 0
t2:	.byte " Space", 0
t3:	.byte " Mountains", 0
t4:	.byte " Tropical", 0
t5:	.byte " Aurora", 0
t6:	.byte " No wallpaper", 0
t7:	.byte " Back to the deskTop", 0
txt_l:	.byte <t0, <t1, <t2, <t3, <t4, <t5, <t6
txt_h:	.byte >t0, >t1, >t2, >t3, >t4, >t5, >t6

n0:	.byte "GEOSWALL.BMX", 0
n1:	.byte "/GeosWallpapers/:SYNTHWAVE.BMX", 0
n2:	.byte "/GeosWallpapers/:SPACE.BMX", 0
n3:	.byte "/GeosWallpapers/:MOUNTAINS.BMX", 0
n4:	.byte "/GeosWallpapers/:TROPICAL.BMX", 0
n5:	.byte "/GeosWallpapers/:AURORA.BMX", 0
n6:	.byte 0                 ; none: ""
name_l:	.byte <n0, <n1, <n2, <n3, <n4, <n5, <n6
name_h:	.byte >n0, >n1, >n2, >n3, >n4, >n5, >n6

dlg_err:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word e1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_2_Y
	.word e2
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_3_Y
	.word e3
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
e1:	.byte BOLDON, "That wallpaper is not there.", PLAINTEXT, 0
e2:	.byte "Put the GeosWallpapers folder", 0
e3:	.byte "next to geosx16.bin. (Now: none)", 0

dlg_nox16:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word x1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_2_Y
	.word x2
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
x1:	.byte BOLDON, "This program is for GEOS-X16,", PLAINTEXT, 0
x2:	.byte "GEOS on the Commander X16.", 0

.segment "BSS"
curname: .res 48
