; X16 FILES: a small "hybrid" GEOS program for GEOS-X16 (and an example of
; GEOS-X16 call 9): it reads HELLO.TXT from the X16's SD card through the
; X16 KERNAL, writes what it read to X16CALL.OUT next to it, and shows the
; first line in a GEOS dialog box.
;
; ca65 -I ../inc x16files.s; ld65 -C wallpaper.cfg (load address $0400);
; tools/mkx16app.py adds the GEOS file header and puts it on a disk.

.include "const.inc"
.include "geossym.inc"
.include "jumptab.inc"
.include "geosx16.inc"

LFN_IN  = 10
LFN_OUT = 11
MAXLEN  = 120

.segment "CODE"

Start:
	ldx #3                  ; GEOS-X16, version 2 or more?
@s:	lda X16_SIG,x
	cmp sig,x
	beq :+
	jmp NotX16
:	dex
	bpl @s
	lda X16_VER
	cmp #2
	bcs :+
	jmp NotX16
:

	; read HELLO.TXT
	lda #inl
	ldx #<inname
	ldy #>inname
	X16K X16K_SETNAM
	lda #LFN_IN
	ldx #8
	ldy #LFN_IN
	X16K X16K_SETLFS
	X16K X16K_OPEN
	bcc :+
	jmp NoFile
:	ldx #LFN_IN
	X16K X16K_CHKIN
	bcc :+
	jmp NoFile
:
	lda #0
	sta len
@rd:	X16K X16K_CHRIN
	sta byte
	X16K X16K_READST
	sta st
	and #$BF                ; an error (not just the end)?
	beq :+
	jmp @end
:	ldx len
	lda byte
	sta text,x
	inc len
	lda len
	cmp #MAXLEN
	beq @end
	lda st                  ; the end of the file: that was the last
	bne @end
	jmp @rd
@end:	X16K X16K_CLRCHN
	lda #LFN_IN
	X16K X16K_CLOSE
	lda len
	bne :+
	jmp NoFile              ; (no file: the drive said so with no bytes)
:

	; write X16CALL.OUT: "GEOS-X16 read: " and the text
	lda #outl
	ldx #<outname
	ldy #>outname
	X16K X16K_SETNAM
	lda #LFN_OUT
	ldx #8
	ldy #LFN_OUT
	X16K X16K_SETLFS
	X16K X16K_OPEN
	ldx #LFN_OUT
	X16K X16K_CHKOUT
	ldy #0
@p:	lda pre,y
	beq @t
	sty idx
	X16K X16K_CHROUT
	ldy idx
	iny
	bne @p
@t:	ldy #0
@w:	cpy len
	beq @wx
	sty idx
	lda text,y
	X16K X16K_CHROUT
	ldy idx
	iny
	bne @w
@wx:	X16K X16K_CLRCHN
	lda #LFN_OUT
	X16K X16K_CLOSE

	; the first line, for the dialog box
	ldy #$FF
@l:	iny
	cpy len
	beq @lz
	lda text,y
	cmp #13
	beq @lz
	cmp #10
	beq @lz
	cmp #' '
	bcs @l
	lda #' '                ; (other control bytes: a space)
	sta text,y
	jmp @l
@lz:	cpy #36                 ; (fits the box)
	bcc :+
	ldy #36
:	lda #0
	sta text,y
	lda #<dlg_ok
	ldx #>dlg_ok
	jmp Show

NoFile:	X16K X16K_CLRCHN
	lda #LFN_IN
	X16K X16K_CLOSE
	lda #<dlg_nofile
	ldx #>dlg_nofile
	jmp Show

NotX16:	lda #<dlg_nox16
	ldx #>dlg_nox16
Show:	sta r0L
	stx r0H
	jsr DoDlgBox
	jmp EnterDeskTop

	X16K_CODE

sig:	.byte "X16G"
inname:	.byte "HELLO.TXT"
inl = * - inname
outname: .byte "@:X16CALL.OUT,S,W"
outl = * - outname
pre:	.byte "GEOS-X16 read: ", 0

dlg_ok:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word o1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_2_Y
	.word text
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_3_Y
	.word o3
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
o1:	.byte BOLDON, "HELLO.TXT, from the SD card:", PLAINTEXT, 0
o3:	.byte "(and written to X16CALL.OUT)", 0

dlg_nofile:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word f1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_2_Y
	.word f2
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
f1:	.byte BOLDON, "No HELLO.TXT on the SD card.", PLAINTEXT, 0
f2:	.byte "Put one next to geosx16.bin.", 0

dlg_nox16:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word x1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_2_Y
	.word x2
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
x1:	.byte BOLDON, "This program needs GEOS-X16", PLAINTEXT, 0
x2:	.byte "(version 2 or newer).", 0

.segment "BSS"
len:	.res 1
byte:	.res 1
st:	.res 1
idx:	.res 1
text:	.res MAXLEN + 1
