#!/bin/sh
# SNES controller navigation (joy.s) in x16emu (Linux, needs Xvfb, xdotool,
# ImageMagick "import", python3): an x16emu built with
# tools/x16emu-testcards.patch, whose X16JOY file stands in for controller
# 1 (its buttons as hex, active low).  The host mouse is not touched.
#   A on the menu bar (the pointer starts there): a menu opens (mouseData
#   pressed, then released); left held: to the left edge; right with Y
#   (slow) for a second, and right alone for a second (faster: it speeds
#   up); down, then up.  Positions from memory dumps (mouseXPos,
#   mouseYPos), the controller let go first.
#   X16EMU=path/to/test-x16emu ./test_x16_joy.sh
set -e
cd "$(dirname "$0")"
HERE=$(pwd)
X16EMU=${X16EMU:-/tmp/x16emu-prn/x16emu}
X16ROM=${X16ROM:-/home/claude/ext/x16-rom/build/x16/rom.bin}
DISK=${DISK:-../disks/WORK.D64}
T=$HERE/build/test_joy
rm -rf $T; mkdir -p $T
cp geosx16.bin $T/
cp $DISK $T/GEOSDISK.D64
export DISPLAY=${DISPLAY:-:99} X16JOY=$T/joy X16ARGS="-dump RBV"
pgrep -x Xvfb >/dev/null || { Xvfb $DISPLAY -screen 0 1024x768x24 >/dev/null 2>&1 & sleep 1; }
. tools/x16ui.sh
# SNES buttons (bit numbers): B 0, Y 1, Up 4, Down 5, Left 6, Right 7, A 8
pad() { python3 -c "import sys; m=0xFFFF
for b in sys.argv[1:]: m &= ~(1 << int(b))
print('%04x' % m)" "$@" > $X16JOY; }
pos() { dumpmem m; python3 -c "
d = open('$T/m.bin', 'rb').read()
print(d[0x3A] | d[0x3B] << 8, d[0x3C], 'up' if d[0x8505] & 0x80 else 'down')"; }

pad
start
set -- $(pos); echo "start: $*"; X0=$1; Y0=$2
[ $Y0 -lt 14 ] || fail "the pointer is not on the menu bar: $X0 $Y0"
shot 1_start
echo "A: a menu"
pad 8; sleep 0.5; set -- $(pos); [ $3 = down ] || fail "A: not pressed"
pad; sleep 1; set -- $(pos); [ $3 = up ] || fail "A: not released"
shot 2_menu
python3 - $T/1_start.png $T/2_menu.png <<'P' || fail "no menu opened"
import sys
from PIL import Image, ImageChops
a, b = (Image.open(p).convert("L") for p in sys.argv[1:])
box = (0, 60, 400, 240)             # below the menu bar (screenshot: 2x, 40 above)
d = ImageChops.difference(a.crop(box), b.crop(box))
sys.exit(0 if sum(1 for v in d.getdata() if v > 30) > 2000 else 1)
P
echo "left held: to the left edge"
pad 6; sleep 3; pad; set -- $(pos); [ $1 -eq 0 ] || fail "left: at $1"
echo "right with Y (slow) for a second, then right alone for a second"
pad 7 1; sleep 1; pad; set -- $(pos); XS=$1
pad 6; sleep 3; pad; set -- $(pos); [ $1 -eq 0 ] || fail "left again: at $1"
pad 7; sleep 1; pad; set -- $(pos); XF=$1
echo "  slow: $XS, normal: $XF"
[ $XS -gt 10 ] && [ $XS -le 80 ] || fail "slow: $XS"
[ $XF -gt $(( XS * 2 )) ] || fail "normal not faster: $XF"
echo "down, then up"
set -- $(pos); Ya=$2
pad 5; sleep 0.5; pad; set -- $(pos); Yb=$2
pad 4; sleep 0.5; pad; set -- $(pos); Yc=$2
echo "  $Ya -> $Yb -> $Yc"
[ $Yb -gt $Ya ] && [ $Yc -lt $Yb ] || fail "down/up: $Ya $Yb $Yc"
shot 3_end
pkill -x "$(basename "$X16EMU")" || true
echo "PASS (screenshots in $T)"
