#!/bin/sh
# Desk accessory test of GEOS-X16 in x16emu: the preference manager is
# opened from the geos menu and closed again, twice.  When a desk accessory
# exits, the deskTop clears its variables at $0334-$03C3 with interrupts on;
# that area holds the X16's interrupt entry ($038B), so this hung before the
# deskTop's clearing loop was patched (X16_PatchAppl).  Afterwards the
# deskTop must be back and the pointer must still move.
#   X16EMU=path/to/x16emu X16ROM=path/to/rom.bin ./test_x16_da.sh
set -e
cd "$(dirname "$0")"
HERE=$(pwd)
X16EMU=${X16EMU:-/home/claude/ext/x16-emulator/x16emu}
X16ROM=${X16ROM:-/home/claude/ext/x16-rom/build/x16/rom.bin}
T=$HERE/build/test_da
export DISPLAY=${DISPLAY:-:99}
pgrep -x Xvfb >/dev/null || { Xvfb $DISPLAY -screen 0 1024x768x24 >/dev/null 2>&1 & sleep 1; }
. tools/x16ui.sh
pkill -x "$(basename "$X16EMU")" 2>/dev/null || true; sleep 1
[ -f dist/GEOS-X16/GEOSDISK.D64 ] || ./mkdist.sh >/dev/null
rm -rf $T; mkdir -p $T
cp geosx16.bin $T/
cp dist/GEOS-X16/GEOSDISK.D64 $T/

start
shot 0_desktop
for round in 1 2; do
  echo "round $round: geos menu > preference mgr, then EXIT"
  goto 10 6; click; sleep 1; goto 30 74; click; sleep 4; shot ${round}_open
  # the accessory keeps the pointer inside its window: corner, then EXIT
  rel -330 -210; rel 176 12; sleep 0.3; click; sleep 4; shot ${round}_closed
done
P1=$(gpos)
rel 40 30; sleep 0.5
P2=$(gpos)
echo "pointer $P1 -> $P2"
[ "$P1" != "none" ] && [ "$P1" != "$P2" ] || fail "the pointer does not move: interrupts stopped"
python3 - $T/2_open.png $T/2_closed.png <<'PY' || fail "the deskTop did not come back"
import sys
from PIL import Image, ImageChops
a = Image.open(sys.argv[1]).convert('RGB'); b = Image.open(sys.argv[2]).convert('RGB')
box = ImageChops.difference(a.crop((160, 180, 480, 300)), b.crop((160, 180, 480, 300))).getbbox()
sys.exit(0 if box else 1)
PY
pkill -x "$(basename "$X16EMU")" || true
echo "PASS (screenshots in $T)"
