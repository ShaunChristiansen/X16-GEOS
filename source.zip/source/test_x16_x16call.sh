#!/bin/sh
# GEOS-X16 call 9 (X16 KERNAL routines for GEOS programs) in x16emu (Linux,
# needs Xvfb, xdotool, ImageMagick "import", python3, ca65/ld65):
#   X16 FILES (apps/x16files.s) is put on a copy of drive A
#   (tools/mkx16app.py), with HELLO.TXT next to it.  It reads HELLO.TXT
#   through the X16 KERNAL (SETNAM, SETLFS, OPEN, CHKIN, CHRIN, READST,
#   CLRCHN, CLOSE), writes X16CALL.OUT (CHKOUT, CHROUT) and shows the first
#   line in a dialog box; OK goes back to the deskTop (GEOS's own disk
#   access must still work).  Then again without HELLO.TXT: its "no file"
#   box, and no X16CALL.OUT.  Screenshots go to build/test_x16call/.
#   X16EMU=path/to/x16emu X16ROM=path/to/rom.bin ./test_x16_x16call.sh
set -e
cd "$(dirname "$0")"
HERE=$(pwd)
X16EMU=${X16EMU:-/home/claude/ext/x16-emulator/x16emu}
X16ROM=${X16ROM:-/home/claude/ext/x16-rom/build/x16/rom.bin}
DISK=${DISK:-../disks/WORK.D64}
command -v ca65 >/dev/null 2>&1 || PATH=/home/claude/ext/cc65/bin:$PATH
T=$HERE/build/test_x16call
rm -rf $T; mkdir -p $T
cp geosx16.bin $T/
cp $DISK $T/GEOSDISK.D64
python3 tools/mkx16app.py $T/GEOSDISK.D64 >/dev/null
printf 'Hello from the SD card! 12345\r\nA second line.\r\n' > $T/HELLO.TXT
export DISPLAY=${DISPLAY:-:99}
pgrep -x Xvfb >/dev/null || { Xvfb $DISPLAY -screen 0 1024x768x24 >/dev/null 2>&1 & sleep 1; }

. tools/x16ui.sh
# X16 FILES (the 8th file: row 2, column 4); its box's OK
run() { goto 220 97; dclick; sleep 6; shot $1; goto 95 111; click; sleep 6; shot ${1}_after; }

start
echo "HELLO.TXT there"
run 1_read
[ -f $T/X16CALL.OUT ] || fail "no X16CALL.OUT"
printf 'GEOS-X16 read: Hello from the SD card! 12345\r\nA second line.\r\n' | cmp -s - $T/X16CALL.OUT \
  || fail "X16CALL.OUT: $(cat -v $T/X16CALL.OUT)"
echo "no HELLO.TXT"
rm $T/HELLO.TXT $T/X16CALL.OUT
run 2_nofile
[ -f $T/X16CALL.OUT ] && fail "X16CALL.OUT written without HELLO.TXT"
echo "and once more (the files were closed)"
printf 'Again!\r\n' > $T/HELLO.TXT
run 3_again
printf 'GEOS-X16 read: Again!\r\n' | cmp -s - $T/X16CALL.OUT || fail "X16CALL.OUT (again): $(cat -v $T/X16CALL.OUT)"
pkill -x "$(basename "$X16EMU")" || true
echo "PASS (screenshots in $T)"
