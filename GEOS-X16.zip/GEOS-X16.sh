#!/bin/sh
# GEOS-X16: GEOS 128 2.0 for the Commander X16 in x16emu R49 (40 and 80
# columns), on Linux or macOS: what GEOS-X16.BAT does on Windows.  Starts
# GEOS 128 (geos128x16.bin).  With GEOSX16SD.img in this folder (the SD card
# image, GEOS128A/B/C.D81 on it too) it runs from that image (SPI videos only
# play this way); without it, or as "./GEOS-X16.sh folder", GEOS128A.D81 (or
# .D64) in this folder is drive A, GEOS128B and GEOS128C B and C.
# x16emu (with its rom.bin) is looked for in this folder, the one above it,
# then on the PATH; or set X16EMU to its full path.
# Ctrl+M in the emulator window releases (and recaptures) the mouse.
cd "$(dirname "$0")" || exit 1
if [ -z "$X16EMU" ]; then
  if [ -x ./x16emu ]; then X16EMU=./x16emu
  elif [ -x ../x16emu ]; then X16EMU=../x16emu
  elif command -v x16emu >/dev/null 2>&1; then X16EMU=x16emu
  else echo "Cannot find x16emu. Put it in this folder or set X16EMU."; exit 1
  fi
fi
if [ ! -f geos128x16.bin ]; then
  echo "geos128x16.bin is missing: unzip the GEOS 128 zip into this folder."; exit 1
fi
if [ "$1" != folder ] && [ -f GEOSX16SD.img ]; then
  # Your own files in the C64GAMES folder here (C64 games, CHARGEN.BIN) go
  # onto the SD card image first: C64 GAMES reads them from there.
  if [ -d C64GAMES ] && [ -f tools/sdput.py ] && command -v python3 >/dev/null 2>&1; then
    python3 tools/sdput.py GEOSX16SD.img C64GAMES || true
  fi
  exec "$X16EMU" -cartbin geos128x16.bin -sdcard GEOSX16SD.img -rtc -scale 2 -capture "$@"
fi
[ "$1" = folder ] && shift
if [ ! -f GEOS128A.D64 ] && [ ! -f GEOS128A.D81 ]; then
  echo "GEOS128A.D64 or GEOS128A.D81 is missing: put a GEOS 128 2.0 disk image with 128 DESKTOP in this folder under one of those names."; exit 1
fi
exec "$X16EMU" -cartbin geos128x16.bin -rtc -scale 2 -capture "$@"
