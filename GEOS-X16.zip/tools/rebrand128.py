#!/usr/bin/env python3
"""rebrand128.py IMAGE ...  -- GEOS-X16 instead of "128" where GEOS 128's
programs show it: file names, menus, dialog boxes, info boxes.

   128 DESKTOP       -> X16 DESKTOP   (the kernel looks for X16 DESKTOP first
                                       and 128 DESKTOP after it: load1a.s)
   GEOWRITE 128      -> GEOWRITE X16
   GEOSPELL 128      -> GEOSPELL X16
   TEXT GRABBER 128  -> TEXT GRABBER X16

and the "128" in their texts (same length, so nothing in the code moves).

Left as they are:
 - each file's permanent name (its class, e.g. "GEOWRITE 128 V2.1" in the
   header block at $4D): documents keep the class of the program that made
   them, and programs find their own files by it;
 - Text Grabber's forms "WordWriter 128", "C128 Generic I/II": the names of
   C128 word processors' formats (Text Grabber looks for them by name);
 - "Cannot run 128 application on 64 kernal": only shown under GEOS 64;
 - documentation (ReadMe files, manuals), PostScript code.

Safe to run again: what is done already is left alone ("already")."""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import geosimg
from scan128 import streams

RENAME = {
    "128 DESKTOP": "X16 DESKTOP",
    "GEOWRITE 128": "GEOWRITE X16",
    "GEOSPELL 128": "GEOSPELL X16",
    "TEXT GRABBER 128": "TEXT GRABBER X16",
}

# (file (its new name), old text, new text, how many times)
TEXT = [
    ("X16 DESKTOP", b"with the 128 deskTop", b"with the X16 deskTop", 1),  # "Please insert a disk with the ..."
    ("X16 DESKTOP", b"\x00128 DESKTOP\x00", b"\x00X16 DESKTOP\x00", 1),      # its own file's name
    ("X16 DESKTOP", b"under 128 GEOS", b"under GEOS-X16", 1),              # "This program can't be run under ..."
    ("X16 DESKTOP", b"C128 Input Driver", b"X16 Input Driver ", 2),        # file types (info box)
    ("GEOWRITE X16", b"geoWrite (128 version)", b"geoWrite (X16 version)", 1),  # info box
    ("GEOWRITE X16", b"for the C128", b"for the X16 ", 1),                 # geoWrite info
    ("GEOSPELL X16", b"geoSpell 128 info", b"geoSpell X16 info", 1),       # geos menu
    ("TEXT GRABBER X16", b"Text Grabber 128", b"Text Grabber X16", 1),     # title
    ("photo manager", b"on a C128.", b"on an X16.", 1),
    ("text manager", b"on a C128.", b"on an X16.", 1),
    ("geoText", b"C64/C128", b"C64/X16 ", 1),
    ("pad color mgr", b"Input 128", b"Input X16", 1),                      # its file type list
    ("geoTheo", b"GEOS 64 and GEOS 128", b"GEOS 64 and GEOS-X16", 1),     # info box
] + [(f, b"Text Grabber 128", b"Text Grabber X16", 1)                    # the forms' info boxes
     for f in ("FleetSystem 4", "PaperClip II", "WordWriter 128", "C128 Generic I", "C128 Generic II")]

CLASS = range(0x4D, 0x4D + 20)          # header: the permanent name, untouched


def entry(img, name):
    for e in img.entries():
        if img.d[e + 2] and img.name_of(e) == name:
            return e


def rebrand(img):
    out = []
    for old, new in RENAME.items():
        e = entry(img, old)
        if e is not None:
            img.d[e + 5:e + 21] = new.encode().ljust(16, b"\xA0")
            out.append("%s -> %s" % (old, new))
        elif entry(img, new) is not None:
            out.append("%s already" % new)
    for f, old, new, n in TEXT:
        e = entry(img, f)
        if e is None:
            continue
        found = done = 0
        for lab, data, where in streams(img, e):
            if lab == "name":
                continue
            i = data.find(old)
            while i >= 0:
                if not (lab == "header" and i in CLASS):
                    for k, b in enumerate(new):
                        img.d[where[i + k]] = b
                    found += 1
                i = data.find(old, i + 1)
            done += data.count(new)
        if found + done < n or found > n:
            raise SystemExit("%s: %r found %d times, wanted %d" % (f, old, found, n))
        out.append("%s: %s" % (f, "already" if found == 0 else new.decode("latin1").strip()))
    return out


def main():
    for path in sys.argv[1:]:
        img = geosimg.Image(open(path, "rb").read())
        r = rebrand(img)
        open(path, "wb").write(img.d)
        print("%s: %s" % (os.path.basename(path), "; ".join(r)))


if __name__ == "__main__":
    main()
