# Copies the files of a folder into the same folder on an SD card image.
#
#    powershell -File tools\sdput.ps1 GEOSX16SD.img C64GAMES
#
# GEOS-X16.BAT runs this at each start, so a game file dropped into C64GAMES
# next to it is on the SD card image when GEOS starts.  (GEOS-X16.sh runs
# sdput.py, the same thing step for step in Python: read that one first.)
#
# Only the folder's own files are looked at, not its subfolders.  A file the
# image has already, with the same contents, is left alone; one that differs
# is replaced; a new one is added.  Nothing is ever removed from the image.
# Before the first change the image is copied to GEOSX16SD.bak.
#
# The image is a FAT32 volume in the first partition.  The steps:
#   1. read the volume's layout and its FAT (the table of cluster chains)
#   2. find the folder in the root directory, and read its entries
#   3. for each file: compare, and if needed write its data into free
#      clusters and make or update its directory entry (in memory)
#   4. write back the folder, the FAT and the free cluster count
param([string]$Image, [string]$Folder)

$ErrorActionPreference = 'Stop'
$END_OF_CHAIN = 0x0FFFFFFF

# ------------------------------------------------------------ the volume
function Read-At([long]$at, [int]$count) {
    $buf = New-Object byte[] $count
    [void]$script:fs.Seek($at, 'Begin')
    [void]$script:fs.Read($buf, 0, $count)
    return ,$buf
}

function Write-At([long]$at, [byte[]]$buf, [int]$from, [int]$count) {
    [void]$script:fs.Seek($at, 'Begin')
    $script:fs.Write($buf, $from, $count)
}

function Get-Entry([long]$cluster) {
    $v = [long][BitConverter]::ToUInt32($script:fat, [int]($cluster * 4))
    return ($v -band 0x0FFFFFFF)
}

function Set-Entry([long]$cluster, [long]$value) {
    $b = [BitConverter]::GetBytes([uint32]$value)
    [Array]::Copy($b, 0, $script:fat, [int]($cluster * 4), 4)
}

# the clusters of the chain that starts at $first
function Get-Chain([long]$first) {
    $out = New-Object 'System.Collections.Generic.List[long]'
    $c = $first
    while ($c -ge 2 -and $c -lt 0x0FFFFFF8) {
        $out.Add($c)
        $c = Get-Entry $c
    }
    return ,$out
}

function Get-Offset([long]$cluster) {
    return ($script:dataAt + ($cluster - 2) * $script:clusterSize)
}

function Read-Chain([long]$first) {
    $chain = Get-Chain $first
    $data = New-Object byte[] ($chain.Count * $script:clusterSize)
    $n = 0
    foreach ($c in $chain) {
        $piece = Read-At (Get-Offset $c) $script:clusterSize
        [Array]::Copy($piece, 0, $data, $n * $script:clusterSize, $script:clusterSize)
        $n = $n + 1
    }
    return ,$data
}

function Free-Chain([long]$first) {
    $chain = Get-Chain $first
    foreach ($c in $chain) {
        Set-Entry $c 0
        $script:used = $script:used - 1
    }
}

function New-Cluster {
    $c = $script:nextFree
    while ($c -lt $script:clusters + 2) {
        if ((Get-Entry $c) -eq 0) {
            Set-Entry $c $END_OF_CHAIN
            $script:nextFree = $c + 1
            $script:used = $script:used + 1
            return $c
        }
        $c = $c + 1
    }
    throw 'The SD card image is full.'
}

# $size bytes of $data into new clusters; the first one's number
function Write-Data([byte[]]$data, [int]$size) {
    $first = 0
    $last = 0
    for ($at = 0; $at -lt $size; $at = $at + $script:clusterSize) {
        $c = New-Cluster
        $piece = New-Object byte[] $script:clusterSize
        $count = [Math]::Min($script:clusterSize, $size - $at)
        [Array]::Copy($data, $at, $piece, 0, $count)
        Write-At (Get-Offset $c) $piece 0 $script:clusterSize
        if ($last -ne 0) { Set-Entry $last $c } else { $first = $c }
        $last = $c
    }
    return $first
}

# ------------------------------------------------------------ a directory
# The directory's files -> $script:files (each: Long, Short, Index, IsDir)
# and the index of its first unused entry -> $script:end
function Read-Entries([byte[]]$dir) {
    $script:files = New-Object System.Collections.ArrayList
    $parts = @{}
    $count = [int]($dir.Length / 32)
    $script:end = $count
    for ($i = 0; $i -lt $count; $i = $i + 1) {
        $e = $i * 32
        if ($dir[$e] -eq 0) {
            $script:end = $i
            break
        }
        if ($dir[$e] -eq 0xE5) {                # a deleted entry
            $parts = @{}
            continue
        }
        if ($dir[$e + 11] -eq 0x0F) {           # a piece of a long name
            $chars = New-Object byte[] 26
            [Array]::Copy($dir, $e + 1, $chars, 0, 10)
            [Array]::Copy($dir, $e + 14, $chars, 10, 12)
            [Array]::Copy($dir, $e + 28, $chars, 22, 4)
            $parts[[int]($dir[$e] -band 0x3F)] = [Text.Encoding]::Unicode.GetString($chars)
            continue
        }
        if (($dir[$e + 11] -band 0x08) -eq 0) { # (not the volume's label)
            $long = ''
            foreach ($k in ($parts.Keys | Sort-Object)) { $long = $long + $parts[$k] }
            $zero = $long.IndexOf([char]0)
            if ($zero -ge 0) { $long = $long.Substring(0, $zero) }
            $latin = [Text.Encoding]::GetEncoding(28591)
            $base = $latin.GetString($dir, $e, 8).TrimEnd()
            $ext = $latin.GetString($dir, $e + 8, 3).TrimEnd()
            $short = $base
            if ($ext -ne '') { $short = $base + '.' + $ext }
            $file = New-Object PSObject -Property @{
                Long = $long; Short = $short; Index = $i
                IsDir = (($dir[$e + 11] -band 0x10) -ne 0)
            }
            [void]$script:files.Add($file)
        }
        $parts = @{}
    }
}

# the file of that name in $script:files, or $null
function Find-File([string]$name) {
    $upper = $name.ToUpper()
    foreach ($file in $script:files) {
        if ($file.Long.ToUpper() -eq $upper -or $file.Short.ToUpper() -eq $upper) {
            return $file
        }
    }
    return $null
}

function Get-FirstCluster([byte[]]$dir, [int]$index) {
    $hi = [long][BitConverter]::ToUInt16($dir, $index * 32 + 20)
    $lo = [long][BitConverter]::ToUInt16($dir, $index * 32 + 26)
    return ($hi * 65536 + $lo)
}

function Set-File([byte[]]$dir, [int]$index, [long]$cluster, [long]$size) {
    $hi = [BitConverter]::GetBytes([uint16][Math]::Floor($cluster / 65536))
    $lo = [BitConverter]::GetBytes([uint16]($cluster % 65536))
    $sz = [BitConverter]::GetBytes([uint32]$size)
    [Array]::Copy($hi, 0, $dir, $index * 32 + 20, 2)
    [Array]::Copy($lo, 0, $dir, $index * 32 + 26, 2)
    [Array]::Copy($sz, 0, $dir, $index * 32 + 28, 4)
}

# is NAME.EXT a short (8.3) name as it stands?
function Test-Short([string]$name) {
    $dot = $name.IndexOf('.')
    $base = $name
    $ext = ''
    if ($dot -ge 0) {
        $base = $name.Substring(0, $dot)
        $ext = $name.Substring($dot + 1)
    }
    if ($base.Length -lt 1 -or $base.Length -gt 8 -or $ext.Length -gt 3) { return $false }
    return (($base + $ext) -cmatch '^[A-Z0-9_-]+$')
}

# the 11 bytes of a short name in a directory entry: "GHOSTB~1PRG"
function Get-ShortField([string]$short) {
    $dot = $short.IndexOf('.')
    $base = $short
    $ext = ''
    if ($dot -ge 0) {
        $base = $short.Substring(0, $dot)
        $ext = $short.Substring($dot + 1)
    }
    $text = $base.PadRight(8) + $ext.PadRight(3)
    return ,([Text.Encoding]::ASCII.GetBytes($text))
}

# a short name nothing in the directory has: GHOSTB~1.PRG
function New-Short([string]$name) {
    $upper = $name.ToUpper()
    $dot = $upper.LastIndexOf('.')
    $base = $upper
    $ext = ''
    if ($dot -ge 0) {
        $base = $upper.Substring(0, $dot)
        $ext = $upper.Substring($dot + 1)
    }
    $base = $base -creplace '[^A-Z0-9_-]', ''
    $ext = $ext -creplace '[^A-Z0-9_-]', ''
    if ($ext.Length -gt 3) { $ext = $ext.Substring(0, 3) }
    $n = 1
    while ($true) {
        $tail = '~' + $n                        # (8 characters with the ~1)
        $keep = [Math]::Min($base.Length, 8 - $tail.Length)
        $short = $base.Substring(0, $keep) + $tail
        if ($ext -ne '') { $short = $short + '.' + $ext }
        $taken = $false
        foreach ($file in $script:files) {
            if ($file.Short.ToUpper() -eq $short) { $taken = $true }
        }
        if (-not $taken) { return $short }
        $n = $n + 1
    }
}

# The 32-byte directory entries for a new file: its long name's (if it
# needs one), then its own.  The short name used -> $script:newShort
function New-Entries([string]$name, [long]$cluster, [long]$size) {
    $now = Get-Date
    $date = ($now.Year - 1980) * 512 + $now.Month * 32 + $now.Day
    $clock = $now.Hour * 2048 + $now.Minute * 32 + [int][Math]::Floor($now.Second / 2)
    $pieces = 0
    if (Test-Short $name) {
        $short = $name
    } else {
        $short = New-Short $name
        $text = $name + [char]0
        while ($text.Length % 13 -ne 0) { $text = $text + [char]0xFFFF }
        $pieces = [int]($text.Length / 13)
    }
    $field = Get-ShortField $short
    $check = 0
    foreach ($b in $field) {
        $check = ((($check -shr 1) -bor (($check -band 1) -shl 7)) + $b) -band 0xFF
    }
    $out = New-Object byte[] (($pieces + 1) * 32)
    $e = 0
    for ($p = $pieces; $p -ge 1; $p = $p - 1) { # the last piece comes first
        $chars = [Text.Encoding]::Unicode.GetBytes($text.Substring(($p - 1) * 13, 13))
        $seq = $p
        if ($p -eq $pieces) { $seq = $p -bor 0x40 }
        $out[$e] = [byte]$seq
        [Array]::Copy($chars, 0, $out, $e + 1, 10)
        $out[$e + 11] = 0x0F
        $out[$e + 13] = [byte]$check
        [Array]::Copy($chars, 10, $out, $e + 14, 12)
        [Array]::Copy($chars, 22, $out, $e + 28, 4)
        $e = $e + 32
    }
    [Array]::Copy($field, 0, $out, $e, 11)
    $out[$e + 11] = 0x20
    $t = [BitConverter]::GetBytes([uint16]$clock)
    $d = [BitConverter]::GetBytes([uint16]$date)
    [Array]::Copy($t, 0, $out, $e + 14, 2)      # made
    [Array]::Copy($d, 0, $out, $e + 16, 2)
    [Array]::Copy($d, 0, $out, $e + 18, 2)      # last read
    [Array]::Copy($t, 0, $out, $e + 22, 2)      # last written
    [Array]::Copy($d, 0, $out, $e + 24, 2)
    Set-File $out $pieces $cluster $size
    $script:newShort = $short
    return ,$out
}

# ------------------------------------------------------------ the copying
function Copy-Folder {
    $imagePath = (Resolve-Path -LiteralPath $Image).Path
    $folderPath = (Resolve-Path -LiteralPath $Folder).Path
    $folderName = Split-Path -Leaf $folderPath
    $script:fs = [IO.File]::Open($imagePath, 'Open', 'ReadWrite', 'None')

    # 1. the volume's layout and its FAT
    $mbr = Read-At 0 512
    $part = [long][BitConverter]::ToUInt32($mbr, 446 + 8) * 512
    $boot = Read-At $part 512
    $sector = [long][BitConverter]::ToUInt16($boot, 11)
    $script:clusterSize = [int]($boot[13] * $sector)
    $reserved = [long][BitConverter]::ToUInt16($boot, 14)
    $fatCount = [int]$boot[16]
    $fatSize = [long][BitConverter]::ToUInt32($boot, 36) * $sector
    $root = [long][BitConverter]::ToUInt32($boot, 44)
    $infoAt = $part + [long][BitConverter]::ToUInt16($boot, 48) * $sector
    $fatAt = $part + $reserved * $sector
    $script:dataAt = $fatAt + $fatCount * $fatSize
    $total = [long][BitConverter]::ToUInt32($boot, 32) * $sector
    $script:clusters = [long][Math]::Floor(($part + $total - $script:dataAt) / $script:clusterSize)
    $script:fat = Read-At $fatAt ([int]$fatSize)
    $script:nextFree = [long]2                  # where to look for a free cluster
    $script:used = [long]0                      # clusters taken, less those freed

    # 2. the folder
    $rootData = Read-Chain $root
    Read-Entries $rootData
    $found = Find-File $folderName
    if ($found -eq $null -or -not $found.IsDir) {
        Write-Host "No folder $folderName on $Image : nothing copied."
        return
    }
    $dirFirst = Get-FirstCluster $rootData $found.Index
    $dir = Read-Chain $dirFirst
    Read-Entries $dir

    # 3. each file
    $changed = $false
    $md5 = [Security.Cryptography.MD5]::Create()
    foreach ($item in (Get-ChildItem -LiteralPath $folderPath -File | Sort-Object Name)) {
        $name = $item.Name
        $size = [int]$item.Length
        $data = [IO.File]::ReadAllBytes($item.FullName)
        $found = Find-File $name
        if ($found -ne $null -and $found.IsDir) { continue }    # (a folder of that name)
        $old = 0
        if ($found -ne $null) {
            $oldSize = [long][BitConverter]::ToUInt32($dir, $found.Index * 32 + 28)
            $old = Get-FirstCluster $dir $found.Index
            if ($oldSize -eq $size) {
                if ($size -eq 0) { continue }
                $have = Read-Chain $old
                if ($have.Length -ge $size) {
                    $a = [BitConverter]::ToString($md5.ComputeHash($have, 0, $size))
                    $b = [BitConverter]::ToString($md5.ComputeHash($data, 0, $size))
                    if ($a -eq $b) { continue }  # the image has it already
                }
            }
        }
        if (-not $changed) {
            $script:fs.Close()                  # the first change: a copy first
            Copy-Item -LiteralPath $imagePath -Destination ([IO.Path]::ChangeExtension($imagePath, '.bak')) -Force
            $script:fs = [IO.File]::Open($imagePath, 'Open', 'ReadWrite', 'None')
            $changed = $true
        }
        $first = 0
        if ($found -ne $null) {
            Free-Chain $old
            if ($size -gt 0) { $first = Write-Data $data $size }
            Set-File $dir $found.Index $first $size
            Write-Host "replaced on the SD card image: $name"
            continue
        }
        if ($size -gt 0) { $first = Write-Data $data $size }
        $entries = New-Entries $name $first $size
        $count = [int]($entries.Length / 32)
        while (($script:end + $count) * 32 -gt $dir.Length) {
            $chain = Get-Chain $dirFirst        # the folder grows a cluster
            $c = New-Cluster
            $lastOne = $chain[$chain.Count - 1]
            Set-Entry $lastOne $c
            $bigger = New-Object byte[] ($dir.Length + $script:clusterSize)
            [Array]::Copy($dir, 0, $bigger, 0, $dir.Length)
            $dir = $bigger
        }
        [Array]::Copy($entries, 0, $dir, $script:end * 32, $entries.Length)
        $file = New-Object PSObject -Property @{
            Long = $name; Short = $script:newShort; Index = $script:end + $count - 1; IsDir = $false
        }
        [void]$script:files.Add($file)
        $script:end = $script:end + $count
        Write-Host "added to the SD card image: $name"
    }

    # 4. the folder, the FAT (each copy), the free cluster count
    if ($changed) {
        $n = 0
        foreach ($c in (Get-Chain $dirFirst)) {
            Write-At (Get-Offset $c) $dir ($n * $script:clusterSize) $script:clusterSize
            $n = $n + 1
        }
        for ($n = 0; $n -lt $fatCount; $n = $n + 1) {
            Write-At ($fatAt + $n * $fatSize) $script:fat 0 ([int]$fatSize)
        }
        $info = Read-At $infoAt 512
        $free = [long][BitConverter]::ToUInt32($info, 488)
        $signed = ($info[0] -eq 0x52 -and $info[1] -eq 0x52 -and $info[2] -eq 0x61 -and $info[3] -eq 0x41)
        if ($signed -and $free -ne 4294967295) {
            $b = [BitConverter]::GetBytes([uint32]($free - $script:used))
            [Array]::Copy($b, 0, $info, 488, 4)
            Write-At $infoAt $info 0 512
        }
    }
}

try {
    Copy-Folder
} catch {
    Write-Host "Could not copy $Folder onto $Image : $($_.Exception.Message)"
    Write-Host "(GEOS starts all the same.  If the image is damaged, GEOSX16SD.bak is the copy from before.)"
} finally {
    if ($script:fs -ne $null) { $script:fs.Close() }
}
