#!/usr/bin/env python3
"""Copies the files of a folder into the same folder on an SD card image.

   sdput.py GEOSX16SD.img C64GAMES

GEOS-X16.sh runs this at each start, so a game file dropped into C64GAMES
next to it is on the SD card image when GEOS starts.  (GEOS-X16.BAT runs
sdput.ps1, the same thing step for step in PowerShell.)

Only the folder's own files are looked at, not its subfolders.  A file the
image has already, with the same contents, is left alone; one that differs
is replaced; a new one is added.  Nothing is ever removed from the image.
Before the first change the image is copied to GEOSX16SD.bak.

The image is a FAT32 volume in the first partition.  The steps:
  1. read the volume's layout and its FAT (the table of cluster chains)
  2. find the folder in the root directory, and read its entries
  3. for each file: compare, and if needed write its data into free
     clusters and make or update its directory entry (in memory)
  4. write back the folder, the FAT and the free cluster count
"""
import os
import shutil
import struct
import sys
import time

END_OF_CHAIN = 0x0FFFFFFF


class Volume:
    def __init__(self, f):
        self.f = f
        f.seek(446 + 8)                         # the first partition's start
        self.part = struct.unpack("<I", f.read(4))[0] * 512
        f.seek(self.part)
        boot = f.read(512)
        self.sector = struct.unpack_from("<H", boot, 11)[0]
        self.cluster_size = boot[13] * self.sector
        reserved = struct.unpack_from("<H", boot, 14)[0]
        self.fat_count = boot[16]
        self.fat_size = struct.unpack_from("<I", boot, 36)[0] * self.sector
        self.root = struct.unpack_from("<I", boot, 44)[0]
        self.info_at = self.part + struct.unpack_from("<H", boot, 48)[0] * self.sector
        self.fat_at = self.part + reserved * self.sector
        self.data_at = self.fat_at + self.fat_count * self.fat_size
        total = struct.unpack_from("<I", boot, 32)[0] * self.sector
        self.clusters = (self.part + total - self.data_at) // self.cluster_size
        f.seek(self.fat_at)
        self.fat = bytearray(f.read(self.fat_size))
        self.next_free = 2                      # where to look for a free cluster
        self.used = 0                           # clusters taken, less those freed

    def entry(self, cluster):
        return struct.unpack_from("<I", self.fat, cluster * 4)[0] & 0x0FFFFFFF

    def set_entry(self, cluster, value):
        struct.pack_into("<I", self.fat, cluster * 4, value)

    def chain(self, first):
        out = []
        c = first
        while 2 <= c < 0x0FFFFFF8:
            out.append(c)
            c = self.entry(c)
        return out

    def offset(self, cluster):
        return self.data_at + (cluster - 2) * self.cluster_size

    def read_chain(self, first):
        data = bytearray()
        for c in self.chain(first):
            self.f.seek(self.offset(c))
            data += self.f.read(self.cluster_size)
        return data

    def free_chain(self, first):
        for c in self.chain(first):
            self.set_entry(c, 0)
            self.used -= 1

    def new_cluster(self):
        c = self.next_free
        while c < self.clusters + 2:
            if self.entry(c) == 0:
                self.set_entry(c, END_OF_CHAIN)
                self.next_free = c + 1
                self.used += 1
                return c
            c += 1
        raise SystemExit("The SD card image is full.")

    def write_data(self, data):
        """data into new clusters; the first one's number (0: no data)"""
        first = 0
        last = 0
        for at in range(0, len(data), self.cluster_size):
            c = self.new_cluster()
            piece = data[at:at + self.cluster_size]
            self.f.seek(self.offset(c))
            self.f.write(piece + bytes(self.cluster_size - len(piece)))
            if last:
                self.set_entry(last, c)
            else:
                first = c
            last = c
        return first


def read_entries(dirdata):
    """The directory's files: (long name, short name, entry's index, is a
    folder), and the index of the first unused entry."""
    files = []
    long_parts = {}
    count = len(dirdata) // 32
    end = count
    for i in range(count):
        e = dirdata[i * 32:i * 32 + 32]
        if e[0] == 0:
            end = i
            break
        if e[0] == 0xE5:                        # a deleted entry
            long_parts = {}
            continue
        if e[11] == 0x0F:                       # a piece of a long name
            text = (e[1:11] + e[14:26] + e[28:32]).decode("utf-16-le")
            long_parts[e[0] & 0x3F] = text
            continue
        if not e[11] & 0x08:                    # (not the volume's label)
            long_name = "".join(long_parts[k] for k in sorted(long_parts))
            long_name = long_name.split("\0")[0]
            base = e[0:8].decode("latin-1").rstrip()
            ext = e[8:11].decode("latin-1").rstrip()
            short = base + ("." + ext if ext else "")
            files.append((long_name, short, i, bool(e[11] & 0x10)))
        long_parts = {}
    return files, end


def find(files, name):
    for long_name, short, index, is_dir in files:
        if name.upper() in (long_name.upper(), short.upper()):
            return index, is_dir
    return None


def first_cluster(dirdata, index):
    hi, = struct.unpack_from("<H", dirdata, index * 32 + 20)
    lo, = struct.unpack_from("<H", dirdata, index * 32 + 26)
    return hi << 16 | lo


def set_file(dirdata, index, cluster, size):
    struct.pack_into("<H", dirdata, index * 32 + 20, cluster >> 16)
    struct.pack_into("<H", dirdata, index * 32 + 26, cluster & 0xFFFF)
    struct.pack_into("<I", dirdata, index * 32 + 28, size)


SHORT_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-"


def fits_short(name):
    """is NAME.EXT a short (8.3) name as it stands?"""
    base, dot, ext = name.partition(".")
    return (1 <= len(base) <= 8 and len(ext) <= 3 and "." not in ext
            and all(ch in SHORT_CHARS for ch in base + ext))


def short_field(name):
    base, dot, ext = name.partition(".")
    return (base.ljust(8) + ext.ljust(3)).encode("latin-1")


def new_short(name, files):
    """a short name nothing in the directory has: GHOSTB~1.PRG"""
    upper = name.upper()
    dot = upper.rfind(".")
    base = upper if dot < 0 else upper[:dot]
    ext = "" if dot < 0 else upper[dot + 1:]
    base = "".join(ch for ch in base if ch in SHORT_CHARS)
    ext = "".join(ch for ch in ext if ch in SHORT_CHARS)[:3]
    taken = [short.upper() for long_name, short, index, is_dir in files]
    n = 1
    while True:
        tail = "~" + str(n)                     # (8 characters with the ~1)
        short = base[:8 - len(tail)] + tail + ("." + ext if ext else "")
        if short not in taken:
            return short
        n += 1


def new_entries(name, files, cluster, size):
    """the 32-byte directory entries for a new file: its long name's (if it
    needs one), then its own"""
    t = time.localtime()
    date = (t.tm_year - 1980) << 9 | t.tm_mon << 5 | t.tm_mday
    clock = t.tm_hour << 11 | t.tm_min << 5 | t.tm_sec // 2
    out = bytearray()
    if fits_short(name):
        short = name
    else:
        short = new_short(name, files)
        field = short_field(short)
        check = 0
        for b in field:
            check = ((check >> 1) | (check & 1) << 7) + b & 0xFF
        text = name + "\0"
        while len(text) % 13:
            text += "￿"
        pieces = len(text) // 13
        for p in range(pieces, 0, -1):          # the last piece comes first
            chars = text[(p - 1) * 13:p * 13].encode("utf-16-le")
            seq = p | (0x40 if p == pieces else 0)
            out += bytes([seq]) + chars[0:10] + bytes([0x0F, 0, check]) \
                + chars[10:22] + bytes(2) + chars[22:26]
    e = bytearray(32)
    e[0:11] = short_field(short)
    e[11] = 0x20
    struct.pack_into("<HHH", e, 14, clock, date, date)
    struct.pack_into("<HH", e, 22, clock, date)
    out += e
    set_file(out, len(out) // 32 - 1, cluster, size)
    return out, short


def main(image, folder):
    names = sorted(n for n in os.listdir(folder) if os.path.isfile(os.path.join(folder, n)))
    f = open(image, "r+b")
    vol = Volume(f)
    root_files, root_end = read_entries(vol.read_chain(vol.root))
    found = find(root_files, os.path.basename(folder))
    if not found or not found[1]:
        print("No folder %s on %s: nothing copied." % (os.path.basename(folder), image))
        return
    root_data = vol.read_chain(vol.root)
    dir_first = first_cluster(root_data, found[0])
    dirdata = vol.read_chain(dir_first)
    files, end = read_entries(dirdata)

    changed = False
    for name in names:
        data = open(os.path.join(folder, name), "rb").read()
        found = find(files, name)
        if found and found[1]:
            continue                            # (a folder of that name)
        if found:
            index = found[0]
            size, = struct.unpack_from("<I", dirdata, index * 32 + 28)
            old = first_cluster(dirdata, index)
            if size == len(data) and vol.read_chain(old)[:size] == data:
                continue                        # the image has it already
        if not changed:
            f.close()                           # the first change: a copy first
            shutil.copyfile(image, os.path.splitext(image)[0] + ".bak")
            f = open(image, "r+b")
            vol.f = f
            changed = True
        if found:
            vol.free_chain(old)
            set_file(dirdata, index, vol.write_data(data), len(data))
            print("replaced on the SD card image:", name)
            continue
        entries, short = new_entries(name, files, vol.write_data(data), len(data))
        while (end + len(entries) // 32) * 32 > len(dirdata):
            c = vol.new_cluster()               # the folder grows a cluster
            vol.set_entry(vol.chain(dir_first)[-1], c)
            dirdata += bytes(vol.cluster_size)
        dirdata[end * 32:end * 32 + len(entries)] = entries
        files.append((name, short, end + len(entries) // 32 - 1, False))
        end += len(entries) // 32
        print("added to the SD card image:", name)

    if not changed:
        return
    for n, c in enumerate(vol.chain(dir_first)):    # the folder
        f.seek(vol.offset(c))
        f.write(dirdata[n * vol.cluster_size:(n + 1) * vol.cluster_size])
    for n in range(vol.fat_count):                  # the FAT, each copy
        f.seek(vol.fat_at + n * vol.fat_size)
        f.write(vol.fat)
    f.seek(vol.info_at)                             # the free cluster count
    info = bytearray(f.read(512))
    free, = struct.unpack_from("<I", info, 488)
    if info[0:4] == b"RRaA" and free != 0xFFFFFFFF:
        struct.pack_into("<I", info, 488, free - vol.used)
        f.seek(vol.info_at)
        f.write(info)
    f.close()


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    main(sys.argv[1], sys.argv[2])
