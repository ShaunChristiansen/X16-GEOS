#!/usr/bin/env python3
"""Makes a GEOS 128 80-column wallpaper (a .W80 file) from a GEOS-X16
wallpaper (a 320x200 BMX, with or without its colour cycling):

   mkw80.py PICTURE.BMX [OUT.W80] [--preview PREVIEW.png] [--gif ANIM.gif]
   mkw80.py --all DIR      every DIR/*.BMX -> DIR/*.W80 (and NAME-80.png)

GEOS-X16 shows NAME.W80 on GEOS 128's 80-column deskTop when NAME.BMX is the
wallpaper: it loads it with the BMX, from the same place.  80 columns has no
room in VERA for 256 colours at 640 wide (its 128K holds the VDC's RAM and
a copy of the screen too), so the picture is VERA layer 0 in 4bpp tiles of
16 x 8 pixels (40 x 25 = 1000 places, at most 856 different tiles), each
place in one of 15 palette rows (palette offset p = 1..15, 15 colours each:
entries 16p+1..16p+15).  The BMX's colour cycling ranges stay where the BMX
has them (12 entries 16p+4..16p+15 of a row), so the water and the stars
move just as in 40 columns; a cycling row's entries 16p+1..16p+3 are 3 more
colours.  Each pixel's colour is taken over all the cycling's frames, so
moving and still pixels are matched as they look, frame by frame.  Ordered
dithering (the same pattern in every tile, so like tiles stay alike).

The file (a PRG: load address $A000, then what goes to RAM bank 57 at
$A000 and on through the banks, at most 57344 bytes):
   $0000  "GXW8", version 2, tiles (2 bytes), jiffies a step, ranges (0-8),
          then first entry and length of each range (8 pairs)  (32 bytes)
   $0020  256 colours (VERA: green/blue, red), entry 16p+k
   $0220  the map: 40 x 25 entries (VERA: tile number, palette offset in
          bits 12-15)
   $09F0  the tiles, 64 bytes each (4bpp, 16 x 8, left pixel high nibble)"""
import math, os, sys
import numpy as np
from PIL import Image

W, H = 640, 200
TW, TH = 16, 8
CX, CY = W // TW, H // TH          # 40 x 25
MAXT = (57344 - 0x9F0) // 64       # 856 tiles
MAXF = 64
ITERS = int(os.environ.get("W80_ITERS", 12))
WMOVE = float(os.environ.get("W80_WMOVE", 4))
DITHER = float(os.environ.get("W80_DITHER", 1.0))
DUP = int(os.environ.get("W80_DUP", 1))
BAYER = (np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]) + 0.5) / 16.0


def read_bmx(path):
    d = open(path, "rb").read()
    if d[:3].lower() != b"bmx" or d[4] != 8 or d[6] | d[7] << 8 != 320 or d[8] | d[9] << 8 < 200:
        raise SystemExit(path + ": not a 320 wide 8 bit BMX")
    pal = np.zeros((256, 3))
    n = d[10] or 256
    for i in range(n):
        e = d[11] + i
        if e < 256:
            gb, r = d[32 + 2 * i], d[33 + 2 * i]
            pal[e] = (r & 15, gb >> 4, gb & 15)
    off = d[12] | d[13] << 8
    ext = d[32 + 2 * n:off]
    cyc, jif = [], 8
    if ext[:4] == b"GXCY":
        jif, k = ext[4] or 8, ext[5]
        for i in range(min(k, 8)):
            f, ln = ext[6 + 2 * i], ext[7 + 2 * i]
            if ln >= 2 and 4 <= (f & 15) and (f & 15) + ln <= 16:
                cyc.append((f, ln))
    h = d[8] | d[9] << 8
    skip = (h - 200) // 2
    idx = np.frombuffer(d[off + 320 * skip:off + 320 * (skip + 200)], dtype=np.uint8).reshape(200, 320)
    return idx, pal, cyc, jif


def frames_of(pal, cyc):
    """the palette at each step (helper.s Cycle: entry first + i shows the
    picture's colour first + (i + step) mod length)"""
    n = 1
    for _, ln in cyc:
        n = n * ln // math.gcd(n, ln)
    n = min(n, MAXF)
    out = []
    for p in range(n):
        q = pal.copy()
        for f, ln in cyc:
            for i in range(ln):
                q[f + i] = pal[f + (i + p) % ln]
        out.append(q)
    return out


def nearest(px, cols):
    """px (N, D), cols (K, D) -> index (N)"""
    return np.argmin(((px[:, None, :] - cols[None]) ** 2).sum(-1), 1)


def make(bmx, out, preview=None, gif=None, quiet=False):
    idx, pal, cyc, jif = read_bmx(bmx)
    fr = frames_of(pal, cyc)
    nf = len(fr)
    D = 3 * nf
    # each pixel's colours over the frames, 640 wide (each pixel twice)
    traj = np.concatenate(fr, 1)                           # (256, D): an entry's frames
    X = np.repeat(traj[idx], 2, axis=1)                    # (200, 640, D)
    tiles = X.reshape(CY, TH, CX, TW, D).transpose(0, 2, 1, 3, 4).reshape(CX * CY, TH * TW, D)
    moves = traj.reshape(256, nf, 3).std(1).sum(1) > 0.3
    moving = np.repeat(moves[idx], 2, axis=1)
    wt = (1.0 + WMOVE * moving).reshape(CY, TH, CX, TW).transpose(0, 2, 1, 3).reshape(CX * CY, TH * TW)
    # the rows: a cycling range keeps its 12 entries (their frames as the BMX
    # has them); every other entry of rows 1..15 is free
    rng = np.random.default_rng(1)
    C = np.zeros((16, 16, D))                              # row, k -> colour
    free = np.zeros((16, 16), bool)
    free[1:, 1:] = True
    # a cycling range in its own row, and (up to 8 ranges) in a second row
    # too: the tiles with a star or a ripple then have 6 colours of their
    # own besides the range's, in two sets
    rowsof = {}
    used = {f >> 4 for f, _ in cyc}
    spare = [r for r in range(15, 0, -1) if r not in used]
    xcyc = list(cyc)
    ncyc = len(cyc)
    for f, ln in cyc:
        if len(xcyc) < 8 and spare and DUP:
            r2 = spare.pop(0)
            xcyc.append((16 * r2 + (f & 15), ln))
            rowsof[r2] = f
    for f, ln in xcyc:
        src = rowsof.get(f >> 4, f)
        for i in range(ln):
            C[f >> 4, (f & 15) + i] = traj[src + i]
            free[f >> 4, (f & 15) + i] = False
    cyc = xcyc
    # start: a cycling row from the tiles that have its range's pixels, the
    # other rows from groups of tiles alike in colour (k-means on their
    # mean colours); each row's free colours from k-means on its tiles'
    # pixels
    tix = np.repeat(idx, 2, axis=1).reshape(CY, TH, CX, TW).transpose(0, 2, 1, 3).reshape(CX * CY, -1)
    mean = (tiles * wt[..., None]).sum(1) / wt.sum(1)[:, None]
    group = np.full(CX * CY, -1)
    crow = []
    for f, ln in cyc[:len(cyc) - (len(cyc) - ncyc)]:
        r = f >> 4
        has = ((tix >= f) & (tix < f + ln)).sum(1)
        group[(has > 0) & (group < 0)] = r
        crow.append(r)
    for f, ln in cyc[ncyc:]:          # the copies: half of their range's tiles
        r = f >> 4
        src = rowsof[r] >> 4
        m = np.nonzero(group == src)[0]
        if len(m) > 1:
            o = np.argsort(mean[m].sum(1))
            group[m[o[len(m) // 2:]]] = r
    srows = [r for r in range(1, 16) if free[r].sum() == 15]
    rest = np.nonzero(group < 0)[0]
    if len(rest) and srows:
        k = min(len(srows), len(rest))
        cent = mean[rest[rng.choice(len(rest), k, replace=False)]]
        for _ in range(20):
            a = nearest(mean[rest], cent)
            for j in range(k):
                if (a == j).any():
                    cent[j] = mean[rest][a == j].mean(0)
        a = nearest(mean[rest], cent)
        for j in range(k):
            group[rest[a == j]] = srows[j]
    for r in range(1, 16):
        n = free[r].sum()
        if not n:
            continue
        m = group == r
        px = tiles[m].reshape(-1, D) if m.any() else tiles[rng.integers(len(tiles))]
        cc = px[rng.choice(len(px), n, replace=len(px) < n)].copy()
        for _ in range(8):
            a = nearest(px, cc)
            for j in range(n):
                if (a == j).any():
                    cc[j] = px[a == j].mean(0)
        C[r, free[r]] = cc
    asg = np.zeros(CX * CY, int)
    for it in range(ITERS + 1):
        # each tile: the row with the least error (nearest colour)
        err = np.empty((len(tiles), 16))
        err[:, 0] = np.inf
        for r in range(1, 16):
            e = ((tiles[:, :, None, :] - C[r, 1:][None, None]) ** 2).sum(-1).min(-1)
            err[:, r] = (e * wt).sum(1)
        asg = np.argmin(err, 1)
        if it == ITERS:
            break
        # each row's free colours: k-means over its tiles' pixels
        for r in range(1, 16):
            m = asg == r
            if not m.any():
                worst = np.argmax(err[np.arange(len(tiles)), asg])
                C[r, free[r]] = tiles[worst][rng.choice(TH * TW, free[r].sum())]
                continue
            px = tiles[m].reshape(-1, D)
            w = wt[m].reshape(-1)
            a = nearest(px, C[r, 1:]) + 1
            for k in range(1, 16):
                if not free[r, k]:
                    continue
                mm = a == k
                if mm.any():
                    C[r, k] = (px[mm] * w[mm, None]).sum(0) / w[mm].sum()
                else:                    # unused: the pixel worst served
                    e = ((px[:, None, :] - C[r, 1:][None]) ** 2).sum(-1).min(1) * w
                    C[r, k] = px[np.argmax(e)]
        C = np.where(free[..., None], np.clip(np.round(C), 0, 15), C)
    # pixels: ordered dithering between a pixel's two nearest colours of
    # its tile's row
    pix = np.zeros((CX * CY, TH * TW), np.uint8)
    by = np.tile(BAYER, (TH // 4, TW // 4)).reshape(-1)    # (128)
    for t in range(len(tiles)):
        cols = C[asg[t], 1:]
        px = tiles[t]
        dd = ((px[:, None, :] - cols[None]) ** 2).sum(-1)  # (128, 15)
        o = np.argsort(dd, 1)
        k0, k1 = o[:, 0], o[:, 1]
        c0, c1 = cols[k0], cols[k1]
        ab = c1 - c0
        l2 = (ab * ab).sum(1)
        tt = np.where(l2 > 0, ((px - c0) * ab).sum(1) / np.maximum(l2, 1e-9), 0)
        # only where px lies between the two (not a colour far from both)
        between = ((px - (c0 + tt[:, None] * ab)) ** 2).sum(1) < dd[np.arange(len(px)), k0]
        k = np.where(between & (tt * DITHER > by), k1, k0)
        pix[t] = k + 1
    # at most MAXT different tiles: the rarest go to their most alike
    keys, uniq = {}, []
    tmap = np.zeros(CX * CY, int)
    for t in range(len(tiles)):
        kb = pix[t].tobytes()
        if kb not in keys:
            keys[kb] = len(uniq)
            uniq.append(t)
        tmap[t] = keys[kb]
    merged = 0
    if len(uniq) > MAXT:
        U = np.array([pix[t] for t in uniq])                 # (n, 128) values 1-15
        n = len(uniq)
        places = [np.nonzero(tmap == v)[0] for v in range(n)]
        def cost_to(v, cand):
            """error if tile v's places showed tile u instead, for u in cand"""
            c = np.zeros(len(cand))
            for t in places[v]:
                shownc = C[asg[t]][U[cand]]                  # (k, 128, D)
                e = ((shownc - tiles[t][None]) ** 2).sum(-1) * wt[t][None]
                c += e.sum(1)
            own = sum((((C[asg[t]][U[v]] - tiles[t]) ** 2).sum(-1) * wt[t]).sum() for t in places[v])
            return c - own
        alive = np.ones(n, bool)
        best = np.zeros(n)
        bt = np.zeros(n, int)
        def refresh(v):
            live = np.nonzero(alive)[0]
            live = live[live != v]
            c = cost_to(v, live)
            j = int(np.argmin(c))
            best[v], bt[v] = c[j], live[j]
        for v in range(n):
            refresh(v)
        while alive.sum() > MAXT:
            live = np.nonzero(alive)[0]
            v = live[np.argmin(best[live])]
            if not alive[bt[v]]:
                refresh(v)
                continue
            u = bt[v]
            tmap[places[v]] = u
            places[u] = np.concatenate([places[u], places[v]])
            merged += len(places[v])
            places[v] = np.array([], int)
            alive[v] = False
            refresh(u)
            for w in np.nonzero(alive & (bt == v))[0]:
                refresh(w)
        live = np.nonzero(alive)[0]
        ren = {v: i for i, v in enumerate(live)}
        tmap = np.array([ren[v] for v in tmap])
        uniq = [uniq[v] for v in live]
    ntiles = len(uniq)
    # the file
    hdr = bytearray(32)
    hdr[0:4] = b"GXW8"
    hdr[4] = 2
    hdr[5], hdr[6] = ntiles & 255, ntiles >> 8
    hdr[7] = jif
    hdr[8] = len(cyc)
    for i, (f, ln) in enumerate(cyc):
        hdr[9 + 2 * i], hdr[10 + 2 * i] = f, ln
    palb = bytearray(512)
    for r in range(1, 16):
        for k in range(1, 16):
            e = 16 * r + k
            c = [int(v) for v in C[r, k, 0:3]]
            palb[2 * e], palb[2 * e + 1] = (c[1] << 4) | c[2], c[0]
    mapb = bytearray(2 * CX * CY)
    for t in range(CX * CY):
        n = int(tmap[t])
        mapb[2 * t] = n & 255
        mapb[2 * t + 1] = (int(asg[t]) << 4) | (n >> 8)
    tb = bytearray()
    for u in uniq:
        q = pix[u].reshape(TH, TW)
        for y in range(TH):
            for x in range(0, TW, 2):
                tb.append((int(q[y, x]) << 4) | int(q[y, x + 1]))
    data = bytes([0x00, 0xA0]) + hdr + palb + mapb + tb
    assert len(data) - 2 <= 57344
    open(out, "wb").write(data)
    # what VERA shows, frame by frame
    shown = np.zeros((nf, H, W, 3))
    for t in range(CX * CY):
        ty, tx = divmod(t, CX)
        v = C[asg[t]][pix[uniq[tmap[t]]]].reshape(TH, TW, nf, 3).transpose(2, 0, 1, 3)
        shown[:, ty * TH:ty * TH + TH, tx * TW:tx * TW + TW] = v
    err = np.abs(shown.transpose(1, 2, 0, 3).reshape(H, W, D) - X).mean()
    if preview or gif:
        ims = [Image.fromarray((shown[f] * 17).astype(np.uint8)).resize((640, 400), Image.NEAREST)
               for f in range(nf)]
        if preview:
            ims[0].save(preview)
        if gif:
            ims[0].save(gif, save_all=True, append_images=ims[1:],
                        duration=max(20, jif * 1000 // 60), loop=0)
    if not quiet:
        print("%s: %d frame(s), %d different tiles%s, mean error %.2f/15 -> %s (%d bytes)"
              % (os.path.basename(bmx), nf, ntiles,
                 " (%d places merged)" % merged if merged else "", err, out, len(data)))


def main(argv):
    if not argv:
        print(__doc__)
        return 1
    if argv[0] == "--all":
        d = argv[1]
        for n in sorted(os.listdir(d)):
            if n.upper().endswith(".BMX"):
                b = os.path.join(d, n)
                stem = os.path.splitext(b)[0]
                make(b, stem + ".W80", stem + "-80.png")
        return 0
    bmx = argv[0]
    out = argv[1] if len(argv) > 1 and not argv[1].startswith("--") else os.path.splitext(bmx)[0] + ".W80"
    pv = argv[argv.index("--preview") + 1] if "--preview" in argv else None
    gf = argv[argv.index("--gif") + 1] if "--gif" in argv else None
    make(bmx, out, pv, gf)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
