#!/usr/bin/env python3
"""Shaun's colours as GEOS 128's defaults: the files preference mgr's and
pad color mgr's SAVE write ("Preferences", "Pad Color Pref", system files
GEOS reads as it boots), on a disk.

   prefs128.py TEMPLATE.D64 DISK.D64|D81

TEMPLATE: a disk where both were saved (their headers are taken from it);
their contents are then set here:
  Preferences (72 bytes): mouse max speed, min speed, acceleration; the
     colours (3 bytes); the pointer's picture (64 bytes, as GEOS has it);
     the 80-column colours (VDC register 26, and 24's bit 6)
  Pad Color Pref (9 bytes): 18 colours, two to a byte (low nibble first):
     the 16 file types' (GEOS types 0-15), then the pad's background and
     foreground
Colours are the C64's (0 black, 1 white, 4 purple, 6 blue, 14 light blue,
15 light grey)."""
import os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import geosimg

LTGREY, WHITE, BLACK, PURPLE, BLUE, LTBLUE = 15, 1, 0, 4, 6, 14

# file types: all light grey, but desk accessories purple, applications blue
TYPES = [LTGREY] * 16
TYPES[5] = PURPLE
TYPES[6] = BLUE
PAD_BG, PAD_FG = WHITE, BLUE
# preference mgr: border black, background white, foreground light blue,
# mouse blue
BORDER, BACK, FORE, MOUSE = BLACK, WHITE, LTBLUE, BLUE
PREFCOL = bytes([(FORE << 4) | BORDER, BACK, MOUSE])
# 80 columns (the last 2 bytes: the deskTop puts them in scr80colors and
# scr80polar's bit 6, VDC registers 26 and 24): white paper, dark blue
# writing (VDC colours 15, 2; not reversed: the low nibble is the paper,
# and the border, as the VDC does it)
SCR80 = bytes([0x2F, 0x00])


def pad_bytes():
    c = TYPES + [PAD_BG, PAD_FG]
    return bytes(c[2 * i] | c[2 * i + 1] << 4 for i in range(9))


def put(img, name, data):
    for e in img.entries():
        if img.d[e + 2] and img.name_of(e) == name:
            t, s = img.d[e + 3], img.d[e + 4]
            o = img.off(t, s)
            assert img.d[o] == 0 and img.d[o + 1] - 1 >= len(data), name
            img.d[o + 2:o + 2 + len(data)] = data
            return
    raise SystemExit("no %s" % name)


def main():
    tpl = geosimg.Image(open(sys.argv[1], "rb").read())
    img = geosimg.Image(open(sys.argv[2], "rb").read())
    for n in ("Preferences", "Pad Color Pref"):
        if any(img.d[e + 2] and img.name_of(e) == n for e in img.entries()):
            geosimg.remove_file(img, n)
        geosimg.copy_file(tpl, img, n)
    o = None
    for e in img.entries():
        if img.d[e + 2] and img.name_of(e) == "Preferences":
            o = img.off(img.d[e + 3], img.d[e + 4])
    img.d[o + 2 + 3:o + 2 + 6] = PREFCOL
    img.d[o + 2 + 70:o + 2 + 72] = SCR80
    put(img, "Pad Color Pref", pad_bytes())
    open(sys.argv[2], "wb").write(img.d)
    print("%s: Preferences colours %s, 80 columns %s, Pad Color Pref %s" % (sys.argv[2], PREFCOL.hex(" "), SCR80.hex(" "), pad_bytes().hex(" ")))


if __name__ == "__main__":
    main()
