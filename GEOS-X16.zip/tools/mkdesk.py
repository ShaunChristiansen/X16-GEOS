#!/usr/bin/env python3
"""Plain coloured deskTops: the deskTop's own checker pattern in two colours,
as a wallpaper pair (NAME.BMX for 40 columns, NAME.W80 for 80 columns).
Windows, menus and icons stay as GEOS draws them; only the deskTop's
pattern area takes the colours (the wallpaper shows where the pattern is).

   mkdesk.py OUTDIR          all of them
   mkdesk.py OUTDIR NAME     one

The W80 is written directly (one 16 x 8 tile, palette row 1), see mkw80.py
for the format."""
import os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mkwall

# name: (dark, light), VERA 4-bit r, g, b
DESKS = {
    "DESKBLUE":   ((3, 5, 11), (7, 9, 15)),
    "DESKTEAL":   ((1, 7, 8), (5, 11, 11)),
    "DESKGREEN":  ((2, 7, 3), (6, 11, 6)),
    "DESKPURPLE": ((5, 3, 9), (9, 7, 13)),
    "DESKAMBER":  ((9, 5, 2), (13, 9, 5)),
    "DESKGEOS64": ((4, 4, 4), (9, 9, 9)),   # GEOS 64's grey 68 / 153
}


def bmx(dark, light, path):
    colours = [(0, 0, 0)] * 256
    colours[16], colours[17] = dark, light
    idx = bytearray(320 * 200)
    for y in range(200):
        for x in range(320):
            idx[y * 320 + x] = 16 + ((x + y) & 1)
    mkwall.write_bmx(idx, colours, path)


def w80(dark, light, path):
    hdr = bytearray(32)
    hdr[0:4] = b"GXW8"
    hdr[4] = 2
    hdr[5], hdr[6] = 1, 0          # one tile
    hdr[7] = 8
    pal = bytearray(512)
    for k, (r, g, b) in ((1, dark), (2, light)):
        e = 16 + k
        pal[2 * e], pal[2 * e + 1] = (g << 4) | b, r
    mp = bytearray()
    for _ in range(40 * 25):
        mp += bytes([0, 1 << 4])   # tile 0, palette offset 1
    tile = bytearray()
    for y in range(8):
        for x in range(0, 16, 2):
            a = 1 + ((x + y) & 1)
            b = 1 + ((x + 1 + y) & 1)
            tile.append((a << 4) | b)
    open(path, "wb").write(bytes([0x00, 0xA0]) + hdr + pal + mp + tile)


def main():
    out = sys.argv[1]
    names = sys.argv[2:] or list(DESKS)
    os.makedirs(out, exist_ok=True)
    for n in names:
        d, l = DESKS[n]
        bmx(d, l, os.path.join(out, n + ".BMX"))
        w80(d, l, os.path.join(out, n + ".W80"))
        print(n)


if __name__ == "__main__":
    main()
