#!/usr/bin/env python3
"""The Oasis BBS in the terminal programs on GEOS disk images, so it can be
picked instead of typed in.

   bbsbook.py IMAGE...

geoTelnet 1.3 (Bo Zimmerman): an entry in its Telnet Server Phonebook.
  geoTelnet keeps the phonebook in its own file: VLIR records after its code
  that start with "PH", each holding three entries of 84 bytes (the name, a
  zero, the host:port, a zero).  It looks from record 1 on and stops at the
  first empty record.  (Its source, S/geoTelConn on its disk: FirstPhNm,
  MkOldHost.)

GeoTerm64 V2.0: function key 8 of its first key set (the set it loads at
  start) dials it: ATDoasisbbs.hopto.org:6400 and Return, so Commodore/8 in
  terminal mode.  Its phone book can't hold the address: a number there is
  20 characters at most (it was made for phone numbers), and the address is
  23.  A key holds 26 and a Return, and ATD is enough (the T of ATDT is
  optional for Zimodem and for GEOS-X16's Calypso modem).  Key sets are
  VLIR records 20 to 29: the set's name, then 8 keys of 28 bytes (the text,
  a Return if wanted, a zero).

Each is done once (already there: left as it is), and only to the version
described here: anything unexpected stops it."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import geosimg

BBS_NAME = b"The Oasis BBS"
BBS_HOST = b"oasisbbs.hopto.org:6400"

INFO_CLASS = 0x4D               # the info block's class (name and version)

# geoTelnet's phonebook
GEOTELNET_CLASS = b"geoTelnet   1.3 "
PHONEBOOK_MARK = b"PH"
ENTRY_BYTES = 84
ENTRIES = 3                     # a record: the mark and three entries, 254 bytes
EMPTY_RECORD = (0, 0xFF)        # a VLIR record with nothing in it

# GeoTerm64's function keys
GEOTERM_CLASS = b"GeoTerm64   V2.0"
FIRST_KEY_SET = 20              # its VLIR record
KEY_SET_BYTES = 254
KEYS_AT = 28                    # after the set's name
KEY_BYTES = 28
OASIS_KEY = 8
OASIS_DIAL = b"ATD" + BBS_HOST + b"\r"


def find(img, name):
    """The directory slot of the file called name (None: not there)."""
    for e in img.entries():
        if img.d[e + geosimg.DIR_TYPE] and img.name_of(e) == name:
            return e
    return None


def check_class(img, e, want):
    """Stops unless the file in slot e is the program and version wanted."""
    got = bytes(img.block(*img.info_block(e))[INFO_CLASS:INFO_CLASS + len(want)])
    if got != want:
        raise SystemExit("%s is %r, not %r" % (img.name_of(e), got, want))


def record(img, e, number):
    """Where VLIR record number of the file in slot e starts (track, sector):
    (0, $FF) for an empty one."""
    index = img.block(*img.first_block(e))
    return index[2 + 2 * number], index[3 + 2 * number]


def add_to_geotelnet(img, e):
    """The Oasis BBS in geoTelnet's phonebook.  False: it is there already."""
    check_class(img, e, GEOTELNET_CLASS)
    entry = BBS_NAME + b"\0" + BBS_HOST + b"\0"
    free = None                 # the first free entry: its block and offset
    number = 1
    while number < geosimg.VLIR_RECORDS:
        t, s = record(img, e, number)
        if t == 0:              # the first empty record: geoTelnet looks no
            break               # further
        data = img.chain_data(t, s)
        if data[:2] == PHONEBOOK_MARK:
            if len(data) != len(PHONEBOOK_MARK) + ENTRIES * ENTRY_BYTES:
                raise SystemExit("geoTelnet: phonebook record %d is %d bytes" % (number, len(data)))
            for i in range(ENTRIES):
                at = len(PHONEBOOK_MARK) + i * ENTRY_BYTES
                if data[at:at + len(entry)] == entry:
                    return False
                if data[at] == 0 and free is None:
                    free = (t, s, at)
        number += 1
    if free:                    # an entry of a phonebook record (one block)
        t, s, at = free
        block = bytearray(img.block(t, s))
        block[2 + at:2 + at + len(entry)] = entry
        img.put(t, s, block)
        return True
    # a new phonebook record, where geoTelnet stopped looking
    if record(img, e, number) != EMPTY_RECORD:
        raise SystemExit("geoTelnet: record %d isn't an empty record" % number)
    data = PHONEBOOK_MARK + entry.ljust(ENTRIES * ENTRY_BYTES, b"\0")
    (t, s), blocks = geosimg.write_chain(img, data)
    index_t, index_s = img.first_block(e)
    index = bytearray(img.block(index_t, index_s))
    index[2 + 2 * number], index[3 + 2 * number] = t, s
    img.put(index_t, index_s, index)
    size = geosimg.get_word(img.d, e + geosimg.DIR_SIZE)
    geosimg.put_word(img.d, e + geosimg.DIR_SIZE, size + blocks)
    return True


def put_on_geoterm_key(img, e):
    """ATDoasisbbs.hopto.org:6400 and Return on GeoTerm64's key 8 (its
    first key set).  False: it is there already."""
    check_class(img, e, GEOTERM_CLASS)
    t, s = record(img, e, FIRST_KEY_SET)
    data = img.chain_data(t, s) if t else b""
    if len(data) != KEY_SET_BYTES:
        raise SystemExit("GeoTerm64: its first key set is %d bytes" % len(data))
    at = KEYS_AT + (OASIS_KEY - 1) * KEY_BYTES
    if data[at:at + len(OASIS_DIAL) + 1] == OASIS_DIAL + b"\0":
        return False
    if any(data[at:at + KEY_BYTES]):
        raise SystemExit("GeoTerm64: key %d is in use" % OASIS_KEY)
    block = bytearray(img.block(t, s))  # (the set is one block)
    block[2 + at:2 + at + len(OASIS_DIAL)] = OASIS_DIAL
    img.put(t, s, block)
    return True


def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    for path in sys.argv[1:]:
        img = geosimg.load(path)
        done = []
        e = find(img, "geoTelnet")
        if e is not None and add_to_geotelnet(img, e):
            done.append("geoTelnet's phonebook")
        e = find(img, "GeoTerm64")
        if e is not None and put_on_geoterm_key(img, e):
            done.append("GeoTerm64's key 8")
        if done:
            geosimg.save(img, path)
        print("%s: %s" % (os.path.basename(path), ", ".join(done) or "nothing to do"))


if __name__ == "__main__":
    main()
