#!/usr/bin/env python3
"""GEOS 128's three drives as D81s: everything of his that fits, GEOS 128
programs before their C64 versions, sorted.

   mk128d81.py OUTDIR A.D64 APPS128.D64 WRUTI128.D64 SPELL128.D64 \\
               GEOSDISK.D81 GEOSDSK2.D81 GEOSDSK3.D81 PREFS.D64 [GEOPROG]

A.D64: drive A as packaged (System 128 with the X16 programs: SD CARD,
MEDIA PLAYER, WALLPAPER, IRC (left out now: geoChat X16 has its place), geoTelnet); APPS128, WRUTI128, SPELL128: his
GEOS 128 disks; GEOSDISK/GEOSDSK2/GEOSDSK3.D81: his GEOS 64 (GEOS-X16)
drives, for the C64 programs with no GEOS 128 version; PREFS.D64: a disk
with "Preferences" and "Pad Color Pref" saved (prefs128.py's template).
GEOPROG (a folder, optional): his geoProgrammer disks for geoprogx16.py
(geoprog_s1.d64, geoprog_s2.d64, GEOPROG-PATCHED.D81): geoProgrammer for
the X16 goes on drive B, first.

  GEOS128A.D81 "GEOS X16 A": the programs, desk accessories, drivers, fonts,
               the dictionary, the system, a page for each (page 1:
               X16 PAINT, DesertFish's paint program, geoWrite, MEDIA
               PLAYER, WALLPAPER, SD CARD and the network programs).
               What is out of date on the X16 is left out (see below).
  GEOS128B.D81 "GEOS X16 B": programming: geoProgrammer for the X16 (with
               GEOPROG), PROG8 DEMO
  GEOS128C.D81 "GEOS X16 C": the manuals, geoDiary, then room for his work
Then desk128.py (the 40-column deskTop), prefs128.py (his colours),
rebrand128.py (GEOS-X16 for "128"), geoPaint, GeoTerm64 and geoCalc set to
40 columns only, and bbsbook.py (The Oasis BBS in geoTelnet's phonebook and
on GeoTerm64's key 8) on drive A."""
import os, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import geosimg

# The deskTop shows a disk's files by directory slot: 8 a page, in two rows
# of 4.  The pages are kept full (no gaps), as GEOS saves a new file in the
# first free slot: a gap between the programs would fill up with documents.

# drive A: the programs, and what they need on their own disk (the desk
# accessories, printer drivers, fonts, dictionaries), and the system.
# ("PREFS": Preferences and Pad Color Pref, which prefs128.py adds.)
A = [
    # page 1, what he wants to see first: X16 PAINT (the paint program to
    # use), geoWrite, MEDIA PLAYER, WALLPAPER, SD CARD, geoChat; then the
    # other two network programs
    ("NEW", "X16 PAINT"), ("APPS", "GEOWRITE 128"), ("A", "MEDIA PLAYER"), ("A", "WALLPAPER"),
    ("NEW", "SD CARD"), ("NEW", "geoChat X16"), ("A", "geoTelnet"), ("NEW", "C64 GAMES"),
    # page 2: writing, CONVERT (it unpacks .CVT downloads), geoCalc (he
    # asked for it here)
    ("SPELL", "GEOSPELL 128"), ("WRUTI", "GEOMERGE"), ("WRUTI", "TEXT GRABBER 128"), ("C64B", "TOOLKIT"),
    ("C64B", "geoText"), ("C64A", "CardFile"), ("A", "CONVERT"), ("C64A", "GEOCALC"),
    # page 3: graphics, the printer drivers (the first, MPS-803, is the one
    # chosen at boot), the settings
    ("APPS", "GEOPAINT"), ("A", "PAINT DRIVERS"), ("C64B", "Icon Edit"), ("A", "MPS-803"),
    ("A", "Star NL-10(com)"), ("A", "ASCII Only"), ("PREFS", "Preferences"), ("PREFS", "Pad Color Pref"),
    # page 4: the desk accessories.  The geos menu lists the first 8 only,
    # so the 9th, CALENDAR, is on page 5 (double-click its icon to open it)
    ("APPS", "calculator"), ("APPS", "note pad"), ("A", "alarm clock"), ("C64C", "geoTheo"),
    ("APPS", "photo manager"), ("WRUTI", "text manager"), ("A", "preference mgr"), ("A", "pad color mgr"),
    # page 5: CALENDAR, geoTheo's data, the dictionary, Text Grabber's forms
    ("C64A", "CALENDAR"), ("C64C", "geoTheo.dat"), ("SPELL", "GeoDictionary"), ("WRUTI", "FleetSystem 4"),
    ("WRUTI", "PaperClip II"), ("WRUTI", "WordWriter 128"), ("WRUTI", "C128 Generic I"), ("WRUTI", "C128 Generic II"),
    # page 6: fonts (geoWrite's font menu lists the first 7), the deskTop
    # (GEOS finds it by name, wherever it is), then new files
    ("APPS", "California"), ("APPS", "Cory"), ("APPS", "Dwinelle"), ("APPS", "Roma"),
    ("APPS", "University"), ("APPS", "Commodore"), ("A", "128 DESKTOP"), ("C64C", "GeoTerm64"),
]
# (not here either, as GEOS-X16 has no use for them: the C128's boot files
# GEOS128, GEOBOOT128, 128 RBOOT; its input drivers 128 JOYSTICK, 128 COMM
# 1351(a) (the X16's mouse is in the kernel); ReadMe128 (booting a C128))
# (GeoTerm64 and GEOCALC say GEOS 64 only, but run on GEOS-X16's GEOS 128 in
# 40 columns: their flags are changed below, columns_40_only.  geoCalc does
# its maths with the C64's BASIC ROM, which the cartridge maps for it under
# GEOS 128 too: x16io.s X16_C64On, boot.s BuildMirrors.)
# (not here, out of date on the X16:
#   GEOLASER, LaserWriter and the LaserWriter's fonts (LW_Roma, LW_Cal,
#     LW_Greek, LW_Barrows): they print to an Apple LaserWriter through the
#     C64's user port, which the X16 hasn't got
#   GEOSTRIPPER, Patcher (GBPatcher), its six notes (1-Intro-Patcher ...
#     6-GB-Notes) and geoPattern (a geoBASIC program): all for geoBASIC,
#     which is GEOS 64 only and on none of the disks
#   ReadMe (about Click Here Software's GEOS 64 D64 archive), READ ME
#     (geoTheo 1.1's upgrade notice from 1991), diary.Mar92 (someone's
#     encrypted diary from 1992))

# drive B: programming: geoProgrammer for the X16 (add_geoprog), and
# PROG8 DEMO (a GEOS program written in Prog8)
B = [("NEW", "PROG8 DEMO")]

# drive C: the manuals, geoDiary, then room for his work.  (Not geoCalc's
# sample sheets: geoCalc 1.0's Drive button only goes between A and B.)
C = [
    ("C64C", "GeoTerm.Doc"), ("C64C", "geoTheo Manual"), ("C64C", "geoTheo now PD"), ("C64C", "geoDiary"),
]


def build(path, name, did, files, src):
    geosimg.new_image(path, name, did)
    img = geosimg.Image(open(path, "rb").read())
    for s, n in files:
        if s not in ("NEW", "PREFS"):
            geosimg.copy_file(src[s], img, n)
    open(path, "wb").write(img.d)
    for s, n in files:              # GEOS-X16's own (tools/mkx16app.py)
        if s == "NEW" and n == "PROG8 DEMO":    # (prog8/: written in Prog8)
            subprocess.run([sys.executable, os.path.join(HERE, "mkp8app.py"),
                            os.path.join(HERE, "..", "prog8", "demo.bin"), n, path,
                            "--class", "Prog8 Demo  V1.0", "--info",
                            "Written in Prog8. Its source, the GEOS target and library: prog8-geos, in the GEOS-X16 zip."],
                           check=True, stdout=subprocess.DEVNULL)
        elif s == "NEW" and n == "geoChat X16":  # (apps/geochat: geoChat 128 for GEOS-X16)
            subprocess.run([os.path.join(HERE, "..", "apps", "geochat", "build.sh"), path],
                           check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif s == "NEW":
            app = {"X16 PAINT": "x16paint", "SD CARD": "sdcard", "C64 GAMES": "c64games"}[n]
            subprocess.run([sys.executable, os.path.join(HERE, "mkx16app.py"), app, path],
                           check=True, stdout=subprocess.DEVNULL)
    subprocess.run([sys.executable, os.path.join(HERE, "geosorder.py"), path] + [n for s, n in files if s != "PREFS"],
                   check=True, stdout=subprocess.DEVNULL)
    return img


def columns_40_only(path, name):
    """NAME's header: 40 columns only (byte $60 = $00), so GEOS 128 runs it
    in 40 columns and never in 80.  geoPaint 2.0 came as $40 (40 or 80
    columns), GeoTerm64 as $80 (GEOS 64 only)."""
    img = geosimg.Image(open(path, "rb").read())
    for e in img.entries():
        if img.d[e + 2] and img.name_of(e) == name:
            t, s = img.d[e + 21], img.d[e + 22]
            h = bytearray(img.block(t, s))
            if h[0x60] not in (0x00, 0x40, 0x80):
                raise SystemExit("%s: header byte $60 is $%02X" % (name, h[0x60]))
            h[0x60] = 0x00
            img.put(t, s, h)
            open(path, "wb").write(img.d)
            return
    raise SystemExit("no " + name + " on " + path)


def add_geoprog(b, folder):
    """geoProgrammer for the X16 (tools/geoprogx16.py) onto drive B, first:
    its three programs, then what was on B already (PROG8 DEMO), then its
    include files and samples."""
    import tempfile
    tmp = os.path.join(tempfile.mkdtemp(), "GEOPROG.D81")
    subprocess.run([sys.executable, os.path.join(HERE, "geoprogx16.py"), tmp,
                    os.path.join(folder, "geoprog_s1.d64"), os.path.join(folder, "geoprog_s2.d64"),
                    os.path.join(folder, "GEOPROG-PATCHED.D81")], check=True, stdout=subprocess.DEVNULL)
    gp = geosimg.Image(open(tmp, "rb").read())
    names = [gp.name_of(e) for e in gp.entries() if gp.d[e + 2]]
    img = geosimg.Image(open(b, "rb").read())
    others = [img.name_of(e) for e in img.entries() if img.d[e + 2]]
    for n in names:
        geosimg.copy_file(gp, img, n)
    open(b, "wb").write(img.d)
    subprocess.run([sys.executable, os.path.join(HERE, "geosorder.py"), b] + names[:3] + others + names[3:],
                   check=True, stdout=subprocess.DEVNULL)


def main():
    out = sys.argv[1]
    keys = ["A", "APPS", "WRUTI", "SPELL", "C64A", "C64B", "C64C"]
    src = {k: geosimg.Image(open(p, "rb").read()) for k, p in zip(keys, sys.argv[2:9])}
    prefs = sys.argv[9]
    os.makedirs(out, exist_ok=True)
    a = os.path.join(out, "GEOS128A.D81")
    build(a, "GEOS X16 A", "XA", A, src)
    build(os.path.join(out, "GEOS128B.D81"), "GEOS X16 B", "XB", B, src)
    build(os.path.join(out, "GEOS128C.D81"), "GEOS X16 C", "XC", C, src)
    for t in ("desk128.py",):
        subprocess.run([sys.executable, os.path.join(HERE, t), a], check=True)
    subprocess.run([sys.executable, os.path.join(HERE, "prefs128.py"), prefs, a], check=True)
    subprocess.run([sys.executable, os.path.join(HERE, "rebrand128.py"), a], check=True)
    columns_40_only(a, "GEOPAINT")          # (X16 PAINT is the paint program to use)
    columns_40_only(a, "GeoTerm64")         # (GEOS 64 only as it came; works in 40 columns)
    columns_40_only(a, "GEOCALC")           # (the same)
    subprocess.run([sys.executable, os.path.join(HERE, "bbsbook.py"), a], check=True)
    if len(sys.argv) > 10:                  # geoProgrammer for the X16, on drive B first
        add_geoprog(os.path.join(out, "GEOS128B.D81"), sys.argv[10])
    # drive A's order once more, as the steps above add files at the end
    # (Preferences, Pad Color Pref) and rename some (rebrand128.py)
    import rebrand128
    order = [rebrand128.RENAME.get(n, n) for _, n in A]
    subprocess.run([sys.executable, os.path.join(HERE, "geosorder.py"), a] + order,
                   check=True, stdout=subprocess.DEVNULL)
    for d in "ABC":
        p = os.path.join(out, "GEOS128%s.D81" % d)
        img = geosimg.Image(open(p, "rb").read())
        print("%s: %d files, %d blocks free" % (os.path.basename(p),
              sum(1 for e in img.entries() if img.d[e + 2]), img.free_blocks()))


if __name__ == "__main__":
    main()
