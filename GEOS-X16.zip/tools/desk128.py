#!/usr/bin/env python3
"""GEOS 128 on the X16 as a 40-column GEOS: his System 128 disk (drive A)
made ready for it.

   desk128.py GEOS128A.D64

 - the disk's name -> "GEOS X16 A" (the deskTop's window shows it, as on
   GEOS 64's GEOS-X16 disk)
 - 128 DESKTOP: "switch 40/80" gone from its geos menu, and the routine
   it called (jsr $19D6, graphMode ^= $80, SetNewMode, jmp $19D6) returns
   at once (rts), so the deskTop stays in 40 columns; an 80-column program (geoChat X16,
   geoWrite 128) opens in 80 columns without asking, and the deskTop comes
   back in 40 (x16io.s X16_PatchAppl).

The routine is found by its bytes, in whichever of the file's blocks they
are (also across two blocks); already done: left as it is."""
import os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import geosimg

NAME = b"GEOS X16 A"
SWITCH = bytes.fromhex("20 d6 19 a5 3f 49 80 85 3f 20 dd c2")
DONE = bytes([0x60]) + SWITCH[1:]
# opening a program: an 80-column-only one ($60 = $00/$C0, deskTop at
# $6487) in 40 columns asked "Switch modes?" (ldx #>dlg, lda #<dlg, jsr
# its DoDlgBox; YES: jsr the switch, r0L = YES, X = 0).  Now: 80 columns
# at once (graphMode = $80, SetNewMode: no redraw of the deskTop, the
# program draws its own screen), r0L = YES, X = 0 as before.  (Back to 40
# columns when the deskTop starts again: x16io.s X16_PatchAppl.)
ASK = bytes.fromhex("a2 64 a9 de 20 44 19 a2 0c c9 03 d0 09 48 20 57 4e 68 85 02 a2 00")
GO80 = bytes.fromhex("a9 80 85 3f 20 dd c2 a9 03 85 02 a2 00 f0 07")
# the geos menu without "switch 40/80" (its first item): the menu ($4769 in
# RAM: 7 bytes, then items of 5: text, type, action) has 5 items of its own,
# then the desk accessories' (up to 8, one action at $4B2C); its count is
# set as 5 + accessories ($28BF: lda #5; $2FE4: lda r3L, adc #5, jsr
# $28C1), and $4B2C finds the accessory as item - 5.  Now: the items one
# place on (the last slot twice), 4 of its own, item - 4.
ITEMS = bytes.fromhex("d8 26 00 d7 4d 9d 24 00 4b 53 a7 24 00 54 53 b4 24 00 eb 52 c4 24 00 f4 52"
                      " 8d 0b 00 2c 4b 9e 0b 00 2c 4b af 0b 00 2c 4b c0 0b 00 2c 4b d1 0b 00 2c 4b"
                      " e2 0b 00 2c 4b f3 0b 00 2c 4b 04 0c 00 2c 4b")
MENU = [
    (ITEMS, ITEMS[5:] + ITEMS[-5:]),
    (bytes.fromhex("a9 05 85 02 09 80 8d 6f 47"), bytes.fromhex("a9 04 85 02 09 80 8d 6f 47")),
    (bytes.fromhex("a5 08 18 69 05 20 c1 28"), bytes.fromhex("a5 08 18 69 04 20 c1 28")),
    (bytes.fromhex("68 38 e9 05 85 0e 0a 0a 0a 0a 18 65 0e 69 8d"),
     bytes.fromhex("68 38 e9 04 85 0e 0a 0a 0a 0a 18 65 0e 69 8d")),
]


def chains(img, e):
    """the file's data chains: its own, or each VLIR record's"""
    d = img.d
    t, s = d[e + 3], d[e + 4]
    if d[e + 23] != 1:                      # sequential
        return [img.chain(t, s)]
    idx = img.block(t, s)
    out = []
    for i in range(2, 256, 2):
        if idx[i]:
            out.append(img.chain(idx[i], idx[i + 1]))
    return out


def find(img, e, old, new):
    for ch in chains(img, e):
        data, where = bytearray(), []
        for t, s in ch:
            o = img.off(t, s)
            n = 254 if img.d[o] else max(img.d[o + 1] - 1, 0)
            data += img.d[o + 2:o + 2 + n]
            where += range(o + 2, o + 2 + n)
        if data.find(new) >= 0:
            return "already"
        i = data.find(old)
        if i >= 0:
            for k, b in enumerate(new):
                img.d[where[i + k]] = b
            return "done"
    raise SystemExit("128 DESKTOP: %s not found" % old.hex(" "))


def patch(img):
    for e in img.entries():
        if img.d[e + 2] and img.name_of(e) in ("128 DESKTOP", "X16 DESKTOP"):
            break
    else:
        raise SystemExit("no 128 DESKTOP")
    menu = [find(img, e, o, n) for o, n in MENU]
    return "switch %s, 80-column programs %s, geos menu %s" % (
        find(img, e, SWITCH, DONE), find(img, e, ASK, GO80),
        "already" if set(menu) == {"already"} else "done")


def main():
    path = sys.argv[1]
    img = geosimg.Image(open(path, "rb").read())
    h = img.headerblock()
    img.d[h + 0x90:h + 0xA0] = NAME + b"\xA0" * (16 - len(NAME))
    r = patch(img)
    open(path, "wb").write(img.d)
    print("%s: disk name %r, 128 DESKTOP: %s" % (path, NAME.decode(), r))


if __name__ == "__main__":
    main()
