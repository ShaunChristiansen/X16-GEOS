@echo off
rem GEOS-X16: GEOS 128 2.0 for the Commander X16, in x16emu R49 (40 and 80
rem columns)
rem
rem Double-click this to start GEOS 128 (geos128x16.bin).  With GEOSX16SD.img
rem in this folder (the SD card image, with GEOS128A.D81, B and C on it as
rem well as GEOS 64's disks) GEOS 128 runs from that image, as from a real
rem X16's SD card: the high-bandwidth (SPI) videos only play this way.
rem Without it, or started as "GEOS-X16.BAT folder", it uses GEOS128A.D81
rem (or .D64) in this folder as drive A, GEOS128B and C as B and C.
rem x16emu.exe (with its rom.bin) is looked for in this folder and the one
rem above it; or set X16EMU to its full path.
rem Ctrl+M in the emulator window releases (and recaptures) the mouse.
setlocal
cd /d "%~dp0"
if not defined X16EMU if exist "%~dp0x16emu.exe" set "X16EMU=%~dp0x16emu.exe"
if not defined X16EMU if exist "%~dp0..\x16emu.exe" set "X16EMU=%~dp0..\x16emu.exe"
if not defined X16EMU (
  echo Cannot find x16emu.exe. Put this folder next to x16emu.exe, inside
  echo the x16emu folder, or set X16EMU in this file.
  pause
  exit /b 1
)
if not exist geos128x16.bin (
  echo geos128x16.bin is missing: unzip the GEOS 128 zip into this folder.
  pause
  exit /b 1
)
if /i "%~1"=="folder" goto folder
if not exist GEOSX16SD.img goto folder
rem Your own files in the C64GAMES folder here (C64 games, CHARGEN.BIN) go
rem onto the SD card image first: C64 GAMES reads them from there.
if exist C64GAMES\ if exist tools\sdput.ps1 powershell -NoProfile -ExecutionPolicy Bypass -File tools\sdput.ps1 GEOSX16SD.img C64GAMES
"%X16EMU%" -cartbin geos128x16.bin -sdcard GEOSX16SD.img -rtc -scale 2 -capture
exit /b
:folder
if not exist GEOS128A.D64 if not exist GEOS128A.D81 (
  echo GEOS128A.D64 or GEOS128A.D81 is missing: put a GEOS 128 2.0 disk
  echo image with 128 DESKTOP in this folder under one of those names.
  pause
  exit /b 1
)
"%X16EMU%" -cartbin geos128x16.bin -rtc -scale 2 -capture
