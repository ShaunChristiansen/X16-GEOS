#!/usr/bin/env python3
"""AUTOBOOT.X16 for GEOS-X16: runs an X16 program a GEOS application asked
for (X16 PAINT, apps/x16paint.s; SD CARD's "Run it", apps/sdcard.s), then
GEOS boots again when the X16 resets.

   mkautoboot.py OUT/AUTOBOOT.X16

The X16's BASIC runs AUTOBOOT.X16 as it starts.  GEOS-X16's ToBASIC (quit
to BASIC) leaves $0400 up as it was, so a GEOS program puts there, at $0408
(1032): "RUNPRG", the name's length, the name (PETSCII), then the folder's
length and the folder ("GAMES/WORK", from geosx16.bin's folder, where
BASIC starts; 0 long: that folder itself); then ToBASIC.
  10 IF PEEK(1032)<>82 OR PEEK(1033)<>85 OR PEEK(1034)<>78 THEN END
  20 N=PEEK(1038):F$="":FOR I=1 TO N:F$=F$+CHR$(PEEK(1038+I)):NEXT
  22 A=1039+N:M=PEEK(A):IF M=0 THEN 30
  24 D$="":FOR I=1 TO M:C=PEEK(A+I):IF C<>47 THEN D$=D$+CHR$(C)
  26 IF C=47 OR I=M THEN IF D$<>"" THEN OPEN 15,8,15,"CD:"+D$:CLOSE 15:D$=""
  28 NEXT
  30 POKE 1032,0:LOAD F$,8
Lines 22-28 go into the folder, a CD: a folder at a time (47 is "/"), so
the program finds its own files there.  (LOAD in a program loads it and
runs it.)  No note: it ends at once, BASIC as always."""
import sys

T = {"END": 0x80, "FOR": 0x81, "NEXT": 0x82, "POKE": 0x97, "LOAD": 0x93,
     "OPEN": 0x9F, "CLOSE": 0xA0,
     "IF": 0x8B, "THEN": 0xA7, "TO": 0xA4, "OR": 0xB0, "PEEK": 0xC2,
     "CHR$": 0xC7, "+": 0xAA, "=": 0xB2, "<": 0xB3, ">": 0xB1}

LINES = [
    (10, ["IF", " ", "PEEK", "(1032)", "<", ">", "82", " ", "OR", " ", "PEEK", "(1033)", "<", ">", "85",
          " ", "OR", " ", "PEEK", "(1034)", "<", ">", "78", " ", "THEN", " ", "END"]),
    (20, ["N", "=", "PEEK", "(1038):F$", "=", "\"\":", "FOR", " I", "=", "1", " ", "TO", " N:F$", "=",
          "F$", "+", "CHR$", "(", "PEEK", "(1038", "+", "I)):", "NEXT"]),
    (22, ["A", "=", "1039", "+", "N:M", "=", "PEEK", "(A):", "IF", " M", "=", "0", " ", "THEN", " 30"]),
    (24, ["D$", "=", "\"\":", "FOR", " I", "=", "1", " ", "TO", " M:C", "=", "PEEK", "(A", "+", "I):",
          "IF", " C", "<", ">", "47", " ", "THEN", " D$", "=", "D$", "+", "CHR$", "(C)"]),
    (26, ["IF", " C", "=", "47", " ", "OR", " I", "=", "M", " ", "THEN", " ", "IF", " D$", "<", ">", "\"\"",
          " ", "THEN", " ", "OPEN", " 15,8,15,\"CD:\"", "+", "D$:", "CLOSE", " 15:D$", "=", "\"\""]),
    (28, ["NEXT"]),
    (30, ["POKE", " 1032,0:", "LOAD", " F$,8"]),
]


def main():
    out = bytearray([0x01, 0x08])
    addr = 0x0801
    for num, parts in LINES:
        body = bytearray()
        for p in parts:
            body += bytes([T[p]]) if p in T else p.encode("ascii")
        body += b"\0"
        nxt = addr + 4 + len(body)
        out += bytes([nxt & 255, nxt >> 8, num & 255, num >> 8]) + body
        addr = nxt
    out += b"\0\0"
    open(sys.argv[1], "wb").write(out)
    print("%s: %d bytes" % (sys.argv[1], len(out)))


if __name__ == "__main__":
    main()
