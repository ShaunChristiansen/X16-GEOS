; C64 GAMES: a GEOS application for GEOS-X16 (version 5 or newer) that
; lists the C64 games the C64-X16 cartridge can play, and starts the one
; picked.  The games are played by that cartridge (C64MODE.BIN) and its
; patch files, not by GEOS: this is the front end.
;
; Everything of the games' is in the folder C64GAMES, in the folder
; geosx16.bin is in: C64MODE.BIN, C64LOAD.PRG, a NAME.PAT for each game the
; cartridge knows, and the user's own files: the games (NAME.PRG) and the
; C64's ROMs.  The list is the folder's .PAT files, each "ready" when its
; NAME.PRG is there too, so a new patch file shows up by itself.
;
; Starting a game means leaving GEOS: the cartridge takes GEOS's place in
; cartridge banks 32-40.  As X16 PAINT and SD CARD's "Run it" do, a note at
; $0408 for AUTOBOOT.X16 (tools/mkautoboot.py), then GEOS's ToBASIC: BASIC
; starts, AUTOBOOT.X16 goes into C64GAMES and runs C64LOAD.PRG
; (apps/c64load.s), which loads the cartridge and starts it with the game.
; The note: "RUNPRG", the program's name and the folder (each with its
; length before it), then the same for the game's name, for C64LOAD.PRG.
;
; ca65 -I ../inc --cpu 65sc02 c64games.s; ld65 -C wallpaper.cfg (load
; address $0400); tools/mkx16app.py c64games puts it on a disk.

.include "const.inc"
.include "geossym.inc"
.include "jumptab.inc"
.include "geosx16.inc"

MAXG    = 40                    ; games listed
GLEN    = 32                    ; a game's name: up to 31 characters and a 0
ILEN    = 40                    ; a menu item's text
PAGE    = 6                     ; games a menu page
MTOP    = 46
MLEFT   = 16
MRIGHT  = 250
LFN_CMD = 14
LBUFSZ  = $2000                 ; the folder's listing (GEOS-X16 call 13)

NOTE    = $0408                 ; AUTOBOOT.X16's note
NOTEMAX = 6 + 1 + 11 + 1 + 8 + 1 + GLEN

; what a menu item does (its pick): a game's number, or
P_HOW   = $FC
P_MORE  = $FE
P_QUIT  = $FF

.segment "CODE"

; The first bytes make room for the note, over code only the start uses.
Start:                          ; (at $0400, the load address)
	jmp Begin
	.res NOTE + NOTEMAX - $0403

Begin:
	ldx #3                  ; GEOS-X16, version 5 or more?
@s:	lda X16_SIG,x
	cmp sig,x
	bne NotX16
	dex
	bpl @s
	lda X16_VER
	cmp #5
	bcc NotX16
	lda $C013               ; GEOS 128 in 80 columns (header byte $60 = $40):
	and graphMode           ; x coordinates with DOUBLE_W (and ADD1_W at
	and #$80                ; the right edge), GEOS 128's own way
	sta dw
	beq :+
	lda #$A0                ; (the screen's 319s -> 639, the title's 96)
	tsb sc_r1+1
	tsb sc_r2+1
	lda #$80
	tsb sc_t+1
:	stz pg
	jsr List
	bcc Window
	lda #<dlg_nofolder
	ldx #>dlg_nofolder
	jsr Box
	jmp EnterDeskTop
NotX16:	lda #<dlg_nox16
	ldx #>dlg_nox16
	jsr Box
	jmp EnterDeskTop

; ------------------------------------------------------------ the window
; "How to add a game...", the games a page at a time, the way out
Window:
	jsr Screen
	stz ni
	lda #<t_how
	ldx #>t_how
	ldy #P_HOW
	jsr Item
	jsr Pg6                 ; the page's first game
	sta gi
@it:	lda gi
	cmp ng
	bcs @more
	lda ni
	cmp #PAGE+1
	bcs @more
	jsr GameText            ; "  NAME - ready" -> item ni
	ldx ni
	lda gi
	sta ipick,x
	jsr Action
	inc ni
	inc gi
	bra @it
@more:	lda ng
	cmp #PAGE+1
	bcc @q
	lda #<t_more
	ldx #>t_more
	ldy #P_MORE
	jsr Item
@q:	lda #<t_quit
	ldx #>t_quit
	ldy #P_QUIT
	jsr Item
	ldx #MTOP
	jmp Show

; game gi's line -> item ni (r1): "  GHOSTBUSTERS - ready"
GameText:
	jsr ItemPtr
	ldy #0
	lda #' '
	sta (r1),y
	iny
	sta (r1),y
	iny
	ldx gi
	lda order,x
	jsr NamePtr
	jsr Append
	ldx gi
	lda order,x
	tax
	lda #<t_ready
	sta r2L
	lda #>t_ready
	sta r2H
	lda ready,x
	bne :+
	lda #<t_nofile
	sta r2L
	lda #>t_nofile
	sta r2H
:	jmp Append

; a pick
DoMain:
	cmp #P_QUIT
	bne :+
	jmp EnterDeskTop
:	cmp #P_MORE
	bne :++
	inc pg
	jsr Pg6
	cmp ng
	bcc :+
	stz pg
:	jmp Window
:	cmp #P_HOW
	bne :+
	lda #<dlg_how
	ldx #>dlg_how
	jsr Box
	jmp Window
:	tax
	lda order,x
	sta pick
	jmp Play

; ------------------------------------------------------------ playing
; Game pick: is the cartridge there?  Then one question, as the only way
; back is a reset, and off: the note, and GEOS's ToBASIC.
Play:
	lda have
	cmp #3                  ; C64MODE.BIN and C64LOAD.PRG
	beq :+
	lda #<dlg_nocart
	ldx #>dlg_nocart
	jsr Box
	jmp Window
:	lda pick                ; "Play GHOSTBUSTERS?"
	jsr NamePtr
	ldx #$FF
:	inx
	lda t_play,x
	sta hbuf,x
	bne :-
	ldy #0
:	lda (r2),y
	sta hbuf,x
	beq :+
	inx
	iny
	bra :-
:	lda #'?'
	sta hbuf,x
	lda #PLAINTEXT
	sta hbuf+1,x
	stz hbuf+2,x
	jsr Title               ; the game's own name, when this knows it
	lda r3L
	sta p_title
	lda r3H
	sta p_title+1
	ldx pick                ; and whether its file is there
	lda #<t_blank
	ldy #>t_blank
	bit ready,x
	bmi :+
	lda #<t_maybe
	ldy #>t_maybe
:	sta p_file
	sty p_file+1
	lda #<dlg_play
	ldx #>dlg_play
	jsr Box
	lda r0L
	cmp #YES
	beq :+
	jmp Window
:	ldx #note_fixed_end - note_fixed - 1
:	lda note_fixed,x
	sta NOTE,x
	dex
	bpl :-
	lda pick                ; then the game's name, its length before it
	jsr NamePtr
	ldy #0
:	lda (r2),y
	beq :+
	sta NOTE + (note_fixed_end - note_fixed) + 1,y
	iny
	bra :-
:	sty NOTE + (note_fixed_end - note_fixed)
	jmp ToBASIC

; AUTOBOOT.X16's part of the note
note_fixed:
	.byte "RUNPRG"
	.byte 11, "C64LOAD.PRG"
	.byte 8, "C64GAMES"
note_fixed_end:

; r3 = game pick's own name ("Ghostbusters (Activision, 1984)"), or an
; empty text for a game this doesn't know
Title:
	lda #<titles
	sta r3L
	lda #>titles
	sta r3H
@t:	ldy #0
	lda (r3),y
	beq @x                  ; the table's end: its 0 is the empty text
@c:	lda (r3),y              ; the file's name
	cmp (r2),y
	bne @n
	iny
	cmp #0
	bne @c
	tya                     ; found: r3 = the text after it
	clc
	adc r3L
	sta r3L
	bcc @x
	inc r3H
@x:	rts
@n:	jsr @skip               ; past this name and its text
	jsr @skip
	bra @t
@skip:	ldy #0
:	lda (r3),y
	inc r3L
	bne :+
	inc r3H
:	cmp #0
	bne :--
	rts

; ------------------------------------------------------------ the folder
; C64GAMES's listing (the directory as a BASIC listing: per line the link,
; the size in blocks, the name in quotes, the type) read twice: first every
; NAME.PAT is a game, then every NAME.PRG makes its game ready; C64MODE.BIN
; and C64LOAD.PRG are noted in have.  The games are then put in order.
; C = 1: no such folder
List:
	stz ng
	stz have
	ldx #7                  ; CD:C64GAMES
:	lda t_folder,x
	sta cmd+3,x
	dex
	bpl :-
	lda #11
	jsr CdCmd
	bcc :+
	rts
:	lda #<dname
	sta r0L
	lda #>dname
	sta r0H
	lda #<lbuf
	sta r1L
	lda #>lbuf
	sta r1H
	lda #<LBUFSZ
	sta r2L
	lda #>LBUFSZ
	sta r2H
	lda #X16C_READ
	jsr X16_CALL
	php
	lda r2L                 ; (the bytes read)
	sta lb_len
	lda r2H
	sta lb_len+1
	lda #$5F                ; CD:<left arrow>: back to geosx16.bin's folder
	sta cmd+3
	lda #4
	jsr CdCmd
	plp
	bcc :+
	rts
:	stz pass                ; the .PAT files
	jsr Scan
	inc pass                ; the .PRG files
	jsr Scan
	jsr Sort
	clc
	rts

; the listing once through: each name -> nbuf (in capitals), then Entry
Scan:
	lda #<lbuf
	sta lb_p
	lda #>lbuf
	sta lb_p+1
	lda lb_len
	sta lb_n
	lda lb_len+1
	sta lb_n+1
	jsr SByte               ; the load address
	jsr SByte
@line:	jsr SByte               ; the link: 0 0 = the end
	sta lk
	jsr SByte
	ora lk
	beq @end
	lda st
	bne @end
	jsr SByte               ; the size
	jsr SByte
	stz q
	ldy #0
@ch:	sty ny
	jsr SByte
	ldy ny
	cmp #0
	beq @eol
	ldx st
	bne @end
	cmp #'"'
	bne :+
	inc q
	bra @ch
:	ldx q                   ; between the quotes: the name
	cpx #1
	bne @ch
	cpy #GLEN+3
	bcs @ch
	jsr Capital
	sta nbuf,y
	iny
	bra @ch
@eol:	lda #0
	sta nbuf,y
	sty nlen
	jsr Entry
	bra @line
@end:	rts

; a letter in capitals: the X16's lower case ($61-$7A, and $C1-$DA) too
Capital:
	cmp #$C1
	bcc :+
	cmp #$DB
	bcs :+
	and #$7F
	rts
:	cmp #'a'
	bcc :+
	cmp #'z'+1
	bcs :+
	and #$DF
:	rts

; the name in nbuf (nlen long): what is it to this program?
Entry:
	ldx #t_mode - t_names   ; the cartridge?
	jsr IsName
	bne :+
	lda #1
	tsb have
	rts
:	ldx #t_load - t_names   ; its loader?
	jsr IsName
	bne :+
	lda #2
	tsb have
	rts
:	ldy nlen                ; NAME.xxx: the extension off
	cpy #5
	bcc @x
	lda nbuf-4,y
	cmp #'.'
	bne @x
	lda #0
	sta nbuf-4,y
	ldx pass
	bne @prg
	lda nbuf-3,y            ; first time through: NAME.PAT is a game
	cmp #'P'
	bne @x
	lda nbuf-2,y
	cmp #'A'
	bne @x
	lda nbuf-1,y
	cmp #'T'
	bne @x
	lda ng
	cmp #MAXG
	bcs @x
	jsr NamePtr
	ldy #GLEN-1
:	lda nbuf,y
	sta (r2),y
	dey
	bpl :-
	ldx ng
	stz ready,x
	txa
	sta order,x
	inc ng
@x:	rts
@prg:	lda nbuf-3,y            ; second time: NAME.PRG makes game NAME ready
	cmp #'P'
	bne @x
	lda nbuf-2,y
	cmp #'R'
	bne @x
	lda nbuf-1,y
	cmp #'G'
	bne @x
	ldx #0
@g:	cpx ng
	bcs @x
	txa
	jsr NamePtr
	ldy #$FF
:	iny
	lda (r2),y
	cmp nbuf,y
	bne @gn
	cmp #0
	bne :-
	lda #$80
	sta ready,x
	rts
@gn:	inx
	bra @g

; is nbuf the name at t_names + X?  Z = 1: yes
IsName:
	ldy #0
@c:	lda t_names,x
	cmp nbuf,y
	bne @x
	inx
	iny
	cmp #0
	bne @c
@x:	rts

; the games in order of their names: order (a bubble sort of its numbers)
Sort:
@pass:	stz q                   ; (a swap made this time through)
	ldx #0
@i:	inx
	cpx ng
	bcs @done
	stx gi
	lda order-1,x
	jsr NamePtr
	lda r2L
	sta r1L
	lda r2H
	sta r1H
	ldx gi
	lda order,x
	jsr NamePtr
	ldy #$FF
:	iny
	lda (r1),y
	beq @ok                 ; (the first ends first: in order)
	cmp (r2),y
	beq :-
	bcc @ok
	ldx gi                  ; the first is the greater: swapped
	lda order,x
	pha
	lda order-1,x
	sta order,x
	pla
	sta order-1,x
	inc q
@ok:	ldx gi
	bra @i
@done:	lda q
	bne @pass
	rts

; the listing's next byte -> A (st = $40 past its end)
SByte:
	lda lb_n
	ora lb_n+1
	bne :+
	lda #$40
	sta st
	lda #0
	rts
:	stz st
	lda lb_n
	bne :+
	dec lb_n+1
:	dec lb_n
lb_p = * + 1
	lda $FFFF
	inc lb_p
	bne :+
	inc lb_p+1
:	rts

; "CD:" + cmd+3..., A long: the drive command at cmd.  C = 1: the drive
; said no (its answer does not start with 0)
CdCmd:
	pha
	lda #'C'
	sta cmd
	lda #'D'
	sta cmd+1
	lda #':'
	sta cmd+2
	pla
	ldx #<cmd
	ldy #>cmd
	X16K X16K_SETNAM
	lda #LFN_CMD
	ldx #8
	ldy #15
	X16K X16K_SETLFS
	X16K X16K_OPEN
	ldx #LFN_CMD
	X16K X16K_CHKIN
	X16K X16K_CHRIN         ; its answer: "00, OK,00,00"
	sta ans
@d:	X16K X16K_READST
	bne @de
	X16K X16K_CHRIN
	cmp #13
	bne @d
@de:	X16K X16K_CLRCHN
	lda #LFN_CMD
	X16K X16K_CLOSE
	lda ans
	cmp #'0'
	beq :+
	sec
	rts
:	clc
	rts

; ------------------------------------------------------------ menus
; the menu: the items made, at y = X
Show:
	stx menu
	lda ni
	asl a                   ; * 14 = * 16 - * 2
	asl a
	asl a
	asl a
	sec
	sbc ni
	sbc ni
	clc
	adc menu
	sta menu+1
	lda #<MLEFT
	sta menu+2
	lda #>MLEFT
	sta menu+3
	lda #<MRIGHT
	sta menu+4
	lda #>MRIGHT
	sta menu+5
	bit dw                  ; 80 columns: the menu in 80-column x (GEOS 128
	bpl :+                  ; tests the mouse against it as it is, so no
	asl menu+2              ; DOUBLE_W here): left * 2, right * 2 + 1
	rol menu+3
	sec
	rol menu+4
	rol menu+5
:
	lda ni
	ora #VERTICAL
	sta menu+6
	lda #<menu
	sta r0L
	lda #>menu
	sta r0H
	lda #0
	jmp DoMenu

; an item: the text at A/X ("  " before it), pick Y
Item:
	sta r2L
	stx r2H
	phy
	jsr ItemPtr
	ldy #0
	lda #' '
	sta (r1),y
	iny
	sta (r1),y
	iny
	jsr Append
	ply
	ldx ni
	tya
	sta ipick,x
	jsr Action
	inc ni
	rts

; r1 = item ni's text (items + ni * 40)
ItemPtr:
	lda ni
	sta r3L
	stz r3H
	asl r3L                 ; * 8
	asl r3L
	asl r3L
	lda r3L                 ; * 40 = * 8 + * 32
	sta r1L
	stz r1H
	asl r1L
	rol r1H
	asl r1L
	rol r1H
	clc
	lda r1L
	adc r3L
	sta r1L
	bcc :+
	inc r1H
:	clc
	lda r1L
	adc #<items
	sta r1L
	lda r1H
	adc #>items
	sta r1H
	rts

; menu entry ni: its text (r1), MENU_ACTION, Pick0 + ni * 3
Action:
	lda ni
	asl a
	asl a
	clc
	adc ni
	tax
	lda r1L
	sta menu+7,x
	lda r1H
	sta menu+8,x
	lda #MENU_ACTION
	sta menu+9,x
	lda ni
	asl a
	adc ni
	clc
	adc #<Pick0
	sta menu+10,x
	lda #>Pick0
	adc #0
	sta menu+11,x
	rts

Pick0:	lda #0
	.byte $2C               ; (bit: skips the next lda)
	lda #1
	.byte $2C
	lda #2
	.byte $2C
	lda #3
	.byte $2C
	lda #4
	.byte $2C
	lda #5
	.byte $2C
	lda #6
	.byte $2C
	lda #7
	.byte $2C
	lda #8
	.byte $2C
	lda #9
	nop
Pick:	tax
	lda ipick,x
	pha
	jsr GotoFirstMenu
	pla
	jmp DoMain

; the background, the title, and what to do with your own game files
Screen:
	jsr i_GraphicsString
	.byte NEWPATTERN, 0
	.byte MOVEPENTO
	.word 0
	.byte 0
	.byte RECTANGLETO
sc_r1:	.word 319
	.byte 199
	.byte NEWPATTERN, 1
	.byte MOVEPENTO
	.word 0
	.byte 0
	.byte RECTANGLETO
sc_r2:	.word 319
	.byte 15
	.byte 0
	jsr i_PutString
sc_t:	.word 96
	.byte 11
	.byte BOLDON, "GEOS-X16 C64 Games", PLAINTEXT, 0
	lda #<t_head1
	ldx #>t_head1
	ldy #26
	jsr Line
	lda #<t_head2
	ldx #>t_head2
	ldy #37
; the text at A/X on line Y, from the left
Line:	sta r0L
	stx r0H
	sty r1H
	lda #<MLEFT
	sta r11L
	lda #>MLEFT
	ora dw
	sta r11H
	jmp PutString

; a dialog box (A/X)
Box:	sta r0L
	stx r0H
	jmp DoDlgBox

Pg6:	lda pg                  ; A = pg * 6
	asl a
	adc pg
	asl a
	rts

; r2 = game A's name (names + A * 32); A, X, Y and r1 kept
NamePtr:
	pha
	sta r2L
	stz r2H
	asl r2L
	rol r2H
	asl r2L
	rol r2H
	asl r2L
	rol r2H
	asl r2L
	rol r2H
	asl r2L
	rol r2H
	clc
	lda r2L
	adc #<names
	sta r2L
	lda r2H
	adc #>names
	sta r2H
	pla
	rts

; (r2) appended at (r1) + Y (the item at most ILEN - 1 long); Y = the end
Append:
	sty ny
	ldx #0
@c:	phx
	txa
	tay
	lda (r2),y
	ldy ny
	plx
	cpy #ILEN-1
	bcs @x
	sta (r1),y
	cmp #0
	beq @z
	inc ny
	inx
	bra @c
@x:	lda #0
	sta (r1),y
@z:	ldy ny
	rts

	X16K_CODE

; ------------------------------------------------------------ the data
dw:	.byte 0               ; $80: GEOS 128, 80 columns (DOUBLE_W)
sig:	.byte "X16G"
dname:	.byte "$", 0
t_folder: .byte "C64GAMES"
t_names:                        ; the files this needs in the folder
t_mode:	.byte "C64MODE.BIN", 0
t_load:	.byte "C64LOAD.PRG", 0
t_head1: .byte "Your own game files go in C64GAMES on the", 0
t_head2: .byte "SD card, named as here: GHOSTBUSTERS.PRG", 0
t_how:	.byte "How to add a game...", 0
t_more:	.byte "More...", 0
t_quit:	.byte "Back to the deskTop", 0
t_ready: .byte " - ready", 0
t_nofile: .byte " - no game file", 0
t_play:	.byte BOLDON, "Play ", 0
t_blank: .byte 0
t_maybe: .byte "No game file yet: it may not start.", 0

; the games' own names, by file name; a game not here is shown without
titles:	.byte "ACIDRUNNER", 0, "Acid Runner (Inflexion, 1992)", 0
	.byte "BRUCELEE", 0, "Bruce Lee (Datasoft, 1984)", 0
	.byte "DEFENDER64", 0, "Defender (Interceptor, 1983)", 0
	.byte "FORTAPOCALYPSE", 0, "Fort Apocalypse (Synapse, 1982)", 0
	.byte "GALAXIAN", 0, "Galaxian DX (Arlasoft, 2021)", 0
	.byte "GHOSTBUSTERS", 0, "Ghostbusters (Activision, 1984)", 0
	.byte "GRIDRUNNER", 0, "Gridrunner (Jeff Minter, 1982)", 0
	.byte "IMPOSSIBLEMISSION", 0, "Impossible Mission (Epyx, 1984)", 0
	.byte "MISSILECOMMAND", 0, "Missile Command (Interceptor, 1983)", 0
	.byte "STARWARS", 0, "Star Wars (Domark, 1988)", 0
	.byte "URIDIUM", 0, "Uridium (Hewson, 1986)", 0
	.byte 0

dlg_play:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word hbuf
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_2_Y
p_title: .word t_blank
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_3_Y
	.word t_leave
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_4_Y
p_file:	.word t_blank
	.byte YES, DBI_X_0, DBI_Y_2
	.byte NO, DBI_X_2, DBI_Y_2
	.byte 0
t_leave: .byte "This leaves GEOS: reset to come back.", 0

dlg_how:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word h1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_2_Y
	.word h2
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_3_Y
	.word h3
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_4_Y
	.word h4
	.byte OK, DBI_X_2, DBI_Y_2
	.byte 0
h1:	.byte BOLDON, "Your own C64 game file:", PLAINTEXT, 0
h2:	.byte "name it as in the list, with .PRG,", 0
h3:	.byte "and put it in C64GAMES on the SD", 0
h4:	.byte "card, with your C64 ROMs (.BIN).", 0

dlg_nocart:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word n1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_2_Y
	.word n2
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
n1:	.byte BOLDON, "The C64 cartridge is missing:", PLAINTEXT, 0
n2:	.byte "C64MODE.BIN, C64LOAD.PRG in C64GAMES.", 0

dlg_nofolder:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word f1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_2_Y
	.word f2
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
f1:	.byte BOLDON, "No C64GAMES folder", PLAINTEXT, 0
f2:	.byte "on the SD card, next to GEOS's disks.", 0

dlg_nox16:
	.byte DEF_DB_POS | 1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_1_Y
	.word x1
	.byte DBTXTSTR, TXT_LN_X, TXT_LN_2_Y
	.word x2
	.byte OK, DBI_X_0, DBI_Y_2
	.byte 0
x1:	.byte BOLDON, "This program needs GEOS-X16", PLAINTEXT, 0
x2:	.byte "(version 5 or newer).", 0

.segment "BSS"
have:	.res 1                ; bit 0: C64MODE.BIN is there; bit 1: C64LOAD.PRG
ng:	.res 1                ; games
pg:	.res 1                ; the page shown
gi:	.res 1
ni:	.res 1                ; menu items
pick:	.res 1
pass:	.res 1
q:	.res 1
ny:	.res 1
st:	.res 1
lk:	.res 1
nlen:	.res 1
ans:	.res 1
nbuf:	.res GLEN + 8
hbuf:	.res 48
cmd:	.res 16
ready:	.res MAXG             ; $80: the game's NAME.PRG is there
order:	.res MAXG             ; the games' numbers, in order of their names
ipick:	.res 10
menu:	.res 7 + 10 * 5
items:	.res 10 * ILEN
names:	.res MAXG * GLEN
lb_n:	.res 2
lb_len:	.res 2
lbuf:	.res LBUFSZ
