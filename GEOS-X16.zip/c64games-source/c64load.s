; C64LOAD.PRG: an X16 program that starts the C64-X16 cartridge (C64MODE.BIN,
; the cartridge that plays C64 games on the X16) from X16 BASIC, with the
; game GEOS-X16's C64 GAMES chose (apps/c64games.s).
;
; C64 GAMES leaves a note at $0408 and quits GEOS to BASIC; BASIC runs
; AUTOBOOT.X16 (tools/mkautoboot.py), which goes into the games' folder and
; runs this.  The note: "RUNPRG", this program's name, the folder (each
; with its length before it: AUTOBOOT.X16 reads those), then the game's
; name with its length before it (read here).
;
; This program:
;   1. turns the game's name into the cartridge's own note at $0E80:
;      "C64GAME", the length, the name (no name: the cartridge's menu)
;   2. loads C64MODE.BIN (147,456 bytes) into RAM banks 1-18
;   3. checks that cartridge banks 32-40 are RAM, and copies it there (over
;      GEOS, which is in those banks)
;   4. changes the cartridge's first letter (CX16 -> XX16), so that a reset
;      goes to X16 BASIC, not to the cartridge's menu
;   5. starts it as the X16 starts a cartridge: bank 32, $C004, interrupts
;      off
; Run by hand (LOAD "C64LOAD.PRG" / RUN, in the games' folder) it does the
; same with no game chosen.
;
; ca65 --cpu 65c02 c64load.s; ld65 -C c64load.cfg; apps/c64load.sh builds
; C64LOAD.PRG.

.setcpu "65C02"

RAM_BANK  = $00
ROM_BANK  = $01
SRC       = $22                 ; (zero page the KERNAL leaves to programs)
DST       = $24

NOTE      = $0408               ; AUTOBOOT.X16's note ("R" wiped by it)
GAME      = $0E80               ; the cartridge's note
NAME_MAX  = 40

CART_BANK  = 32                 ; the cartridge: banks 32-40
CART_BANKS = 9
LOAD_BANK  = 1                  ; C64MODE.BIN first comes into RAM banks 1-18
CART_ENTRY = $C004

SETLFS    = $FFBA
SETNAM    = $FFBD
LOAD      = $FFD5
CHROUT    = $FFD2

.segment "LOADADDR"
	.word $0801
.segment "CODE"
	.word @end, 10          ; 10 SYS2061
	.byte $9E, "2061", 0
@end:	.word 0

Start:
	jsr GameNote
	ldx #msg_loading - msgs
	jsr Print
	jsr LoadCartridge
	bcs @noload
	sei
	jsr CartridgeIsRam
	bcs @noram
	jsr CopyCartridge
	lda #CART_BANK
	sta ROM_BANK
	lda #'X'                ; (XX16: not started by a reset)
	sta $C000
	stz RAM_BANK
	jmp CART_ENTRY

@noram:	stz ROM_BANK            ; the KERNAL again
	cli
	ldx #msg_noram - msgs
	jmp Print
@noload:
	ldx #msg_noload - msgs
	jmp Print

; ------------------------------------------------------------------------
; The game's name, from AUTOBOOT.X16's note to the cartridge's.  The name
; is the third thing in the note; anything but 1 to 40 capitals and digits
; is no name.  Both notes are used once.
GameNote:
	stz GAME                ; (no game chosen, unless...)
	ldx #4
@u:	lda NOTE+1,x            ; "UNPRG" left of "RUNPRG"?
	cmp unprg,x
	bne @none
	dex
	bpl @u
	stz NOTE+1
	ldx #6                  ; past the program's name and the folder
	jsr @skip
	jsr @skip
	lda NOTE,x              ; the game's name: its length
	beq @none
	cmp #NAME_MAX+1
	bcs @none
	sta GAME+7
	ldy #0                  ; Y: the letters copied
@c:	inx
	lda NOTE,x
	cmp #'0'
	bcc @none
	cmp #'9'+1
	bcc @ok
	cmp #'A'
	bcc @none
	cmp #'Z'+1
	bcs @none
@ok:	sta GAME+8,y
	iny
	cpy GAME+7
	bne @c
	ldx #6                  ; "C64GAME": the note is whole
@m:	lda c64game,x
	sta GAME,x
	dex
	bpl @m
@none:	rts
; X: at a length byte -> at the byte after its text
@skip:	txa
	sec                     ; (+ 1 + the length)
	adc NOTE,x
	tax
	rts

; ------------------------------------------------------------------------
; C64MODE.BIN, as it is (no load address in it), into RAM banks 1-18 from
; $A000: the KERNAL goes on into the next bank at $C000.  C = 1: not there,
; or not 147,456 bytes
LoadCartridge:
	lda #cartname_end - cartname
	ldx #<cartname
	ldy #>cartname
	jsr SETNAM
	lda #1
	ldx #8
	ldy #2                  ; (2: a file without a load address)
	jsr SETLFS
	lda #LOAD_BANK
	sta RAM_BANK
	lda #0
	ldx #<$A000
	ldy #>$A000
	jsr LOAD
	bcs @x
	cpx #<$A000             ; it ends where bank 19 starts
	bne @no
	cpy #>$A000
	bne @no
	lda RAM_BANK
	cmp #LOAD_BANK + 2 * CART_BANKS
	bne @no
	clc
	rts
@no:	sec
@x:	rts

; ------------------------------------------------------------------------
; Are banks 32-40 RAM?  A byte of each is changed and put back.  C = 1: no
CartridgeIsRam:
	ldx #CART_BANK
@b:	stx ROM_BANK
	lda $C000
	tay
	eor #$FF
	sta $C000
	cmp $C000
	bne @no
	sty $C000
	inx
	cpx #CART_BANK + CART_BANKS
	bne @b
	clc
	rts
@no:	sec
	rts

; ------------------------------------------------------------------------
; RAM banks 1-18 ($A000-$BFFF, 8K each) to cartridge banks 32-40
; ($C000-$FFFF, 16K each): two RAM banks to a cartridge bank.  This runs
; with the cartridge banks in place of the KERNAL: interrupts are off.
CopyCartridge:
	lda #LOAD_BANK
	sta RAM_BANK
	ldx #CART_BANK
@bank:	stx ROM_BANK
	lda #>$C000
	jsr @half
	lda #>$E000
	jsr @half
	inx
	cpx #CART_BANK + CART_BANKS
	bne @bank
	rts
; one RAM bank to the 8K at A * 256, then the next RAM bank
@half:	sta DST+1
	stz DST
	lda #>$A000
	sta SRC+1
	stz SRC
	ldy #0
@c:	lda (SRC),y
	sta (DST),y
	iny
	bne @c
	inc DST+1
	inc SRC+1
	lda SRC+1
	cmp #>$C000
	bne @c
	inc RAM_BANK
	rts

; ------------------------------------------------------------------------
; the message at msgs + X on the screen
Print:
@c:	lda msgs,x
	beq @x
	jsr CHROUT
	inx
	bne @c
@x:	rts

msgs:
msg_loading:
	.byte 13, "LOADING THE C64 CARTRIDGE (C64MODE.BIN)...", 13, 0
msg_noload:
	.byte 13, "C64MODE.BIN IS NOT IN THIS FOLDER", 13
	.byte "(OR IS NOT 147,456 BYTES).", 13, 0
msg_noram:
	.byte 13, "THE C64 GAMES NEED A CARTRIDGE WITH RAM", 13
	.byte "IN BANKS 32-40. THIS ONE HAS NONE THERE.", 13, 0

cartname: .byte "C64MODE.BIN"
cartname_end:
unprg:	.byte "UNPRG"
c64game: .byte "C64GAME"
