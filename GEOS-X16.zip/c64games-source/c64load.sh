#!/bin/sh
# Builds C64LOAD.PRG (apps/c64load.s): c64load.sh OUT/C64LOAD.PRG
# Needs ca65 and ld65 (cc65).
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
command -v ca65 >/dev/null 2>&1 || PATH=/home/claude/ext/cc65/bin:$PATH
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
ca65 --cpu 65c02 "$HERE/c64load.s" -o "$TMP/c64load.o"
ld65 -C "$HERE/c64load.cfg" -o "$1" "$TMP/c64load.o"
echo "$1: $(wc -c < "$1") bytes"
