C64 GAMES for GEOS-X16: the source

c64games.s    the GEOS program (drive A, page 1).  It lists C64GAMES's
              .PAT files, and for the game picked leaves a note at $0408
              and goes to X16 BASIC (GEOS's ToBASIC).
mkautoboot.py makes AUTOBOOT.X16, the BASIC program the X16 runs at
              start: on that note it goes into C64GAMES and runs
              C64LOAD.PRG.  (SD CARD's "Run it" uses the same note.)
c64load.s     C64LOAD.PRG: loads C64MODE.BIN into cartridge banks 32-40,
              gives it the game's name (the cartridge's note at $0E80)
              and starts it.  c64load.sh builds it (ca65 and ld65).
mkx16app.py   builds c64games.s and puts it on a disk image:
              "python3 mkx16app.py c64games GEOS128A.D81 7" (it needs
              GEOS-X16's source tree: its inc/ folder and apps/).

To add a game: put its NAME.PAT in C64GAMES and it is in the list.  For
its full name in the "Play ...?" box, add a line to "titles" in
c64games.s.

The cartridge itself (C64MODE.BIN) and the patch files are the C64-X16
project's.
