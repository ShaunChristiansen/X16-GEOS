#!/usr/bin/env python3
"""geowritedoc.py - plain text files into geoWrite documents, the form
geoAssembler and geoLinker read their source from.

    geowritedoc.py IMAGE "DOC NAME" TEXTFILE ["info text"]

The document is written the way Berkeley's own geoProgrammer files are
(geosSym, geosMac, SamSeq...): a geoWrite 1.1 "Write Image" VLIR file, one
record per page.  Each page is

    20 bytes   the ruler: left margin, right margin, eight tab stops
     4 bytes   NEWCARDSET: font BSW 9 point, plain
     ...       the text, lines ending in CR, tabs as TAB
     2 bytes   CR and then PAGE_BREAK ($0C), or CR and $00 on the last page

A line of the text file holding only "\\f" (form feed) starts a new page.

A picture (geoAssembler turns one into bitmap data: a file icon in a
.header, an icon's picture) is drawn in the text file as rows of "#" (set)
and "." (clear), each row a multiple of 8 wide, between a line "\\picture"
and a line "\\end".  It goes into the document as geoWrite does it: an
ESC_GRAPHICS in the text ($10, the width in bytes, the height, the record)
and the bitmap in a record of its own from 64 on.
Otherwise a page is ended after PAGE_LINES lines, at the last blank line
before that if there is one, so a routine is not split in the middle.

geoWrite itself opens these documents too (geoWrite 2.x offers to convert
them to its own format; geoAssembler reads either)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import geosimg

PAGE_LINES = 48                 # lines on a page at most

# The ruler of Berkeley's source files (geosMac): margins 0 and 479, tab
# stops at 48, 96 and 200 pixels, the rest at the right margin.
RULER = bytes.fromhex("0000df01" "3000" "6000" "c800" "df01" "df01" "df01" "df01" "df01")
FONT = bytes([0x17, 0x09, 0x00, 0x00])  # NEWCARDSET: BSW font, 9 point, plain
CR, PAGE_BREAK, END = 13, 12, 0
ESC_GRAPHICS = 16
PICTURE_MARK = "\x01"           # (a picture's place among the lines)


def take_pictures(text):
    """The text with each picture block replaced by a mark line, and the
    pictures: a list of (width in bytes, height, bitmap bytes)."""
    lines, pictures, rows = [], [], None
    for line in text.split("\n"):
        if line.strip() == "\\picture":
            rows = []
        elif rows is not None and line.strip() == "\\end":
            width = len(rows[0])
            if width % 8 or any(len(r) != width for r in rows):
                raise SystemExit("a picture's rows must all be the same width, a multiple of 8")
            bits = "".join(rows).replace("#", "1").replace(".", "0")
            data = bytes(int(bits[i:i + 8], 2) for i in range(0, len(bits), 8))
            pictures.append((width // 8, len(rows), data))
            lines.append(PICTURE_MARK + str(len(pictures) - 1))
            rows = None
        elif rows is not None:
            rows.append(line.strip())
        else:
            lines.append(line)
    return "\n".join(lines), pictures


def picture_record(width, height, data):
    """A picture as geoWrite keeps it: width, height, compacted bitmap
    (GEOS's packets of up to 91 bytes as they are: $80 + count, bytes)."""
    out = bytearray([width, height & 255, height >> 8])
    for i in range(0, len(data), 91):
        chunk = data[i:i + 91]
        out += bytes([0x80 + len(chunk)]) + chunk
    return bytes(out)


def split_pages(text):
    """The text's lines, as a list of pages (each a list of lines)."""
    pages, page = [], []
    for line in text.split("\n"):
        if line.strip() == "\\f":
            pages.append(page)
            page = []
            continue
        page.append(line.rstrip())
        if len(page) >= PAGE_LINES:
            cut = max((i for i, l in enumerate(page) if not l.strip()), default=None)
            if cut is None or cut < PAGE_LINES // 2:
                cut = len(page) - 1
            pages.append(page[:cut + 1])
            page = page[cut + 1:]
    while page and not page[-1].strip():        # (no blank lines at the very end)
        page.pop()
    if page:
        pages.append(page)
    return [p for p in pages if p]


def page_record(lines, last, pictures):
    body = bytearray()
    for n, line in enumerate(lines):
        if n:
            body.append(CR)
        if line.startswith(PICTURE_MARK):
            k = int(line[1:])
            width, height, _ = pictures[k]
            body += bytes([ESC_GRAPHICS, width, height & 255, height >> 8, 64 + k])
        else:
            body += line.encode("latin-1")
    return RULER + FONT + bytes(body) + bytes([CR, END if last else PAGE_BREAK])


def header_block(info):
    """A 256-byte GEOS header block for a geoWrite 1.1 document."""
    h = bytearray(256)
    h[0], h[1] = 0x00, 0xFF                     # (the link bytes: a single block)
    h[2], h[3], h[4] = 3, 21, 0xBF              # icon: 24 x 21, 63 bytes follow
    h[5:5 + 63] = DOC_ICON
    h[0x44] = 0x83                              # Commodore type USR
    h[0x45] = 7                                 # GEOS type APPL_DATA
    h[0x46] = 1                                 # VLIR
    h[0x4D:0x4D + 20] = b"Write Image V1.1".ljust(20, b"\0")
    h[0x75:0x75 + 20] = b"geoWrite    V1.1".ljust(20, b"\0")
    info = info.encode("latin-1")[:95]
    h[0xA0:0xA0 + len(info)] = info
    return h


# geoWrite's document icon (as on Berkeley's geoProgrammer files)
DOC_ICON = bytes.fromhex(
    "ffffff8000018fff018801018bffc18a00418afff18a80118a8e118a80118abf91"
    "8a80118a9f118a80118abf918e801182bf9183801180801180fff1ffffff")


def add_document(img, name, text, info=""):
    """Writes NAME into the disk image IMG (a geosimg.Image) from TEXT."""
    for e in img.entries():
        if img.d[e + 2] and img.name_of(e) == name:
            geosimg.remove_file(img, name)
            break
    text, pictures = take_pictures(text)
    pages = split_pages(text)
    if not pages:
        raise SystemExit("%s: no text" % name)
    if len(pages) > 61:
        raise SystemExit("%s: %d pages, geoWrite takes 61" % (name, len(pages)))
    records = {i: page_record(p, i == len(pages) - 1, pictures) for i, p in enumerate(pages)}
    for k, pic in enumerate(pictures):
        records[64 + k] = picture_record(*pic)

    ht, hs = img.alloc()                        # the header block
    img.put(ht, hs, header_block(info))
    index = bytearray(256)
    index[0], index[1] = 0, 0xFF
    for r in range(127):                        # every record empty to begin with
        index[3 + 2 * r] = 0xFF
    total = 2
    for r, rec in sorted(records.items()):
        (t, s), n = geosimg.write_chain(img, rec)
        index[2 + 2 * r], index[3 + 2 * r] = t, s
        total += n
    it, is_ = img.alloc()
    img.put(it, is_, index)

    entry = img.free_slot()
    img.d[entry + 2] = 0x83                     # USR, closed
    img.d[entry + 3], img.d[entry + 4] = it, is_
    img.d[entry + 5:entry + 21] = name.encode("latin-1").ljust(16, b"\xA0")
    img.d[entry + 21], img.d[entry + 22] = ht, hs
    img.d[entry + 23] = 1                       # VLIR
    img.d[entry + 24] = 7                       # APPL_DATA
    img.d[entry + 25:entry + 30] = bytes([126, 11, 27, 12, 0])   # 27 Nov 2026
    img.d[entry + 30], img.d[entry + 31] = total & 255, total >> 8
    return len(pages)


def main():
    if len(sys.argv) not in (4, 5):
        raise SystemExit(__doc__)
    path, name, textfile = sys.argv[1:4]
    info = sys.argv[4] if len(sys.argv) == 5 else ""
    img = geosimg.Image(open(path, "rb").read())
    n = add_document(img, name, open(textfile, encoding="latin-1").read(), info)
    open(path, "wb").write(img.d)
    print("%s: %s, %d page(s)" % (os.path.basename(path), name, n))


if __name__ == "__main__":
    main()
