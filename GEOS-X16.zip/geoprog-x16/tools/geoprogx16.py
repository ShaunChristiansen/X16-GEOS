#!/usr/bin/env python3
"""geoprogx16.py - Berkeley's geoProgrammer 1.1, made for programming the
Commander X16 on GEOS-X16, on one D81.

    geoprogx16.py OUT.D81 S1.D64 S2.D64 PATCHED.D81 [--geos64]

    S1.D64, S2.D64  the two geoProgrammer disks, as they came
    PATCHED.D81     GEOASSEMBLER, GEOLINKER and GEODEBUGGER after Robert
                    J.G. Norton's geoProgPatch 2.1 has been run on them
                    (it lets them run on GEOS 128, in 40 and 80 columns)
    --geos64        for the GEOS 64 cartridge (see "geoWrite's name")

What it does:

1. Copies the three programs (patched) and Berkeley's source files and
   samples onto a new disk called GEOPROG X16.

2. Teaches geoAssembler the 65C02's instructions (the X16's CPU):
   stz, bra, phx, phy, plx, ply, trb, tsb, bit abs,x, wai, stp, the
   (zp) addressing mode and jmp (addr,x).  See ASSEMBLER below.

3. geoWrite's name: geoAssembler's and geoLinker's "open the error file"
   start geoWrite by its file name.  On GEOS-X16's GEOS 128 disks that's
   GEOWRITE X16; on the GEOS 64 disks it's GEOWRITE (--geos64).

4. Adds the X16 include files and the X16 sample program, made into
   geoWrite documents from the text files in geoprog/ (x16Sym,
   x16GeosSym, x16Mac, SamX16, SamX16Hdr, SamX16.lnk).

Every change checks the bytes it replaces first, so a different version
of a program is refused rather than damaged."""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import geosimg
import geowritedoc
from scan128 import streams

SOURCES = os.path.join(HERE, "..", "geoprog")    # the text files (in the GEOS-X16 tree)
if not os.path.isdir(SOURCES):                    # (or, in the geoprog-x16 package, beside tools/)
    SOURCES = os.path.join(HERE, "..")

# --------------------------------------------------------------------------
# ASSEMBLER: where things are in GEOASSEMBLER V1.1, record 0 (it loads at
# $0400; the offset in the record is the address - $0400)
# --------------------------------------------------------------------------
REC0_LOAD = 0x0400

# The instruction table: four 256-byte tables, indexed by the opcode byte
# itself.  For opcode n: the mnemonic's 1st, 2nd and 3rd letters, and its
# addressing mode.  Unused opcodes have "???" and mode 0.  geoAssembler
# looks a line's mnemonic and addressing mode up here (at $3B89); the
# opcode is where it's found.  The instruction's length comes from a
# fifth table, by mode, at $401C.
LETTER1, LETTER2, LETTER3, MODE = 0x3C1C, 0x3D1C, 0x3E1C, 0x3F1C

# Addressing modes (what the parser returns, and what the table holds)
IMPLIED, ACCUM, IMMED, ZP, ABS = 1, 2, 3, 4, 5
IND_ZP_X, IND_ZP_Y, RELATIVE, ZP_X, ZP_Y, ABS_X, ABS_Y, IND_ABS = 6, 7, 8, 9, 10, 11, 12, 13
# Two new modes for the 65C02.  The numbers are chosen so that the length
# table, read past its 14 entries, already gives the right length:
# $401C + $50 holds 2 and $401C + $BC holds 3.
IND_ZP = 0x50                   # (zp)       2 bytes
IND_ABS_X = 0xBC                # (addr,x)   3 bytes

# The 65C02's instructions that the 6502 doesn't have, by opcode.
# (inc a, dec a, bit zp,x and bit # were in Berkeley's table already.)
NEW_INSTRUCTIONS = {
    0x04: ("tsb", ZP),        0x0C: ("tsb", ABS),
    0x14: ("trb", ZP),        0x1C: ("trb", ABS),
    0x64: ("stz", ZP),        0x74: ("stz", ZP_X),
    0x9C: ("stz", ABS),       0x9E: ("stz", ABS_X),
    0x3C: ("bit", ABS_X),     # (its mode was there, its letters not)
    0x80: ("bra", RELATIVE),
    0xDA: ("phx", IMPLIED),   0xFA: ("plx", IMPLIED),
    0x5A: ("phy", IMPLIED),   0x7A: ("ply", IMPLIED),
    0xCB: ("wai", IMPLIED),   0xDB: ("stp", IMPLIED),
    0x12: ("ora", IND_ZP),    0x32: ("and", IND_ZP),
    0x52: ("eor", IND_ZP),    0x72: ("adc", IND_ZP),
    0x92: ("sta", IND_ZP),    0xB2: ("lda", IND_ZP),
    0xD2: ("cmp", IND_ZP),    0xF2: ("sbc", IND_ZP),
    0x7C: ("jmp", IND_ABS_X),
}

# The parser, operand "(expr)": as it was, a zero page value is an error
# (only jmp (addr) existed).  Now: zero page -> IND_ZP, else IND_ABS.
# $BD is set when the value isn't known yet, $797D is its high byte.
# (A zero page value gives A = 0: LSR keeps 0 and EOR makes it $50.  Any
# other gives A = $BA: LSR makes $5D, EOR $0D.  Carry ends up clear both
# ways, which the caller wants.)
PAREN_AT = 0x3AD2
PAREN_OLD = bytes.fromhex("a6bd d005 ae7d79 f042 a90d 18 60")
PAREN_NEW = bytes.fromhex(
    "a5bd"      # lda $BD       unknown yet?
    "0d7d79"    # ora $797D     or more than a byte?
    "f002"      # beq +2
    "a9ba"      # lda #$BA      (becomes IND_ABS)
    "4a"        # lsr a
    "4950"      # eor #IND_ZP
    "60")       # rts

# The parser, operand "(expr,x)": as it was, more than a zero page value
# was an error.  Now: zero page -> IND_ZP_X as before, else IND_ABS_X.
# (0: ASL keeps 0, EOR makes 6.  $5D: ASL makes $BA, EOR makes $BC.)
PAREN_X_AT = 0x3B10
PAREN_X_OLD = bytes.fromhex("a906 ae7d79 d006 a6bd d002 18 60")
PAREN_X_NEW = bytes.fromhex(
    "a5bd"      # lda $BD
    "0d7d79"    # ora $797D
    "f002"      # beq +2
    "a95d"      # lda #$5D      (becomes IND_ABS_X)
    "0a"        # asl a
    "4906"      # eor #IND_ZP_X
    "60")       # rts

LENGTHS = 0x401C                # the instruction length, by mode

# --------------------------------------------------------------------------
# geoWrite's name, for "open the error file": in record 3 of each program
# (an overlay), loaded into r6 (lda #high, sta r6H, lda #low, sta r6L) in
# two places.  The new name goes on the end of the record, and the two
# loads point at it.
#   GEOASSEMBLER: record 3 loads at $5C7C, its name was at $5E9B
#   GEOLINKER:    record 3 loads at $5461, its name was at $5540
# Both records stay inside their program's overlay area (the biggest
# overlay of each is 896 and 912 bytes).
# --------------------------------------------------------------------------
GEOWRITE_NAME = {
    "GEOASSEMBLER": {"load": 0x5C7C, "old": 0x5E9B, "loads": (0x82, 0xC1)},
    "GEOLINKER":    {"load": 0x5461, "old": 0x5540, "loads": (0x6A, 0xA7)},
}

# --------------------------------------------------------------------------
# What goes on the disk, in this order
# --------------------------------------------------------------------------
PROGRAMS = ["GEOASSEMBLER", "GEOLINKER", "GEODEBUGGER"]
X16_FILES = [   # (name on the disk, text file, info)
    ("x16Sym", "x16Sym.txt", "The Commander X16's hardware for geoAssembler: VERA, YM2151, VIA 2, TexElec's card."),
    ("x16GeosSym", "x16GeosSym.txt", "GEOS-X16's calls for programs (serial, files, video...) and the X16 KERNAL."),
    ("x16Mac", "x16Mac.txt", "The X16 macro for geoAssembler: VAddr, VERA's address registers."),
    ("SamX16", "SamX16.txt", "Sample X16 program: VERA's PSG, the serial port, GEOS-X16's version."),
    ("SamX16Hdr", "SamX16Hdr.txt", "The sample X16 program's header block."),
    ("SamX16.lnk", "SamX16.lnk.txt", "geoLinker's instructions for the sample X16 program."),
]
BERKELEY = ["geosSym", "geosMac", "geosConstants", "geosMemoryMap", "geosRoutines", "geosMacros",
            "SamSeq", "SamSeqHdr", "SamSeq.lnk", "SampleSeq.dbm", "geosMac.rel", "SamSeqHdr.rel",
            "SamVlirRes", "SamVlirFile", "SamVlirEdit", "SamVlirEquates", "SamVlirZPVars",
            "SamVlirHdr", "SamVlir.lnk", "SamDA", "SamDAHdr", "SamDA.lnk"]


# --------------------------------------------------------------------------
# Disk helpers
# --------------------------------------------------------------------------
def entry(img, name):
    for e in img.entries():
        if img.d[e + 2] and img.name_of(e) == name:
            return e
    raise SystemExit("not on the disk: " + name)


def records(img, name):
    """NAME's VLIR records: {number: bytes}."""
    e = entry(img, name)
    return {int(lab[3:]): d for lab, d, _ in streams(img, e) if lab.startswith("rec")}


def write_record(img, name, number, data):
    """Replaces record NUMBER of NAME with DATA."""
    e = entry(img, name)
    it, is_ = img.d[e + 3], img.d[e + 4]
    index = bytearray(img.block(it, is_))
    t, s = index[2 + 2 * number], index[3 + 2 * number]
    if t:
        old = img.chain(t, s)
        for bt, bs in old:
            img.free(bt, bs)
        blocks = len(old)
    else:
        blocks = 0
    (t, s), n = geosimg.write_chain(img, data)
    index[2 + 2 * number], index[3 + 2 * number] = t, s
    img.put(it, is_, index)
    size = (img.d[e + 30] | img.d[e + 31] << 8) - blocks + n
    img.d[e + 30], img.d[e + 31] = size & 255, size >> 8


def check(data, at, expected, what):
    if bytes(data[at:at + len(expected)]) != expected:
        raise SystemExit("%s: not the bytes expected (a different version?)" % what)


# --------------------------------------------------------------------------
# The changes
# --------------------------------------------------------------------------
def teach_65c02(img):
    rec0 = bytearray(records(img, "GEOASSEMBLER")[0])
    off = lambda addr: addr - REC0_LOAD

    for op, (mnemonic, mode) in sorted(NEW_INSTRUCTIONS.items()):
        here = [rec0[off(t) + op] for t in (LETTER1, LETTER2, LETTER3, MODE)]
        empty = here[:3] == list(b"???") and here[3] in (0, mode)
        if not empty:
            raise SystemExit("GEOASSEMBLER: opcode $%02X is already %r" % (op, here))
        for table, letter in zip((LETTER1, LETTER2, LETTER3), mnemonic):
            rec0[off(table) + op] = ord(letter)
        rec0[off(MODE) + op] = mode

    for mode, length in ((IND_ZP, 2), (IND_ABS_X, 3)):      # (see IND_ZP)
        if rec0[off(LENGTHS) + mode] != length:
            raise SystemExit("GEOASSEMBLER: the length table isn't as expected")

    check(rec0, off(PAREN_AT), PAREN_OLD, "GEOASSEMBLER (zp) parser")
    rec0[off(PAREN_AT):off(PAREN_AT) + len(PAREN_NEW)] = PAREN_NEW
    check(rec0, off(PAREN_X_AT), PAREN_X_OLD, "GEOASSEMBLER (addr,x) parser")
    rec0[off(PAREN_X_AT):off(PAREN_X_AT) + len(PAREN_X_NEW)] = PAREN_X_NEW

    write_record(img, "GEOASSEMBLER", 0, rec0)


def set_geowrite_name(img, program, name):
    where = GEOWRITE_NAME[program]
    rec3 = bytearray(records(img, program)[3])
    check(rec3, where["old"] - where["load"], b"GEOWRITE\0", program + ": geoWrite's name")
    new_at = where["load"] + len(rec3)
    for at in where["loads"]:           # lda #>name, sta r6H, lda #<name, sta r6L
        check(rec3, at, bytes([0xA9, where["old"] >> 8, 0x85, 0x0F, 0xA9, where["old"] & 255, 0x85, 0x0E]),
              program + ": loading geoWrite's name")
        rec3[at + 1], rec3[at + 5] = new_at >> 8, new_at & 255
    rec3 += name.encode("latin-1") + b"\0"
    write_record(img, program, 3, rec3)


def info_text(img, name, text):
    """NAME's info text (the deskTop's info box)."""
    e = entry(img, name)
    t, s = img.d[e + 21], img.d[e + 22]
    h = bytearray(img.block(t, s))
    h[0xA0:0x100] = text.encode("latin-1")[:95].ljust(96, b"\0")
    img.put(t, s, h)


# --------------------------------------------------------------------------
def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if len(args) != 4:
        raise SystemExit(__doc__)
    out, s1_path, s2_path, patched_path = args
    geowrite = "GEOWRITE" if "--geos64" in sys.argv else "GEOWRITE X16"

    s1 = geosimg.Image(open(s1_path, "rb").read())
    s2 = geosimg.Image(open(s2_path, "rb").read())
    patched = geosimg.Image(open(patched_path, "rb").read())
    on_s1 = {s1.name_of(e) for e in s1.entries() if s1.d[e + 2]}

    geosimg.new_image(out, "GEOPROG X16", "GX")
    img = geosimg.Image(open(out, "rb").read())
    for name in PROGRAMS:
        geosimg.copy_file(patched, img, name)
    for name in BERKELEY:
        geosimg.copy_file(s1 if name in on_s1 else s2, img, name)

    teach_65c02(img)
    for program in ("GEOASSEMBLER", "GEOLINKER"):
        set_geowrite_name(img, program, geowrite)
    info_text(img, "GEOASSEMBLER", "geoProgrammer's assembler, for GEOS-X16: knows the X16's "
                                   "65C02 instructions (stz, bra, phx, (zp)...).")

    for name, textfile, info in X16_FILES:
        text = open(os.path.join(SOURCES, textfile), encoding="latin-1").read()
        geowritedoc.add_document(img, name, text, info)

    open(out, "wb").write(img.d)
    order = PROGRAMS + [n for n, _, _ in X16_FILES] + BERKELEY
    import subprocess
    subprocess.run([sys.executable, os.path.join(HERE, "geosorder.py"), out] + order,
                   check=True, stdout=subprocess.DEVNULL)
    img = geosimg.Image(open(out, "rb").read())
    print("%s: %d files, %d blocks free (geoWrite: %s)" % (
        os.path.basename(out), sum(1 for e in img.entries() if img.d[e + 2]),
        img.free_blocks(), geowrite))


if __name__ == "__main__":
    main()
