#!/usr/bin/env python3
"""scan128.py IMAGE ...  -- every "128" in every GEOS file: the file, where
(dir name, header info text, record N), and the text around it."""
import sys, os, re
sys.path.insert(0, os.path.dirname(__file__))
from geosimg import Image


def streams(img, e):
    """(label, bytes, [image offset of each byte]) for a file's parts."""
    d = img.d

    def chain(t, s):
        data, offs = bytearray(), []
        for bt, bs in img.chain(t, s):
            o = img.off(bt, bs)
            n = d[o + 1] - 1 if d[o] == 0 else 254
            data += d[o + 2:o + 2 + n]
            offs += range(o + 2, o + 2 + n)
        return data, offs
    yield "name", bytes(d[e + 5:e + 21]), list(range(e + 5, e + 21))
    if d[e + 21]:
        o = img.off(d[e + 21], d[e + 22])
        yield "header", bytes(d[o:o + 256]), list(range(o, o + 256))
    t, s = d[e + 3], d[e + 4]
    if d[e + 21] and d[e + 23] == 1:
        idx = img.block(t, s)
        for i in range(2, 256, 2):
            if idx[i]:
                a, b = chain(idx[i], idx[i + 1])
                yield "rec%d" % (i // 2 - 1), bytes(a), b
    else:
        a, b = chain(t, s)
        yield "data", bytes(a), b


def show(b):
    return "".join(chr(c) if 32 <= c < 127 else "." for c in b)


def main():
    for path in sys.argv[1:]:
        img = Image(open(path, "rb").read())
        for e in img.entries():
            if not img.d[e + 2]:
                continue
            nm = img.name_of(e)
            for lab, data, _ in streams(img, e):
                for m in re.finditer(rb"128", data):
                    a = max(0, m.start() - 24)
                    print("%s | %-16s | %-6s %5d | %s" % (
                        os.path.basename(path), nm, lab, m.start(),
                        show(data[a:m.end() + 24])))


if __name__ == "__main__":
    main()
