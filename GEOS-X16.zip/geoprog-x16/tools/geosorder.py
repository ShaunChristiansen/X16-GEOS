#!/usr/bin/env python3
"""Puts the files on a GEOS disk image in a given order (the deskTop shows
them in directory order, 8 a page).

   geosorder.py IMAGE NAME [NAME ...]

The files named come first, in that order; the others follow in the order
they had, with no gaps.  Only the directory entries move: the files and the
BAM stay as they are.  Other tools can call put_in_order() on an Image."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import geosimg


def put_in_order(img, names):
    """Moves img's directory entries so that the files named come first, in
    that order, and the others follow in the order they had.  Gives back
    the new order (every file's name)."""
    slots = list(img.entries())
    used = [e for e in slots if img.d[e + geosimg.DIR_TYPE]]
    entry_of = {img.name_of(e): bytes(img.d[e + 2:e + geosimg.SLOT]) for e in used}
    for name in names:
        if name not in entry_of:
            raise SystemExit("not on the disk: " + name)
    if len(set(names)) != len(names):
        raise SystemExit("a name is given twice")
    if len(entry_of) != len(used):
        raise SystemExit("two files on the disk have the same name")
    order = list(names) + [img.name_of(e) for e in used if img.name_of(e) not in names]
    for e, name in zip(slots, order):
        img.d[e + 2:e + geosimg.SLOT] = entry_of[name]
    for e in slots[len(order):]:                    # the slots after them: free
        img.d[e + 2:e + geosimg.SLOT] = bytes(geosimg.SLOT - 2)
    return order


def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    path, names = sys.argv[1], sys.argv[2:]
    img = geosimg.Image(open(path, "rb").read())
    order = put_in_order(img, names)
    open(path, "wb").write(img.d)
    for i, name in enumerate(order):
        print("page %d  %s" % (i // 8 + 1, name))


if __name__ == "__main__":
    main()
