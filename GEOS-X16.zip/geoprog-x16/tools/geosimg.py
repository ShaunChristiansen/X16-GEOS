#!/usr/bin/env python3
"""GEOS disk images: D64 (1541) and D81 (1581).

   geosimg.py new IMAGE.D81 "DISK NAME" ID   a blank GEOS disk (D64 or D81,
                                             by the file name's extension)
   geosimg.py cp FROM TO "FILE NAME" ...     copy files (GEOS-aware: the info
                                             block and the VLIR records go
                                             along); "*" copies them all
   geosimg.py clone FROM TO                  copy every file to the same
                                             directory slot (the deskTop
                                             shows the icons by slot)
   geosimg.py add IMAGE "NAME" HEADER DATA   a new GEOS file (sequential): its
                                             256-byte header block and its data
   geosimg.py cvt IMAGE FILE.CVT ...         GEOS files in CVT (convert) form
                                             (as GEOS's CONVERT makes them)
   geosimg.py cvtfrom IMAGE FROM "NAME" ...  the same, from CVT files kept on
                                             another disk image (plain files)
   geosimg.py rm IMAGE "FILE NAME" ...       delete files (GEOS-aware: the
                                             info block and the VLIR records
                                             are freed too)
   geosimg.py slot IMAGE "FILE NAME" N       move a file's directory entry to
                                             slot N (the deskTop shows the
                                             icons by slot)
   geosimg.py sum IMAGE "FILE NAME" ...      a checksum of each file's contents
                                             (its types, data or VLIR records,
                                             info block): equal for a copy
   geosimg.py ls IMAGE                       the directory
   geosimg.py check IMAGE                    every block of every file
                                             allocated once, the BAM agrees

A D81 gets what GEOS 2.0's 1581 driver expects: header 40/0 (the disk name
also at $90, where GEOS reads it, and the GEOS signature with the border
block at $AB), BAM 40/1 (tracks 1-40) and 40/2 (tracks 41-80), directory
from 40/3.  Files go from track 39 down, then from track 41 up, as the
1581 driver allocates them.

Other tools import it: Image is a disk image in memory, and the functions
below copy, add and remove files on one."""
import hashlib
import sys

# Every block is 256 bytes.  The first two are the track and sector of the
# next block of the file (track 0: this is the last block, and the second
# byte is where its data ends); the other 254 are data.
BLOCK = 256
DATA_BYTES = 254

D81_SIZE = 819200
D64_SIZE = 174848
D64_WITH_ERRORS = 175531        # a D64 with the 683 error bytes on the end

# The disk's header block (D64 18/0, D81 40/0): where GEOS's things are
DISK_NAME = 0x90                # the disk's name, where GEOS reads it
BORDER = 0xAB                   # track, sector of GEOS's border block
SIGNATURE = 0xAD                # the GEOS signature: it makes a disk GEOS's
GEOS_ID = b"GEOS format V1.0"

# The directory is a chain of blocks, each with eight 32-byte slots.  The
# first two bytes of a block (its first slot's) link to the next directory
# block; the other 30 bytes of each slot are a directory entry, the same 30
# bytes a CVT file starts with.  Where things are in a slot:
SLOT = 32
DIR_TYPE = 2                    # the Commodore file type ($83: USR); 0 = a free slot
DIR_FIRST = 3                   # track, sector of the data (a VLIR file: its index block)
DIR_NAME = 5                    # the name: 16 bytes, padded with $A0
DIR_INFO = 21                   # track, sector of the GEOS info block (0: not a GEOS file)
DIR_STRUCTURE = 23              # SEQUENTIAL or VLIR
DIR_GEOS_TYPE = 24              # application, desk accessory ... (GEOS_TYPES)
DIR_DATE = 25                   # year - 1900, month, day, hour, minute
DIR_SIZE = 30                   # the size in blocks (a word, low byte first)
ENTRY = slice(2, SLOT)          # the directory entry in a slot

SEQUENTIAL = 0
VLIR = 1
VLIR_RECORDS = 127              # a VLIR file's index block: each record's
                                # track and sector, from byte 2 (0, 0: no
                                # record; 0, $FF: an empty one)

# In a GEOS info block (a GEOS file's header)
INFO_CBM_TYPE = 0x44
INFO_GEOS_TYPE = 0x45

GEOS_TYPES = {0: "non-GEOS", 1: "BASIC", 2: "assembly", 3: "data", 4: "system",
              5: "desk acc", 6: "application", 7: "appl data", 8: "font",
              9: "printer", 10: "input", 11: "disk driver", 12: "boot",
              13: "temporary", 14: "auto-exec", 15: "input 128"}


def get_word(data, at):
    """The 16-bit number at data[at] (low byte first)."""
    return data[at] | data[at + 1] << 8


def put_word(data, at, value):
    data[at] = value & 255
    data[at + 1] = value >> 8


def name_bytes(name):
    """A file or disk name as it's kept: 16 bytes, padded with $A0."""
    return name.encode("latin1")[:16].ljust(16, b"\xA0")


def unpadded(data):
    """A name as it's kept (padded with $A0), as a string."""
    return bytes(c for c in data if c != 0xA0).decode("latin1")


class Image:
    """A D64 or D81 disk image in memory.  d is its bytes (a bytearray),
    changed in place: write it back to the file when you're done."""

    def __init__(self, data):
        self.d = bytearray(data)
        if len(self.d) == D81_SIZE:
            self.kind = "d81"
        elif len(self.d) in (D64_SIZE, D64_WITH_ERRORS):
            self.kind = "d64"
            del self.d[D64_SIZE:]                   # (the error bytes, if any)
        else:
            raise SystemExit("not a D64 or D81 image (%d bytes)" % len(self.d))
        d81 = self.kind == "d81"
        self.tracks = 80 if d81 else 35
        self.dirtrack = 40 if d81 else 18
        self.header = (40, 0) if d81 else (18, 0)       # the disk's header block
        self.firstdir = (40, 3) if d81 else (18, 1)     # the first directory block

    # ---- blocks

    def spt(self, t):
        """How many sectors track t has."""
        if self.kind == "d81":
            return 40
        if t <= 17:
            return 21
        if t <= 24:
            return 19
        if t <= 30:
            return 18
        return 17

    def off(self, t, s):
        """Where block t/s starts in the image."""
        if not (1 <= t <= self.tracks and 0 <= s < self.spt(t)):
            raise SystemExit("bad block %d/%d" % (t, s))
        if self.kind == "d81":
            return ((t - 1) * 40 + s) * BLOCK
        return (sum(self.spt(i) for i in range(1, t)) + s) * BLOCK

    def block(self, t, s):
        """A copy of block t/s."""
        o = self.off(t, s)
        return self.d[o:o + BLOCK]

    def put(self, t, s, data):
        """Writes block t/s (data shorter than a block is padded with 0s)."""
        o = self.off(t, s)
        self.d[o:o + BLOCK] = bytes(data).ljust(BLOCK, b"\0")

    def chain(self, t, s):
        """The blocks of the chain that starts at t/s, in order."""
        blocks = []
        while t:
            if (t, s) in blocks:
                raise SystemExit("chain loop")
            blocks.append((t, s))
            o = self.off(t, s)
            t, s = self.d[o], self.d[o + 1]
        return blocks

    def chain_data(self, t, s):
        """The data the chain that starts at t/s holds."""
        data = b""
        for bt, bs in self.chain(t, s):
            b = self.block(bt, bs)
            if b[0] == 0:                           # the last block: up to b[1]
                data += bytes(b[2:b[1] + 1])
            else:
                data += bytes(b[2:])
        return data

    def headerblock(self):
        """Where the disk's header block starts in the image."""
        return self.off(*self.header)

    def diskname(self):
        h = self.headerblock()
        return unpadded(self.d[h + DISK_NAME:h + DISK_NAME + 16])

    # ---- the BAM: which blocks are free

    def bament(self, t):
        """Where track t is in the BAM: the offsets of its free count and of
        its bitmap (a bit a sector, 1 = free)."""
        if self.kind == "d81":
            bam = self.off(40, 1 if t <= 40 else 2)     # 40/1 tracks 1-40, 40/2 41-80
            count = bam + 0x10 + 6 * ((t - 1) % 40)
        else:
            count = self.off(18, 0) + 4 * t
        return count, count + 1

    def is_free(self, t, s):
        _, bitmap = self.bament(t)
        return self.d[bitmap + s // 8] & (1 << (s % 8)) != 0

    def use(self, t, s):
        """Marks block t/s used (it must be free)."""
        count, bitmap = self.bament(t)
        if not self.is_free(t, s):
            raise SystemExit("block %d/%d already in use" % (t, s))
        self.d[bitmap + s // 8] &= ~(1 << (s % 8)) & 255
        self.d[count] -= 1

    def free(self, t, s):
        """Marks block t/s free (if it isn't already)."""
        count, bitmap = self.bament(t)
        if self.is_free(t, s):
            return
        self.d[bitmap + s // 8] |= 1 << (s % 8)
        self.d[count] += 1

    def free_blocks(self):
        """The free blocks, not counting the directory track (as the drive
        counts them)."""
        return sum(self.d[self.bament(t)[0]] for t in range(1, self.tracks + 1)
                   if t != self.dirtrack)

    def order(self):
        """The order the tracks are filled in: a D81 from track 39 down to
        1, then 41 up to 80 (as GEOS's 1581 driver does it); a D64 outwards
        from the directory track: 17, 19, 16, 20 ..."""
        if self.kind == "d81":
            return list(range(39, 0, -1)) + list(range(41, 81))
        tracks = []
        for k in range(1, 18):
            for t in (18 - k, 18 + k):
                if 1 <= t <= 35:
                    tracks.append(t)
        return tracks

    def sector_order(self, t):
        """The order a track's sectors are taken in: on a D81 one after the
        other; on a D64 10 apart (0, 10, 20, 9, 19 ...), as the 1541 spaces
        them, and when that lands on one already taken, the next one up (so
        an 18-sector track gets 0, 10, 2 ... 8, then 1, 11, 3 ... 9)."""
        sectors = self.spt(t)
        if self.kind == "d81":
            return list(range(sectors))
        order = []
        s = 0
        while len(order) < sectors:
            while s in order:
                s = (s + 1) % sectors
            order.append(s)
            s = (s + 10) % sectors
        return order

    def alloc(self):
        """Takes the next free block, marks it used and gives back its track
        and sector."""
        for t in self.order():
            for s in self.sector_order(t):
                if self.is_free(t, s):
                    self.use(t, s)
                    return t, s
        raise SystemExit("disk full")

    # ---- the directory

    def entries(self):
        """The offset of every slot in the directory, in order (the deskTop
        shows the files in this order, 8 a page), used or free."""
        t, s = self.firstdir
        seen = set()
        while t:
            if (t, s) in seen:
                raise SystemExit("directory loop")
            seen.add((t, s))
            o = self.off(t, s)
            for i in range(8):
                yield o + i * SLOT
            t, s = self.d[o], self.d[o + 1]

    def name_of(self, e):
        """The name of the file in slot e."""
        return unpadded(self.d[e + DIR_NAME:e + DIR_NAME + 16])

    def find(self, name):
        """The slot of the file called name, or None."""
        for e in self.entries():
            if self.d[e + DIR_TYPE] and self.name_of(e) == name:
                return e
        return None

    def find_file(self, name):
        """The slot of the file called name, which must be there."""
        e = self.find(name)
        if e is None:
            raise SystemExit("not found: " + name)
        return e

    def files(self):
        """The names of the files on the disk, in directory order."""
        return [self.name_of(e) for e in self.entries() if self.d[e + DIR_TYPE]]

    def is_vlir(self, e):
        """Whether the file in slot e is a GEOS VLIR file."""
        return self.d[e + DIR_INFO] != 0 and self.d[e + DIR_STRUCTURE] == VLIR

    def first_block(self, e):
        return self.d[e + DIR_FIRST], self.d[e + DIR_FIRST + 1]

    def info_block(self, e):
        """The track and sector of the GEOS info block of the file in slot e
        (track 0: it isn't a GEOS file)."""
        return self.d[e + DIR_INFO], self.d[e + DIR_INFO + 1]

    def vlir_records(self, e):
        """The records of the VLIR file in slot e: (number, track, sector)
        for each one there (track 0, sector $FF: an empty record)."""
        index = self.block(*self.first_block(e))
        records = []
        for r in range(VLIR_RECORDS):
            t, s = index[2 + 2 * r], index[3 + 2 * r]
            if t or s == 0xFF:
                records.append((r, t, s))
        return records

    def free_slot(self, want=None):
        """A free slot in the directory: the first one, or slot number want
        (0 = the first), which must be free.  Directory blocks are added if
        need be."""
        if want is not None:
            while len(list(self.entries())) <= want:
                self.add_dir_block()
            e = list(self.entries())[want]
            if self.d[e + DIR_TYPE]:
                raise SystemExit("slot %d in use" % want)
            return e
        for e in self.entries():
            if self.d[e + DIR_TYPE] == 0:
                return e
        return self.add_dir_block()

    def add_dir_block(self):
        """Adds an empty block to the end of the directory, from the
        directory track, and gives back its first slot."""
        last = list(self.entries())[-8]             # the last block's first slot: its link
        for s in range(self.spt(self.dirtrack)):
            if self.is_free(self.dirtrack, s):
                self.use(self.dirtrack, s)
                self.d[last], self.d[last + 1] = self.dirtrack, s
                o = self.off(self.dirtrack, s)
                self.d[o:o + BLOCK] = bytes(BLOCK)
                self.d[o + 1] = 0xFF
                return o
        raise SystemExit("directory full")


# ---- making disks

def new_image(path, name, disk_id):
    """Writes a blank GEOS disk image to path: a D81 if it ends in .d81,
    otherwise a D64."""
    name16 = name_bytes(name)
    disk_id = disk_id.encode("latin1")[:2].ljust(2)
    if path.lower().endswith(".d81"):
        img = Image(bytes(D81_SIZE))
        # the header block: the link to the directory, the DOS version "D",
        # the name, the ID and the DOS type "3D", then all that again at
        # $90 for GEOS
        h = bytearray(BLOCK)
        h[0:4] = bytes([40, 3, 0x44, 0])
        h[4:20] = name16
        h[0x14:0x16] = b"\xA0\xA0"
        h[0x16:0x18] = disk_id
        h[0x18:0x1D] = b"\xA0\x33\x44\xA0\xA0"
        for_geos = name16 + b"\xA0\xA0" + disk_id + b"\xA0\x33\x44\xA0\xA0\xA0\xA0"
        h[DISK_NAME:DISK_NAME + len(for_geos)] = for_geos
        img.put(40, 0, h)
        # the BAM: 40/1 (tracks 1-40, linked to 40/2) and 40/2 (tracks
        # 41-80), every track with its 40 sectors free
        for sector, link in ((1, (40, 2)), (2, (0, 0xFF))):
            b = bytearray(BLOCK)
            b[0:8] = bytes([link[0], link[1], 0x44, 0xBB]) + disk_id + bytes([0xC0, 0])
            for i in range(40):
                track = 0x10 + 6 * i
                b[track:track + 6] = bytes([40, 255, 255, 255, 255, 255])
            img.put(40, sector, b)
        for s in (0, 1, 2, 3):                      # the header, the BAM, the directory
            img.use(40, s)
        img.put(40, 3, bytes([0, 0xFF]))
        border = (40, 19)       # where GEOS's SetGEOSDisk puts it: the first free after 40/18
    else:
        img = Image(bytes(D64_SIZE))
        # the header block holds the BAM too: the link to the directory,
        # the DOS version "A", each track's free count and bitmap (all
        # free), then the name, the ID and the DOS type "2A" at $90
        b = bytearray(BLOCK)
        b[0:4] = bytes([18, 1, 0x41, 0])
        for t in range(1, 36):
            n = img.spt(t)
            bits = (1 << n) - 1
            b[4 * t:4 * t + 4] = bytes([n, bits & 255, (bits >> 8) & 255, bits >> 16])
        for_geos = name16 + b"\xA0\xA0" + disk_id + b"\xA0\x32\x41\xA0\xA0\xA0\xA0"
        b[DISK_NAME:DISK_NAME + len(for_geos)] = for_geos
        img.put(18, 0, b)
        img.use(18, 0)
        img.use(18, 1)
        img.put(18, 1, bytes([0, 0xFF]))
        border = (19, 0)
    # GEOS's border block (an empty directory block, for the files on the
    # deskTop's border) and the signature that makes it a GEOS disk
    img.use(*border)
    img.put(border[0], border[1], bytes([0, 0xFF]))
    h = img.headerblock()
    img.d[h + BORDER], img.d[h + BORDER + 1] = border
    img.d[h + SIGNATURE:h + SIGNATURE + 16] = GEOS_ID
    open(path, "wb").write(img.d)
    print("%s: %s, %d blocks free" % (path, img.kind.upper(), img.free_blocks()))


# ---- copying, adding and removing files

def copy_chain(src, dst, t, s):
    """Copies the chain that starts at src's t/s to new blocks on dst.
    Gives back its first block on dst ((0, 0) for no chain) and how many
    blocks it has."""
    blocks = src.chain(t, s)
    new = [dst.alloc() for _ in blocks]
    for i, ((old_t, old_s), (new_t, new_s)) in enumerate(zip(blocks, new)):
        data = bytearray(src.block(old_t, old_s))
        if i + 1 < len(new):
            data[0], data[1] = new[i + 1]           # the link: to the next new block
        dst.put(new_t, new_s, data)
    return (new[0] if new else (0, 0)), len(new)


def write_chain(dst, data):
    """Writes data to new blocks on dst, as a chain.  Gives back its first
    block and how many blocks it has (no data still takes one block)."""
    chunks = [data[i:i + DATA_BYTES] for i in range(0, len(data), DATA_BYTES)] or [b""]
    blocks = [dst.alloc() for _ in chunks]
    for i, (chunk, (t, s)) in enumerate(zip(chunks, blocks)):
        b = bytearray(BLOCK)
        if i + 1 < len(blocks):
            b[0], b[1] = blocks[i + 1]
        else:
            b[0], b[1] = 0, len(chunk) + 1          # the last block: where its data ends
        b[2:2 + len(chunk)] = chunk
        dst.put(t, s, b)
    return blocks[0], len(blocks)


def must_not_have(dst, name):
    if dst.find(name) is not None:
        raise SystemExit("already there: " + name)


def copy_file(src, dst, name, keep_slot=False):
    """Copies the file called name from src to dst: its data (a VLIR file's
    index block and records) and its GEOS info block.  keep_slot: in the
    same directory slot as on src (which must be free on dst)."""
    e = src.find_file(name)
    slot_number = list(src.entries()).index(e)
    must_not_have(dst, name)
    slot = bytearray(src.d[e:e + SLOT])             # changed below to dst's blocks
    blocks = 0
    if src.d[e + DIR_INFO]:
        slot[DIR_INFO:DIR_INFO + 2], n = copy_chain(src, dst, *src.info_block(e))
        blocks += n
    if src.d[e + DIR_STRUCTURE] == VLIR:
        index = bytearray(src.block(*src.first_block(e)))
        for r in range(VLIR_RECORDS):
            t, s = index[2 + 2 * r], index[3 + 2 * r]
            if t:
                index[2 + 2 * r:4 + 2 * r], n = copy_chain(src, dst, t, s)
                blocks += n
        index_t, index_s = dst.alloc()
        dst.put(index_t, index_s, index)
        slot[DIR_FIRST:DIR_FIRST + 2] = index_t, index_s
        blocks += 1
    else:
        slot[DIR_FIRST:DIR_FIRST + 2], n = copy_chain(src, dst, *src.first_block(e))
        blocks += n
    put_word(slot, DIR_SIZE, blocks)
    to = dst.free_slot(slot_number if keep_slot else None)
    dst.d[to + 2:to + SLOT] = slot[ENTRY]
    print("copied %-16s %4d blocks" % (name, blocks))


def add_file(dst, name, header, data, date=(126, 11, 16, 12, 0)):
    """Adds a sequential GEOS file to dst: header is its info block (256
    bytes; bytes 0-1 are ignored), data its contents.  Its Commodore and
    GEOS file types come from the header ($44 and $45).  date: year - 1900,
    month, day, hour, minute."""
    must_not_have(dst, name)
    info_t, info_s = dst.alloc()
    info = bytearray(header[:BLOCK].ljust(BLOCK, b"\0"))
    info[0], info[1] = 0, 0xFF                      # (a single block)
    dst.put(info_t, info_s, info)
    first, n = write_chain(dst, data)
    slot = bytearray(SLOT)
    slot[DIR_TYPE] = info[INFO_CBM_TYPE] or 0x83
    slot[DIR_FIRST:DIR_FIRST + 2] = first
    slot[DIR_NAME:DIR_NAME + 16] = name_bytes(name)
    slot[DIR_INFO:DIR_INFO + 2] = info_t, info_s
    slot[DIR_STRUCTURE] = SEQUENTIAL
    slot[DIR_GEOS_TYPE] = info[INFO_GEOS_TYPE]
    slot[DIR_DATE:DIR_DATE + 5] = bytes(date)
    put_word(slot, DIR_SIZE, n + 1)
    e = dst.free_slot()
    dst.d[e + 2:e + SLOT] = slot[ENTRY]
    print("added %-16s %4d blocks" % (name, n + 1))


def parse_cvt(raw):
    """Splits a CVT file (as GEOS's CONVERT makes them) into its directory
    entry (30 bytes), its header (the info block, 256 bytes), and its data:
    a VLIR file's records (a list; None for an empty record) or a
    sequential file's bytes."""
    if b"formatted GEOS file" not in raw[30:64]:
        raise SystemExit("not a CVT file")
    entry = bytearray(raw[0:30])
    header = bytearray(2) + raw[254:508]
    header[0], header[1] = 0, 0xFF
    if entry[DIR_STRUCTURE - 2] == VLIR:
        # a table of each record's size (its blocks, and the bytes used in
        # its last block), then the records, each in whole blocks
        sizes = raw[508:762]
        at = 762
        records = []
        for r in range(VLIR_RECORDS):
            blocks, last = sizes[2 * r], sizes[2 * r + 1]
            if blocks == 0 and last == 0:           # no more records
                break
            if blocks == 0:                         # (0, $FF): an empty record
                records.append(None)
                continue
            size = (blocks - 1) * DATA_BYTES + (last - 1)
            records.append(raw[at:at + size])
            at += blocks * DATA_BYTES
        return entry, bytes(header), records
    return entry, bytes(header), raw[508:]


def add_cvt(dst, raw):
    """Adds the GEOS file in a CVT file to dst.  Gives back its name."""
    entry, header, body = parse_cvt(raw)
    name = unpadded(entry[DIR_NAME - 2:DIR_NAME - 2 + 16])
    must_not_have(dst, name)
    info_t, info_s = dst.alloc()
    dst.put(info_t, info_s, bytearray(header))
    blocks = 1
    if isinstance(body, list):                      # VLIR: the records, then the index
        index = bytearray(BLOCK)
        index[0], index[1] = 0, 0xFF
        for r, record in enumerate(body):
            if record is None:
                index[2 + 2 * r], index[3 + 2 * r] = 0, 0xFF
                continue
            (t, s), n = write_chain(dst, record)
            index[2 + 2 * r], index[3 + 2 * r] = t, s
            blocks += n
        first = dst.alloc()
        dst.put(first[0], first[1], index)
        blocks += 1
    else:
        first, n = write_chain(dst, body)
        blocks += n
    slot = bytearray(2) + entry
    slot[DIR_FIRST:DIR_FIRST + 2] = first
    slot[DIR_INFO:DIR_INFO + 2] = info_t, info_s
    put_word(slot, DIR_SIZE, blocks)
    e = dst.free_slot()
    dst.d[e + 2:e + SLOT] = slot[ENTRY]
    print("added %-16s %4d blocks (from CVT)" % (name, blocks))
    return name


def remove_file(img, name):
    """Deletes the file called name: its blocks are freed in the BAM (its
    data, or a VLIR file's index block and records; its GEOS info block),
    and its directory entry is cleared."""
    e = img.find_file(name)
    if img.is_vlir(e):
        for r, t, s in img.vlir_records(e):
            if t:
                for bt, bs in img.chain(t, s):
                    img.free(bt, bs)
        img.free(*img.first_block(e))
    else:
        for bt, bs in img.chain(*img.first_block(e)):
            img.free(bt, bs)
    if img.d[e + DIR_INFO]:
        img.free(*img.info_block(e))
    img.d[e + 2:e + SLOT] = bytes(SLOT - 2)


def move_slot(img, name, slot):
    """Moves the directory entry of the file called name to slot number
    slot (0 = the first), which must be free."""
    slots = list(img.entries())
    while len(slots) <= slot:
        img.add_dir_block()
        slots = list(img.entries())
    e = img.find_file(name)
    to = slots[slot]
    if to == e:
        return
    if img.d[to + DIR_TYPE]:
        raise SystemExit("slot %d is not free" % slot)
    img.d[to + 2:to + SLOT] = img.d[e + 2:e + SLOT]
    img.d[e + 2:e + SLOT] = bytes(SLOT - 2)


# ---- looking at disks

def file_sum(img, name):
    """A SHA-1 of the contents of the file called name, the same for any
    copy of the file: its Commodore, structure and GEOS types, its data (a
    VLIR file's records, in order, each one marked), and its GEOS info block
    (not the blocks' addresses)."""
    e = img.find_file(name)
    h = hashlib.sha1(bytes([img.d[e + DIR_TYPE], img.d[e + DIR_STRUCTURE], img.d[e + DIR_GEOS_TYPE]]))
    if img.is_vlir(e):
        for r, t, s in img.vlir_records(e):
            i = 2 + 2 * r                           # (the record's place in the index block)
            if t:
                h.update(b"R%d:" % i + img.chain_data(t, s))
            else:
                h.update(b"E%d" % i)                # an empty record
    else:
        h.update(img.chain_data(*img.first_block(e)))
    if img.d[e + DIR_INFO]:
        h.update(bytes(img.block(*img.info_block(e))[2:]))
    return h.hexdigest()


def ls(img):
    h = img.headerblock()
    is_geos = bytes(img.d[h + SIGNATURE:h + SIGNATURE + 16]) == GEOS_ID
    print("%s  disk: %r  GEOS: %s" % (img.kind.upper(), img.diskname(), is_geos))
    for e in img.entries():
        if img.d[e + DIR_TYPE]:
            structure = "VLIR" if img.d[e + DIR_STRUCTURE] == VLIR else "seq"
            print("%5d  %-16s  $%02X  %-12s %-4s %d/%d" % (
                get_word(img.d, e + DIR_SIZE), img.name_of(e), img.d[e + DIR_TYPE],
                GEOS_TYPES.get(img.d[e + DIR_GEOS_TYPE], "?"), structure, *img.first_block(e)))
    print("blocks free:", img.free_blocks())


def check(img):
    """Checks that every block in use belongs to one thing (the header, the
    BAM, the directory, the border block, a file), that each file's size is
    right, and that the BAM agrees.  Prints what's wrong; True if nothing
    is."""
    used = {}                                       # block: what it belongs to

    def mark(t, s, what):
        if (t, s) in used:
            raise SystemExit("%d/%d used twice: %s, %s" % (t, s, used[(t, s)], what))
        used[(t, s)] = what

    mark(*img.header, what="header")
    if img.kind == "d81":
        mark(40, 1, "BAM 1")
        mark(40, 2, "BAM 2")
    for t, s in img.chain(*img.firstdir):
        mark(t, s, "directory")
    h = img.headerblock()
    if bytes(img.d[h + SIGNATURE:h + SIGNATURE + 16]) == GEOS_ID and img.d[h + BORDER]:
        mark(img.d[h + BORDER], img.d[h + BORDER + 1], "border block")

    for e in img.entries():
        if not img.d[e + DIR_TYPE]:
            continue
        name = img.name_of(e)
        blocks = 0
        if img.d[e + DIR_INFO]:
            for t, s in img.chain(*img.info_block(e)):
                mark(t, s, name)
                blocks += 1
        if img.d[e + DIR_STRUCTURE] == VLIR:
            mark(*img.first_block(e), what=name)    # the index block
            blocks += 1
            index = img.block(*img.first_block(e))
            for r in range(VLIR_RECORDS):
                if index[2 + 2 * r]:
                    for t, s in img.chain(index[2 + 2 * r], index[3 + 2 * r]):
                        mark(t, s, name)
                        blocks += 1
        else:
            for t, s in img.chain(*img.first_block(e)):
                mark(t, s, name)
                blocks += 1
        size = get_word(img.d, e + DIR_SIZE)
        if blocks != size:
            print("note: %s says %d blocks, has %d" % (name, size, blocks))

    problems = 0
    for t in range(1, img.tracks + 1):
        count, _ = img.bament(t)
        free = 0
        for s in range(img.spt(t)):
            is_free = img.is_free(t, s)
            free += is_free
            if is_free == ((t, s) in used):
                problems += 1
                if problems < 10:
                    print("BAM: %d/%d %s" % (t, s, "free but used" if is_free else "allocated but unused"))
        if free != img.d[count]:
            problems += 1
            print("BAM: track %d count %d, %d free" % (t, img.d[count], free))
    print("%s: %d blocks used, BAM %s" % (img.kind.upper(), len(used),
                                          "OK" if not problems else "has %d problems" % problems))
    return problems == 0


# ---- the command line

def load(path):
    return Image(open(path, "rb").read())


def save(img, path):
    open(path, "wb").write(img.d)


def main():
    args = sys.argv[1:]
    if not args:
        raise SystemExit(__doc__)
    command = args[0]
    if command == "new":
        new_image(args[1], args[2], args[3])
    elif command == "ls":
        ls(load(args[1]))
    elif command == "check":
        sys.exit(0 if check(load(args[1])) else 1)
    elif command == "sum":
        img = load(args[1])
        for name in args[2:]:
            print("  %s: %s" % (name, file_sum(img, name)))
    elif command == "rm":
        img = load(args[1])
        for name in args[2:]:
            remove_file(img, name)
        save(img, args[1])
        print("blocks free:", img.free_blocks())
    elif command == "slot":
        img = load(args[1])
        move_slot(img, args[2], int(args[3]))
        save(img, args[1])
    elif command in ("cp", "clone"):
        src, dst = load(args[1]), load(args[2])
        keep_slot = command == "clone"
        names = src.files() if keep_slot or args[3:] == ["*"] else args[3:]
        for name in names:
            copy_file(src, dst, name, keep_slot)
        save(dst, args[2])
        print("blocks free:", dst.free_blocks())
    elif command == "add":
        dst = load(args[1])
        add_file(dst, args[2], open(args[3], "rb").read(), open(args[4], "rb").read())
        save(dst, args[1])
        print("blocks free:", dst.free_blocks())
    elif command == "cvt":
        dst = load(args[1])
        for path in args[2:]:
            add_cvt(dst, open(path, "rb").read())
        save(dst, args[1])
        print("blocks free:", dst.free_blocks())
    elif command == "cvtfrom":
        dst, src = load(args[1]), load(args[2])
        for name in args[3:]:
            e = src.find_file(name)
            add_cvt(dst, src.chain_data(*src.first_block(e)))
        save(dst, args[1])
        print("blocks free:", dst.free_blocks())
    else:
        raise SystemExit(__doc__)


if __name__ == "__main__":
    main()
