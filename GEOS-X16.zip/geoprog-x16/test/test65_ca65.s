	.setcpu "65C02"
	.org $0400
ProgStart:
	tsb $12
	tsb $1234
	trb $12
	trb $1234
	stz $12
	stz $12,x
	stz $1234
	stz $1234,x
	bit $1234,x
	bit $12,x
	bit #$55
	inc a
	dec a
	phx
	plx
	phy
	ply
	wai
	stp
	ora ($12)
	and ($12)
	eor ($12)
	adc ($12)
	sta ($12)
	lda ($12)
	cmp ($12)
	sbc ($12)
	jmp ($1234,x)
	jmp (JumpTab,x)
	jmp ($1234)
	lda ($12),y
	lda ($12,x)
	lda $12
	lda $1234
	bra Forward
	nop
Back:	bra Back
Forward:
	rts
JumpTab:
	.word ProgStart
