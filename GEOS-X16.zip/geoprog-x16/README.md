# geoProgrammer for the Commander X16

Berkeley Softworks' geoProgrammer 1.1 (geoAssembler, geoLinker, geoDebugger), set up for writing programs
for the Commander X16 on GEOS-X16, the GEOS 128 cartridge. It goes on drive B ("GEOS X16 B"), first.

You need your own copy of geoProgrammer: these files only change it.

## What's different from the 1987 package

* **Runs on GEOS 128.** Robert J.G. Norton's geoProgPatch 2.1 is applied first: geoAssembler and
  geoLinker in 40 and 80 columns, geoDebugger in 40.
* **geoAssembler knows the X16's 65C02.** As well as the 6502's instructions: `stz`, `bra`, `phx`,
  `phy`, `plx`, `ply`, `trb`, `tsb`, `bit` (`#`, `zp,x`, `addr,x`), `inc a`, `dec a`, the `(zp)` mode
  (`lda (ptr)` ...), `jmp (addr,x)`, `wai` and `stp`. For the WDC bit instructions, Berkeley's own
  geosMac macros `smb`, `rmb`, `bbs` and `bbr` do the same job. test/Test65 assembles every one of them,
  and the result is compared byte for byte with ca65's.
* **"Open the error file" works.** It starts geoWrite as GEOWRITE X16, and GEOS-X16 switches to 80
  columns for it (geoWrite X16 is an 80-column program), and back to 40 with the deskTop.
* **X16 include files**, as geoWrite documents like Berkeley's own:
  * `x16Sym`: the X16's hardware: VERA (video, the PSG, PCM), the YM2151, VIA 2, the expansion
    slots, and TexElec's serial card (its UART registers and baud divisors).
  * `x16GeosSym`: GEOS-X16's calls for programs (the serial port on either card, files, disk
    images, video and sound) and the X16 KERNAL routines they can reach.
  * `x16Mac`: `VAddr`, a macro for VERA's address registers. (geoAssembler has room for 30 macros
    and geosMac already holds 29.)
* **A sample X16 program**, `SamX16` (with `SamX16Hdr` and `SamX16.lnk`): it shows GEOS-X16's version,
  beeps on VERA's PSG and says AT to the modem through the serial port.

## Things to know about geoAssembler

* It keeps the **first 8 characters** of a name. `VERA_ADDR_L` and `VERA_ADDR_M` would be the same
  name to it, so every name in the X16 files is unique in its first 8.
* `.output` in a link file takes one word: `X16Sample`, not `X16 Sample`.
* `==` makes a name geoDebugger shows; `=` doesn't. The X16 files use `==` for registers.
* A file icon in a `.header` has to be a picture in the document. In the text files here it's drawn
  in `#` and `.` between `\picture` and `\end`, and `tools/geowritedoc.py` makes it a picture.

## The files here

| File | What |
|---|---|
| `x16Sym.txt`, `x16GeosSym.txt`, `x16Mac.txt` | the include files, as plain text |
| `SamX16.txt`, `SamX16Hdr.txt`, `SamX16.lnk.txt` | the sample program |
| `test/` | Test65 (every 65C02 instruction), its link file, and the same source for ca65 |

`tools/geowritedoc.py` turns a text file into a geoWrite document (`\f` on a line of its own starts a
new page). `tools/geoprogx16.py` builds the whole disk from your geoProgrammer disks:

    geoprogx16.py GEOPROG.D81 geoprog_s1.d64 geoprog_s2.d64 GEOPROG-PATCHED.D81

GEOPROG-PATCHED.D81 holds GEOASSEMBLER, GEOLINKER and GEODEBUGGER after geoProgPatch 2.1 has been
run on them (once, in GEOS 128). Every change checks the bytes it replaces first, so another version
of geoProgrammer is refused rather than damaged.

`test_x16_128_geoprog.sh` (in the GEOS-X16 folder) builds the disk, assembles and links the sample
and Test65 in the emulator, compares Test65 with ca65, and runs the sample against an emulated
TexElec card.

## How geoAssembler was taught the 65C02

Its instruction table (in record 0, at $3C1C) is four 256-byte tables indexed by the opcode: the
mnemonic's three letters and its addressing mode. The 65C02's opcodes went into the empty slots.
Two new addressing modes, `(zp)` and `(addr,x)`, needed the operand parser changed. Each of its two
13-byte pieces was rewritten in place, to the same length, and the new mode numbers ($50 and $BC) are
ones the existing length table already answers with 2 and 3 bytes.
