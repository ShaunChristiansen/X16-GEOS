@echo off
rem Makes GEOPROG-X16.D81: geoProgrammer for the X16, from your own geoProgrammer disks (see README.md).
rem   build.bat geoprog_s1.d64 geoprog_s2.d64 GEOPROG-PATCHED.D81
rem Needs Python 3 (python on the PATH).
cd /d "%~dp0"
if "%~3"=="" (
  echo usage: build.bat geoprog_s1.d64 geoprog_s2.d64 GEOPROG-PATCHED.D81
  exit /b 1
)
python tools\geoprogx16.py GEOPROG-X16.D81 "%~1" "%~2" "%~3"
