#!/bin/sh
# Makes GEOPROG-X16.D81: geoProgrammer for the X16, from your own geoProgrammer disks (see README.md).
#   ./build.sh geoprog_s1.d64 geoprog_s2.d64 GEOPROG-PATCHED.D81
# Needs Python 3.
cd "$(dirname "$0")" || exit 1
[ $# -eq 3 ] || { echo "usage: ./build.sh geoprog_s1.d64 geoprog_s2.d64 GEOPROG-PATCHED.D81"; exit 1; }
python3 tools/geoprogx16.py GEOPROG-X16.D81 "$1" "$2" "$3"
