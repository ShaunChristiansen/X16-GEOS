@echo off
rem Builds a Prog8 GEOS program and puts it on a GEOS disk image.
rem
rem   build.bat SOURCE.p8 "NAME" DISK.D81 [SLOT]
rem   e.g.  build.bat examples\demo.p8 "PROG8 DEMO" path\to\GEOS128A.D81
rem
rem NAME is the file's name on the disk (up to 16 characters).  SLOT, if it's
rem given, is the file's place in the directory, 0 for the first (the deskTop
rem shows the files 8 a page, in that order).  A file of the same name on the
rem disk is replaced.
rem
rem Needs Java, Prog8's compiler prog8c.jar (12.3.5 or newer: in this folder,
rem or set PROG8C to its path), 64tass on the PATH, and Python 3.
setlocal
if "%~3"=="" (
  echo usage: build.bat SOURCE.p8 "NAME" DISK.D81 [SLOT]
  exit /b 1
)

rem The paths given are from the folder we were started in.  The build runs in
rem this script's folder (where target and lib are), so make them full paths.
set "SRC=%~f1"
set "NAME=%~2"
set "DISK=%~f3"
set "SLOT=%~4"
if defined PROG8C (
  for %%F in ("%PROG8C%") do set "PROG8C=%%~fF"
) else (
  set "PROG8C=prog8c.jar"
)

cd /d "%~dp0"
if not exist build mkdir build
java -jar "%PROG8C%" -target target\geos.properties -srcdirs lib -out build "%SRC%" || exit /b 1
python tools\mkp8app.py "build\%~n1.bin" "%NAME%" "%DISK%" %SLOT%
