#!/usr/bin/env python3
"""Puts a Prog8 program built for GEOS on a GEOS disk image, as a GEOS
application: the deskTop shows its icon, and runs it when it's
double-clicked.

   mkp8app.py PROGRAM.bin "NAME" DISK.D81 [SLOT] [--icon ICON.txt]
              [--class "Class Name V1.0"] [--info "the info box's text"]

PROGRAM.bin is what Prog8 makes with prog8-geos's target: the program's
bytes, which run at $0400.  The file gets a GEOS header: an icon (ICON.txt:
21 lines of 24 characters, # for a black pixel; without one, a "P8" icon),
the type APPLICATION, loaded and started at $0400, a class name (up to 19
characters), "Prog8" as the author, and the text of its info box (up to 95
characters).  GEOS 128 runs it in 40 columns.

SLOT puts it at that place in the directory (0 = the first; the deskTop
shows the files 8 a page, in that order).  A file of the same name already
on the disk is replaced.  DISK can be a D64 too."""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import geosimg
import geosorder

LOAD = 0x0400           # where GEOS loads an application, and starts it
TOP = 0x6000            # where GEOS 64's application area ends

# Where things are in a GEOS file's header (its info block)
HDR_ICON = 2            # the icon: its width in bytes, height, a count byte, the bitmap
HDR_CBM_TYPE = 0x44     # the Commodore file type ($83: USR)
HDR_GEOS_TYPE = 0x45
HDR_STRUCTURE = 0x46    # 0: sequential
HDR_LOAD = 0x47         # the load address, the end address and the start address (words)
HDR_END = 0x49
HDR_START = 0x4B
HDR_CLASS = 0x4D        # the class name
HDR_MODE = 0x60         # (the class's 20th byte) GEOS 128: $00 40 columns, $40 40 or 80,
                        # $80 GEOS 64 only, $C0 80 columns
HDR_AUTHOR = 0x61
HDR_INFO = 0xA0         # the info box's text

APPLICATION = 6

# The icon if none is given: 24 x 21 pixels, # for black
ICON = """
########################
#......................#
#.#####.....#####......#
#.#....#...#.....#.....#
#.#....#...#.....#.....#
#.#####.....#####......#
#.#........#.....#.....#
#.#........#.....#.....#
#.#.........#####......#
#......................#
#......................#
#..##..###..####...##..#
#.#...#...#.#...#.#..#.#
#.#.#.#...#.####..#..#.#
#.#.#.#...#.#.....#..#.#
#..##..###..#......##..#
#......................#
#......................#
#......................#
#......................#
########################
"""


def icon_bitmap(picture):
    """The icon's bitmap (63 bytes, 3 a row) from its picture: 21 lines of
    24 characters, # for a black pixel and anything else for white."""
    rows = picture.strip("\r\n").splitlines()
    if len(rows) != 21 or any(len(row) != 24 for row in rows):
        raise SystemExit("an icon is 21 lines of 24 characters")
    bitmap = bytearray()
    for row in rows:
        for x in range(0, 24, 8):
            byte = 0
            for pixel in row[x:x + 8]:
                byte = byte << 1 | (pixel == "#")
            bitmap.append(byte)
    return bytes(bitmap)


def put_text(header, at, text, most):
    data = text.encode("latin1")[:most]
    header[at:at + len(data)] = data


def make_header(program, icon, class_name, info):
    """The program's GEOS header: its info block, 256 bytes."""
    h = bytearray(geosimg.BLOCK)
    h[0], h[1] = 0, 0xFF                                    # (a single block)
    h[HDR_ICON:HDR_ICON + 3] = bytes([3, 21, 0x80 | 63])    # 3 bytes x 21, 63 bytes as they are
    h[HDR_ICON + 3:HDR_ICON + 3 + 63] = icon_bitmap(icon)
    h[HDR_CBM_TYPE] = 0x83
    h[HDR_GEOS_TYPE] = APPLICATION
    h[HDR_STRUCTURE] = 0
    geosimg.put_word(h, HDR_LOAD, LOAD)
    geosimg.put_word(h, HDR_END, LOAD + len(program))
    geosimg.put_word(h, HDR_START, LOAD)
    put_text(h, HDR_CLASS, class_name, 19)
    h[HDR_MODE] = 0x00                                      # 40 columns
    put_text(h, HDR_AUTHOR, "Prog8", 20)
    put_text(h, HDR_INFO, info, 95)
    return bytes(h)


def main():
    ap = argparse.ArgumentParser(description="Puts a Prog8 GEOS program on a GEOS disk image.")
    ap.add_argument("bin", help="the program, as Prog8 built it")
    ap.add_argument("name", help="its name on the disk (up to 16 characters)")
    ap.add_argument("disk", help="the disk image (D81 or D64)")
    ap.add_argument("slot", nargs="?", type=int, help="its place in the directory (0 = the first)")
    ap.add_argument("--icon", help="a text file with its icon: 21 lines of 24, # for black")
    ap.add_argument("--class", dest="class_name", default="Prog8 App   V1.0",
                    help="its class name (up to 19 characters)")
    ap.add_argument("--info", default="A GEOS application written in Prog8.",
                    help="the text of its info box (up to 95 characters)")
    args = ap.parse_args()

    program = open(args.bin, "rb").read()
    if LOAD + len(program) > TOP:
        raise SystemExit("%s is too big for GEOS: %d bytes, and $%04X-$%04X holds %d"
                         % (args.bin, len(program), LOAD, TOP - 1, TOP - LOAD))
    icon = open(args.icon).read() if args.icon else ICON
    header = make_header(program, icon, args.class_name, args.info)

    img = geosimg.Image(open(args.disk, "rb").read())
    if img.find(args.name) is not None:                     # an older copy: replaced
        geosimg.remove_file(img, args.name)
    geosimg.add_file(img, args.name, header, program)
    if args.slot is not None:
        # the first SLOT of the other files stay first, then this one
        others = [name for name in img.files() if name != args.name]
        geosorder.put_in_order(img, others[:args.slot] + [args.name])
    open(args.disk, "wb").write(img.d)
    print("%s: %s (%d bytes, $%04X-$%04X)" % (args.disk, args.name, len(program),
                                              LOAD, LOAD + len(program) - 1))


if __name__ == "__main__":
    main()
