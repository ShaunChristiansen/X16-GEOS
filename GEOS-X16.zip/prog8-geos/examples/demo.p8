; PROG8 DEMO: a GEOS application written in Prog8, for GEOS-X16.
;
; It shows a window with a click counter and two buttons (+1 and reset), and
; a menu bar: geos > about... (a dialog box) and file > quit.  The window
; also tells whoever runs it where this source is, so they can write their
; own.  Copying this file is a good way to start a program of your own.
;
; Build it and put it on a GEOS disk with the kit's build script:
;   ./build.sh examples/demo.p8 "PROG8 DEMO" path/to/GEOS128A.D81
; (on Windows: build.bat, the same way).
;
; Screen positions are GEOS's: x 0-319 and y 0-199 (40 columns).  Text is
; placed by its baseline, the line its letters sit on.

%import geos
%zeropage dontuse

main {
    ; GEOS's tables for the menus, the buttons and the about box.  They hold
    ; addresses, so start() fills them in (lib/geos.p8 has the sizes).
    ubyte[geos.MENU_HEAD + 2*geos.MENU_ITEM] mainmenu
    ubyte[geos.MENU_HEAD + 1*geos.MENU_ITEM] geosmenu
    ubyte[geos.MENU_HEAD + 1*geos.MENU_ITEM] filemenu
    ubyte[geos.ICONS_HEAD + 2*geos.ICON] buttons
    ubyte[geos.DLG_HEAD + 4*geos.DLG_TEXT + geos.DLG_BUTTON + geos.DLG_END] aboutbox

    ; The buttons' picture: 48 x 16 pixels, 6 bytes a row, a bit a pixel
    ; (1 is black).  It's in GEOS's compacted bitmap format, where a count
    ; byte of 128 + n means "the next n bytes, as they are".  One count goes
    ; up to 92 bytes, so the 96 bytes here are two runs of 48 (8 rows each).
    ubyte[] button = [
        128 + 48,
        %00111111, %11111111, %11111111, %11111111, %11111111, %11111100,
        %01000000, %00000000, %00000000, %00000000, %00000000, %00000010,
        %10000000, %00000000, %00000000, %00000000, %00000000, %00000001,
        %10000000, %00000000, %00000000, %00000000, %00000000, %00000001,
        %10000000, %00000000, %00000000, %00000000, %00000000, %00000001,
        %10000000, %00000000, %00000000, %00000000, %00000000, %00000001,
        %10000000, %00000000, %00000000, %00000000, %00000000, %00000001,
        %10000000, %00000000, %00000000, %00000000, %00000000, %00000001,
        128 + 48,
        %10000000, %00000000, %00000000, %00000000, %00000000, %00000001,
        %10000000, %00000000, %00000000, %00000000, %00000000, %00000001,
        %10000000, %00000000, %00000000, %00000000, %00000000, %00000001,
        %10000000, %00000000, %00000000, %00000000, %00000000, %00000001,
        %10000000, %00000000, %00000000, %00000000, %00000000, %00000001,
        %10000000, %00000000, %00000000, %00000000, %00000000, %00000001,
        %01000000, %00000000, %00000000, %00000000, %00000000, %00000010,
        %00111111, %11111111, %11111111, %11111111, %11111111, %11111100
    ]

    uword count = 0         ; clicks on +1 since the start (or the last reset)

    sub start() {
        ; GEOS calls this when the program has loaded.  It draws the screen
        ; and sets up the buttons and the menus, then returns: from then on
        ; GEOS calls the routines below when they're clicked.

        ; the screen: GEOS's grey background, and a white window with a frame
        geos.box(0, 199, 0, 319, 2)
        geos.box(20, 186, 8, 311, 0)
        geos.frame(20, 186, 8, 311)
        geos.text("\x18Hello from Prog8!\x1b", 16, 36)        ; (\x18 bold, \x1b plain)
        geos.text("This GEOS program was written in Prog8.", 16, 52)

        ; how to write your own
        geos.text("To write your own, use your Prog8", 16, 68)
        geos.text("compiler (12.3.5 or newer) with prog8-geos", 16, 79)
        geos.text("in the GEOS-X16 zip: the GEOS target,", 16, 90)
        geos.text("the GEOS library, this program's source", 16, 101)
        geos.text("(examples/demo.p8) and build.bat/.sh,", 16, 112)
        geos.text("which put your program on a GEOS disk.", 16, 123)

        geos.text("Clicks:", 16, 141)
        show_count()

        ; the buttons: two GEOS icons with the picture above, at y 152 and
        ; x card 8 and 22 (a card is 8 pixels: x 64 and 176), 6 cards wide
        ; and 16 pixels high; their labels are written on top of them
        geos.icons_header(&buttons, 2, 160, 100)        ; (160, 100: where the pointer goes)
        geos.icon(&buttons, 0, &button, 8, 152, 6, 16, &plus_one)
        geos.icon(&buttons, 1, &button, 22, 152, 6, 16, &reset)
        geos.icons(&buttons)
        geos.text("+1", 88, 163)
        geos.text("reset", 191, 163)

        ; the menus: the bar at the top (y 0-14), and the menu each of its
        ; items opens under it (y 14-29)
        geos.menu_header(&geosmenu, 14, 29, 0, 70, geos.VERTICAL, 1)
        geos.menu_item(&geosmenu, 0, "about...", geos.MENU_ACTION, &about)
        geos.menu_header(&filemenu, 14, 29, 24, 64, geos.VERTICAL, 1)
        geos.menu_item(&filemenu, 0, "quit", geos.MENU_ACTION, &quit)
        geos.menu_header(&mainmenu, 0, 14, 0, 50, geos.HORIZONTAL, 2)
        geos.menu_item(&mainmenu, 0, "geos", geos.SUB_MENU, &geosmenu)
        geos.menu_item(&mainmenu, 1, "file", geos.SUB_MENU, &filemenu)
        geos.menu(&mainmenu)

        ; the about box, for about() to show
        geos.dialog_begin(&aboutbox)
        geos.dialog_text(geos.TXT_LN_X, geos.TXT_LN_1_Y, "\x18PROG8 DEMO\x1b")
        geos.dialog_text(geos.TXT_LN_X, geos.TXT_LN_2_Y, "Its source: examples/demo.p8")
        geos.dialog_text(geos.TXT_LN_X, geos.TXT_LN_3_Y, "in prog8-geos, in the zip.")
        geos.dialog_text(geos.TXT_LN_X, geos.TXT_LN_4_Y, "(for Prog8 12.3.5 or newer)")
        geos.dialog_button(geos.OK, geos.DBI_X_2, geos.DBI_Y_2)
        geos.dialog_end()
    }

    sub show_count() {
        ; the count after "Clicks:", with the old number blanked out first
        geos.box(132, 143, 64, 140, 0)
        geos.number(count, 64, 141)
    }

    ; ---- called by GEOS: the buttons, then the menu items

    sub plus_one() {
        count++
        show_count()
    }

    sub reset() {
        count = 0
        show_count()
    }

    sub about() {
        geos.menu_done()                ; (a menu item's routine closes the menus)
        void geos.dialog(&aboutbox)
    }

    sub quit() {
        geos.menu_done()
        geos.to_desktop()
    }
}
