#!/bin/sh
# Builds a Prog8 GEOS program and puts it on a GEOS disk image.
#
#   ./build.sh SOURCE.p8 "NAME" DISK.D81 [SLOT]
#   e.g.  ./build.sh examples/demo.p8 "PROG8 DEMO" path/to/GEOS128A.D81
#
# NAME is the file's name on the disk (up to 16 characters).  SLOT, if it's
# given, is the file's place in the directory, 0 for the first (the deskTop
# shows the files 8 a page, in that order).  A file of the same name on the
# disk is replaced.
#
# Needs Java, Prog8's compiler prog8c.jar (12.3.5 or newer: in this folder,
# or set PROG8C to its path), 64tass on the PATH, and Python 3.

if [ $# -lt 3 ]; then
    echo "usage: ./build.sh SOURCE.p8 \"NAME\" DISK.D81 [SLOT]"
    exit 1
fi

# The paths given are from the folder we were started in.  The build runs in
# this script's folder (where target/ and lib/ are), so make them full paths.
full_path() {
    echo "$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"
}
SRC=$(full_path "$1")
NAME=$2
DISK=$(full_path "$3")
SLOT=$4
if [ -n "$PROG8C" ]; then
    PROG8C=$(full_path "$PROG8C")
else
    PROG8C=prog8c.jar
fi

cd "$(dirname "$0")" || exit 1
mkdir -p build
java -jar "$PROG8C" -target target/geos.properties -srcdirs lib -out build "$SRC" || exit 1
python3 tools/mkp8app.py "build/$(basename "$SRC" .p8).bin" "$NAME" "$DISK" $SLOT
