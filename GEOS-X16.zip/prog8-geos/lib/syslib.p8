; Prog8 for GEOS (GEOS-X16): the system library, what the Prog8 compiler
; needs from every target.
;
; GEOS loads an application and calls it at $0400.  The program's
; main.start() sets things up (the screen, menus, icons) and returns to
; GEOS's MainLoop, which from then on calls the program back when the user
; does something (see geos.p8).  sys.exit() leaves the program: back to the
; deskTop.

%option no_symbol_prefixing, ignore_unused

%import shared_sys_functions

sys {
    const ubyte target = 64     ; Prog8's number for the machine: GEOS programs are C64 style

    ; The compiler calls these to end a program.  In GEOS that's always
    ; "back to the deskTop" (EnterDeskTop, $c22c on GEOS's jump table).

    asmsub reset_system() {
        %asm {{
            jmp  $c22c          ; EnterDeskTop
        }}
    }

    asmsub exit(ubyte returnvalue @A) {
        %asm {{
            jmp  $c22c          ; EnterDeskTop
        }}
    }

    asmsub exit2(ubyte resulta @A, ubyte resultx @X, ubyte resulty @Y) {
        %asm {{
            jmp  $c22c          ; EnterDeskTop
        }}
    }

    asmsub exit3(ubyte resulta @A, ubyte resultx @X, ubyte resulty @Y, bool carry @Pc) {
        %asm {{
            jmp  $c22c          ; EnterDeskTop
        }}
    }
}


p8_sys_startup {
    ; What runs around main.start().  GEOS has already set the machine up,
    ; so there is next to nothing to do.
    %option force_output

    asmsub init_system() {
        %asm {{
            rts
        }}
    }

    asmsub init_system_phase2() {
        %asm {{
            cld
            rts
        }}
    }

    asmsub cleanup_at_exit() {
        ; main.start() has returned: this rts goes back to GEOS's MainLoop
        ; (GEOS called the program, so the return address is GEOS's).
        %asm {{
            rts
        }}
    }
}


cx16 {
    ; Prog8's sixteen 16-bit virtual registers, in every form the compiler
    ; and its libraries use (word, signed, long, low and high bytes, bool).
    ; Here they are GEOS's own r0-r15 ($02-$21), so cx16.r0 = &something
    ; sets GEOS's r0 for the call that follows.

    &uword r0  = $02
    &uword r1  = $04
    &uword r2  = $06
    &uword r3  = $08
    &uword r4  = $0a
    &uword r5  = $0c
    &uword r6  = $0e
    &uword r7  = $10
    &uword r8  = $12
    &uword r9  = $14
    &uword r10 = $16
    &uword r11 = $18
    &uword r12 = $1a
    &uword r13 = $1c
    &uword r14 = $1e
    &uword r15 = $20

    ; signed words
    &word r0s  = $02
    &word r1s  = $04
    &word r2s  = $06
    &word r3s  = $08
    &word r4s  = $0a
    &word r5s  = $0c
    &word r6s  = $0e
    &word r7s  = $10
    &word r8s  = $12
    &word r9s  = $14
    &word r10s = $16
    &word r11s = $18
    &word r12s = $1a
    &word r13s = $1c
    &word r14s = $1e
    &word r15s = $20

    ; signed longs (two registers each)
    &long r0r1sl   = $02
    &long r2r3sl   = $06
    &long r4r5sl   = $0a
    &long r6r7sl   = $0e
    &long r8r9sl   = $12
    &long r10r11sl = $16
    &long r12r13sl = $1a
    &long r14r15sl = $1e

    ; low bytes
    &ubyte r0L  = $02
    &ubyte r1L  = $04
    &ubyte r2L  = $06
    &ubyte r3L  = $08
    &ubyte r4L  = $0a
    &ubyte r5L  = $0c
    &ubyte r6L  = $0e
    &ubyte r7L  = $10
    &ubyte r8L  = $12
    &ubyte r9L  = $14
    &ubyte r10L = $16
    &ubyte r11L = $18
    &ubyte r12L = $1a
    &ubyte r13L = $1c
    &ubyte r14L = $1e
    &ubyte r15L = $20

    ; high bytes
    &ubyte r0H  = $03
    &ubyte r1H  = $05
    &ubyte r2H  = $07
    &ubyte r3H  = $09
    &ubyte r4H  = $0b
    &ubyte r5H  = $0d
    &ubyte r6H  = $0f
    &ubyte r7H  = $11
    &ubyte r8H  = $13
    &ubyte r9H  = $15
    &ubyte r10H = $17
    &ubyte r11H = $19
    &ubyte r12H = $1b
    &ubyte r13H = $1d
    &ubyte r14H = $1f
    &ubyte r15H = $21

    ; signed low bytes
    &byte r0sL  = $02
    &byte r1sL  = $04
    &byte r2sL  = $06
    &byte r3sL  = $08
    &byte r4sL  = $0a
    &byte r5sL  = $0c
    &byte r6sL  = $0e
    &byte r7sL  = $10
    &byte r8sL  = $12
    &byte r9sL  = $14
    &byte r10sL = $16
    &byte r11sL = $18
    &byte r12sL = $1a
    &byte r13sL = $1c
    &byte r14sL = $1e
    &byte r15sL = $20

    ; signed high bytes
    &byte r0sH  = $03
    &byte r1sH  = $05
    &byte r2sH  = $07
    &byte r3sH  = $09
    &byte r4sH  = $0b
    &byte r5sH  = $0d
    &byte r6sH  = $0f
    &byte r7sH  = $11
    &byte r8sH  = $13
    &byte r9sH  = $15
    &byte r10sH = $17
    &byte r11sH = $19
    &byte r12sH = $1b
    &byte r13sH = $1d
    &byte r14sH = $1f
    &byte r15sH = $21

    ; low bytes as bools
    &bool r0bL  = $02
    &bool r1bL  = $04
    &bool r2bL  = $06
    &bool r3bL  = $08
    &bool r4bL  = $0a
    &bool r5bL  = $0c
    &bool r6bL  = $0e
    &bool r7bL  = $10
    &bool r8bL  = $12
    &bool r9bL  = $14
    &bool r10bL = $16
    &bool r11bL = $18
    &bool r12bL = $1a
    &bool r13bL = $1c
    &bool r14bL = $1e
    &bool r15bL = $20

    ; high bytes as bools
    &bool r0bH  = $03
    &bool r1bH  = $05
    &bool r2bH  = $07
    &bool r3bH  = $09
    &bool r4bH  = $0b
    &bool r5bH  = $0d
    &bool r6bH  = $0f
    &bool r7bH  = $11
    &bool r8bH  = $13
    &bool r9bH  = $15
    &bool r10bH = $17
    &bool r11bH = $19
    &bool r12bH = $1b
    &bool r13bH = $1d
    &bool r14bH = $1f
    &bool r15bH = $21
}
