; Prog8 for GEOS (GEOS-X16): the GEOS library.
;
; It has GEOS's own routines (on GEOS's jump table, the same in GEOS 64 and
; GEOS 128), GEOS's constants, and helpers for the everyday jobs: text,
; numbers, boxes, and building GEOS's tables for menus, dialog boxes and
; icons.
;
; GEOS's routines take their parameters in GEOS's registers r0-r15.  In this
; kit those are also Prog8's cx16.r0-cx16.r15 (the same zero page, $02-$21),
; so calling one is: set the registers, then call it.  The helpers do that
; for you.
;
; GEOS is event driven.  main.start() draws the screen, sets up the menus
; and the icons (geos.menu, geos.icons) and returns; GEOS then calls the
; routines the tables name when the user picks a menu item or clicks an
; icon.  A menu item's routine calls geos.menu_done() to close the menus.
;
; GEOS is told about menus, dialog boxes and icons with tables, and the
; tables hold addresses (of strings and routines).  Prog8 won't put
; addresses in a constant array, so a program fills its tables in when it
; starts: it makes a ubyte array of the right size (the sizes are below) and
; fills it with the helpers, as examples/demo.p8 does.

%option no_symbol_prefixing, ignore_unused

geos {
    ; ---- GEOS's routines (the comment after each: the registers it takes)

    extsub $c118 = HorizontalLine(ubyte pattern @A) clobbers(A,X,Y)     ; r3 left, r4 right, r11L y
    extsub $c124 = Rectangle() clobbers(A,X,Y)                           ; r2L top, r2H bottom, r3 left, r4 right
    extsub $c127 = FrameRectangle(ubyte pattern @A) clobbers(A,X,Y)      ; as Rectangle; A: the line's pattern
    extsub $c12a = InvertRectangle() clobbers(A,X,Y)                     ; as Rectangle
    extsub $c139 = SetPattern(ubyte pattern @A) clobbers(A,X,Y)          ; A: Rectangle's fill pattern
    extsub $c145 = PutChar(ubyte character @A) clobbers(A,X,Y)           ; r11 x, r1H y
    extsub $c148 = PutString() clobbers(A,X,Y)                           ; r0 the string, r11 x, r1H y
    extsub $c14b = UseSystemFont() clobbers(A,X,Y)
    extsub $c151 = DoMenu(ubyte item @A) clobbers(A,X,Y)                 ; r0 the menu table; A: the item the pointer starts on
    extsub $c15a = DoIcons() clobbers(A,X,Y)                             ; r0 the icon table
    extsub $c184 = PutDecimal(ubyte format @A) clobbers(A,X,Y)           ; r0 the number, r11 x, r1H y
    extsub $c193 = ReDoMenu() clobbers(A,X,Y)
    extsub $c199 = Sleep() clobbers(A,X,Y)                               ; r0 the time, in sixtieths of a second
    extsub $c1bd = GotoFirstMenu() clobbers(A,X,Y)
    extsub $c22c = EnterDeskTop() clobbers(A,X,Y)
    extsub $c256 = DoDlgBox() clobbers(A,X,Y)                            ; r0 the dialog box table; r0L: the button clicked

    ; ---- GEOS's variables

    &ubyte dispBufferOn = $2f
    &ubyte graphMode = $3f              ; GEOS 128: bit 7 set in 80 columns
    &ubyte c128Flag = $c013             ; bit 7 set: GEOS 128

    ; ---- menus

    const ubyte HORIZONTAL = $00        ; menu_header's kind: a menu bar,
    const ubyte VERTICAL = $80          ; or a menu that drops down
    const ubyte CONSTRAINED = $40       ; (| either: the pointer can't leave the menu)
    const ubyte MENU_ACTION = $00       ; menu_item's kind: it calls a routine,
    const ubyte SUB_MENU = $80          ; or it opens another menu,
    const ubyte DYN_SUB_MENU = $40      ; or it calls a routine that gives the menu to open (in r0)

    ; ---- dialog boxes

    const ubyte DEF_DB_POS = $80        ; the box in GEOS's usual place (| the pattern of its shadow)
    const ubyte OK = 1                  ; the buttons: dialog_button's which, and what dialog() gives back
    const ubyte CANCEL = 2
    const ubyte YES = 3
    const ubyte NO = 4
    const ubyte DBTXTSTR = 11           ; the table's code for a line of text
    const ubyte DBI_X_0 = 1             ; where a button goes: x in cards (8 pixels) from the box's left,
    const ubyte DBI_X_1 = 9
    const ubyte DBI_X_2 = 17
    const ubyte DBI_Y_0 = 8             ; and y in pixels from its top
    const ubyte DBI_Y_1 = 40
    const ubyte DBI_Y_2 = 72
    const ubyte TXT_LN_X = 16           ; where text goes: x, then the four lines' y (baselines)
    const ubyte TXT_LN_1_Y = 16
    const ubyte TXT_LN_2_Y = 32
    const ubyte TXT_LN_3_Y = 48
    const ubyte TXT_LN_4_Y = 64

    ; ---- text

    const ubyte BOLDON = 24             ; codes that can go in a string (\x18 is BOLDON)
    const ubyte ITALICON = 25
    const ubyte OUTLINEON = 26
    const ubyte PLAINTEXT = 27          ; (\x1b)

    const ubyte DEC_LEFT = %11000000    ; PutDecimal's format: left-justified, no leading zeros

    ; ---- the sizes of GEOS's tables, in bytes
    ; a menu is MENU_HEAD + MENU_ITEM for each item; an icon table is
    ; ICONS_HEAD + ICON for each icon; a dialog box is DLG_HEAD, DLG_TEXT for
    ; each line of text, DLG_BUTTON for each button, and DLG_END

    const ubyte MENU_HEAD = 7
    const ubyte MENU_ITEM = 5
    const ubyte ICONS_HEAD = 4
    const ubyte ICON = 8
    const ubyte DLG_HEAD = 1
    const ubyte DLG_TEXT = 5
    const ubyte DLG_BUTTON = 3
    const ubyte DLG_END = 1

    ; ---- drawing and text

    sub text(str s, uword x, ubyte y) {
        ; Writes a string at x, y (y: the baseline).  It can have BOLDON and
        ; the other codes in it.
        cx16.r0 = s
        cx16.r11 = x
        cx16.r1H = y
        PutString()
    }

    sub number(uword n, uword x, ubyte y) {
        ; Writes a number at x, y (y: the baseline).
        cx16.r0 = n
        cx16.r11 = x
        cx16.r1H = y
        PutDecimal(DEC_LEFT)
    }

    sub box(ubyte top, ubyte bottom, uword left, uword right, ubyte pattern) {
        ; Fills a rectangle with one of GEOS's patterns (0 white, 1 black,
        ; 2 grey, and more).
        SetPattern(pattern)
        set_rect(top, bottom, left, right)
        Rectangle()
    }

    sub frame(ubyte top, ubyte bottom, uword left, uword right) {
        ; Draws a solid line around a rectangle.
        set_rect(top, bottom, left, right)
        FrameRectangle($ff)
    }

    sub invert(ubyte top, ubyte bottom, uword left, uword right) {
        ; Turns a rectangle's black pixels white and its white pixels black.
        set_rect(top, bottom, left, right)
        InvertRectangle()
    }

    sub set_rect(ubyte top, ubyte bottom, uword left, uword right) {
        ; Puts a rectangle in r2-r4, where GEOS's rectangle routines want it.
        cx16.r2L = top
        cx16.r2H = bottom
        cx16.r3 = left
        cx16.r4 = right
    }

    sub sleep(uword sixtieths) {
        cx16.r0 = sixtieths
        Sleep()
    }

    sub to_desktop() {
        ; Quits the program: back to the deskTop.
        EnterDeskTop()
    }

    ; ---- menus
    ; A menu table is a header and then the items.  The header: top y,
    ; bottom y, left x (a word), right x (a word), and the kind | the number
    ; of items.  An item: its name's address (a word), its kind, and the
    ; address of its routine or of the menu it opens (a word).

    sub menu_header(uword table, ubyte top, ubyte bottom, uword left, uword right, ubyte kind, ubyte items) {
        ; kind: HORIZONTAL or VERTICAL (| CONSTRAINED)
        @(table) = top
        @(table+1) = bottom
        pokew(table+2, left)
        pokew(table+4, right)
        @(table+6) = kind | items
    }

    sub menu_item(uword table, ubyte n, str name, ubyte kind, uword target) {
        ; Item n (0 = the first).  kind: MENU_ACTION (target: the routine to
        ; call) or SUB_MENU (target: the menu to open).
        uword item = table + MENU_HEAD + n * MENU_ITEM
        pokew(item, name)
        @(item+2) = kind
        pokew(item+3, target)
    }

    sub menu(uword table) {
        ; Draws the menu bar and turns it on (it stays on).
        cx16.r0 = table
        DoMenu(0)
    }

    sub menu_done() {
        ; Closes the menus.  A menu item's routine calls this when it's done.
        GotoFirstMenu()
    }

    ; ---- dialog boxes
    ; A dialog box table is its position (DEF_DB_POS | its shadow's pattern),
    ; then the items, then a 0.  A line of text: DBTXTSTR, x, y, and the
    ; string's address (a word).  A button: which one (OK, CANCEL, YES, NO),
    ; x and y.  dialog_begin starts a table, dialog_text and dialog_button
    ; add to it, and dialog_end finishes it.

    uword dlg_next          ; where the next item goes in the table being made

    sub dialog_begin(uword table) {
        ; In the usual place, with a black shadow (pattern 1).
        @(table) = DEF_DB_POS | 1
        dlg_next = table + DLG_HEAD
    }

    sub dialog_text(ubyte x, ubyte y, str s) {
        ; x, y: TXT_LN_X and TXT_LN_1_Y to TXT_LN_4_Y, or any others
        @(dlg_next) = DBTXTSTR
        @(dlg_next+1) = x
        @(dlg_next+2) = y
        pokew(dlg_next+3, s)
        dlg_next += DLG_TEXT
    }

    sub dialog_button(ubyte which, ubyte x, ubyte y) {
        ; which: OK, CANCEL, YES or NO.  x, y: DBI_X_0 to DBI_X_2 and
        ; DBI_Y_0 to DBI_Y_2, or any others.
        @(dlg_next) = which
        @(dlg_next+1) = x
        @(dlg_next+2) = y
        dlg_next += DLG_BUTTON
    }

    sub dialog_end() {
        @(dlg_next) = 0
    }

    sub dialog(uword table) -> ubyte {
        ; Shows the dialog box and waits; gives back the button clicked
        ; (OK, CANCEL, YES or NO).
        cx16.r0 = table
        DoDlgBox()
        return cx16.r0L
    }

    ; ---- icons: buttons with a picture (in GEOS's compacted bitmap format)
    ; An icon table is a header and then the icons.  The header: how many
    ; icons, then where to put the pointer: x (a word) and y.  An icon: its
    ; picture's address (a word), x in cards (8 pixels), y, its width in
    ; cards, its height, and its routine's address (a word).

    sub icons_header(uword table, ubyte icons, uword mouse_x, ubyte mouse_y) {
        @(table) = icons
        pokew(table+1, mouse_x)
        @(table+3) = mouse_y
    }

    sub icon(uword table, ubyte n, uword picture, ubyte x_card, ubyte y, ubyte width_cards, ubyte height, uword routine) {
        ; Icon n (0 = the first).  routine: called when it's clicked.
        uword entry = table + ICONS_HEAD + n * ICON
        pokew(entry, picture)
        @(entry+2) = x_card
        @(entry+3) = y
        @(entry+4) = width_cards
        @(entry+5) = height
        pokew(entry+6, routine)
    }

    sub icons(uword table) {
        ; Draws the icons and turns them on (they stay on: a click flashes
        ; the icon and calls its routine).
        cx16.r0 = table
        DoIcons()
    }
}
