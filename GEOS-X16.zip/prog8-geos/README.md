# Prog8 for GEOS (GEOS-X16)

Write GEOS applications in [Prog8](https://github.com/irmen/prog8) for
GEOS-X16: GEOS 64 and GEOS 128 on the Commander X16.

## What you need

- Java, to run the compiler.
- Prog8's compiler, `prog8c.jar`: 12.3.5 (the stable release) or newer.
  Put it in this folder, or set `PROG8C` to where it is.
- 64tass on the PATH (Prog8 assembles with it).
- Python 3.

PROG8 DEMO on the GEOS-X16 disks was built with 12.3.5 (14.0-BETA4 builds
it too).

## Building a program

    ./build.sh examples/demo.p8 "PROG8 DEMO" path/to/GEOS128A.D81

(On Windows: `build.bat`, the same way.)  It compiles the program for the
GEOS target into `build/`, then `tools/mkp8app.py` gives it a GEOS header
(an icon, APPLICATION, loaded and started at $0400) and puts it on the disk
image.  A file of the same name already on the disk is replaced.  A fourth
argument, a number, puts the file in that slot of the directory (0 is the
first): the deskTop shows the files in that order, 8 a page.  Double-click it on the
deskTop to run it.

To start a program of your own, copy `examples/demo.p8`, change it, and
build the copy the same way.  For your own icon, class name or info box
text, run `tools/mkp8app.py` yourself: its `--icon`, `--class` and
`--info` options are described at the top of it.

## What's here

- `target/geos.properties`: the Prog8 compilation target.  The program loads
  and starts at $0400 (GEOS's application area, up to $5FFF), uses only the
  zero page GEOS leaves an application ($70-$7F, $FB-$FE), and Prog8's
  virtual registers R0-R15 *are* GEOS's r0-r15 ($02-$21).
- `lib/syslib.p8`: the system library every Prog8 target has.
  `main.start()` returns to GEOS's MainLoop; `sys.exit()` goes back to the
  deskTop.
- `lib/geos.p8`: GEOS's routines (`extsub`s on its jump table: PutString,
  Rectangle, DoMenu, DoIcons, DoDlgBox, EnterDeskTop and more), its
  constants, and helpers: `geos.text`, `geos.number`, `geos.box`,
  `geos.frame`, `geos.invert`; menus (`menu_header`, `menu_item`, `menu`,
  `menu_done`); dialog boxes (`dialog_begin`, `dialog_text`,
  `dialog_button`, `dialog_end`, `dialog`); icons (`icons_header`, `icon`,
  `icons`).  For a GEOS routine that isn't there yet, add an `extsub` line
  with its jump table address.
- `examples/demo.p8`: PROG8 DEMO, a window, a counter, two buttons (GEOS
  icons), a menu bar and an about box.
- `build.sh`, `build.bat`: build a program and put it on a disk image.
- `tools/mkp8app.py`: makes a compiled program a GEOS application on a
  disk image.  It uses `geosimg.py` (GEOS disk images, D64 and D81) and
  `geosorder.py` (puts the files on a disk in a given order).

## How a GEOS program works

GEOS is event driven.  `main.start()` draws the screen and sets up the
menus and icons, then returns; GEOS takes over, and calls the routines the
tables name when the user clicks something.  A menu item's routine calls
`geos.menu_done()` when it's done.

GEOS's tables (menus, dialog boxes, icons) hold addresses, which Prog8
won't put into a constant array, so a program makes them as `ubyte` arrays
and fills them in with the helpers when it starts.  Their sizes are in
`lib/geos.p8`: for example, a menu with n items is
`geos.MENU_HEAD + n*geos.MENU_ITEM` bytes.

Inside GEOS, everything goes through GEOS: drawing, text, files, input.
Prog8's X16 libraries (textio, diskio, gfx, floats) use the X16's KERNAL
and ROM, which GEOS has swapped out, so they can't be used.  Text is ASCII
(GEOS's fonts); in a string, `\x18` turns bold on and `\x1b` goes back to
plain text.
