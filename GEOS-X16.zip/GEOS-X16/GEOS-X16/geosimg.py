#!/usr/bin/env python3
"""GEOS disk images: D64 (1541) and D81 (1581).

   geosimg.py new IMAGE.D81 "DISK NAME" ID   a blank GEOS disk (D64 or D81,
                                             by the file name's extension)
   geosimg.py cp FROM TO "FILE NAME" ...     copy files (GEOS-aware: the info
                                             block and the VLIR records go
                                             along); "*" copies them all
   geosimg.py clone FROM TO                  copy every file to the same
                                             directory slot (the deskTop
                                             shows the icons by slot)
   geosimg.py ls IMAGE                       the directory
   geosimg.py check IMAGE                    every block of every file
                                             allocated once, the BAM agrees

A D81 gets what GEOS 2.0's 1581 driver expects: header 40/0 (the disk name
also at $90, where GEOS reads it, and the GEOS signature with the border
block at $AB), BAM 40/1 (tracks 1-40) and 40/2 (tracks 41-80), directory
from 40/3.  Files go from track 39 down, then from track 41 up, as the
1581 driver allocates them."""
import sys

GEOS_ID = b"GEOS format V1.0"


class Image:
    def __init__(self, data):
        self.d = bytearray(data)
        if len(self.d) == 819200:
            self.kind = "d81"
        elif len(self.d) in (174848, 175531):
            self.kind = "d64"
            del self.d[174848:]
        else:
            raise SystemExit("not a D64 or D81 image (%d bytes)" % len(self.d))
        k = self.kind == "d81"
        self.tracks = 80 if k else 35
        self.dirtrack = 40 if k else 18
        self.header = (40, 0) if k else (18, 0)
        self.firstdir = (40, 3) if k else (18, 1)

    # geometry
    def spt(self, t):
        if self.kind == "d81":
            return 40
        return 21 if t <= 17 else 19 if t <= 24 else 18 if t <= 30 else 17

    def off(self, t, s):
        if not (1 <= t <= self.tracks and 0 <= s < self.spt(t)):
            raise SystemExit("bad block %d/%d" % (t, s))
        if self.kind == "d81":
            return ((t - 1) * 40 + s) * 256
        return (sum(self.spt(i) for i in range(1, t)) + s) * 256

    def block(self, t, s):
        o = self.off(t, s)
        return self.d[o:o + 256]

    def put(self, t, s, data):
        o = self.off(t, s)
        self.d[o:o + 256] = bytes(data).ljust(256, b"\0")

    # BAM: (offset of the free count, offset of the bitmap)
    def bament(self, t):
        if self.kind == "d81":
            b = self.off(40, 1 if t <= 40 else 2)
            e = b + 0x10 + 6 * ((t - 1) % 40)
            return e, e + 1
        e = self.off(18, 0) + 4 * t
        return e, e + 1

    def is_free(self, t, s):
        _, m = self.bament(t)
        return self.d[m + s // 8] & (1 << (s % 8)) != 0

    def use(self, t, s):
        c, m = self.bament(t)
        if not self.is_free(t, s):
            raise SystemExit("block %d/%d already in use" % (t, s))
        self.d[m + s // 8] &= ~(1 << (s % 8)) & 255
        self.d[c] -= 1

    def free_blocks(self):
        return sum(self.d[self.bament(t)[0]] for t in range(1, self.tracks + 1)
                   if t != self.dirtrack)

    def order(self):
        if self.kind == "d81":        # 39 down to 1, then 41 up to 80
            return list(range(39, 0, -1)) + list(range(41, 81))
        out = []                      # outwards from the directory
        for k in range(1, 18):
            for t in (18 - k, 18 + k):
                if 1 <= t <= 35:
                    out.append(t)
        return out

    def alloc(self):
        for t in self.order():
            n = self.spt(t)
            for i in range(n):
                if self.kind == "d81":
                    s = i
                else:
                    s = (i * 10) % n if n % 10 else i
                if self.is_free(t, s):
                    self.use(t, s)
                    return t, s
        raise SystemExit("disk full")

    # directory
    def entries(self):
        t, s = self.firstdir
        seen = set()
        while t:
            if (t, s) in seen:
                raise SystemExit("directory loop")
            seen.add((t, s))
            o = self.off(t, s)
            for i in range(8):
                yield o + i * 32
            t, s = self.d[o], self.d[o + 1]

    def name_of(self, e):
        return bytes(c for c in self.d[e + 5:e + 21] if c != 0xA0).decode("latin1")

    def free_slot(self, want=None):
        if want is not None:            # slot number want, made if need be
            while len(list(self.entries())) <= want:
                self.add_dir_block()
            e = list(self.entries())[want]
            if self.d[e + 2]:
                raise SystemExit("slot %d in use" % want)
            return e
        for e in self.entries():
            if self.d[e + 2] == 0:
                return e
        return self.add_dir_block()

    def add_dir_block(self):
        last = list(self.entries())[-8]
        for s in range(self.spt(self.dirtrack)):
            if self.is_free(self.dirtrack, s):
                self.use(self.dirtrack, s)
                self.d[last], self.d[last + 1] = self.dirtrack, s
                o = self.off(self.dirtrack, s)
                self.d[o:o + 256] = bytes(256)
                self.d[o + 1] = 0xFF
                return o
        raise SystemExit("directory full")

    def chain(self, t, s):
        seen = []
        while t:
            if (t, s) in seen:
                raise SystemExit("chain loop")
            seen.append((t, s))
            o = self.off(t, s)
            t, s = self.d[o], self.d[o + 1]
        return seen

    def headerblock(self):
        return self.off(*self.header)

    def diskname(self):
        h = self.headerblock()
        return bytes(c for c in self.d[h + 0x90:h + 0xA0] if c != 0xA0).decode("latin1")


def new_image(path, name, did):
    nm = name.encode("latin1")[:16].ljust(16, b"\xA0")
    did = did.encode("latin1")[:2].ljust(2)
    if path.lower().endswith(".d81"):
        img = Image(bytes(819200))
        h = bytearray(256)
        h[0:4] = bytes([40, 3, 0x44, 0])
        h[4:20] = nm
        h[0x14:0x16] = b"\xA0\xA0"
        h[0x16:0x18] = did
        h[0x18:0x1D] = b"\xA0\x33\x44\xA0\xA0"
        info = nm + b"\xA0\xA0" + did + b"\xA0\x33\x44\xA0\xA0\xA0\xA0"
        h[0x90:0x90 + len(info)] = info
        img.put(40, 0, h)
        for n, (lt, ls) in ((1, (40, 2)), (2, (0, 0xFF))):
            b = bytearray(256)
            b[0:8] = bytes([lt, ls, 0x44, 0xBB]) + did + bytes([0xC0, 0])
            for i in range(40):
                e = 0x10 + 6 * i
                b[e:e + 6] = bytes([40, 255, 255, 255, 255, 255])
            img.put(40, n, b)
        for s in (0, 1, 2, 3):
            img.use(40, s)
        img.put(40, 3, bytes([0, 0xFF]))
        border = (40, 19)               # SetGEOSDisk: the first free after 40/18
    else:
        img = Image(bytes(174848))
        b = bytearray(256)
        b[0:4] = bytes([18, 1, 0x41, 0])
        for t in range(1, 36):
            n = img.spt(t)
            bits = (1 << n) - 1
            b[4 * t:4 * t + 4] = bytes([n, bits & 255, (bits >> 8) & 255, bits >> 16])
        b[0x90:0xAB] = nm + b"\xA0\xA0" + did + b"\xA0\x32\x41\xA0\xA0\xA0\xA0"
        img.put(18, 0, b)
        img.use(18, 0)
        img.use(18, 1)
        img.put(18, 1, bytes([0, 0xFF]))
        border = (19, 0)
    img.use(*border)
    img.put(border[0], border[1], bytes([0, 0xFF]))
    h = img.headerblock()
    img.d[h + 0xAB], img.d[h + 0xAC] = border
    img.d[h + 0xAD:h + 0xAD + 16] = GEOS_ID
    open(path, "wb").write(img.d)
    print("%s: %s, %d blocks free" % (path, img.kind.upper(), img.free_blocks()))


def copy_chain(src, dst, t, s):
    blocks = src.chain(t, s)
    new = [dst.alloc() for _ in blocks]
    for i, ((ot, os_), (nt, ns)) in enumerate(zip(blocks, new)):
        data = bytearray(src.block(ot, os_))
        if i + 1 < len(new):
            data[0], data[1] = new[i + 1]
        dst.put(nt, ns, data)
    return (new[0] if new else (0, 0)), len(new)


def copy_file(src, dst, name, keep_slot=False):
    se = None
    for i, e in enumerate(src.entries()):
        if src.d[e + 2] and src.name_of(e) == name:
            se, slot = e, i
    if se is None:
        raise SystemExit("not found: " + name)
    for e in dst.entries():
        if dst.d[e + 2] and dst.name_of(e) == name:
            raise SystemExit("already there: " + name)
    ent = bytearray(src.d[se + 2:se + 32])
    total = 0
    if src.d[se + 21]:                                  # GEOS info block
        (it, is_), n = copy_chain(src, dst, src.d[se + 21], src.d[se + 22])
        ent[19], ent[20] = it, is_
        total += n
    if src.d[se + 23] == 1:                             # VLIR
        idx = src.block(src.d[se + 3], src.d[se + 4])
        nidx = bytearray(idx)
        for r in range(127):
            rt, rs = idx[2 + 2 * r], idx[3 + 2 * r]
            if rt:
                (nt, ns), n = copy_chain(src, dst, rt, rs)
                nidx[2 + 2 * r], nidx[3 + 2 * r] = nt, ns
                total += n
        xt, xs = dst.alloc()
        dst.put(xt, xs, nidx)
        ent[1], ent[2] = xt, xs
        total += 1
    else:
        (ft, fs), n = copy_chain(src, dst, src.d[se + 3], src.d[se + 4])
        ent[1], ent[2] = ft, fs
        total += n
    ent[28], ent[29] = total & 255, total >> 8
    e = dst.free_slot(slot if keep_slot else None)
    dst.d[e + 2:e + 32] = ent
    print("copied %-16s %4d blocks" % (name, total))


TYPES = {0: "non-GEOS", 1: "BASIC", 2: "assembly", 3: "data", 4: "system",
         5: "desk acc", 6: "application", 7: "appl data", 8: "font",
         9: "printer", 10: "input", 11: "disk driver", 12: "boot",
         13: "temporary", 14: "auto-exec", 15: "input 128"}


def ls(img):
    h = img.headerblock()
    print("%s  disk: %r  GEOS: %s" % (img.kind.upper(), img.diskname(),
          bytes(img.d[h + 0xAD:h + 0xBD]) == GEOS_ID))
    for e in img.entries():
        if img.d[e + 2]:
            st = "VLIR" if img.d[e + 23] == 1 else "seq"
            print("%5d  %-16s  $%02X  %-12s %-4s %d/%d" % (
                img.d[e + 30] | img.d[e + 31] << 8, img.name_of(e), img.d[e + 2],
                TYPES.get(img.d[e + 24], "?"), st, img.d[e + 3], img.d[e + 4]))
    print("blocks free:", img.free_blocks())


def check(img):
    used = {}
    def mark(t, s, what):
        if (t, s) in used:
            raise SystemExit("%d/%d used twice: %s, %s" % (t, s, used[(t, s)], what))
        used[(t, s)] = what
    h = img.header
    mark(*h, what="header")
    if img.kind == "d81":
        mark(40, 1, "BAM 1")
        mark(40, 2, "BAM 2")
    for b in img.chain(*img.firstdir):
        mark(*b, what="directory")
    hb = img.headerblock()
    if bytes(img.d[hb + 0xAD:hb + 0xBD]) == GEOS_ID and img.d[hb + 0xAB]:
        mark(img.d[hb + 0xAB], img.d[hb + 0xAC], "border block")
    for e in img.entries():
        if not img.d[e + 2]:
            continue
        n = img.name_of(e)
        cnt = 0
        if img.d[e + 21]:
            for b in img.chain(img.d[e + 21], img.d[e + 22]):
                mark(*b, what=n)
                cnt += 1
        if img.d[e + 23] == 1:
            mark(img.d[e + 3], img.d[e + 4], n)
            cnt += 1
            idx = img.block(img.d[e + 3], img.d[e + 4])
            for r in range(127):
                if idx[2 + 2 * r]:
                    for b in img.chain(idx[2 + 2 * r], idx[3 + 2 * r]):
                        mark(*b, what=n)
                        cnt += 1
        else:
            for b in img.chain(img.d[e + 3], img.d[e + 4]):
                mark(*b, what=n)
                cnt += 1
        if cnt != (img.d[e + 30] | img.d[e + 31] << 8):
            print("note: %s says %d blocks, has %d" % (n, img.d[e + 30] | img.d[e + 31] << 8, cnt))
    bad = 0
    for t in range(1, img.tracks + 1):
        c, _ = img.bament(t)
        free = 0
        for s in range(img.spt(t)):
            f = img.is_free(t, s)
            free += f
            if f == ((t, s) in used):
                bad += 1
                if bad < 10:
                    print("BAM: %d/%d %s" % (t, s, "free but used" if f else "allocated but unused"))
        if free != img.d[c]:
            bad += 1
            print("BAM: track %d count %d, %d free" % (t, img.d[c], free))
    print("%s: %d blocks used, BAM %s" % (img.kind.upper(), len(used), "OK" if not bad else "has %d problems" % bad))
    return bad == 0


def main():
    a = sys.argv[1:]
    if not a:
        raise SystemExit(__doc__)
    if a[0] == "new":
        new_image(a[1], a[2], a[3])
    elif a[0] == "ls":
        ls(Image(open(a[1], "rb").read()))
    elif a[0] == "check":
        sys.exit(0 if check(Image(open(a[1], "rb").read())) else 1)
    elif a[0] == "clone":
        src = Image(open(a[1], "rb").read())
        dst = Image(open(a[2], "rb").read())
        for e in src.entries():
            if src.d[e + 2]:
                copy_file(src, dst, src.name_of(e), keep_slot=True)
        open(a[2], "wb").write(dst.d)
        print("blocks free:", dst.free_blocks())
    elif a[0] == "cp":
        src = Image(open(a[1], "rb").read())
        dst = Image(open(a[2], "rb").read())
        names = a[3:]
        if names == ["*"]:
            names = [src.name_of(e) for e in src.entries() if src.d[e + 2]]
        for n in names:
            copy_file(src, dst, n)
        open(a[2], "wb").write(dst.d)
        print("blocks free:", dst.free_blocks())
    else:
        raise SystemExit(__doc__)


if __name__ == "__main__":
    main()
