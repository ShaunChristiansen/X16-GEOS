#!/usr/bin/env python3
"""Makes GEOSWALL.BIN, the GEOS-X16 deskTop wallpaper.

   mkwall.py PICTURE GEOSWALL.BIN [--preview PREVIEW.png]
   mkwall.py --default GEOSWALL.BIN [--preview PREVIEW.png]

PICTURE is any image PIL can read (PNG, JPEG, GIF, BMP ...): it is scaled to
cover 320x200 (centred, cropped) and reduced to the 207 colours GEOS leaves
free in the VERA palette.  --default draws the built-in wallpaper instead.

GEOSWALL.BIN (64512 bytes, loaded by the boot code straight into VRAM at
$06000) is layer 0's tiles 0-999, 8 bits per pixel (tile n = card n:
row n / 40, column n % 40), then the 256 palette entries (VERA format: one
byte green/blue, one byte red, 4 bits each).  Entry 0 and entries 16c+1,
16c+2 and 16c+3 (the C64 colours, the screen background, the mouse
pointer's outline) belong to GEOS: the picture does not use them."""
import sys
from PIL import Image, ImageDraw, ImageFilter

W, H = 320, 200
RESERVED = {0} | {16 * c + k for c in range(16) for k in (1, 2, 3)}
FREE = [i for i in range(256) if i not in RESERVED]   # 207 entries


def default_picture():
    """An evening sky over hills and a lake, with the sun low on the right:
    the deskTop shows the wallpaper along the right edge and the bottom,
    around its file window."""
    import math, random
    rnd = random.Random(16)
    img = Image.new("RGB", (W, H))
    px = img.load()
    horizon = 158
    sun_x, sun_y, sun_r = 272, 150, 40

    def mix(c1, c2, t):
        t = max(0.0, min(1.0, t))
        return tuple(int(a + (b - a) * t) for a, b in zip(c1, c2))

    sky = [(0.00, (14, 10, 52)), (0.35, (52, 22, 104)), (0.62, (150, 40, 120)),
           (0.82, (238, 96, 92)), (1.00, (255, 176, 92))]

    def sky_at(y):
        t = y / horizon
        for (t0, c0), (t1, c1) in zip(sky, sky[1:]):
            if t <= t1:
                return mix(c0, c1, (t - t0) / (t1 - t0))
        return sky[-1][1]

    for y in range(H):
        for x in range(W):
            if y < horizon:
                c = sky_at(y)
                # glow around the sun
                d = math.hypot(x - sun_x, (y - sun_y) * 1.15)
                g = max(0.0, 1.0 - d / 150.0) ** 2
                c = mix(c, (255, 190, 120), g * 0.55)
            else:
                # water: the sky mirrored, darker
                c = mix(sky_at(horizon - (y - horizon) * 3), (20, 12, 56), 0.55)
            px[x, y] = c
    d = ImageDraw.Draw(img)
    # stars in the upper sky
    for _ in range(90):
        x, y = rnd.randrange(W), rnd.randrange(int(horizon * 0.55))
        b = rnd.randrange(150, 256)
        if rnd.random() < 0.15:
            d.point([(x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)], fill=(b // 2, b // 2, b // 2 + 30))
        d.point((x, y), fill=(b, b, min(255, b + 20)))
    # the sun: yellow to orange
    for y in range(sun_y - sun_r, sun_y + sun_r + 1):
        t = (y - (sun_y - sun_r)) / (2 * sun_r)
        col = mix((255, 236, 120), (255, 92, 96), t)
        hw = math.sqrt(max(0, sun_r * sun_r - (y - sun_y) ** 2))
        d.line([(sun_x - hw, y), (sun_x + hw, y)], fill=col)
    # hills: three layers, far ones lighter
    def ridge(base, amp, freq, phase, col, seed):
        r = random.Random(seed)
        pts = []
        for x in range(-2, W + 3, 2):
            v = (math.sin(x * freq + phase) * amp
                 + math.sin(x * freq * 2.7 + phase * 1.3) * amp * 0.35
                 + r.uniform(-1.0, 1.0) * amp * 0.08)
            pts.append((x, base - v))
        d.polygon(pts + [(W + 3, horizon), (-2, horizon)], fill=col)
    ridge(horizon - 22, 14, 0.018, 1.0, (92, 36, 104), 1)
    ridge(horizon - 12, 12, 0.026, 3.0, (56, 22, 78), 2)
    ridge(horizon - 4, 8, 0.041, 5.0, (30, 12, 50), 3)
    # the sun's reflection on the water: broken horizontal strokes
    for y in range(horizon + 2, H, 3):
        t = (y - horizon) / (H - horizon)
        w = int(46 * (1.0 - 0.6 * t)) + rnd.randrange(-6, 7)
        x0 = sun_x - w // 2 + rnd.randrange(-4, 5)
        d.line([(x0, y), (x0 + w, y)], fill=mix((255, 200, 120), (255, 110, 110), t))
    # gentle ripples
    for y in range(horizon + 4, H, 5):
        for x in range(rnd.randrange(0, 18), W, rnd.randrange(22, 40)):
            d.line([(x, y), (x + rnd.randrange(6, 16), y)],
                   fill=mix((60, 40, 110), (120, 70, 150), rnd.random()))
    return img.filter(ImageFilter.SMOOTH)


def load_picture(path):
    img = Image.open(path).convert("RGB")
    s = max(W / img.width, H / img.height)
    img = img.resize((max(W, round(img.width * s)), max(H, round(img.height * s))), Image.LANCZOS)
    x0, y0 = (img.width - W) // 2, (img.height - H) // 2
    return img.crop((x0, y0, x0 + W, y0 + H))


def convert(img):
    """-> (pixels as VERA palette indices, row-major 320x200; 256 colours)"""
    # the VERA has 4 bits per channel: choose the free entries' colours
    # (median cut), round them to 12 bits, then map the picture onto the
    # rounded colours with dithering (so gradients do not band)
    q = img.quantize(colors=len(FREE), method=Image.Quantize.MEDIANCUT,
                     dither=Image.Dither.NONE)
    pal = q.getpalette()[:3 * len(FREE)]
    pal += [0] * (3 * len(FREE) - len(pal))
    rounded = [round(v / 17) for v in pal]
    # no colour exactly like one of GEOS's C64 colours (the mouse pointer
    # stands out, and test tools can find it by its colour)
    c64 = {(0, 0, 0), (15, 15, 15), (6, 3, 3), (7, 10, 10), (7, 4, 8), (5, 8, 4),
           (3, 2, 7), (11, 12, 7), (7, 5, 2), (4, 3, 0), (9, 6, 5), (4, 4, 4),
           (6, 6, 6), (9, 12, 8), (6, 6, 11), (9, 9, 9)}
    for i in range(0, len(rounded), 3):
        if tuple(rounded[i:i + 3]) in c64:
            rounded[i + 2] = rounded[i + 2] + 1 if rounded[i + 2] < 15 else 14
    palimg = Image.new("P", (1, 1))
    palimg.putpalette([17 * v for v in rounded] + [0] * (768 - len(rounded)))
    q = img.quantize(palette=palimg, dither=Image.Dither.FLOYDSTEINBERG)
    colours = [(0, 0, 0)] * 256
    for i, e in enumerate(FREE):
        colours[e] = tuple(rounded[3 * i:3 * i + 3])
    data = q.get_flattened_data() if hasattr(q, "get_flattened_data") else q.getdata()
    idx = [FREE[min(p, len(FREE) - 1)] for p in data]
    return idx, colours


def write_bin(idx, colours, path):
    out = bytearray()
    for n in range(1000):
        row, col = divmod(n, 40)
        for y in range(8):
            base = (row * 8 + y) * W + col * 8
            out += bytes(idx[base:base + 8])
    for r, g, b in colours:
        out += bytes([(g << 4) | b, r])
    assert len(out) == 64512
    open(path, "wb").write(out)


def preview(idx, colours, path):
    img = Image.new("RGB", (W, H))
    img.putdata([tuple(17 * v for v in colours[i]) for i in idx])
    img.resize((W * 2, H * 2), Image.NEAREST).save(path)


def main(argv):
    args = [a for a in argv if not a.startswith("--")]
    prev = None
    if "--preview" in argv:
        prev = argv[argv.index("--preview") + 1]
        args.remove(prev)
    if "--default" in argv and len(args) == 1:
        img, out = default_picture(), args[0]
    elif len(args) == 2:
        img, out = load_picture(args[0]), args[1]
    else:
        raise SystemExit(__doc__)
    idx, colours = convert(img)
    write_bin(idx, colours, out)
    if prev:
        preview(idx, colours, prev)
    print("wrote %s" % out)


if __name__ == "__main__":
    main(sys.argv[1:])
