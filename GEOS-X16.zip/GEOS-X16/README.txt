GEOS-X16 - your own run folder (private: these disks hold your own copies
of the GEOS software, not for posting)
=========================================================================

New in this one:

  geosx16.bin      the new cartridge: printing, and the WALLPAPER program's
                   wallpaper call (replace your old geosx16.bin with it)
  GEOSDISK.D81     drive A, now with WALLPAPER (8th file, first page) and
                   the printer drivers MPS-803, Star NL-10(com), ASCII Only
                   (the deskTop picks MPS-803 at boot; double-click another
                   printer icon to change)
  GEOSDSK2.D81     drive B, unchanged
  GEOSDSK3.D81     drive C, now with geoTelnet too (next to GeoTerm64)
  GEOSWALL.BMX     the wallpaper, now a BMX picture (the X16's own bitmap
                   format; it replaces GEOSWALL.BIN, which you can delete)
  GeosWallpapers   five wallpapers for WALLPAPER, as .BMX (keep the folder here)
  prnview.py       shows a print file as a picture: python prnview.py PRINT1.PRN

Printing: with no printer on the IEC port (always so in x16emu), each print
job goes to PRINT1.PRN, PRINT2.PRN, ... in this folder, 5 seconds after the
printing stops. With a printer on device 4 of a real X16's IEC port, it goes
to the printer instead.

WALLPAPER writes GEOSWALL.CFG here to remember your choice. Delete that file
to go back to plain GEOSWALL.BMX. Any 256-colour BMX that is 320 wide and at
least 200 high works as a wallpaper, from X16 programs too; mkwall.py makes
one from any picture (python mkwall.py picture.png GEOSWALL.BMX).

All three drives are D81s. Take any old GEOSDISK.D64 / GEOSDSK2.D64 out of
the folder: a .D64 is used before a .D81 of the same name.

geoTelnet and GeoTerm (drive C) now work with your TexElec serial/WiFi
card: GEOS-X16 points their user-port modem code at the card as they load.
Both use the card's WiFi modem (Zimodem) by default: dial a BBS with
ATDT and its address, e.g. ATDToasisbbs.hopto.org:6400 (The Oasis BBS).
For the DB9 port instead, put a file GEOSSER.CFG here with one line: DB9,
or DB9 and a speed (e.g. DB9 9600). Tested in the emulator only so far
(a stand-in BBS); the card must be at its default address ($9FE0).

Sounds: a click on the mouse button, a flick when a menu drops down and a
swish when a dialog box opens or closes (VERA PSG voice 15). To turn them
off, put a file GEOSSND.CFG here with one line: OFF.
