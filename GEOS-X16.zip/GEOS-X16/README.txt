GEOS-X16: three D81 disks
=========================

Put these in your GEOS-X16 folder (replace the old files):

  geosx16.bin    the updated cartridge - needed: the old one could crash
                 at boot when drive A is a D81 (it looked for auto-start
                 programs on a 1541's directory track)
  GEOSDISK.D81   drive A - office
  GEOSDSK2.D81   drive B - publishing and tools
  GEOSDSK3.D81   drive C - extras

Take GEOSDISK.D64 and GEOSDSK2.D64 out of the folder (a .D64 is used before
a .D81 of the same name).

Every disk has DESK TOP, geoWrite, geoPaint, the desk accessories
(calculator, note pad, photo manager, text manager, alarm clock,
preference mgr, pad color mgr) and the six system fonts.

A  GEOSDISK.D81  geoCalc (+ New Car, 1987 budget), geoSpell + GeoDictionary,
                 geoMerge, CardFile, Calendar, ReadMe          1585 blocks free
B  GEOSDSK2.D81  geoText, Text Grabber + its 7 forms, geoLaser + LaserWriter
                 + 4 LW fonts, CONVERT, PAINT DRIVERS, and the Gazette disk:
                 TOOLKIT, Icon Edit, Patcher, GEOSTRIPPER, geoPattern and the
                 six articles                                  1765 blocks free
C  GEOSDSK3.D81  GeoTerm64 2.0 + GeoTerm.Doc, geoTheo + geoTheo.dat + its 3
                 documents, geoDiary + diary.Mar92, Calendar, CONVERT
                                                               1570 blocks free

Left out: geoTelnet 1.3 (it hangs at a blank screen: it needs a modem or
network cartridge the X16 doesn't have) and its source files.
geoDiary is an auto-start program: if disk C is ever used as drive A,
geoDiary opens by itself at every boot.

Tested in x16emu R49: all three boot together; CardFile, Calendar,
GeoTerm64, geoTheo, TOOLKIT and geoDiary open.

These disks hold your own copies of commercial GEOS software: they're for
your use, not for posting.
