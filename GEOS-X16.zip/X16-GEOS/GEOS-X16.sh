#!/bin/sh
# GEOS 2.0 for the Commander X16 in x16emu R49, on Linux or macOS: what
# GEOS-X16.bat does on Windows.  With GEOSX16SD.img in this folder (an SD
# card image with GEOS-X16's files on it) GEOS runs from that image, as from
# a real X16's SD card: the high-bandwidth (SPI) videos only play this way.
# Without it, or started as "./GEOS-X16.sh folder", GEOS uses the files in
# this folder itself.  geosx16.bin always stays in this folder.
# x16emu (with its rom.bin) is looked for in this folder, the one above it,
# then on the PATH; or set X16EMU to its full path.
# Ctrl+M in the emulator window releases (and recaptures) the mouse.
cd "$(dirname "$0")" || exit 1
if [ -z "$X16EMU" ]; then
  if [ -x ./x16emu ]; then X16EMU=./x16emu
  elif [ -x ../x16emu ]; then X16EMU=../x16emu
  elif command -v x16emu >/dev/null 2>&1; then X16EMU=x16emu
  else echo "Cannot find x16emu. Put it in this folder or set X16EMU."; exit 1
  fi
fi
if [ "$1" != folder ] && [ -f GEOSX16SD.img ]; then
  exec "$X16EMU" -cartbin geosx16.bin -sdcard GEOSX16SD.img -rtc -scale 2 -capture "$@"
fi
[ "$1" = folder ] && shift
if [ ! -f GEOSDISK.D64 ] && [ ! -f GEOSDISK.D81 ]; then
  echo "GEOSDISK.D64 or GEOSDISK.D81 is missing: put a GEOS 2.0 disk image with DESK TOP in this folder under one of those names."; exit 1
fi
exec "$X16EMU" -cartbin geosx16.bin -rtc -scale 2 -capture "$@"
