@echo off
rem GEOS 2.0 for the Commander X16, in x16emu R49
rem
rem With GEOSX16SD.img in this folder (an SD card image with GEOS-X16's files
rem on it: GEOSDISK.D64 or .D81, the other disks, VIDKIT-A000.BIN, videos),
rem GEOS runs from that image, as from a real X16's SD card; the
rem high-bandwidth (SPI) videos only play this way.  Without it, or started
rem as "GEOS-X16.bat folder", GEOS uses the files in this folder itself:
rem geosx16.bin, GEOSDISK.D64 or .D81 (drive A) and the rest.
rem geosx16.bin always stays in this folder.  x16emu.exe (with its rom.bin)
rem is looked for in this folder and the one above it; or set X16EMU to its
rem full path.
setlocal
cd /d "%~dp0"
if not defined X16EMU if exist "%~dp0x16emu.exe" set "X16EMU=%~dp0x16emu.exe"
if not defined X16EMU if exist "%~dp0..\x16emu.exe" set "X16EMU=%~dp0..\x16emu.exe"
if not defined X16EMU (
  echo Cannot find x16emu.exe. Put this folder next to x16emu.exe, inside
  echo the x16emu folder, or set X16EMU in this file.
  pause
  exit /b 1
)
rem Ctrl+M in the emulator window releases (and recaptures) the mouse.
if /i "%~1"=="folder" goto folder
if not exist GEOSX16SD.img goto folder
"%X16EMU%" -cartbin geosx16.bin -sdcard GEOSX16SD.img -rtc -scale 2 -capture %*
exit /b
:folder
if not exist GEOSDISK.D64 if not exist GEOSDISK.D81 (
  echo GEOSDISK.D64 or GEOSDISK.D81 is missing: put a GEOS 2.0 disk image
  echo with DESK TOP in this folder under one of those names.
  pause
  exit /b 1
)
"%X16EMU%" -cartbin geosx16.bin -rtc -scale 2 -capture
