/* net_x16.c - network driver for GEOS-X16 (geoChat X16): the X16's serial port through GEOS-X16's calls
 * (x16io.s), with a modem that takes AT commands on the other side. That is TexElec's card (its ESP32 WiFi
 * modem, Zimodem) or the Calypso (GEOS-X16 plays the modem), whichever GEOS-X16 is set up for (GEOSSER.CFG).
 * Both dial a server by name: ATDT then host:port, answered with CONNECT (or NO CARRIER, BUSY, ERROR,
 * NO ANSWER). The line is hung up with +++ (a second of quiet on each side) and ATH. NO CARRIER at the start
 * of a line while connected means the modem lost the connection.
 */
#include <string.h>
#include "net.h"

unsigned char x16_present(void);
void s_open(void);
void s_close(void);
void __fastcall__ s_put(unsigned char c);
int s_get(void);
void __fastcall__ frames(unsigned char n);

static unsigned char online;                /* 1 = connected */
static unsigned char gone;                  /* 1 = the modem said NO CARRIER: the next read reports it */
static unsigned char bol = 1;               /* at the start of a line (for NO CARRIER) */
static unsigned char nc;                    /* characters of NO CARRIER matched so far */
static const char nocarr[] = "NO CARRIER";

static void put_s(const char *s)
{
    while (*s) s_put(*s++);
}

unsigned char net_probe(void)
{
    return x16_present() ? 0 : 1;
}

/* a line from the modem into ln (CR/LF dropped); 0 = none within 'secs' seconds */
static char ln[48];
static unsigned char modem_line(unsigned char secs)
{
    unsigned char n = 0, f = 0;
    int c;
    for (;;) {
        c = s_get();
        if (c < 0) {
            frames(1);
            if (++f == 60) {
                f = 0;
                if (secs-- == 0) return 0;
            }
            continue;
        }
        if (c == '\r' || c == '\n') {
            if (n) { ln[n] = 0; return 1; }
            continue;
        }
        if (n < sizeof(ln) - 1) ln[n++] = c;
    }
}

static unsigned char starts(const char *w)
{
    return strncmp(ln, w, strlen(w)) == 0;
}

unsigned char net_connect(const char *host, unsigned port)
{
    char num[6];
    unsigned char i = 5;
    online = gone = 0;
    s_open();
    put_s("\rAT\r");
    while (modem_line(1)) ;                 /* the echo, OK: whatever comes within a second */
    num[5] = 0;
    do { num[--i] = '0' + port % 10; port /= 10; } while (port);
    put_s("ATDT");
    put_s(host);
    s_put(':');
    put_s(num + i);
    s_put('\r');
    while (modem_line(30)) {                /* 30 seconds for an answer */
        if (starts("CONNECT")) {
            online = 1;
            bol = 1;
            nc = 0;
            return 0;
        }
        if (starts("NO CARRIER") || starts("BUSY") || starts("ERROR") || starts("NO ANSWER")) break;
    }
    s_close();
    return 1;
}

int net_read(char *buf, unsigned max)
{
    unsigned n = 0;
    int c;
    if (!online) return -1;
    if (gone) { net_close(); return -1; }
    while (n < max) {
        c = s_get();
        if (c < 0) break;
        buf[n++] = c;
        if (c == '\r' || c == '\n') { bol = 1; nc = 0; continue; }
        if (bol && c == nocarr[nc]) {
            if (++nc == sizeof(nocarr) - 1) { gone = 1; break; }
        } else {
            bol = 0;
            nc = 0;
        }
    }
    return (int)n;
}

unsigned char net_write(const char *buf, unsigned len)
{
    if (!online) return 1;
    while (len--) s_put(*buf++);
    return 0;
}

void net_close(void)
{
    if (!online) return;
    online = 0;
    if (!gone) {
        frames(70);                         /* +++ with a second of quiet before and after: command mode */
        put_s("+++");
        frames(70);
        put_s("ATH\r");
        frames(15);
    }
    gone = 0;
    s_close();
}

/* no clock from the network: GEOS-X16 keeps GEOS's time from the X16's own real-time clock */
unsigned char net_time(char *buf)
{
    (void)buf;
    return 1;
}

/* no way to ask the modem: say yes, so a failure reads "Connection failed." */
unsigned char net_ip(void)
{
    return 0;
}
