; x16io.s - GEOS-X16's calls for geoChat X16 (ca65, cc65 calling conventions)
;
; The serial port is GEOS-X16's (calls 2-6, inc/geosx16.inc in the GEOS-X16 tree): TexElec's card (its
; ESP32 WiFi modem) or the Calypso, whichever GEOSSER.CFG names; both answer AT commands.
;
;   unsigned char x16_present(void)          1 = GEOS-X16 version 5 or more ("X16G" at $FF78)
;   void s_open(void)                         the serial port, at the speed geoTelnet uses (code 5)
;   void s_close(void)
;   void __fastcall__ s_put(unsigned char)
;   int s_get(void)                           a byte, or -1 when none is waiting
;   void __fastcall__ frames(unsigned char n) wait n frames (1/60 s each: GEOS's dblClickCount, counted
;                                              down by its interrupt)
;   void beep(void)                           the "ding": a short falling note on VERA's PSG (voice 15)

        .setcpu "65C02"
        .export _x16_present, _s_open, _s_close, _s_put, _s_get, _frames, _beep

X16_SIG       = $FF78
X16_VER       = $FF7C
X16_CALL      = $FF7D
X16C_SOPEN    = 2
X16C_SCLOSE   = 3
X16C_SPUT     = 4
X16C_SGET     = 5
dblClickCount = $8515

VERA_ADDR_L   = $9F20
VERA_ADDR_M   = $9F21
VERA_ADDR_H   = $9F22
VERA_DATA0    = $9F23
VERA_CTRL     = $9F25
PSG15         = $F9FC           ; VRAM $1F9FC: PSG voice 15 (frequency lo, hi, volume, waveform)

        .code

_x16_present:
        ldx #3
@s:     lda X16_SIG,x
        cmp sig,x
        bne @no
        dex
        bpl @s
        lda X16_VER
        cmp #5
        bcc @no
        lda #1
        ldx #0
        rts
@no:    lda #0
        tax
        rts
sig:    .byte "X16G"

_s_open:
        ldx #5
        lda #X16C_SOPEN
        jmp X16_CALL

_s_close:
        lda #X16C_SCLOSE
        jmp X16_CALL

_s_put:
        tax
        lda #X16C_SPUT
        jmp X16_CALL

_s_get:
        lda #X16C_SGET
        jsr X16_CALL
        bcs @none
        ldx #0
        rts
@none:  lda #$FF
        tax
        rts

_frames:
        sta dblClickCount
@w:     lda dblClickCount
        bne @w
        rts

; ---- the ding: about 1 kHz (frequency word = Hz / 0.3725), triangle, both sides; volume 63 then down to 0
; over a few frames.  VERA's address registers are put back as they were (GEOS-X16 uses them too).
_beep:
        lda #63
        jsr psg
        lda #2
        jsr _frames
        lda #40
        jsr psg
        lda #2
        jsr _frames
        lda #20
        jsr psg
        lda #3
        jsr _frames
        lda #8
        jsr psg
        lda #3
        jsr _frames
        lda #0
psg:    php                     ; volume A
        sei
        pha
        lda VERA_CTRL
        pha
        stz VERA_CTRL
        lda VERA_ADDR_L
        pha
        lda VERA_ADDR_M
        pha
        lda VERA_ADDR_H
        pha
        lda #<PSG15
        sta VERA_ADDR_L
        lda #>PSG15
        sta VERA_ADDR_M
        lda #$11                ; VRAM $1xxxx, step 1
        sta VERA_ADDR_H
        lda #<2684
        sta VERA_DATA0
        lda #>2684
        sta VERA_DATA0
        tsx
        lda $0105,x             ; the volume (pushed first)
        ora #$C0                ; left and right
        sta VERA_DATA0
        lda #$80                ; triangle
        sta VERA_DATA0
        pla
        sta VERA_ADDR_H
        pla
        sta VERA_ADDR_M
        pla
        sta VERA_ADDR_L
        pla
        sta VERA_CTRL
        pla
        plp
        rts
