#!/bin/sh
# geoChat X16: geoChat 128 (github.com/djcarlin/geochat128, MIT) for GEOS-X16, the X16's serial port
# (TexElec's card or the Calypso) in place of the Ultimate.  Needs cc65 2.19 (cl65, grc65) and python3.
#   ./build.sh                  -> build/geochatx16.cvt
#   ./build.sh DISK.D81 [SLOT]  -> and onto that GEOS disk image (../../tools/geosimg.py)
# Build-time defaults for the settings page: NICK=you CHAN='#chan' SERVER=host ./build.sh
set -e
cd "$(dirname "$0")"
mkdir -p build
NICK=${NICK:-}
CHAN=${CHAN:-#c64friends}
SERVER=${SERVER:-irc.libera.chat}
grc65 -t geos-cbm -s build/res.s src/res.grc
cl65 -t geos-cbm -O -C src/geochat128.cfg -DDEF_NICK="\"$NICK\"" -DDEF_CHAN="\"$CHAN\"" -DDEF_SERVER="\"$SERVER\"" \
  -m build/geochatx16.map -Ln build/geochatx16.lbl -o build/geochatx16.cvt build/res.s \
  src/main.c src/ui.c src/store.c src/settings.c src/irc.c src/fmt.c src/fastline.c src/hw.s src/fastdraw.s \
  src/net_x16.c src/x16io.s
python3 tools/seticon.py build/geochatx16.cvt
echo "build/geochatx16.cvt: $(wc -c < build/geochatx16.cvt) bytes"
if [ -n "$1" ]; then
  python3 ../../tools/geosimg.py rm "$1" "geoChat X16" >/dev/null 2>&1 || true
  python3 ../../tools/geosimg.py cvt "$1" build/geochatx16.cvt
  if [ -n "$2" ]; then python3 ../../tools/geosimg.py slot "$1" "geoChat X16" "$2"; fi
fi
