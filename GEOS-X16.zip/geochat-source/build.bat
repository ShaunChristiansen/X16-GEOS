@echo off
rem geoChat X16: geoChat 128 (github.com/djcarlin/geochat128, MIT) for GEOS-X16.
rem Needs cc65 2.19 (cl65, grc65 on the PATH) and Python 3 (python on the PATH).
rem   build.bat                  -> build\geochatx16.cvt
rem   build.bat DISK.D81 [SLOT]  -> and onto that GEOS disk image
rem Settings page defaults: set NICK=you, set CHAN=#chan, set SERVER=host before running.
setlocal
cd /d "%~dp0"
if not exist build mkdir build
if "%CHAN%"=="" set CHAN=#c64friends
if "%SERVER%"=="" set SERVER=irc.libera.chat
grc65 -t geos-cbm -s build\res.s src\res.grc || exit /b 1
cl65 -t geos-cbm -O -C src\geochat128.cfg -DDEF_NICK="\"%NICK%\"" -DDEF_CHAN="\"%CHAN%\"" -DDEF_SERVER="\"%SERVER%\"" -m build\geochatx16.map -Ln build\geochatx16.lbl -o build\geochatx16.cvt build\res.s src\main.c src\ui.c src\store.c src\settings.c src\irc.c src\fmt.c src\fastline.c src\hw.s src\fastdraw.s src\net_x16.c src\x16io.s || exit /b 1
python tools\seticon.py build\geochatx16.cvt || exit /b 1
echo build\geochatx16.cvt built.
if "%~1"=="" goto :eof
python ..\..\tools\geosimg.py rm "%~1" "geoChat X16" >nul 2>&1
python ..\..\tools\geosimg.py cvt "%~1" build\geochatx16.cvt || exit /b 1
if not "%~2"=="" python ..\..\tools\geosimg.py slot "%~1" "geoChat X16" %2
