# geoChat X16

geoChat 128 by David Carlin (https://github.com/djcarlin/geochat128, MIT licence: `LICENSE`), an IRC client
for GEOS 128 in 80 columns, ported to GEOS-X16 (GEOS 128 on the Commander X16). Upstream version: see
`UPSTREAM.txt`. Upstream's own documentation is in `README.md`; this file says what changed.

## What changed for the X16

| Upstream (C128) | geoChat X16 |
|---|---|
| Network: the Ultimate 1541 II+'s Command Interface (`src/net_uci.c`) | `src/net_x16.c`: the X16's serial port through GEOS-X16's calls 2-5 (`src/x16io.s`), with a modem on the other side that takes AT commands: TexElec's card (its ESP32 WiFi modem) or the Calypso (GEOS-X16 plays the modem), whichever GEOSSER.CFG names. `ATDT host:port`, CONNECT; hung up with `+++` and `ATH`; NO CARRIER at the start of a line means the line was lost (geoChat then reconnects by itself, as upstream does). |
| Clock from the Ultimate's RTC into CIA 1's time-of-day clock | Not needed: GEOS-X16 runs GEOS's clock from the X16's RTC (`net_time` says "none"; `tod_set` does nothing). |
| The "ding": SID voice 1 | VERA's PSG, voice 15 (`x16io.s`). |
| 64 KB VDC window cache (`vc_detect`) | Off: GEOS-X16 keeps the VDC's RAM in VERA's, and VDC RAM above $6000 holds GEOS-X16's own copy of the screen for the 80-column wallpaper and colour. |
| `test_result` ($D7FF, VICE) | Does nothing: $D000-$DFFF is GEOS-X16 kernel code. |
| ESC | ESC or the X16's Esc key (GEOS-X16 gives it as the C64's RUN/STOP, KEY_STOP). |
| Name "geoChat 128", settings file "geoChat 128 cfg" | "geoChat X16", "geoChat X16 cfg"; the about box credits geoChat 128 and David Carlin. |

Unchanged: everything else, including the VDC drawing code (`src/hw.s`, `src/fastdraw.s`): GEOS-X16 turns a
GEOS 128 program's own VDC accesses into its VDC emulation as the program loads (helper.s H_VdcPatch), which
keeps the 80-column wallpaper and colour copies up to date. The scrollback lives in GEOS's RAM expansion,
which GEOS-X16 provides from the X16's banked RAM.

Not built here: upstream's self-test (`src/agent.c`, `src/net_mbox.c`, `tools/vtest.py`: VICE x128) and boot
disk tools. The GEOS-X16 test is `test_x16_128_geochat.sh` (TexElec and Calypso, through the test x16emu and
`tools/fakeirc.py`).

## Building

Needs cc65 2.19 (`cl65`, `grc65`) and Python 3.

    ./build.sh                       (Windows: build.bat)  -> build/geochatx16.cvt
    ./build.sh GEOS128A.D81 4        and onto a GEOS disk image, in directory slot 4

`NICK=you CHAN='#chan' SERVER=host ./build.sh` changes the settings page's defaults.
