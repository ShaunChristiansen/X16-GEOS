Gridrunner (HES, 1982, Jeff Minter) on C64-X16
==============================================

Fly the Gridrunner along the bottom of the Grid and shoot the droid squads
snaking down towards you.  A droid you hit turns into a pod, which sits on
the Grid and grows.  Pods block your way, so shoot them too.  The X and Y
zappers patrol the Grid's edges, and their beams are deadly.

Starting
--------
Pick GRIDRUNNER (its number) at the cartridge's menu.  The cartridge uses
the original 8K cartridge: Gridrunner.crt, or its ROM as an 8K .bin.  Put
either in the folder (or a folder inside it) and the first start copies
the game in as GRIDRUNNER.PRG.  (The tape version - GRIDRUNNER-8000 and
the "(J1)" files - has different code, and this patch doesn't fit it.)

At the title screen, push the joystick up to start on a later grid (the
"ENTER LEVEL" number goes up by one each push), then press fire to begin.

The joystick (port 1)
---------------------
On the X16:  the cursor keys move, Ctrl, Alt or Space fire.  An SNES game
pad works too.  (F12 switches the keys-as-joystick off and on.)

  joystick         move (along the bottom seven lines of the Grid)
  fire             shoot; hold it down to keep shooting

The keys
--------
  P                pause; P again to carry on

Scoring (from the original instructions)
----------------------------------------
  a pod                          10
  a droid in a squad            100
  a squad's leader droid        400
  a whole gridful of droids     an extra Gridrunner

Speed
-----
The same as a PAL C64's: checked against the VICE emulator, a minute of
the same game takes the same time on both, to within half a percent.
