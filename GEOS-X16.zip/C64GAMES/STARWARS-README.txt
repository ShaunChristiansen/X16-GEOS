Star Wars (Domark, 1988, written by Vektor Grafix) on C64-X16
=============================================================

The home version of Atari's 1983 arcade game: you fly Red Five against
the Death Star, in wire-frame 3D.  Each wave has three parts: shoot the
TIE fighters and their fireballs in space, fly over the Death Star's
surface past the laser towers and bunkers, then down the trench to hit
the exhaust port.

Starting
--------
Pick STARWARS (its number) at the cartridge's menu.  The loading picture
stays for ten seconds, or until you press fire or a key.  Then comes the
speech ("The Force will be with you... always") and the title screens.

  fire                 start a game
  joystick + fire      on the "SELECT A DEATH STAR" screen: move the
                       cursor onto a Death Star and fire - wave 1
                       (easy), wave 3 (medium) or wave 5 (hard, with a
                       bonus)

The joystick (port 2)
---------------------
On the X16:  the cursor keys move, Ctrl, Alt or Space fire.  An SNES game
pad works too.  (F12 switches the keys-as-joystick off and on.)

  joystick             moves the cross-hair
  fire                 fires the lasers at the cross-hair

The keys
--------
  Esc  (RUN/STOP)      pause ("GAME PAUSED"); Esc again to carry on
  Q                    give up the game

Playing
-------
 - Your shield takes nine hits (the number at the top).  A fireball that
   reaches you costs one; so does hitting a tower or the trench's
   catwalks.
 - Shoot fireballs before they reach you.
 - The game's own instructions and its score table come up on the title
   screens if you wait.

Practice version
----------------
If you can't get past the TIE fighters: the practice folder has a patch
file with a shield that is never used up.  See practice/README.txt.

What isn't right yet
--------------------
 - Speed: a whole wave has been played on the X16 now - TIE
   fighters, towers, trench, "exhaust port missed" and round again, the
   Death Star's end, the bonus and the start of wave 2 - and so have
   game over, the title pages after it and a new game.  All look right.
   Against a C64 (measured in VICE) the TIE fighters run at about 98%,
   the towers at about 94%, the trench at 90-95%.  It is a slow game on
   a C64 too: four or five pictures a second.  When your shield is hit
   and the screen flashes, it drops for a fraction of a second.
 - Entering your name in the high score table has not been tried (it
   takes 380,000 points).
