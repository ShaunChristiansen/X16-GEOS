Impossible Mission (Epyx, 1984) on C64-X16
==========================================

The evil Elvin Atombender is about to launch a nuclear strike. You have
six hours (12:00 to 6:00 on the game clock) to search his rooms for the
pieces of the password puzzle, put them together on your pocket computer
and reach his control room.  Avoid his robots, and don't fall.

Starting
--------
Pick IMPOSSIBLEMISSION (its number) at the cartridge's menu.  At the
game's title screen, press fire.

The joystick (port 2)
---------------------
On the X16:  the cursor keys move, Ctrl, Alt or Space fire.  An SNES game
pad works too.  (F12 switches the keys-as-joystick off and on.)

In the lift (the corridors between the rooms):
  up / down      ride the lift up or down
  left / right   walk along the corridor; walk off the screen's edge to
                 go into a room
  fire           the pocket computer (only here, not in a room)

In a room:
  left / right   run
  fire           somersault (jump over robots and gaps in the floor)
  up / down      on a striped lifting platform: raise or lower it
  up             in front of a piece of furniture: search it.  Keep
                 holding up until the bar runs out.  You may find a
                 puzzle piece, a password (snooze the robots, or reset
                 the lifting platforms), or nothing.  Leaving the room
                 before the bar ends means starting that search again.
  up             in front of a security terminal: use it, then choose
                 with the joystick and press fire

The pocket computer
-------------------
Move the glove with the joystick and press fire to pick puzzle pieces up,
put them down, turn them over and fit them together.  Asking for help
costs you time on the clock.
