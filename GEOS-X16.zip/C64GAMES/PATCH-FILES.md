# Patch files for the C64-X16 cartridge

A C64 game can't run on the X16 untouched. The X16 has its own I/O chips at
`$9F00-$9FFF`, uses `$00` and `$01` to switch memory banks, and keeps
interrupt entries in page 3, and the cartridge has no real VIC-II, CIA or
SID chips for a game to read. A patch file lists the small changes one game
needs. The cartridge loads `NAME.PAT` next to `NAME.PRG` and makes the changes
before the game starts.

Each `NAME.txt` here is the readable source of a `NAME.PAT`. To build one:

    python3 tools/mkpat.py patches/NAME.txt patches/NAME.PAT

or run `build-patches.bat` (Windows) or `build-patches.sh` (Linux) to build
them all.

## A quick example

    prg 64750 69CD7F5E                  # the game file's size and CRC-32
    flags keyjoy                        # options
    start jmp 033C                      # how the game starts

    ram 8E0E: LDA $D012 -> JSR lda_d012

The last line says: at `$8E0E` the game has `LDA $D012` (read the raster
line). Put `JSR lda_d012` there instead, which calls the cartridge's helper
that gives the line a real C64 would be on at that moment.

The cartridge checks the game file's size and CRC-32 first, then every
`ram` line's old bytes, so a patch can only be used on the exact file it
was made for.

## The lines

| Line | What it does |
|---|---|
| `prg SIZE CRC32` | The game file: its size in bytes (decimal) and its CRC-32 (hex). |
| `flags NAME ...` | Options, see below. Several `flags` lines add up. |
| `memtop HH` | BASIC's top of memory, high byte (default `9F`). |
| `start ready` | Start at BASIC's READY prompt. |
| `start run` | Type RUN. |
| `start jmp ADDR` | Jump to ADDR, with the C64's ROMs in. |
| `start norom ADDR` | Jump to ADDR with all 64K as RAM: no BASIC, no KERNAL; the game has its own vectors at `$FFFA-$FFFF`. |
| `unpack exo2 R1 L1 R2 INIT T` | The file is an Exomizer 2 self-extractor; the cartridge unpacks it first. (The numbers say where the packed data is in the file.) |
| `ram ADDR: OLD -> NEW` | The game's bytes at ADDR must be OLD (checked); they become NEW. Both sides must be the same length. |
| `rom ADDR: OLD -> NEW` | The same in BASIC (`$A000`) or the KERNAL (`$E000`). |
| `poke ADDR: BYTES` | Bytes put into the game's memory, nothing checked. |
| `code ADDR` ... `end` | Assembly language put at ADDR (see below). |
| `copy DST SRC LEN` | A block copied inside the game's memory. |
| `chrcopy DST OFS LEN` | Bytes of the C64's character ROM, from offset OFS, into the game's memory. |
| `fill ADDR LEN BYTE` | LEN bytes of BYTE. |
| `io ADDR: BYTES` | Starting values of I/O registers (`$D000-$DFFF`). |
| `NAME = VALUE` | A name for a number, to use in the assembly (`$` for hex). |

The lines are carried out in their order, after the unpacking, and the
order can matter: a `copy` takes the bytes as they are at that point, with
any changes made above it.

Addresses, lengths and byte values in these lines are hex, with or without
`$`. A comment starts with `# ` (a hash and a space) or with `;`. A long
line can continue on the next: end it with `\`.

## Bytes and instructions

`OLD`, `NEW` and `BYTES` can be hex bytes, 65C02 instructions, or a mix,
separated by spaces. A `/` between instructions is only there to make the
line easier to read:

    ram 6022: STA $01 -> NOP / NOP
    ram 629C: LDA $D011 / BPL $629C -> JSR bwset / NOP / NOP
    ram AAFF: 02 -> C0

- A branch gives its target address (`BPL $629C`), not an offset.
- An operand with 1 or 2 hex digits is zero page (`LDA $D0`); with 3 or 4,
  absolute (`LDA $00D0`).
- `JSR name` or `JMP name` with a helper's name calls the cartridge (see
  "The helpers" below).
- Plain hex bytes are still needed where a change is only part of an
  instruction, like the high byte of an address (`ram 8368: 9F -> C4`).
  The comment next to such a line says which instruction it belongs to.

## Code blocks

New routines are written as assembly, between `code ADDR` and `end`:

    code C900
    speech_wait:
            JSR lda_d012            ; a hook: the NMIs due are delivered here
            LDA #$FF
            JMP $F080
    end
    ram 8E29: JSR $F080 -> JSR speech_wait

- One instruction per line; `name:` starts a label. Labels can be used
  anywhere in the file, in `ram` and `poke` lines too, before or after
  their block. Names are 3 letters or more, and not something that looks
  like a hex number.
- A line that starts with `:` is an unnamed label. `:+` means the next
  one, `:-` the last one (`:++` the one after the next, and so on).
- `.byte` and `.word` give data: `.byte $24`, `.word $9F2C`.
- Operands can use names, `name+1`, `<name` and `>name` (low and high
  byte), `*` (this instruction's address) and decimal numbers.
- `a:` forces an absolute address (`LDA a:$D0`), `z:` zero page.

`mkpat.py` refuses code that lands on the bytes of an earlier `poke` or
`code` line, and a branch that is too far.

## Flags

| Flag | Meaning |
|---|---|
| `keyjoy` | The cursor keys, Ctrl, Alt and Space are the joystick (F12 switches this at any time). |
| `keypos` | Each key is the C64 key in the same place, for games that go by the keys' places (F11 switches this). |
| `joy1` | The joystick is in port 1 (read through `$DC01`). |
| `ntsc` | An NTSC C64: 263 lines of 65 cycles, 60 frames a second. |
| `v2` | Use the newer runtime. Without it, the proven one. |
| `topsync` | (v2) The screen's rows are read early in the frame, before its first raster interrupt: for a game that scrolls its screen behind the raster, ready by the next frame. |
| `flip` | (v2) A text screen's rows go into a second screen map, shown at the start of their frame: scrolling at a third of the cost. |
| `quick` | (v2) A change of screen shows at once. |
| `nohold` | (v2) A screen change's redraw doesn't hold back the backgrounds. |
| `blank` | (v2) A text screen's whole redraw happens with its layer switched off. |
| `hooksync` | (v2) The screen's rows are read when the patch says so (`lnote` with A = 2-5), not when the cartridge chooses. |
| `catchup` | (v2, with `ntsc`) A raster interrupt whose line the game wrote after the line it was at, but which the cartridge's own work has let go by, comes at once, in its own frame - as it would on a C64 that ran only the game - instead of a frame late. The same for a wait for such a line, and for the next frame's first line set at a frame's end. (The experimental cartridge only.) |
| `halfscreen` | (v2, with `ntsc`) The cartridge's screen work - the display list and the screen's copy - is done every other game frame only, and the frame in between is the game's alone: the game runs faster (Pitstop II's race about 30 frames a second instead of 24) and the picture moves in steps of two frames. The display list is still played every frame, so the split screen stays where it is. (The experimental cartridge only.) |

## The helpers

A patch calls the cartridge with `JSR name` (or `JMP name`) in place of the
instructions in the second column. Each helper does what those instructions
would do on a C64, using the cartridge's model of the C64's chips.

| Helper | Replaces | What it does |
|---|---|---|
| `lda_d012` | `LDA $D012` | The raster line the C64 would be on now. |
| `cmp_d012`, `cpx_d012`, `cpy_d012`, `eor_d012` | `CMP`, `CPX`, `CPY`, `EOR $D012` | The same, compared or combined. |
| `lda_d011` | `LDA $D011` | `$D011` with bit 7 as the raster line's ninth bit now. |
| `wset` | `LDA $D011 / AND #$80 / BEQ back` | Waits for line 256: the C64's clock moves straight on to it. |
| `wclr` | `LDA $D011 / AND #$80 / BNE back` | Waits for the end of the frame, the same way. |
| `bwset`, `bwclr` | `BIT $D011 / BPL` (or `BMI`) `back` | The same, for the BIT form. |
| `d01e_rd`, `d01f_rd` | `LDA $D01E`, `LDA $D01F` | The sprite-sprite and sprite-background collisions, worked out at the read. Use these where the game uses the answer. |
| `d01e_clr`, `d01f_clr` | `LDA $D01E`, `LDA $D01F` | A read that only clears the register (its answer isn't used), which is quicker. |
| `d01e_bit` | `BIT $D01E` | The same as `d01e_rd`, for BIT. |
| `joy` | `LDA $DC00,X` | The joystick: X = 0 is port 2 (with the keyboard columns that port also drives), X = 1 is port 1. |
| `lda_dc00` | `LDA $DC00` | The joystick in port 2. |
| `lda_dc01`, `ldx_dc01`, `cmp_dc01` | `LDA`, `LDX`, `CMP $DC01` | The keyboard's rows for the columns selected in `$DC00`, and the joystick in port 1. |
| `basout` | `LDA #$26 / STA $01` | BASIC switched out (done with X16 RAM banks). |
| `basin` | `LDA #$27 / STA $01` | BASIC switched back in. |
| `sei` | `SEI` | The start of a long stretch with interrupts off. The C64's interrupt waits until the CLI; the X16's own go on (screen, keys, timing). |
| `cli_rts` | `CLI / RTS` | The end of such a stretch. |
| `sid1`, `sid2`, `sid3` | `STA $D404`, `$D40B`, `$D412` | A write to a voice's control register. The gate bit starts and stops a note; the helpers make sure every start and stop is heard, even a note switched off and on again before the sound is next updated. |
| `sidx`, `sidy` | `STA $D404,X`, `STA $D404,Y` | The same, for any voice. |
| `sid3x`, `sid3y` | `STX $D412`, `STY $D412` | The same, from X or Y. |
| `lnote` | (none) | Tells the cartridge about a register the patch has just written: A = its number (the low byte of `$D0xx`, e.g. `$21` the background, `$2E` sprite 7's colour, `$11` for `$D011`), Y = the raster line it holds from. Small values of A are requests instead, see below. lnote changes A and X; Y comes back as the line. |
| `file` | (none) | The KERNAL's LOAD (X = 0) or SAVE (X = 1), for a game with no C64 ROMs: the file is next to the cartridge. It takes the KERNAL's own zero-page variables: `$93` (0 = load, not verify), the name's length in `$B7` and address in `$BB/$BC`, the secondary address in `$B9` (1 = load to the file's own address, 0 = to `$C3/$C4`), and for a save the start in `$C1/$C2` and the end in `$AE/$AF`. Returns A = 0, or the KERNAL's error number. |

`lnote`'s requests:

| A | Request |
|---|---|
| 0 | All the screen registers, as they are now, hold from line Y. |
| 1 | The same, worked out right away. |
| 2 | Read the screen's rows now, for this frame (the rows that changed lately). |
| 3 | The same, looking at all the rows. |
| 4, 5 | As 2 and 3, for the frame before. |
| 6 | "This frame's rows and display list at its end": sent in every frame while it should hold (with `io D03D` bit 7). |
| 7 | Build the last frame's display list now (with `io D03D` bit 2). |
| `$24` | (band mode) Both multicolour registers at once from line Y: the patch puts `$D022` in the low four bits of `$D024` and `$D023` in the high four, then calls `lnote` with A = `$24`. Pitstop II's road stripes: 22 of them a frame. (The experimental cartridge only.) |

## The cartridge's own registers

Nothing sits at `$D02F-$D03F` on a C64, so the newer runtime reads settings
at `$D039-$D03F` (and keeps its band list at `$D02F-$D038`). A patch sets
them with an `io` line.

| Register | Meaning |
|---|---|
| `$D039` | (experimental cartridge) Band mode, for a multicolour text screen whose screen and character set (`$D018`) change at rows down the frame - Pitstop II's two views, each with its own sky, road and text line. Non-zero turns it on: each character set the frame uses has tiles of its own (eight places), switched at the rows their bands start. Its bits are the palette groups - cells of colour 8 + group - whose `$D022`/`$D023` the display list sets band by band (the other groups get the frame's first band's); bits 4-7 also take `lnote` A = `$24`. A band whose `$D011` has the extended-colour bit set (with multicolour on, a mode the VIC shows as black) is shown black. |
| `$D03A` | The empty character for the collision code (which skips empty cells), EOR `$20`. The default 0 means `$20`, a space. |
| `$D03B` | Bit 0: work each collision register out every other frame (the read in between gets the last answer). |
| `$D03D` | The display list. Bit 0: build it at the end of every frame. Bit 1: read the screen's rows at the frame's end too. Bit 2: allow `lnote` A = 7. Bit 7: bits 0 and 1 only while `lnote` A = 6 comes in every frame. Bit 3 is the screen's: a game that draws in two multicolour bitmaps in turn and shows the one that is ready (Star Wars). Each newly shown bitmap is compared with the last one and only what differs is drawn, instead of the whole picture. |
| `$D03E` | The screen window's last line (e.g. `$D8` = line 216 of 240); 0 = as normal. |
| `$D03F` | The first C64 line shown (e.g. `$28`: lines 40-279, for a game that uses the bottom border). |

## Why the patches move things

Some parts of a C64's memory are taken on the X16, so a game's code or
data there has to move:

- `$00` and `$01` are the X16's RAM and ROM bank registers. A game's
  writes to them (the 6510's port) go, or become `basout` / `basin`.
- `$9F00-$9FFF` is the X16's I/O. Code or data on that page moves
  somewhere free, and every address pointing into it changes.
- `$038B` and `$03B7` (in page 3) are the X16's interrupt entries. Game
  variables there move.
- The cartridge's own code sits where no chip is on a C64: `$D420`,
  `$DC10`, `$DD10`, `$DE00`, and (when the game has the ROMs) the KERNAL's
  tape routines.
- What a game keeps under BASIC, the KERNAL or the I/O area lives in X16
  RAM banks.

## Other versions of a game's file

The same game gets passed around in more than one form, and a patch fits
one exact file. `versions/` holds patches for other common forms of a game,
named `NAME-WHICH.txt`. Once the game is in memory its code is the same, so
each is the main patch with the `prg` line changed (and no `unpack` line
when the file is already unpacked):

- `GHOSTBUSTERS-memory-image.txt`: the 64,750-byte file that is the game's
  memory from `$0314` up.
- `GHOSTBUSTERS-statmat-cartridge.txt`: what the game finder takes out of
  Statmat's Ghostbusters cartridge (the `.crt`, or the same ROM as a 64K
  `.bin`).
- `STARWARS-statmat-cartridge.txt`: what the game finder takes out of
  Statmat's Star Wars cartridge. It is the game as the one-file version
  unpacks it, so the patch is the main one without its `unpack` line.
- `IMPOSSIBLEMISSION-memory-image.txt`: the 64,514-byte memory image
  (`$0400-$FFFF`). Statmat's cartridge holds exactly this file, so this
  patch fits the cartridge too.

A package puts the built patches in its own `versions/` folder, with the
main one as `NAME-one-file.PAT`, and the game finder copies whichever one
fits the file you have in as `NAME.PAT`. The cartridge only lists the
`.PAT` files next to it, so it never sees that folder.

Statmat's cartridges are the Magic Desk type: 8K banks at `$8000`, the
bank chosen by writing to `$DE00`. They start by copying ROM offsets
`$0400-$FFFF` to the same addresses in the C64's memory, then call the
game's own start-up and jump to its start. So ROM `$0400-$FFFF` is the
game, and the finder writes it out as a program file that loads at
`$0400`.

To make a version patch for another file of the same game: copy the main
patch, change the `prg` line to the new file's size and CRC-32 (and drop
`unpack` if it isn't packed), build it and try it. The cartridge checks
every `ram` line's old bytes, so it says straight away if that file's code
isn't the same.
