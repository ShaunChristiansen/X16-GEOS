Practice version of Star Wars: the shield is never used up
==========================================================
With this patch file a hit still flashes the screen, but the shield stays
at 9, so you can fly on to the towers, the trench and the Death Star's
end without being good at the game.

To use it:  copy this folder's STARWARS.PAT over the STARWARS.PAT next to
the cartridge (c64_x16.bin).  To go back to the real game, take
STARWARS.PAT from the zip again.

It is the same patch as the normal one with seven extra lines at its end
(STARWARS.txt in this folder is its readable text).  Not for high scores.
