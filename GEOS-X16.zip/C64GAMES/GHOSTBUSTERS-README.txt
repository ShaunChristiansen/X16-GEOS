Ghostbusters (Activision, 1984) on C64-X16
==========================================

Start a ghost-busting franchise in a haunted city: borrow the money, buy a
car and equipment, catch ghosts for cash, and keep the city's psychokinetic
energy down until you can get two Ghostbusters past the Marshmallow Man and
into the Zuul building.

Starting
--------
Pick GHOSTBUSTERS (its number) at the cartridge's menu.  At the title
screen, press F1 or F3 (the screen says so).  You'll be asked for your
name and whether you have an account: as a new customer you start with a
$10,000 loan; at the end of a good game you get an account number to
start with more money next time.

The joystick (port 1)
---------------------
On the X16:  the cursor keys move, Ctrl, Alt or Space fire.  An SNES game
pad works too.  (F12 switches the keys-as-joystick off and on.)

The keys
--------
On the X16, Esc is the C64's RUN/STOP.  The other keys are the same.

  RUN/STOP (Esc)   pause
  B                drop ghost bait (on the city map, when the Marshmallow
                   alert flashes - quickly, before he stomps a building)
  Space            status.  On the X16 Space is also a fire button: press
                   F12 to switch the keys-as-joystick off, then Space is
                   only the space bar (F12 again to switch back)

Buying your gear (the shop)
---------------------------
  1, 2, 3          the shop's three screens
  up / down        choose an item
  left / right     drive the forklift between the shelves and your car
  fire             pick an item up; fire again over the car to buy it
  E                leave the shop and start busting

The city map
------------
  joystick         move the Ghostbusters' sign and draw your route
  fire             go (the destination is set)

Driving
-------
  joystick         steer
  fire             the ghost vacuum (if you bought one) sucks up the
                   ghosts you drive past

Catching a ghost
----------------
  joystick         move a Ghostbuster
  fire             first press: put the trap down.  Then fire leaves this
                   Ghostbuster where he is and moves the other.  With both
                   in place the beams come on: herd the ghost over the
                   trap and press fire to spring it.

At the end, at the Zuul building, the joystick moves your Ghostbusters.
